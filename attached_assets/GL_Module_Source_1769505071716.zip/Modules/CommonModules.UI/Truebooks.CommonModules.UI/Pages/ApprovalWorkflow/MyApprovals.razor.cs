using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using MudBlazor;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace Web.Pages.ApprovalWorkflow;

public partial class MyApprovals : ComponentBase
{
    [Inject] private HttpClient Http { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;
    [Inject] private ISnackbar Snackbar { get; set; } = default!;
    [Inject] private NavigationManager Navigation { get; set; } = default!;

    private List<ApprovalRequestDto> _pendingApprovals = new();
    private List<ApprovalRequestDto> _myRequests = new();
    private List<UserDelegationDto> _delegations = new();
    private bool _isLoading = true;
    private bool _isProcessing = false;
    private int _activeTab = 0;
    private HashSet<ApprovalRequestDto> _selectedItems = new();
    private string _searchText = string.Empty;
    private string _statusFilter = "All";
    private bool _showDelegationDialog = false;
    private UserDelegationDto _newDelegation = new();
    private List<UserDto> _users = new();
    private DateTime? _delegationStartDate;
    private DateTime? _delegationEndDate;

    protected override async Task OnInitializedAsync()
    {
        await LoadData();
    }

    private async Task LoadData()
    {
        _isLoading = true;
        StateHasChanged();

        try
        {
            await SetAuthHeader();

            var pendingTask = Http.GetFromJsonAsync<List<ApprovalRequestDto>>("api/approval/pending");
            var myRequestsTask = Http.GetFromJsonAsync<List<ApprovalRequestDto>>("api/approval/my-requests");
            var delegationsTask = Http.GetFromJsonAsync<List<UserDelegationDto>>("api/approval/delegations");

            await Task.WhenAll(pendingTask, myRequestsTask, delegationsTask);

            _pendingApprovals = await pendingTask ?? new();
            _myRequests = await myRequestsTask ?? new();
            _delegations = await delegationsTask ?? new();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading data: {ex.Message}");
            Snackbar.Add("Failed to load approvals", Severity.Error);
        }
        finally
        {
            _isLoading = false;
            StateHasChanged();
        }
    }

    private async Task SetAuthHeader()
    {
        var token = await JS.InvokeAsync<string?>("localStorage.getItem", "authToken");
        var tenantId = await JS.InvokeAsync<string?>("localStorage.getItem", "tenantId");

        if (!string.IsNullOrEmpty(token))
        {
            Http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        if (!string.IsNullOrEmpty(tenantId))
        {
            Http.DefaultRequestHeaders.Remove("X-Tenant-Id");
            Http.DefaultRequestHeaders.Add("X-Tenant-Id", tenantId);
        }
    }

    private IEnumerable<ApprovalRequestDto> FilteredPendingApprovals
    {
        get
        {
            var query = _pendingApprovals.AsEnumerable();

            if (!string.IsNullOrEmpty(_searchText))
            {
                var searchLower = _searchText.ToLower();
                query = query.Where(a => 
                    (a.EntityCode?.ToLower().Contains(searchLower) ?? false) ||
                    (a.EntityDescription?.ToLower().Contains(searchLower) ?? false) ||
                    (a.RequesterName?.ToLower().Contains(searchLower) ?? false) ||
                    a.EntityType.ToLower().Contains(searchLower));
            }

            return query;
        }
    }

    private IEnumerable<ApprovalRequestDto> FilteredMyRequests
    {
        get
        {
            var query = _myRequests.AsEnumerable();

            if (!string.IsNullOrEmpty(_searchText))
            {
                var searchLower = _searchText.ToLower();
                query = query.Where(a => 
                    (a.EntityCode?.ToLower().Contains(searchLower) ?? false) ||
                    (a.EntityDescription?.ToLower().Contains(searchLower) ?? false) ||
                    a.EntityType.ToLower().Contains(searchLower));
            }

            if (_statusFilter != "All")
            {
                query = query.Where(a => a.Status == _statusFilter);
            }

            return query;
        }
    }

    private async Task ApproveSelected()
    {
        if (!_selectedItems.Any())
        {
            Snackbar.Add("Please select items to approve", Severity.Warning);
            return;
        }

        _isProcessing = true;
        StateHasChanged();

        var successCount = 0;
        var failCount = 0;

        try
        {
            await SetAuthHeader();

            foreach (var item in _selectedItems)
            {
                try
                {
                    var response = await Http.PostAsJsonAsync(
                        $"api/approval/{item.Id}/approve", 
                        new { Comments = "Bulk approved" });

                    if (response.IsSuccessStatusCode)
                    {
                        successCount++;
                    }
                    else
                    {
                        failCount++;
                    }
                }
                catch
                {
                    failCount++;
                }
            }

            if (successCount > 0)
            {
                Snackbar.Add($"Approved {successCount} request(s)", Severity.Success);
            }
            if (failCount > 0)
            {
                Snackbar.Add($"Failed to approve {failCount} request(s)", Severity.Warning);
            }

            _selectedItems.Clear();
            await LoadData();
        }
        finally
        {
            _isProcessing = false;
            StateHasChanged();
        }
    }

    private async Task ApproveItem(ApprovalRequestDto item)
    {
        _isProcessing = true;
        StateHasChanged();

        try
        {
            await SetAuthHeader();

            var response = await Http.PostAsJsonAsync(
                $"api/approval/{item.Id}/approve", 
                new { Comments = "" });

            if (response.IsSuccessStatusCode)
            {
                Snackbar.Add("Request approved", Severity.Success);
                await LoadData();
            }
            else
            {
                Snackbar.Add("Failed to approve", Severity.Error);
            }
        }
        catch (Exception ex)
        {
            Snackbar.Add($"Error: {ex.Message}", Severity.Error);
        }
        finally
        {
            _isProcessing = false;
            StateHasChanged();
        }
    }

    private async Task RejectItem(ApprovalRequestDto item)
    {
        _isProcessing = true;
        StateHasChanged();

        try
        {
            await SetAuthHeader();

            var response = await Http.PostAsJsonAsync(
                $"api/approval/{item.Id}/reject", 
                new { Comments = "" });

            if (response.IsSuccessStatusCode)
            {
                Snackbar.Add("Request rejected", Severity.Success);
                await LoadData();
            }
            else
            {
                Snackbar.Add("Failed to reject", Severity.Error);
            }
        }
        catch (Exception ex)
        {
            Snackbar.Add($"Error: {ex.Message}", Severity.Error);
        }
        finally
        {
            _isProcessing = false;
            StateHasChanged();
        }
    }

    private void ViewDocument(ApprovalRequestDto item)
    {
        if (!string.IsNullOrEmpty(item.ActionUrl))
        {
            Navigation.NavigateTo(item.ActionUrl);
        }
    }

    private void ShowNewDelegationDialog()
    {
        _newDelegation = new UserDelegationDto
        {
            StartDate = DateTime.Today,
            EndDate = DateTime.Today.AddDays(7),
            NotifyOnAction = true
        };
        _showDelegationDialog = true;
    }

    private async Task CreateDelegation()
    {
        if (_newDelegation.DelegateUserId == Guid.Empty)
        {
            Snackbar.Add("Please select a delegate", Severity.Warning);
            return;
        }

        _isProcessing = true;
        StateHasChanged();

        try
        {
            await SetAuthHeader();

            var response = await Http.PostAsJsonAsync("api/approval/delegation", new
            {
                DelegateUserId = _newDelegation.DelegateUserId,
                DelegateName = _newDelegation.DelegateName,
                StartDate = _newDelegation.StartDate,
                EndDate = _newDelegation.EndDate,
                EntityType = string.IsNullOrEmpty(_newDelegation.EntityType) ? null : _newDelegation.EntityType,
                Reason = _newDelegation.Reason,
                NotifyOnAction = _newDelegation.NotifyOnAction
            });

            if (response.IsSuccessStatusCode)
            {
                Snackbar.Add("Delegation created", Severity.Success);
                _showDelegationDialog = false;
                await LoadData();
            }
            else
            {
                Snackbar.Add("Failed to create delegation", Severity.Error);
            }
        }
        catch (Exception ex)
        {
            Snackbar.Add($"Error: {ex.Message}", Severity.Error);
        }
        finally
        {
            _isProcessing = false;
            StateHasChanged();
        }
    }

    private async Task RevokeDelegation(UserDelegationDto delegation)
    {
        try
        {
            await SetAuthHeader();

            var response = await Http.DeleteAsync($"api/approval/delegation/{delegation.Id}");

            if (response.IsSuccessStatusCode)
            {
                Snackbar.Add("Delegation revoked", Severity.Success);
                await LoadData();
            }
            else
            {
                Snackbar.Add("Failed to revoke delegation", Severity.Error);
            }
        }
        catch (Exception ex)
        {
            Snackbar.Add($"Error: {ex.Message}", Severity.Error);
        }
    }

    private Color GetStatusColor(string status)
    {
        return status switch
        {
            "Pending" => Color.Info,
            "InProgress" => Color.Warning,
            "Approved" => Color.Success,
            "Rejected" => Color.Error,
            "Returned" => Color.Secondary,
            "Cancelled" => Color.Dark,
            _ => Color.Default
        };
    }

    private string GetStatusIcon(string status)
    {
        return status switch
        {
            "Pending" => Icons.Material.Filled.HourglassEmpty,
            "InProgress" => Icons.Material.Filled.HourglassTop,
            "Approved" => Icons.Material.Filled.CheckCircle,
            "Rejected" => Icons.Material.Filled.Cancel,
            "Returned" => Icons.Material.Filled.Undo,
            "Cancelled" => Icons.Material.Filled.DoNotDisturb,
            _ => Icons.Material.Filled.Info
        };
    }

    public class ApprovalRequestDto
    {
        public Guid Id { get; set; }
        public string EntityType { get; set; } = string.Empty;
        public Guid EntityId { get; set; }
        public string? EntityCode { get; set; }
        public string? EntityDescription { get; set; }
        public decimal? Amount { get; set; }
        public string? Currency { get; set; }
        public Guid RequesterId { get; set; }
        public string? RequesterName { get; set; }
        public Guid? CurrentApproverId { get; set; }
        public string? CurrentApproverName { get; set; }
        public int CurrentStepNumber { get; set; }
        public int TotalSteps { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime? SubmittedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        public DateTime? DueDate { get; set; }
        public string? Notes { get; set; }
        public string? ActionUrl { get; set; }
    }

    public class UserDelegationDto
    {
        public Guid Id { get; set; }
        public Guid DelegatorUserId { get; set; }
        public string? DelegatorName { get; set; }
        public Guid DelegateUserId { get; set; }
        public string? DelegateName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string? EntityType { get; set; }
        public string? Reason { get; set; }
        public bool IsActive { get; set; }
        public bool NotifyOnAction { get; set; }
    }

    public class UserDto
    {
        public Guid Id { get; set; }
        public string? FullName { get; set; }
    }
}
