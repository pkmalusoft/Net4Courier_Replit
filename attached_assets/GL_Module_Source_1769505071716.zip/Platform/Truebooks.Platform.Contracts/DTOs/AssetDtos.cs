namespace Truebooks.Platform.Contracts.DTOs;

public record AssetCategoryDto(
    Guid Id,
    Guid TenantId,
    string Code,
    string Name,
    string? Description,
    string CategoryType,
    Guid? ParentCategoryId,
    bool IsActive,
    int SortOrder,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateAssetCategoryRequest(
    string Code,
    string Name,
    string? Description,
    int CategoryType,
    Guid? ParentCategoryId,
    int SortOrder = 0,
    bool IsActive = true
);

public record UpdateAssetCategoryRequest(
    string Code,
    string Name,
    string? Description,
    int CategoryType,
    Guid? ParentCategoryId,
    int SortOrder,
    bool IsActive
);

public record AssetDto(
    Guid Id,
    Guid TenantId,
    Guid CategoryId,
    string? CategoryName,
    string AssetCode,
    string Name,
    string? Description,
    string? SerialNumber,
    string? Make,
    string? Model,
    DateTime? PurchaseDate,
    decimal PurchasePrice,
    decimal CurrentValue,
    decimal DepreciationRate,
    string? Location,
    Guid? BranchId,
    string? BranchName,
    Guid? DepartmentId,
    string? DepartmentName,
    Guid? AssignedToUserId,
    string? AssignedToUserName,
    int Status,
    DateTime? WarrantyExpiryDate,
    DateTime? LastMaintenanceDate,
    DateTime? NextMaintenanceDate,
    string? Notes,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateAssetRequest(
    Guid CategoryId,
    string AssetCode,
    string Name,
    string? Description,
    string? SerialNumber,
    string? Make,
    string? Model,
    DateTime? PurchaseDate,
    decimal PurchasePrice,
    decimal CurrentValue,
    decimal DepreciationRate,
    string? Location,
    Guid? BranchId,
    Guid? DepartmentId,
    Guid? AssignedToUserId,
    int Status,
    DateTime? WarrantyExpiryDate,
    DateTime? LastMaintenanceDate,
    DateTime? NextMaintenanceDate,
    string? Notes,
    bool IsActive = true
);

public record UpdateAssetRequest(
    Guid CategoryId,
    string AssetCode,
    string Name,
    string? Description,
    string? SerialNumber,
    string? Make,
    string? Model,
    DateTime? PurchaseDate,
    decimal PurchasePrice,
    decimal CurrentValue,
    decimal DepreciationRate,
    string? Location,
    Guid? BranchId,
    Guid? DepartmentId,
    Guid? AssignedToUserId,
    int Status,
    DateTime? WarrantyExpiryDate,
    DateTime? LastMaintenanceDate,
    DateTime? NextMaintenanceDate,
    string? Notes,
    bool IsActive
);
