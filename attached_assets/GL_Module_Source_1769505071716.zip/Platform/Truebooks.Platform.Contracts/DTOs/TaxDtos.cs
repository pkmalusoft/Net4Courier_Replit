namespace Truebooks.Platform.Contracts.DTOs;

public record TenantNexusDto(
    Guid Id,
    Guid TenantId,
    string StateCode,
    string StateName,
    Guid? CountryId,
    Guid? StateId,
    Guid? CityId,
    Guid? PostalCodeId,
    DateTime EffectiveDate,
    bool IsActive,
    string? Notes
);

public record CreateTenantNexusRequest(
    string StateCode,
    string StateName,
    Guid? CountryId,
    Guid? StateId,
    Guid? CityId,
    Guid? PostalCodeId,
    DateTime EffectiveDate,
    bool IsActive,
    string? Notes
);

public record UpdateTenantNexusRequest(
    string StateCode,
    string StateName,
    Guid? CountryId,
    Guid? StateId,
    Guid? CityId,
    Guid? PostalCodeId,
    DateTime EffectiveDate,
    bool IsActive,
    string? Notes
);

public record USStateTaxRateDto(
    Guid Id,
    Guid TenantId,
    string StateCode,
    string StateName,
    decimal DefaultTaxRate,
    bool HasStateTax,
    bool IsActive
);

public record UpdateUSStateTaxRateRequest(
    decimal DefaultTaxRate,
    bool HasStateTax,
    bool IsActive
);

public record BulkUpdateUSStateTaxRateRequest(
    List<USStateTaxRateUpdateItem> Items
);

public record USStateTaxRateUpdateItem(
    Guid Id,
    decimal DefaultTaxRate,
    bool HasStateTax,
    bool IsActive
);

public record TaxExemptionCertificateDto(
    Guid Id,
    Guid TenantId,
    Guid CustomerId,
    string CustomerName,
    string CertificateNumber,
    string ExemptionType,
    string? IssuingState,
    Guid? CountryId,
    Guid? StateId,
    Guid? CityId,
    Guid? PostalCodeId,
    bool AppliesToAllStates,
    DateTime IssueDate,
    DateTime ExpirationDate,
    bool IsExpired,
    bool IsActive,
    string? Notes
);

public record CreateTaxExemptionCertificateRequest(
    Guid CustomerId,
    string CertificateNumber,
    string ExemptionType,
    string? IssuingState,
    Guid? CountryId,
    Guid? StateId,
    Guid? CityId,
    Guid? PostalCodeId,
    bool AppliesToAllStates,
    DateTime IssueDate,
    DateTime ExpirationDate,
    bool IsActive,
    string? Notes
);

public record UpdateTaxExemptionCertificateRequest(
    Guid CustomerId,
    string CertificateNumber,
    string ExemptionType,
    string? IssuingState,
    Guid? CountryId,
    Guid? StateId,
    Guid? CityId,
    Guid? PostalCodeId,
    bool AppliesToAllStates,
    DateTime IssueDate,
    DateTime ExpirationDate,
    bool IsActive,
    string? Notes
);
