using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.DTOs;

public record EmployeeDto(
    Guid Id,
    string EmployeeCode,
    string FirstName,
    string LastName,
    string FullName,
    string? Email,
    string? Phone,
    Guid? DepartmentId,
    string? DepartmentName,
    string? Designation,
    EmployeeType EmployeeType,
    PaymentType PaymentType,
    decimal? HourlyRate,
    decimal? MonthlySalary,
    bool IsActive,
    DateTime? JoiningDate
);

public record EmployeeDropdownDto(
    Guid Id,
    string FullName,
    string? Email,
    string? DepartmentName
);

public record CreateEmployeeRequest(
    string EmployeeCode,
    string FirstName,
    string? LastName,
    string? Email,
    string? Phone,
    Guid? DepartmentId,
    string? Designation,
    string? Address,
    DateTime? JoiningDate
);

public record UpdateEmployeeRequest(
    string FirstName,
    string? LastName,
    string? Email,
    string? Phone,
    Guid? DepartmentId,
    string? Designation,
    string? Address,
    DateTime? JoiningDate
);
