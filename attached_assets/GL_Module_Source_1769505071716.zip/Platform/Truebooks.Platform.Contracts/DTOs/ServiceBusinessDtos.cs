using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.DTOs;

public record ServiceEnquiryDto(
    Guid Id,
    string EnquiryNumber,
    DateTime EnquiryDate,
    Guid? CustomerId,
    string CustomerName,
    string CompanyName,
    string ContactPerson,
    string Email,
    string Phone,
    string? Address,
    EnquiryStatus Status,
    EnquirySource Source,
    string? SourceDetails,
    RequirementType RequirementType,
    string? Description,
    string? RequirementDetails,
    decimal EstimatedValue,
    decimal EstimatedBudget,
    string CurrencyCode,
    string? AssignedTo,
    DateTime? FollowUpDate,
    DateTime? NextFollowUpDate,
    DateTime? ExpectedStartDate,
    string? Notes,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateServiceEnquiryRequest(
    DateTime EnquiryDate,
    Guid? CustomerId,
    string CustomerName,
    string CompanyName,
    string ContactPerson,
    string Email,
    string Phone,
    string? Address,
    EnquirySource Source,
    string? SourceDetails,
    RequirementType RequirementType,
    string? RequirementDetails,
    string? Description,
    decimal EstimatedValue,
    decimal EstimatedBudget,
    string CurrencyCode,
    string? AssignedTo,
    DateTime? FollowUpDate,
    DateTime? NextFollowUpDate,
    DateTime? ExpectedStartDate,
    string? Notes
);

public record UpdateServiceEnquiryRequest(
    Guid? CustomerId,
    string CustomerName,
    string CompanyName,
    string ContactPerson,
    string Email,
    string Phone,
    string? Address,
    EnquiryStatus Status,
    EnquirySource Source,
    string? SourceDetails,
    RequirementType RequirementType,
    string? RequirementDetails,
    string? Description,
    decimal EstimatedValue,
    decimal EstimatedBudget,
    string CurrencyCode,
    string? AssignedTo,
    DateTime? FollowUpDate,
    DateTime? NextFollowUpDate,
    DateTime? ExpectedStartDate,
    string? Notes
);

public record ServiceQuotationDto(
    Guid Id,
    string QuotationNumber,
    int VersionNumber,
    DateTime QuotationDate,
    DateTime ValidUntil,
    Guid? EnquiryId,
    Guid? CustomerId,
    string CustomerName,
    string? ProjectName,
    QuotationStatus Status,
    string? Subject,
    string? Description,
    decimal SubTotal,
    decimal TaxAmount,
    decimal DiscountAmount,
    decimal TotalAmount,
    string CurrencyCode,
    string? Terms,
    string? Notes,
    IReadOnlyList<ServiceQuotationLineDto> Lines,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record ServiceQuotationLineDto(
    Guid Id,
    Guid QuotationId,
    int LineNumber,
    string Description,
    decimal Quantity,
    string? Unit,
    decimal UnitPrice,
    decimal DiscountPercent,
    decimal TaxPercent,
    decimal LineTotal
);

public record CreateServiceQuotationRequest(
    DateTime QuotationDate,
    DateTime ValidUntil,
    Guid? EnquiryId,
    Guid? CustomerId,
    string CustomerName,
    string? ProjectName,
    string? Subject,
    string? Description,
    decimal DiscountAmount,
    string CurrencyCode,
    string? Terms,
    string? Notes,
    IReadOnlyList<CreateServiceQuotationLineRequest> Lines
);

public record CreateServiceQuotationLineRequest(
    string Description,
    decimal Quantity,
    string? Unit,
    decimal UnitPrice,
    decimal DiscountPercent,
    decimal TaxPercent
);

public record UpdateServiceQuotationRequest(
    DateTime QuotationDate,
    DateTime ValidUntil,
    Guid? CustomerId,
    string CustomerName,
    string? ProjectName,
    string? Subject,
    string? Description,
    decimal DiscountAmount,
    string CurrencyCode,
    string? Terms,
    string? Notes,
    IReadOnlyList<CreateServiceQuotationLineRequest> Lines
);

public record ServiceContractDto(
    Guid Id,
    string ContractNumber,
    Guid? QuotationId,
    Guid? CustomerId,
    string CustomerName,
    string? ProjectName,
    string? ScopeOfWork,
    ContractType ContractType,
    ContractStatus Status,
    DateTime StartDate,
    DateTime EndDate,
    DateTime? NextBillingDate,
    int BillingDayOfMonth,
    BillingFrequency BillingFrequency,
    decimal ContractValue,
    decimal MonthlyValue,
    decimal RecurringAmount,
    string CurrencyCode,
    string? Description,
    string? Terms,
    string? PaymentTerms,
    string? SLATerms,
    string? Notes,
    string? Deliverables,
    bool AutoRenew,
    int RenewalNoticeDays,
    int DaysUntilExpiry,
    bool IsExpiringSoon,
    bool EnableDeferredRevenue,
    Guid? DeferredRevenueAccountId,
    Guid? RevenueAccountId,
    Guid? ClientCalendarId,
    decimal DeferredRevenueBalance,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateServiceContractRequest(
    Guid? QuotationId,
    Guid? CustomerId,
    string? ProjectName,
    string? ScopeOfWork,
    ContractType ContractType,
    DateTime StartDate,
    DateTime EndDate,
    BillingFrequency BillingFrequency,
    int BillingDayOfMonth,
    decimal ContractValue,
    decimal RecurringAmount,
    decimal TaxPercent,
    string CurrencyCode,
    string? Description,
    string? Terms,
    string? PaymentTerms,
    string? SLATerms,
    string? Notes,
    string? Deliverables,
    bool AutoRenew,
    int RenewalNoticeDays,
    bool EnableDeferredRevenue,
    Guid? DeferredRevenueAccountId,
    Guid? RevenueAccountId,
    Guid? ClientCalendarId
);

public record UpdateServiceContractRequest(
    Guid? CustomerId,
    string? ProjectName,
    string? ScopeOfWork,
    ContractType ContractType,
    ContractStatus Status,
    DateTime StartDate,
    DateTime EndDate,
    BillingFrequency BillingFrequency,
    int BillingDayOfMonth,
    decimal ContractValue,
    decimal RecurringAmount,
    string CurrencyCode,
    string? Description,
    string? Terms,
    string? PaymentTerms,
    string? SLATerms,
    string? Notes,
    string? Deliverables,
    bool AutoRenew,
    int RenewalNoticeDays,
    bool EnableDeferredRevenue,
    Guid? DeferredRevenueAccountId,
    Guid? RevenueAccountId,
    Guid? ClientCalendarId
);

public record ContractRenewalAlertDto(
    Guid ContractId,
    string ContractNumber,
    string CustomerName,
    string? ProjectName,
    DateTime EndDate,
    int DaysUntilExpiry,
    decimal ContractValue,
    string CurrencyCode,
    bool AutoRenew,
    ContractStatus Status
);

public record ServiceTaskLogDto(
    Guid Id,
    Guid? ContractId,
    string? ContractNumber,
    Guid? CustomerId,
    string? CustomerName,
    string TaskNumber,
    string TaskTitle,
    string? Subject,
    string? Description,
    string? Category,
    ServiceTaskStatus Status,
    TaskPriority Priority,
    string? AssignedTo,
    DateTime TaskDate,
    DateTime? DueDate,
    DateTime? CompletedDate,
    decimal HoursWorked,
    decimal HoursSpent,
    decimal BillableHours,
    bool IsBillable,
    bool IsInvoiced,
    decimal HourlyRate,
    decimal BillableAmount,
    string? Deliverables,
    string? Notes,
    Guid? EmployeeId,
    string? EmployeeName,
    TimesheetApprovalStatus ApprovalStatus,
    Guid? ApprovedByUserId,
    string? ApprovedByName,
    DateTime? ApprovedDate,
    string? ApprovalNotes,
    bool ProcessedForPayroll,
    Guid? PayrollJournalId,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateServiceTaskLogRequest(
    Guid? ContractId,
    Guid? CustomerId,
    string TaskTitle,
    string? Subject,
    string? Description,
    string? Category,
    TaskPriority Priority,
    string? AssignedTo,
    DateTime TaskDate,
    DateTime? DueDate,
    decimal HoursWorked,
    decimal BillableHours,
    bool IsBillable,
    decimal HourlyRate,
    string? Deliverables,
    string? Notes,
    Guid? EmployeeId
);

public record UpdateServiceTaskLogRequest(
    Guid? ContractId,
    Guid? CustomerId,
    string TaskTitle,
    string? Subject,
    string? Description,
    string? Category,
    ServiceTaskStatus Status,
    TaskPriority Priority,
    string? AssignedTo,
    DateTime TaskDate,
    DateTime? DueDate,
    DateTime? CompletedDate,
    decimal HoursWorked,
    decimal BillableHours,
    bool IsBillable,
    decimal HourlyRate,
    string? Deliverables,
    string? Notes,
    Guid? EmployeeId
);

public record TimesheetApprovalRequest(
    Guid TaskLogId,
    TimesheetApprovalStatus Status,
    string? ApprovalNotes
);

public record ServiceDashboardDto(
    int TotalEnquiries,
    int NewEnquiries,
    int QualifiedEnquiries,
    int TotalQuotations,
    int DraftQuotations,
    int SentQuotations,
    int AcceptedQuotations,
    decimal QuotationPipelineValue,
    decimal QuotationWinRate,
    int TotalActiveContracts,
    int ExpiringContracts,
    decimal ActiveContractValue,
    decimal MonthlyRecurringRevenue,
    int PendingTasks,
    int OverdueTasks,
    decimal PendingBillableHours,
    decimal PendingBillableAmount
);

public record ContractDropdownDto(
    Guid Id,
    string ContractNumber,
    string? CustomerName,
    string? ProjectName
);

public record DailyTimesheetEntryRequest(
    Guid? ContractId,
    DateTime TaskDate,
    string TaskTitle,
    string? Description,
    decimal HoursWorked,
    decimal BillableHours,
    bool IsBillable,
    decimal HourlyRate,
    string? Notes,
    Guid? EmployeeId
);

public record TimesheetReportRequest(
    DateTime FromDate,
    DateTime ToDate,
    Guid? EmployeeId,
    Guid? ContractId,
    TimesheetApprovalStatus? Status
);

public record TimesheetReportDto(
    DateTime FromDate,
    DateTime ToDate,
    IReadOnlyList<TimesheetReportLineDto> Lines,
    decimal TotalHours,
    decimal TotalBillableHours,
    decimal TotalBillableAmount
);

public record TimesheetReportLineDto(
    Guid TaskId,
    DateTime TaskDate,
    string TaskTitle,
    string? ContractNumber,
    string? CustomerName,
    string? EmployeeName,
    decimal HoursWorked,
    decimal BillableHours,
    decimal HourlyRate,
    decimal BillableAmount,
    TimesheetApprovalStatus ApprovalStatus
);

public record CampaignDto(
    Guid Id,
    string Name,
    string? Description,
    CampaignType Type,
    CampaignStatus Status,
    DateTime StartDate,
    DateTime? EndDate,
    decimal Budget,
    decimal SpentAmount,
    string? TargetAudience,
    string? Goals,
    int LeadsGenerated,
    int ConversionsCount,
    decimal ConversionRate,
    decimal ROI,
    string? Notes,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateCampaignRequest(
    string Name,
    string? Description,
    CampaignType Type,
    DateTime StartDate,
    DateTime? EndDate,
    decimal Budget,
    string? TargetAudience,
    string? Goals,
    string? Notes
);

public record UpdateCampaignRequest(
    string Name,
    string? Description,
    CampaignType Type,
    CampaignStatus Status,
    DateTime StartDate,
    DateTime? EndDate,
    decimal Budget,
    decimal SpentAmount,
    string? TargetAudience,
    string? Goals,
    int LeadsGenerated,
    int ConversionsCount,
    string? Notes
);

public record CampaignMetricsDto(
    Guid CampaignId,
    string CampaignName,
    int TotalLeads,
    int QualifiedLeads,
    int Conversions,
    decimal ConversionRate,
    decimal TotalRevenue,
    decimal CostPerLead,
    decimal ROI
);

public record ClientReportDto(
    Guid Id,
    Guid ContractId,
    string? ContractNumber,
    Guid CustomerId,
    string CustomerName,
    string ReportTitle,
    DateTime PeriodStart,
    DateTime PeriodEnd,
    ClientReportStatus Status,
    string? Summary,
    string? Achievements,
    string? Issues,
    string? NextSteps,
    decimal HoursWorked,
    decimal BillableAmount,
    DateTime? SentDate,
    string? SentTo,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateClientReportRequest(
    Guid ContractId,
    Guid CustomerId,
    string ReportTitle,
    DateTime PeriodStart,
    DateTime PeriodEnd,
    string? Summary,
    string? Achievements,
    string? Issues,
    string? NextSteps
);

public record UpdateClientReportRequest(
    string ReportTitle,
    DateTime PeriodStart,
    DateTime PeriodEnd,
    ClientReportStatus Status,
    string? Summary,
    string? Achievements,
    string? Issues,
    string? NextSteps
);
