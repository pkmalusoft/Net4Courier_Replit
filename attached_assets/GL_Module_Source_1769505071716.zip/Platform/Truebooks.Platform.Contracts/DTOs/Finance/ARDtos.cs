namespace Truebooks.Platform.Contracts.DTOs.Finance;

public record SalesEnquiryListDto(
    Guid Id,
    string EnquiryNo,
    DateTime EnquiryDate,
    string? CustomerName,
    string? Description,
    string Status,
    decimal TotalAmount
);

public record SalesEnquiryDetailDto(
    Guid Id,
    string EnquiryNo,
    DateTime EnquiryDate,
    Guid? CustomerId,
    string? CustomerName,
    string? CustomerPhone,
    string? CustomerAddress,
    Guid? CurrencyId,
    string? CurrencyCode,
    decimal ExchangeRate,
    string? Description,
    string Status,
    decimal SubTotal,
    decimal TaxTotal,
    decimal TotalAmount,
    DateTime? ValidUntil,
    DateTime CreatedAt,
    string? CreatedBy,
    List<SalesEnquiryLineDto> Lines
);

public record SalesEnquiryLineDto(
    Guid Id,
    Guid? ItemId,
    string? ItemCode,
    string? ItemName,
    decimal Quantity,
    Guid? UomId,
    string? UomName,
    decimal UnitPrice,
    Guid? TaxCodeId,
    decimal TaxRate,
    decimal TaxAmount,
    decimal Amount,
    string? Description
);

public record CreateSalesEnquiryRequest(
    string EnquiryNo,
    DateTime EnquiryDate,
    Guid? CustomerId,
    Guid? CurrencyId,
    decimal ExchangeRate,
    string? Description,
    DateTime? ValidUntil,
    List<CreateSalesEnquiryLineRequest> Lines
);

public record CreateSalesEnquiryLineRequest(
    Guid? ItemId,
    decimal Quantity,
    Guid? UomId,
    decimal UnitPrice,
    Guid? TaxCodeId,
    string? Description
);

public record SalesQuotationListDto(
    Guid Id,
    string QuotationNo,
    DateTime QuotationDate,
    string? CustomerName,
    string? Description,
    string Status,
    decimal TotalAmount,
    DateTime? ValidUntil
);

public record SalesQuotationDetailDto(
    Guid Id,
    string QuotationNo,
    DateTime QuotationDate,
    Guid? CustomerId,
    string? CustomerName,
    string? CustomerPhone,
    string? CustomerAddress,
    Guid? CurrencyId,
    string? CurrencyCode,
    decimal ExchangeRate,
    string? Description,
    string Status,
    decimal SubTotal,
    decimal TaxTotal,
    decimal TotalAmount,
    DateTime? ValidUntil,
    Guid? EnquiryId,
    string? EnquiryNo,
    DateTime CreatedAt,
    string? CreatedBy,
    List<SalesQuotationLineDto> Lines
);

public record SalesQuotationLineDto(
    Guid Id,
    Guid? ItemId,
    string? ItemCode,
    string? ItemName,
    decimal Quantity,
    Guid? UomId,
    string? UomName,
    decimal UnitPrice,
    Guid? TaxCodeId,
    decimal TaxRate,
    decimal TaxAmount,
    decimal Amount,
    string? Description
);

public record CreateSalesQuotationRequest(
    string QuotationNo,
    DateTime QuotationDate,
    Guid? CustomerId,
    Guid? CurrencyId,
    decimal ExchangeRate,
    string? Description,
    DateTime? ValidUntil,
    Guid? EnquiryId,
    List<CreateSalesQuotationLineRequest> Lines
);

public record CreateSalesQuotationLineRequest(
    Guid? ItemId,
    decimal Quantity,
    Guid? UomId,
    decimal UnitPrice,
    Guid? TaxCodeId,
    string? Description
);

public record SalesOrderListDto(
    Guid Id,
    string OrderNo,
    DateTime OrderDate,
    string? CustomerName,
    string Status,
    decimal TotalAmount,
    DateTime? ExpectedDate
);

public record SalesOrderDetailDto(
    Guid Id,
    string OrderNo,
    DateTime OrderDate,
    Guid? CustomerId,
    string? CustomerName,
    string? CustomerPhone,
    string? CustomerAddress,
    Guid? CurrencyId,
    string? CurrencyCode,
    decimal ExchangeRate,
    string? Description,
    string Status,
    decimal SubTotal,
    decimal TaxTotal,
    decimal TotalAmount,
    DateTime? ExpectedDate,
    Guid? QuotationId,
    string? QuotationNo,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? ApprovedAt,
    string? ApprovedBy,
    List<SalesOrderLineDto> Lines
);

public record SalesOrderLineDto(
    Guid Id,
    Guid? ItemId,
    string? ItemCode,
    string? ItemName,
    decimal Quantity,
    Guid? UomId,
    string? UomName,
    decimal UnitPrice,
    Guid? TaxCodeId,
    decimal TaxRate,
    decimal TaxAmount,
    decimal Amount,
    string? Description
);

public record CreateSalesOrderRequest(
    string OrderNo,
    DateTime OrderDate,
    Guid? CustomerId,
    Guid? CurrencyId,
    decimal ExchangeRate,
    string? Description,
    DateTime? ExpectedDate,
    Guid? QuotationId,
    List<CreateSalesOrderLineRequest> Lines
);

public record CreateSalesOrderLineRequest(
    Guid? ItemId,
    decimal Quantity,
    Guid? UomId,
    decimal UnitPrice,
    Guid? TaxCodeId,
    string? Description
);

public record SalesReturnListDto(
    Guid Id,
    string ReturnNo,
    DateTime ReturnDate,
    string? CustomerName,
    string? InvoiceNo,
    string Status,
    decimal TotalAmount
);

public record SalesReturnDetailDto(
    Guid Id,
    string ReturnNo,
    DateTime ReturnDate,
    Guid? CustomerId,
    string? CustomerName,
    Guid? InvoiceId,
    string? InvoiceNo,
    Guid? CurrencyId,
    string? CurrencyCode,
    decimal ExchangeRate,
    string? Reason,
    string Status,
    decimal SubTotal,
    decimal TaxTotal,
    decimal TotalAmount,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? ApprovedAt,
    string? ApprovedBy,
    List<SalesReturnLineDto> Lines
);

public record SalesReturnLineDto(
    Guid Id,
    Guid? ItemId,
    string? ItemCode,
    string? ItemName,
    decimal Quantity,
    Guid? UomId,
    string? UomName,
    decimal UnitPrice,
    Guid? TaxCodeId,
    decimal TaxRate,
    decimal TaxAmount,
    decimal Amount,
    string? Description
);

public record CreateSalesReturnRequest(
    string ReturnNo,
    DateTime ReturnDate,
    Guid? CustomerId,
    Guid? InvoiceId,
    Guid? CurrencyId,
    decimal ExchangeRate,
    string? Reason,
    List<CreateSalesReturnLineRequest> Lines
);

public record CreateSalesReturnLineRequest(
    Guid? ItemId,
    decimal Quantity,
    Guid? UomId,
    decimal UnitPrice,
    Guid? TaxCodeId,
    string? Description
);

public record SalesInvoiceListDto(
    Guid Id,
    string InvoiceNo,
    DateTime InvoiceDate,
    string? CustomerName,
    decimal TotalAmount,
    decimal AmountDue,
    DateTime? DueDate,
    string Status,
    bool IsVoided
);

public record SalesInvoiceDetailDto(
    Guid Id,
    string InvoiceNumber,
    string InvoiceType,
    DateTime InvoiceDate,
    DateTime? DueDate,
    Guid? CustomerId,
    string? CustomerName,
    string? CustomerPhone,
    string? CustomerAddress,
    Guid CurrencyId,
    string? CurrencyCode,
    decimal ExchangeRate,
    string? Notes,
    string Status,
    decimal SubTotal,
    decimal TaxTotal,
    decimal TotalAmount,
    decimal AmountPaid,
    decimal AmountDue,
    Guid? BranchId,
    Guid? DepartmentId,
    Guid? ContractId,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? PostedAt,
    string? PostedBy,
    bool IsVoided,
    List<SalesInvoiceDetailLineDto> Lines
);

public record SalesInvoiceDetailLineDto(
    Guid Id,
    Guid? ItemId,
    string? ItemCode,
    string? ItemName,
    decimal Quantity,
    Guid? UomId,
    string? UomName,
    decimal UnitPrice,
    Guid? TaxCodeId,
    decimal TaxRate,
    decimal TaxAmount,
    decimal Amount,
    string? Description
);

public record InvoiceableContractDto(
    Guid Id,
    string ContractNumber,
    string ProjectName,
    Guid CustomerId,
    string CustomerName,
    decimal ContractValue,
    decimal RecurringAmount,
    decimal TaxPercent,
    string CurrencyCode,
    DateTime StartDate,
    DateTime EndDate,
    decimal TotalBilledAmount,
    int Status
);
