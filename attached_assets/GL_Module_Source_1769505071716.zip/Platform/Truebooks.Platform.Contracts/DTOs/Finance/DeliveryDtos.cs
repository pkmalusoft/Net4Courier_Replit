namespace Truebooks.Platform.Contracts.DTOs.Finance;

public record DeliveryNoteListDto(
    Guid Id,
    string DeliveryNo,
    DateTime DeliveryDate,
    Guid? SalesOrderId,
    string? SalesOrderNo,
    Guid? CustomerId,
    string? CustomerName,
    string? DeliveryAddress,
    string Status,
    DateTime CreatedAt,
    bool IsVoided
);

public record DeliveryNoteDetailDto(
    Guid Id,
    string DeliveryNo,
    DateTime DeliveryDate,
    Guid? SalesOrderId,
    string? SalesOrderNo,
    Guid? CustomerId,
    string? CustomerName,
    string? CustomerPhone,
    string? DeliveryAddress,
    Guid? WarehouseId,
    string? WarehouseName,
    string? Notes,
    string Status,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? CompletedAt,
    string? CompletedBy,
    bool IsVoided,
    List<DeliveryNoteLineDto> Lines
);

public record DeliveryNoteLineDto(
    Guid Id,
    Guid? ItemId,
    string? ItemCode,
    string? ItemName,
    decimal OrderedQuantity,
    decimal DeliveredQuantity,
    Guid? UomId,
    string? UomName,
    string? BatchNumber,
    string? SerialNumber,
    string? Notes
);

public record CreateDeliveryNoteRequest(
    string DeliveryNo,
    DateTime DeliveryDate,
    Guid? SalesOrderId,
    Guid? CustomerId,
    string? DeliveryAddress,
    Guid? WarehouseId,
    string? Notes,
    List<CreateDeliveryNoteLineRequest> Lines
);

public record CreateDeliveryNoteLineRequest(
    Guid? ItemId,
    decimal DeliveredQuantity,
    Guid? UomId,
    string? BatchNumber,
    string? SerialNumber,
    string? Notes
);
