namespace Truebooks.Platform.Contracts.DTOs.Finance;

public record BankAccountDto(
    Guid Id,
    string AccountNumber,
    string AccountName,
    string BankName,
    string CurrencyCode,
    Guid? CurrencyId,
    Guid? GLAccountId,
    string? GLAccountCode,
    decimal OpeningBalance,
    decimal CurrentBalance,
    DateTime? OpeningDate,
    bool IsActive,
    string? SwiftCode,
    string? IbanNumber,
    string? BankAddress,
    string? Notes
);

public record BankAccountListDto(
    Guid Id,
    string AccountNumber,
    string AccountName,
    string BankName,
    string CurrencyCode,
    decimal OpeningBalance,
    decimal CurrentBalance,
    bool IsActive
);

public record CreateBankAccountRequest(
    string AccountNumber,
    string AccountName,
    string BankName,
    Guid CurrencyId,
    Guid? GLAccountId,
    decimal OpeningBalance,
    DateTime? OpeningDate,
    string? SwiftCode,
    string? IbanNumber,
    string? BankAddress,
    string? Notes
);

public record UpdateBankAccountRequest(
    string AccountName,
    string BankName,
    Guid CurrencyId,
    Guid? GLAccountId,
    decimal OpeningBalance,
    DateTime? OpeningDate,
    string? SwiftCode,
    string? IbanNumber,
    string? BankAddress,
    string? Notes,
    bool IsActive
);

public record BankReconciliationDto(
    Guid Id,
    Guid BankAccountId,
    string BankAccountName,
    DateTime StatementDate,
    decimal StatementEndingBalance,
    decimal BookBalance,
    decimal Difference,
    string Status,
    int MatchedCount,
    int UnmatchedCount,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? ReconciledAt,
    string? ReconciledBy
);

public record BankReconciliationLineDto(
    Guid Id,
    Guid TransactionId,
    string TransactionType,
    DateTime TransactionDate,
    string ReferenceNo,
    string? Description,
    decimal DebitAmount,
    decimal CreditAmount,
    bool IsMatched,
    DateTime? MatchedDate
);

public record CreateBankReconciliationRequest(
    Guid BankAccountId,
    DateTime StatementDate,
    decimal StatementEndingBalance
);

public record MatchReconciliationLineRequest(
    Guid LineId,
    bool IsMatched
);

public record CashBankTransactionDto(
    Guid Id,
    string VoucherNo,
    DateTime VoucherDate,
    string TransactionType,
    string TransactionCategory,
    string RecPayType,
    Guid? BankAccountId,
    string? BankAccountName,
    Guid? CashAccountId,
    string? CashAccountName,
    Guid? CustomerId,
    string? CustomerName,
    Guid? VendorId,
    string? VendorName,
    decimal TotalAmount,
    string? PaymentMode,
    string? ReferenceNo,
    string? Description,
    string Status,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? PostedAt,
    string? PostedBy
);

public record CashBankTransactionListDto(
    Guid Id,
    string VoucherNo,
    DateTime VoucherDate,
    string TransactionType,
    string TransactionCategory,
    string RecPayType,
    string? BankAccountName,
    string? PartyName,
    decimal TotalAmount,
    string Status
);

public record CreateCashBankTransactionRequest(
    string TransactionType,
    string TransactionCategory,
    string RecPayType,
    DateTime VoucherDate,
    Guid? BankAccountId,
    Guid? CashAccountId,
    Guid? CustomerId,
    Guid? VendorId,
    string? PaymentMode,
    string? ReferenceNo,
    string? Description,
    List<CashBankTransactionLineRequest> Lines
);

public record CashBankTransactionLineRequest(
    Guid AccountId,
    decimal DebitAmount,
    decimal CreditAmount,
    string? Description,
    Guid? BranchId,
    Guid? DepartmentId,
    Guid? ProjectId
);

public record UpdateCashBankTransactionRequest(
    DateTime VoucherDate,
    Guid? BankAccountId,
    Guid? CashAccountId,
    Guid? CustomerId,
    Guid? VendorId,
    string? PaymentMode,
    string? ReferenceNo,
    string? Description,
    List<CashBankTransactionLineRequest> Lines
);

public record StartReconciliationRequest(
    Guid BankAccountId,
    DateTime StatementDate
);

public record ImportStatementRequest(
    string FileName,
    string FileContent
);

public record AutoMatchResultDto(
    int MatchedCount,
    int TotalStatementLines,
    int UnmatchedCount
);
