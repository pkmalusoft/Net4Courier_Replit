namespace Truebooks.Platform.Contracts.DTOs.Finance;

public record InvoiceForAllocationDto(
    Guid Id,
    string InvoiceNo,
    DateTime InvoiceDate,
    decimal TotalAmount,
    decimal AmountDue,
    decimal AmountPaid,
    string? Description
);

public record BillForAllocationDto(
    Guid Id,
    string BillNo,
    DateTime BillDate,
    decimal TotalAmount,
    decimal AmountDue,
    decimal AmountPaid,
    string? Description
);

public record CashBankInvoiceAllocationDto(
    Guid Id,
    Guid CashBankTransactionId,
    Guid SalesInvoiceId,
    string? InvoiceNo,
    decimal AllocatedAmount,
    DateTime AllocationDate
);

public record CashBankBillAllocationDto(
    Guid Id,
    Guid CashBankTransactionId,
    Guid PurchaseBillId,
    string? BillNo,
    decimal AllocatedAmount,
    DateTime AllocationDate
);

public record CreateInvoiceAllocationRequest(
    Guid CashBankTransactionId,
    Guid SalesInvoiceId,
    decimal AllocatedAmount
);

public record CreateBillAllocationRequest(
    Guid CashBankTransactionId,
    Guid PurchaseBillId,
    decimal AllocatedAmount
);

public record VoucherAttachmentDto(
    Guid Id,
    Guid TransactionId,
    string FileName,
    string? ContentType,
    long FileSize,
    DateTime UploadedAt,
    string? UploadedBy
);
