namespace Truebooks.Platform.Contracts.DTOs.Finance;

public record PurchaseEnquiryDto(
    Guid Id,
    string EnquiryNo,
    DateTime EnquiryDate,
    Guid SupplierId,
    string? SupplierName,
    Guid? CurrencyId,
    string? CurrencyCode,
    decimal ExchangeRate,
    string? Description,
    string Status,
    decimal TotalAmount,
    DateTime? ValidUntil,
    DateTime CreatedAt,
    string? CreatedBy,
    List<PurchaseEnquiryLineDto> Lines
);

public record PurchaseEnquiryLineDto(
    Guid Id,
    Guid ItemId,
    string? ItemCode,
    string? ItemName,
    decimal Quantity,
    Guid? UomId,
    string? UomName,
    decimal UnitPrice,
    decimal Amount,
    string? Description
);

public record CreatePurchaseEnquiryRequest(
    DateTime EnquiryDate,
    Guid SupplierId,
    Guid? CurrencyId,
    decimal ExchangeRate,
    string? Description,
    DateTime? ValidUntil,
    List<CreatePurchaseEnquiryLineRequest> Lines
);

public record CreatePurchaseEnquiryLineRequest(
    Guid ItemId,
    decimal Quantity,
    Guid? UomId,
    decimal UnitPrice,
    string? Description
);

public record PurchaseQuotationDto(
    Guid Id,
    string QuotationNo,
    DateTime QuotationDate,
    Guid SupplierId,
    string? SupplierName,
    Guid? CurrencyId,
    string? CurrencyCode,
    decimal ExchangeRate,
    string? Description,
    string Status,
    decimal SubTotal,
    decimal TaxTotal,
    decimal TotalAmount,
    DateTime? ValidUntil,
    Guid? PurchaseEnquiryId,
    DateTime CreatedAt,
    string? CreatedBy,
    List<PurchaseQuotationLineDto> Lines
);

public record PurchaseQuotationLineDto(
    Guid Id,
    Guid ItemId,
    string? ItemCode,
    string? ItemName,
    decimal Quantity,
    Guid? UomId,
    string? UomName,
    decimal UnitPrice,
    Guid? TaxCodeId,
    decimal TaxRate,
    decimal TaxAmount,
    decimal Amount,
    string? Description
);

public record CreatePurchaseQuotationRequest(
    DateTime QuotationDate,
    Guid SupplierId,
    Guid? CurrencyId,
    decimal ExchangeRate,
    string? Description,
    DateTime? ValidUntil,
    Guid? PurchaseEnquiryId,
    List<CreatePurchaseQuotationLineRequest> Lines
);

public record CreatePurchaseQuotationLineRequest(
    Guid ItemId,
    decimal Quantity,
    Guid? UomId,
    decimal UnitPrice,
    Guid? TaxCodeId,
    string? Description
);

public record PurchaseOrderDto(
    Guid Id,
    string OrderNo,
    DateTime OrderDate,
    Guid SupplierId,
    string? SupplierName,
    Guid? CurrencyId,
    string? CurrencyCode,
    decimal ExchangeRate,
    string? Description,
    string Status,
    decimal SubTotal,
    decimal TaxTotal,
    decimal TotalAmount,
    DateTime? ExpectedDeliveryDate,
    Guid? PurchaseQuotationId,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? ApprovedAt,
    string? ApprovedBy,
    List<PurchaseOrderLineDto> Lines
);

public record PurchaseOrderLineDto(
    Guid Id,
    Guid ItemId,
    string? ItemCode,
    string? ItemName,
    decimal Quantity,
    decimal ReceivedQuantity,
    Guid? UomId,
    string? UomName,
    decimal UnitPrice,
    Guid? TaxCodeId,
    decimal TaxRate,
    decimal TaxAmount,
    decimal Amount,
    string? Description
);

public record PurchaseBillDetailDto(
    Guid Id,
    string BillNo,
    DateTime BillDate,
    Guid SupplierId,
    string? SupplierName,
    Guid? CurrencyId,
    string? CurrencyCode,
    decimal ExchangeRate,
    string? Description,
    string Status,
    decimal SubTotal,
    decimal TaxTotal,
    decimal TotalAmount,
    decimal AmountPaid,
    decimal AmountDue,
    DateTime? DueDate,
    Guid? PurchaseOrderId,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? PostedAt,
    string? PostedBy,
    bool IsVoided,
    List<PurchaseBillDetailLineDto> Lines
);

public record PurchaseBillDetailLineDto(
    Guid Id,
    Guid ItemId,
    string? ItemCode,
    string? ItemName,
    decimal Quantity,
    Guid? UomId,
    string? UomName,
    decimal UnitPrice,
    Guid? TaxCodeId,
    decimal TaxRate,
    decimal TaxAmount,
    decimal Amount,
    Guid? AccountId,
    string? AccountCode,
    string? Description
);

public record PurchaseBillListDto(
    Guid Id,
    string BillNo,
    DateTime BillDate,
    string? SupplierName,
    decimal TotalAmount,
    decimal AmountDue,
    DateTime? DueDate,
    string Status,
    bool IsVoided
);
