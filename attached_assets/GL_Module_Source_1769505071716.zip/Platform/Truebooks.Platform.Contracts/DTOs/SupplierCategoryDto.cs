namespace Truebooks.Platform.Contracts.DTOs;

public record SupplierCategoryDto(
    Guid Id,
    Guid TenantId,
    string Name,
    string? Description,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateSupplierCategoryRequest(
    string Name,
    string? Description,
    bool IsActive = true
);

public record UpdateSupplierCategoryRequest(
    string Name,
    string? Description,
    bool IsActive
);
