namespace Truebooks.Platform.Contracts.DTOs;

public record ProductDto(
    Guid Id,
    Guid TenantId,
    string Code,
    string Name,
    string? Description,
    string? SKU,
    string? Barcode,
    decimal UnitPrice,
    decimal CostPrice,
    string UnitOfMeasure,
    decimal AvailableQuantity,
    bool IsActive,
    bool TrackInventory
);
