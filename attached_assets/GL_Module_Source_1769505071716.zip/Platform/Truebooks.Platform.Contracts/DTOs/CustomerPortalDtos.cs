namespace Truebooks.Platform.Contracts.DTOs;

public record CustomerInvoiceSummaryDto(
    Guid Id,
    string InvoiceNumber,
    DateTime InvoiceDate,
    DateTime DueDate,
    decimal TotalAmount,
    decimal PaidAmount,
    decimal BalanceAmount,
    string Status,
    string? ContractNumber,
    string? Description
);

public record CustomerInvoiceDetailDto(
    Guid Id,
    string InvoiceNumber,
    DateTime InvoiceDate,
    DateTime DueDate,
    decimal SubTotal,
    decimal TaxAmount,
    decimal TotalAmount,
    decimal PaidAmount,
    decimal BalanceAmount,
    string Status,
    string? ContractNumber,
    string? CustomerName,
    string? CustomerAddress,
    string? Description,
    string? Notes,
    List<CustomerInvoiceLineDto> Lines
);

public record CustomerInvoiceLineDto(
    Guid Id,
    string Description,
    decimal Quantity,
    decimal UnitPrice,
    decimal Amount,
    string? TaxCode,
    decimal TaxAmount
);

public record CustomerStatementRequestDto(
    Guid CustomerId,
    DateTime FromDate,
    DateTime ToDate
);

public record CustomerStatementDto(
    Guid CustomerId,
    string CustomerName,
    string? CustomerAddress,
    DateTime FromDate,
    DateTime ToDate,
    decimal OpeningBalance,
    decimal TotalDebits,
    decimal TotalCredits,
    decimal ClosingBalance,
    List<CustomerStatementLineDto> Lines
);

public record CustomerStatementLineDto(
    DateTime TransactionDate,
    string TransactionType,
    string ReferenceNumber,
    string? Description,
    decimal DebitAmount,
    decimal CreditAmount,
    decimal RunningBalance
);

public record CustomerLedgerEntryDto(
    Guid Id,
    DateTime TransactionDate,
    string TransactionType,
    string ReferenceNumber,
    string? Description,
    decimal DebitAmount,
    decimal CreditAmount,
    decimal RunningBalance,
    string? ContractNumber
);

public record CustomerLedgerRequestDto(
    Guid CustomerId,
    DateTime? FromDate,
    DateTime? ToDate,
    Guid? ContractId
);

public record SupportTicketDto(
    Guid Id,
    string TicketNumber,
    string Subject,
    string Description,
    string Status,
    string Priority,
    DateTime CreatedDate,
    DateTime? ResolvedDate,
    string? AssignedTo,
    Guid? ContractId,
    string? ContractNumber,
    List<SupportTicketMessageDto>? Messages
);

public record SupportTicketMessageDto(
    Guid Id,
    string Message,
    string SenderName,
    bool IsCustomer,
    DateTime SentDate
);

public record CreateSupportTicketRequest(
    Guid CustomerId,
    string Subject,
    string Description,
    string Priority,
    Guid? ContractId
);

public record AddTicketMessageRequest(
    Guid TicketId,
    string Message
);

public record CustomerPaymentDto(
    Guid Id,
    string PaymentNumber,
    DateTime PaymentDate,
    decimal Amount,
    string PaymentMethod,
    string Status,
    string? ReferenceNumber,
    Guid? InvoiceId,
    string? InvoiceNumber,
    string? Notes
);

public record CustomerPaymentRequestDto(
    Guid CustomerId,
    Guid InvoiceId,
    decimal Amount,
    string PaymentMethod,
    string? ReferenceNumber,
    string? Notes
);

public record CustomerPaymentResultDto(
    bool Success,
    string? PaymentNumber,
    string? Message,
    string? PaymentUrl
);

public record PaymentMethodDto(
    string Code,
    string Name,
    bool IsOnline,
    string? Instructions
);
