namespace Truebooks.Platform.Contracts.DTOs;

public record CustomerCategoryDto(
    Guid Id,
    Guid TenantId,
    string Code,
    string Name,
    string? Description,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateCustomerCategoryRequest(
    string Code,
    string Name,
    string? Description,
    bool IsActive = true
);

public record UpdateCustomerCategoryRequest(
    string Code,
    string Name,
    string? Description,
    bool IsActive
);
