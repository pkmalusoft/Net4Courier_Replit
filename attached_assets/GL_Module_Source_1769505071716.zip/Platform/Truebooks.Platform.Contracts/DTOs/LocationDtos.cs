namespace Truebooks.Platform.Contracts.DTOs;

public record CountryDto(
    Guid Id,
    Guid TenantId,
    string Code,
    string Name,
    bool IsActive
);

public record CountryDetailDto(
    Guid Id,
    string Code,
    string Code3,
    string Name,
    string? PhoneCode,
    string? CurrencyCode,
    string? Region,
    int SortOrder,
    bool IsActive,
    DateTime CreatedAt
);

public record CreateCountryRequest(
    string Code,
    string? Code3,
    string Name,
    string? PhoneCode,
    string? CurrencyCode,
    string? Region,
    int SortOrder
);

public record UpdateCountryRequest(
    string? Code3,
    string Name,
    string? PhoneCode,
    string? CurrencyCode,
    string? Region,
    int SortOrder,
    bool IsActive
);

public record StateDto(
    Guid Id,
    Guid TenantId,
    Guid CountryId,
    string Code,
    string Name,
    bool IsActive
);

public record StateDetailDto(
    Guid Id,
    Guid CountryId,
    string? CountryName,
    string? CountryCode,
    string Code,
    string Name,
    string? Region,
    int SortOrder,
    bool IsActive,
    DateTime CreatedAt
);

public record CreateStateRequest(
    Guid CountryId,
    string Code,
    string Name,
    string? Region,
    int SortOrder
);

public record UpdateStateRequest(
    Guid CountryId,
    string Name,
    string? Region,
    int SortOrder,
    bool IsActive
);

public record CityDto(
    Guid Id,
    Guid TenantId,
    Guid StateId,
    string Name,
    bool IsActive
);

public record CityDetailDto(
    Guid Id,
    Guid StateId,
    string? StateName,
    string? StateCode,
    Guid CountryId,
    string? CountryName,
    string? CountryCode,
    string Name,
    string? AreaCode,
    string? TimeZone,
    int SortOrder,
    bool IsActive,
    DateTime CreatedAt
);

public record CreateCityRequest(
    Guid StateId,
    string Name,
    string? AreaCode,
    string? TimeZone,
    int SortOrder
);

public record UpdateCityRequest(
    Guid StateId,
    string Name,
    string? AreaCode,
    string? TimeZone,
    int SortOrder,
    bool IsActive
);

public record PostalCodeDto(
    Guid Id,
    Guid TenantId,
    Guid CityId,
    string Code,
    bool IsActive
);

public record PostalCodeDetailDto(
    Guid Id,
    Guid CityId,
    string? CityName,
    Guid StateId,
    string? StateName,
    Guid CountryId,
    string? CountryName,
    string Code,
    string? AreaName,
    bool IsActive,
    DateTime CreatedAt
);

public record CreatePostalCodeRequest(
    Guid CityId,
    string Code,
    string? AreaName
);

public record UpdatePostalCodeRequest(
    Guid CityId,
    string? AreaName,
    bool IsActive
);
