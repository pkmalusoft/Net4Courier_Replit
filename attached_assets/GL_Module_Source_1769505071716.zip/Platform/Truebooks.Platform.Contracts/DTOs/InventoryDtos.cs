using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.DTOs;

public record ItemDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string ItemCode,
    string Name,
    string? Description,
    ItemType ItemType,
    string? Barcode,
    string? HSNCode,
    Guid? DefaultTaxCodeId,
    string? DefaultTaxCodeName,
    Guid? DefaultUomId,
    string DefaultUomName,
    Guid? ItemGroupId,
    string? ItemGroupName,
    Guid? BrandId,
    string? BrandName,
    string? Model,
    string? Design,
    Guid? SizeId,
    string? SizeName,
    Guid? ColourId,
    string? ColourName,
    bool TrackInventory,
    bool RequiresSerialTracking,
    CostingMethod? CostingMethod,
    decimal? ReorderLevel,
    decimal? ReorderQuantity,
    decimal? StandardCost,
    decimal? DefaultSellingPrice,
    Guid? InventoryAccountId,
    string? InventoryAccountName,
    Guid? COGSAccountId,
    string? COGSAccountName,
    Guid? SalesAccountId,
    string? SalesAccountName,
    Guid? PurchaseAccountId,
    string? PurchaseAccountName,
    Guid? IncomeAccountId,
    string? IncomeAccountName,
    bool IsActive,
    List<Guid> CategoryIds,
    List<string> Categories,
    string DisplayName
);

public record ItemSearchResultDto(
    Guid Id,
    string ItemCode,
    string Name,
    ItemType ItemType,
    string? Barcode,
    string? HSNCode,
    decimal? DefaultSellingPrice,
    Guid? DefaultTaxCodeId,
    bool TrackInventory,
    decimal StockQuantity,
    string DisplayName
);

public record CreateItemRequest(
    string ItemCode,
    string Name,
    string? Description,
    ItemType ItemType,
    Guid? ItemGroupId,
    Guid? BrandId,
    Guid? SizeId,
    Guid? ColourId,
    string? UnitOfMeasure,
    decimal? CostPrice,
    decimal? SellingPrice,
    decimal ReorderLevel,
    decimal ReorderQuantity,
    bool TrackInventory,
    bool IsActive
);

public record UpdateItemRequest(
    Guid Id,
    string ItemCode,
    string Name,
    string? Description,
    ItemType ItemType,
    Guid? ItemGroupId,
    Guid? BrandId,
    Guid? SizeId,
    Guid? ColourId,
    string? UnitOfMeasure,
    decimal? CostPrice,
    decimal? SellingPrice,
    decimal ReorderLevel,
    decimal ReorderQuantity,
    bool TrackInventory,
    bool IsActive
);

public record ItemCategoryDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string Code,
    string Name,
    string? Description,
    bool IsActive,
    string DisplayName
);

public record CreateItemCategoryRequest(
    string Code,
    string Name,
    string? Description,
    bool IsActive
);

public record UpdateItemCategoryRequest(
    Guid Id,
    string Code,
    string Name,
    string? Description,
    bool IsActive
);

public record UomDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string Code,
    string Name,
    string? Description,
    UsageScope UsageScope,
    bool IsActive,
    string DisplayName
);

public record CreateUomRequest(
    string Code,
    string Name,
    string? Description,
    UsageScope UsageScope,
    bool IsActive
);

public record UpdateUomRequest(
    Guid Id,
    string Code,
    string Name,
    string? Description,
    UsageScope UsageScope,
    bool IsActive
);

public record WarehouseDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string Code,
    string Name,
    string? Address,
    Guid? BranchId,
    string? BranchName,
    bool IsActive,
    string DisplayName
);

public record CreateWarehouseRequest(
    string Code,
    string Name,
    string? Address,
    Guid? BranchId,
    bool IsActive
);

public record UpdateWarehouseRequest(
    Guid Id,
    string Code,
    string Name,
    string? Address,
    Guid? BranchId,
    bool IsActive
);

public record InventoryLocationDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string Code,
    string Name,
    string? Description,
    Guid WarehouseId,
    string WarehouseName,
    Guid? ParentLocationId,
    string? ParentLocationName,
    bool IsActive,
    string DisplayName
);

public record CreateInventoryLocationRequest(
    string Code,
    string Name,
    string? Description,
    Guid WarehouseId,
    Guid? ParentLocationId,
    bool IsActive
);

public record UpdateInventoryLocationRequest(
    Guid Id,
    string Code,
    string Name,
    string? Description,
    Guid WarehouseId,
    Guid? ParentLocationId,
    bool IsActive
);

public record SerialNumberDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    Guid ItemId,
    string ItemCode,
    string ItemName,
    Guid? WarehouseId,
    string? WarehouseName,
    string SerialCode,
    SerialStatus Status,
    string? CurrentLocation,
    string? AcquisitionDocumentType,
    Guid? AcquisitionDocumentId,
    DateTime? AcquisitionDate,
    decimal? Cost,
    DateTime? WarrantyExpiry,
    string? Notes,
    string StatusText
);

public record CreateSerialNumberRequest(
    Guid ItemId,
    Guid? WarehouseId,
    string SerialCode,
    SerialStatus Status,
    string? CurrentLocation,
    string? AcquisitionDocumentType,
    Guid? AcquisitionDocumentId,
    DateTime? AcquisitionDate,
    decimal? Cost,
    DateTime? WarrantyExpiry,
    string? Notes
);

public record UpdateSerialNumberRequest(
    Guid Id,
    Guid? WarehouseId,
    SerialStatus Status,
    string? CurrentLocation,
    decimal? Cost,
    DateTime? WarrantyExpiry,
    string? Notes
);

public record ItemPriceScheduleDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string Code,
    string Name,
    string? Description,
    PriceType PriceType,
    DateTime? StartDate,
    DateTime? EndDate,
    bool IsActive,
    List<ItemPriceScheduleLineDto> Lines
);

public record ItemPriceScheduleLineDto(
    Guid Id,
    Guid PriceScheduleId,
    Guid ItemId,
    string ItemCode,
    string ItemName,
    decimal Price,
    decimal? MinQuantity,
    decimal? MaxQuantity
);

public record CreateItemPriceScheduleRequest(
    string Code,
    string Name,
    string? Description,
    PriceType PriceType,
    DateTime? StartDate,
    DateTime? EndDate,
    bool IsActive,
    List<CreateItemPriceScheduleLineRequest> Lines
);

public record CreateItemPriceScheduleLineRequest(
    Guid ItemId,
    decimal Price,
    decimal? MinQuantity,
    decimal? MaxQuantity
);

public record UpdateItemPriceScheduleRequest(
    Guid Id,
    string Code,
    string Name,
    string? Description,
    PriceType PriceType,
    DateTime? StartDate,
    DateTime? EndDate,
    bool IsActive,
    List<CreateItemPriceScheduleLineRequest> Lines
);

public record ItemInventoryDetailDto(
    Guid Id,
    Guid ItemId,
    string ItemCode,
    string ItemName,
    Guid WarehouseId,
    string WarehouseName,
    decimal QuantityOnHand,
    decimal QuantityReserved,
    decimal QuantityAvailable,
    decimal? ReorderLevel,
    decimal? ReorderQuantity,
    decimal AverageCost,
    DateTime? LastRestockDate
);

public record StockTransferDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string TransferNumber,
    DateTime TransferDate,
    Guid FromLocationId,
    string FromLocationDisplay,
    Guid ToLocationId,
    string ToLocationDisplay,
    int Status,
    string StatusText,
    string Notes,
    DateTime? RequestedDate,
    Guid? RequestedByUserId,
    DateTime? ApprovedDate,
    Guid? ApprovedByUserId,
    DateTime? DispatchedDate,
    Guid? DispatchedByUserId,
    DateTime? ReceivedDate,
    Guid? ReceivedByUserId,
    DateTime? CancelledDate,
    Guid? CancelledByUserId,
    string? CancellationReason,
    List<StockTransferLineDto> Lines
);

public record StockTransferLineDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    Guid StockTransferId,
    Guid ItemId,
    string ItemCode,
    string ItemName,
    decimal RequestedQuantity,
    decimal DispatchedQuantity,
    decimal ReceivedQuantity,
    decimal UnitCost,
    decimal TotalCost,
    string? Notes
);

public record StockAdjustmentDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    string AdjustmentNumber,
    DateTime AdjustmentDate,
    Guid WarehouseId,
    string WarehouseName,
    int AdjustmentType,
    string AdjustmentTypeText,
    string Reason,
    Guid? JournalEntryId,
    Guid? BranchId,
    string? BranchName,
    Guid? DepartmentId,
    string? DepartmentName,
    List<StockAdjustmentLineDto> Lines,
    decimal TotalCost
);

public record StockAdjustmentLineDto(
    Guid Id,
    Guid TenantId,
    DateTime CreatedAt,
    Guid StockAdjustmentId,
    Guid ItemId,
    string ItemCode,
    string ItemName,
    decimal Quantity,
    decimal UnitCost,
    decimal TotalCost
);

public record CreateStockAdjustmentRequest(
    string AdjustmentNumber,
    DateTime AdjustmentDate,
    Guid WarehouseId,
    int AdjustmentType,
    string Reason,
    Guid? BranchId,
    Guid? DepartmentId,
    List<CreateStockAdjustmentLineRequest> Lines
);

public record CreateStockAdjustmentLineRequest(
    Guid ItemId,
    decimal Quantity,
    decimal UnitCost
);

public record CreateStockTransferRequest(
    string? TransferNumber,
    DateTime TransferDate,
    Guid FromLocationId,
    Guid ToLocationId,
    string Notes,
    List<CreateStockTransferLineRequest> Lines
);

public record CreateStockTransferLineRequest(
    Guid ItemId,
    decimal RequestedQuantity,
    string? Notes
);

public record UpdateStockTransferRequest(
    DateTime TransferDate,
    Guid FromLocationId,
    Guid ToLocationId,
    string Notes,
    List<UpdateStockTransferLineRequest> Lines
);

public record UpdateStockTransferLineRequest(
    Guid? Id,
    Guid ItemId,
    decimal RequestedQuantity,
    string? Notes
);
