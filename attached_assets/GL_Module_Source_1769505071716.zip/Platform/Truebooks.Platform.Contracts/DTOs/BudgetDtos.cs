using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.DTOs;

public record BudgetHeaderDto(
    Guid Id,
    string BudgetCode,
    string BudgetName,
    string? Description,
    int FiscalYear,
    Guid? CostCenterId,
    string? CostCenterCode,
    string? CostCenterName,
    Guid? DepartmentId,
    string? DepartmentName,
    Guid? BranchId,
    string? BranchName,
    BudgetStatus Status,
    decimal TotalBudgetAmount,
    string? CurrencyCode,
    DateTime? EffectiveDate,
    DateTime? ExpiryDate,
    DateTime? ApprovedDate,
    string? ApprovedBy,
    string? Notes,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    IReadOnlyList<BudgetLineDto> Lines
);

public record BudgetLineDto(
    Guid Id,
    Guid BudgetHeaderId,
    Guid ChartOfAccountId,
    string? AccountCode,
    string? AccountName,
    string? LineDescription,
    decimal BudgetAmount,
    decimal Month01,
    decimal Month02,
    decimal Month03,
    decimal Month04,
    decimal Month05,
    decimal Month06,
    decimal Month07,
    decimal Month08,
    decimal Month09,
    decimal Month10,
    decimal Month11,
    decimal Month12,
    int SortOrder,
    string? Notes
);

public record CostCenterDto(
    Guid Id,
    string Code,
    string Name,
    string? Description,
    Guid? ParentId,
    string? ParentCode,
    string? ParentName,
    Guid? DepartmentId,
    Guid? BranchId,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record BudgetVarianceReportDto(
    Guid BudgetHeaderId,
    string BudgetCode,
    string BudgetName,
    int FiscalYear,
    string? CostCenterCode,
    string? CostCenterName,
    decimal TotalBudget,
    decimal TotalActual,
    decimal TotalVariance,
    decimal VariancePercent,
    IReadOnlyList<BudgetLineVarianceDto> Lines
);

public record BudgetLineVarianceDto(
    Guid BudgetLineId,
    Guid ChartOfAccountId,
    string? AccountCode,
    string? AccountName,
    string? LineDescription,
    decimal BudgetAmount,
    decimal RevisedBudget,
    decimal ActualAmount,
    decimal Variance,
    decimal VariancePercent,
    decimal UtilizationPercent,
    decimal RemainingBudget,
    IReadOnlyList<MonthlyVarianceDto> MonthlyBreakdown
);

public record MonthlyVarianceDto(
    int Month,
    string MonthName,
    decimal BudgetAmount,
    decimal ActualAmount,
    decimal Variance
);

public record BudgetCheckResultDto(
    bool IsWithinBudget,
    decimal BudgetAmount,
    decimal UsedAmount,
    decimal RemainingBudget,
    decimal ProposedAmount,
    decimal ExcessAmount,
    string? Message
);

public record CreateBudgetRequest(
    string BudgetCode,
    string BudgetName,
    string? Description,
    int FiscalYear,
    Guid? CostCenterId,
    Guid? DepartmentId,
    Guid? BranchId,
    string? CurrencyCode,
    DateTime? EffectiveDate,
    DateTime? ExpiryDate,
    string? Notes,
    IReadOnlyList<CreateBudgetLineRequest> Lines
);

public record CreateBudgetLineRequest(
    Guid ChartOfAccountId,
    string? LineDescription,
    decimal BudgetAmount,
    decimal Month01,
    decimal Month02,
    decimal Month03,
    decimal Month04,
    decimal Month05,
    decimal Month06,
    decimal Month07,
    decimal Month08,
    decimal Month09,
    decimal Month10,
    decimal Month11,
    decimal Month12,
    int SortOrder,
    string? Notes
);

public record UpdateBudgetRequest(
    string BudgetName,
    string? Description,
    Guid? CostCenterId,
    Guid? DepartmentId,
    Guid? BranchId,
    string? CurrencyCode,
    DateTime? EffectiveDate,
    DateTime? ExpiryDate,
    string? Notes,
    IReadOnlyList<CreateBudgetLineRequest> Lines
);

public record CreateCostCenterRequest(
    string Code,
    string Name,
    string? Description,
    Guid? ParentId,
    Guid? DepartmentId,
    Guid? BranchId
);

public record UpdateCostCenterRequest(
    string Name,
    string? Description,
    Guid? ParentId,
    Guid? DepartmentId,
    Guid? BranchId,
    bool IsActive
);
