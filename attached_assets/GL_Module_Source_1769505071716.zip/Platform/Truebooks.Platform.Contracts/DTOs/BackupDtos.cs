namespace Truebooks.Platform.Contracts.DTOs;

public record BackupJobDto(
    Guid Id,
    Guid TenantId,
    string Name,
    string? Description,
    string BackupType,
    string Status,
    string? FilePath,
    string? FileSizeDisplay,
    long? FileSize,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? StartedAt,
    DateTime? CompletedAt,
    bool CanDownload,
    bool CanRestore,
    List<string>? SelectedModules
);

public record RestoreJobDto(
    Guid Id,
    Guid TenantId,
    string Name,
    Guid? SourceBackupJobId,
    string? SourceBackupName,
    string RestoreMode,
    string Status,
    int TotalRecords,
    int ProcessedRecords,
    int FailedRecords,
    DateTime? StartedAt,
    DateTime? CompletedAt,
    string? ErrorMessage
);

public record BackupScheduleDto(
    Guid Id,
    Guid TenantId,
    string Name,
    string? Description,
    string Frequency,
    string BackupType,
    string ScheduledTime,
    string? DayOfWeek,
    int? DayOfMonth,
    int RetentionDays,
    bool IsActive,
    DateTime? LastRunAt,
    DateTime? NextRunAt,
    List<string>? SelectedModules
);

public record CreateBackupRequest(
    string Name,
    string? Description,
    string BackupType,
    List<string>? SelectedModules
);

public record CreateRestoreRequest(
    string Name,
    string? Description,
    Guid SourceBackupJobId,
    string RestoreMode,
    bool CreatePreRestoreBackup
);

public record CreateBackupScheduleRequest(
    string Name,
    string? Description,
    string Frequency,
    string BackupType,
    string ScheduledTime,
    string? DayOfWeek,
    int? DayOfMonth,
    int RetentionDays,
    List<string>? SelectedModules,
    bool IsActive
);

public record UpdateBackupScheduleRequest(
    string Name,
    string? Description,
    string Frequency,
    string BackupType,
    string ScheduledTime,
    string? DayOfWeek,
    int? DayOfMonth,
    int RetentionDays,
    List<string>? SelectedModules,
    bool IsActive
);
