namespace Truebooks.Platform.Contracts.DTOs;

public record DocumentCategoryDto(
    Guid Id,
    Guid TenantId,
    string Code,
    string Name,
    int CategoryType,
    bool RequiresExpiry,
    int ReminderDaysBefore,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateDocumentCategoryRequest(
    string Code,
    string Name,
    int CategoryType,
    bool RequiresExpiry,
    int ReminderDaysBefore
);

public record UpdateDocumentCategoryRequest(
    string Code,
    string Name,
    int CategoryType,
    bool RequiresExpiry,
    int ReminderDaysBefore,
    bool IsActive
);
