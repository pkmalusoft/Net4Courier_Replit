namespace Truebooks.Platform.Contracts.DTOs;

public record AlertDto(
    Guid Id,
    Guid TenantId,
    int AlertType,
    string Title,
    string? Message,
    int Priority,
    int Status,
    Guid? RelatedEntityId,
    string? RelatedEntityType,
    Guid? AssignedToUserId,
    DateTime? DueDate,
    DateTime? AcknowledgedDate,
    DateTime? ResolvedDate,
    DateTime CreatedAt
);

public record CreateAlertRequest(
    int AlertType,
    string Title,
    string? Message,
    int Priority,
    Guid? RelatedEntityId,
    string? RelatedEntityType,
    Guid? AssignedToUserId,
    DateTime? DueDate
);

public record UpdateAlertStatusRequest(
    int Status,
    DateTime? AcknowledgedDate = null,
    Guid? AcknowledgedByUserId = null,
    DateTime? ResolvedDate = null,
    Guid? ResolvedByUserId = null
);
