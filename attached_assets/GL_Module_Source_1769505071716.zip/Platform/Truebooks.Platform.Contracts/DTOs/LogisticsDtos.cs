using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.DTOs.Logistics;

public record JobWithAccrualStatusDto(
    Guid Id,
    string JobNumber,
    DateTime JobDate,
    string? CustomerName,
    string? JobTypeName,
    string? JobModeName,
    int Status,
    JobClosingStatus ClosingStatus,
    decimal? TotalEstimatedCost,
    decimal? TotalEstimatedSales,
    decimal? TotalActualCost,
    decimal? TotalActualSales,
    bool IsProvisionPosted,
    DateTime? ProvisionPostedDate,
    decimal? ProvisionalCostAmount,
    decimal? AccruedCostPayableAmount,
    bool IsRevenueRecognized,
    decimal? RecognizedRevenueAmount,
    int TotalCostLines,
    int MatchedCostLines,
    int UnmatchedCostLineCount,
    decimal? UnmatchedCostAmount
);

public record JobClosingSummaryDto(
    Guid JobId,
    string JobNumber,
    DateTime JobDate,
    string? CustomerName,
    JobClosingStatus ClosingStatus,
    decimal TotalEstimatedCost,
    decimal TotalEstimatedSales,
    decimal TotalEstimatedMargin,
    decimal TotalActualCost,
    decimal TotalActualSales,
    decimal TotalActualMargin,
    bool IsProvisionPosted,
    DateTime? ProvisionPostedDate,
    decimal ProvisionalCostAmount,
    decimal AccruedCostPayableAmount,
    decimal DeferredRevenueAmount,
    bool IsRevenueRecognized,
    DateTime? RevenueRecognizedDate,
    decimal RecognizedRevenueAmount,
    decimal RecognizedCostOfSalesAmount,
    int TotalCostLines,
    int MatchedCostLines,
    int UnmatchedCostLines,
    decimal UnmatchedCostAmount,
    decimal VarianceAmount,
    bool CanClose,
    string? CannotCloseReason,
    List<CostLineMatchingStatusDto> CostLines
);

public record CostLineMatchingStatusDto(
    Guid Id,
    int LineNumber,
    string Description,
    string? SupplierName,
    string? ChargeTypeName,
    decimal CostAmount,
    CostLineMatchingStatus MatchingStatus,
    bool IsProvisioned,
    decimal? ProvisionedAmount,
    DateTime? ProvisionedDate,
    bool IsMatched,
    Guid? VendorInvoiceId,
    string? VendorInvoiceNumber,
    DateTime? MatchedDate,
    decimal? MatchedAmount,
    decimal? VarianceAmount
);

public record MonthEndAccrualRequest(
    DateTime PeriodEndDate,
    Guid FinancialPeriodId,
    List<Guid>? JobIds = null,
    bool IncludeAllOpenJobs = true,
    string? Notes = null
);

public record MonthEndAccrualResultDto(
    bool Success,
    string? ErrorMessage,
    int JobsProcessed,
    int CostLinesProvisioned,
    decimal TotalProvisionalCost,
    decimal TotalAccruedCostPayable,
    List<JobAccrualResultDto> JobResults
);

public record JobAccrualResultDto(
    Guid JobId,
    string JobNumber,
    bool Success,
    string? ErrorMessage,
    int CostLinesProvisioned,
    decimal ProvisionalCostAmount,
    decimal AccruedCostPayableAmount,
    Guid? JournalEntryId,
    string? JournalEntryNumber
);

public record VendorInvoiceMatchRequest(
    Guid JobId,
    Guid CostLineId,
    Guid VendorInvoiceId,
    string? VendorInvoiceNumber,
    decimal InvoiceAmount,
    DateTime InvoiceDate,
    Guid FinancialPeriodId,
    bool AllowVariance = false,
    decimal? MaxVariancePercent = null,
    string? Notes = null
);

public record CostLineMatchResultDto(
    bool Success,
    string? ErrorMessage,
    Guid CostLineId,
    CostLineMatchingStatus NewStatus,
    decimal ProvisionedAmount,
    decimal MatchedAmount,
    decimal VarianceAmount,
    Guid? JournalEntryId,
    string? JournalEntryNumber
);

public record JobCloseRequest(
    Guid JobId,
    DateTime CloseDate,
    Guid FinancialPeriodId,
    bool ForceClose = false,
    decimal? VarianceTolerance = null,
    string? ClosingNotes = null
);

public record JobCloseResultDto(
    bool Success,
    string? ErrorMessage,
    Guid JobId,
    string JobNumber,
    JobClosingStatus NewStatus,
    bool RevenueRecognized,
    decimal RecognizedRevenueAmount,
    decimal RecognizedCostOfSalesAmount,
    decimal FinalMargin,
    decimal FinalVariance,
    Guid? RevenueJournalEntryId,
    string? RevenueJournalEntryNumber,
    List<string> Warnings
);

public record RevenueRecognitionRequest(
    Guid JobId,
    DateTime RecognitionDate,
    Guid FinancialPeriodId,
    string? Notes = null
);

public record RevenueRecognitionResultDto(
    bool Success,
    string? ErrorMessage,
    Guid JobId,
    decimal DeferredRevenueAmount,
    decimal RecognizedRevenueAmount,
    Guid? JournalEntryId,
    string? JournalEntryNumber
);

public record JobClosingEntryDto(
    Guid Id,
    Guid JobId,
    string JobNumber,
    JobClosingEntryType EntryType,
    DateTime EntryDate,
    string? FinancialPeriodName,
    string? JournalEntryNumber,
    string? DebitAccountCode,
    string? DebitAccountName,
    decimal DebitAmount,
    string? CreditAccountCode,
    string? CreditAccountName,
    decimal CreditAmount,
    Guid? JobCostLineId,
    string? VendorInvoiceNumber,
    string? Description,
    bool IsReversed,
    DateTime? ReversedDate,
    DateTime CreatedAt,
    string? CreatedByUserName
);

public record OpenProvisionsReportDto(
    DateTime AsOfDate,
    decimal TotalProvisionalCost,
    decimal TotalAccruedCostPayable,
    int TotalJobsWithProvisions,
    int TotalUnmatchedCostLines,
    List<JobProvisionSummaryDto> JobProvisions
);

public record JobProvisionSummaryDto(
    Guid JobId,
    string JobNumber,
    DateTime JobDate,
    string? CustomerName,
    DateTime? ProvisionPostedDate,
    decimal ProvisionalCostAmount,
    decimal AccruedCostPayableAmount,
    int TotalCostLines,
    int MatchedCostLines,
    int UnmatchedCostLines,
    decimal UnmatchedCostAmount,
    int DaysOutstanding
);

public record DeferredRevenueReportDto(
    DateTime AsOfDate,
    decimal TotalDeferredRevenue,
    int TotalJobsWithDeferredRevenue,
    List<JobDeferredRevenueSummaryDto> JobDeferredRevenues
);

public record JobDeferredRevenueSummaryDto(
    Guid JobId,
    string JobNumber,
    DateTime JobDate,
    string? CustomerName,
    decimal DeferredRevenueAmount,
    decimal EstimatedSales,
    decimal ActualSales,
    bool IsRevenueRecognized,
    DateTime? RevenueRecognizedDate,
    JobClosingStatus ClosingStatus,
    int DaysOutstanding
);

public record JobProfitabilityReportDto(
    Guid JobId,
    string JobNumber,
    DateTime JobDate,
    string? CustomerName,
    string? JobTypeName,
    string? JobModeName,
    JobClosingStatus ClosingStatus,
    decimal EstimatedCost,
    decimal EstimatedSales,
    decimal EstimatedMargin,
    decimal EstimatedMarginPercent,
    decimal ActualCost,
    decimal ActualSales,
    decimal ActualMargin,
    decimal ActualMarginPercent,
    decimal VarianceAmount,
    decimal VariancePercent,
    bool IsProvisionPosted,
    decimal ProvisionalCostAmount,
    bool IsRevenueRecognized,
    decimal RecognizedRevenueAmount,
    decimal RecognizedCostOfSalesAmount,
    List<CostLineDetailDto> CostLineDetails
);

public record CostLineDetailDto(
    Guid Id,
    int LineNumber,
    string Description,
    string? SupplierName,
    string? ChargeTypeName,
    decimal EstimatedCost,
    decimal ActualCost,
    decimal SalesAmount,
    decimal Margin,
    CostLineMatchingStatus MatchingStatus,
    bool IsProvisioned,
    decimal? ProvisionedAmount,
    bool IsMatched,
    string? VendorInvoiceNumber,
    decimal? MatchedAmount,
    decimal? VarianceAmount
);
