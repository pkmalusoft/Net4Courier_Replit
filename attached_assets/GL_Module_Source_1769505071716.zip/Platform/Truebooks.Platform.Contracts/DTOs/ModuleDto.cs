namespace Truebooks.Platform.Contracts.DTOs;

public record ModuleDto(
    Guid Id,
    string Name,
    string Code,
    string? Description,
    bool IsActive,
    string? Icon,
    int DisplayOrder
);

public record CustomerModuleAssignmentDto(
    Guid CustomerId,
    List<Guid> ModuleIds
);

public record SupplierModuleAssignmentDto(
    Guid SupplierId,
    List<Guid> ModuleIds
);
