using Truebooks.Platform.Contracts.Services;

namespace Truebooks.Platform.Contracts.DTOs;

public record AccountDto(
    Guid Id,
    Guid TenantId,
    string Code,
    string Name,
    AccountType Type,
    Guid? ParentAccountId,
    string? ParentAccountCode,
    bool IsActive,
    bool IsSystemAccount,
    int Level
);
