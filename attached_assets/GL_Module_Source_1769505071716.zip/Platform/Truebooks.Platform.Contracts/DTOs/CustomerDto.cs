namespace Truebooks.Platform.Contracts.DTOs;

public enum CustomerType
{
    Cash = 0,
    Credit = 1
}

public enum CreditApprovalStatus
{
    None = 0,
    Pending = 1,
    Approved = 2,
    Rejected = 3
}

public record CustomerDto(
    Guid Id,
    Guid TenantId,
    Guid? BranchId,
    string? BranchName,
    string CustomerCode,
    string Name,
    string? ContactName,
    string? Address,
    Guid? CountryId,
    string? CountryName,
    Guid? StateId,
    string? StateName,
    Guid? CityId,
    string? CityName,
    Guid? PostalCodeId,
    string? PostalCode,
    string Email,
    string Phone,
    string? TaxIdNumber,
    Guid? DefaultCurrencyId,
    string? DefaultCurrencyCode,
    Guid? PreferredCurrencyId,
    string? PreferredCurrencyCode,
    Guid? DefaultARAccountId,
    string? DefaultARAccountName,
    CustomerType CustomerType,
    Guid? CustomerCategoryId,
    string? CustomerCategoryName,
    decimal CreditLimit,
    decimal RequestedCreditLimit,
    CreditApprovalStatus CreditApprovalStatus,
    string? CreditRequestNotes,
    string? CreditApprovalNotes,
    int PaymentTermsDays,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? UpdatedAt
)
{
    public string CustomerTypeDisplay => CustomerType == CustomerType.Cash ? "Cash" : "Credit";
    public string CreditStatusDisplay => CreditApprovalStatus switch
    {
        CreditApprovalStatus.None => "None",
        CreditApprovalStatus.Pending => "Pending",
        CreditApprovalStatus.Approved => "Approved",
        CreditApprovalStatus.Rejected => "Rejected",
        _ => "Unknown"
    };
}

public record CreateCustomerRequest(
    Guid? BranchId,
    string CustomerCode,
    string Name,
    string? ContactName,
    string? Address,
    Guid? CountryId,
    Guid? StateId,
    Guid? CityId,
    Guid? PostalCodeId,
    string Email,
    string Phone,
    string? TaxIdNumber,
    Guid? DefaultCurrencyId,
    Guid? PreferredCurrencyId,
    Guid? DefaultARAccountId,
    CustomerType CustomerType,
    Guid? CustomerCategoryId,
    decimal CreditLimit,
    int PaymentTermsDays,
    bool IsActive = true
);

public record UpdateCustomerRequest(
    Guid? BranchId,
    string CustomerCode,
    string Name,
    string? ContactName,
    string? Address,
    Guid? CountryId,
    Guid? StateId,
    Guid? CityId,
    Guid? PostalCodeId,
    string Email,
    string Phone,
    string? TaxIdNumber,
    Guid? DefaultCurrencyId,
    Guid? PreferredCurrencyId,
    Guid? DefaultARAccountId,
    CustomerType CustomerType,
    Guid? CustomerCategoryId,
    decimal CreditLimit,
    int PaymentTermsDays,
    bool IsActive
);

public record RequestCreditLimitRequest(
    decimal RequestedCreditLimit,
    string? Notes
);

public record ApproveCreditLimitRequest(
    bool Approved,
    decimal? ApprovedLimit,
    string? Notes
);
