namespace Truebooks.Platform.Contracts.DTOs;

public record CourierDashboardDto(
    int TotalShipments,
    int DeliveredCount,
    int InTransitCount,
    int OutForDeliveryCount,
    int RtoCount,
    int HubCount,
    int DrsCount,
    int ActiveAgents,
    int TotalAgents,
    decimal CodCollected,
    decimal TotalRevenue,
    int CodPendingCount,
    double DeliveryRate,
    double RtoRate,
    int PendingPickupCount,
    int PendingInscanCount,
    int UnassignedDrsCount,
    int PendingManifestCount,
    List<StatusDistributionItemDto> StatusDistribution,
    List<ZoneDistributionItemDto> ZoneDistribution,
    List<ServiceTypeDistributionItemDto> ServiceTypeDistribution,
    ShipmentTrendDataDto TrendData,
    List<RecentShipmentItemDto> RecentShipments,
    List<TopAgentItemDto> TopAgents
);

public record StatusDistributionItemDto(string Status, int Count);
public record ZoneDistributionItemDto(string ZoneName, int Count);
public record ServiceTypeDistributionItemDto(string ServiceType, int Count);

public record ShipmentTrendDataDto(
    List<string> Labels,
    List<int> BookedData,
    List<int> DeliveredData
);

public record RecentShipmentItemDto(
    Guid Id,
    string AWBNumber,
    string Status,
    string SenderName,
    string ReceiverName,
    string ReceiverCity,
    string DestinationCity,
    string ServiceType,
    DateTime BookingDate,
    string? AssignedAgentName
);

public record TopAgentItemDto(
    Guid Id,
    string Name,
    int ShipmentCount,
    double DeliveryRate,
    decimal Revenue
);
