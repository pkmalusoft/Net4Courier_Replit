namespace Truebooks.Platform.Contracts.DTOs;

public record DocumentDto(
    Guid Id,
    Guid TenantId,
    Guid CategoryId,
    string? CategoryName,
    int DocumentType,
    Guid? RelatedEntityId,
    string DocumentName,
    string? Description,
    string? FileName,
    string? FilePath,
    string? FileType,
    long? FileSize,
    DateTime? IssueDate,
    DateTime? ExpiryDate,
    bool IsExpired,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateDocumentRequest(
    Guid CategoryId,
    int DocumentType,
    Guid? RelatedEntityId,
    string DocumentName,
    string? Description,
    string? FileName,
    string? FilePath,
    string? FileType,
    long? FileSize,
    DateTime? IssueDate,
    DateTime? ExpiryDate
);

public record UpdateDocumentRequest(
    Guid CategoryId,
    int DocumentType,
    Guid? RelatedEntityId,
    string DocumentName,
    string? Description,
    string? FileName,
    string? FilePath,
    string? FileType,
    long? FileSize,
    DateTime? IssueDate,
    DateTime? ExpiryDate,
    bool IsActive
);
