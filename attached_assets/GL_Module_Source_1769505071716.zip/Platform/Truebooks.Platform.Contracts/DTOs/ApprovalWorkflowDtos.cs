namespace Truebooks.Platform.Contracts.DTOs;

public record ApprovalWorkflowDto(
    Guid Id,
    Guid TenantId,
    int WorkflowType,
    string Name,
    string? Description,
    bool IsActive,
    bool RequireAllApprovers,
    int StepsCount,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateApprovalWorkflowRequest(
    int WorkflowType,
    string Name,
    string? Description,
    bool RequireAllApprovers,
    bool IsActive = true
);

public record UpdateApprovalWorkflowRequest(
    int WorkflowType,
    string Name,
    string? Description,
    bool RequireAllApprovers,
    bool IsActive
);

public record ApprovalStepDto(
    Guid Id,
    Guid WorkflowId,
    int StepOrder,
    string StepName,
    Guid? ApproverUserId,
    string? ApproverUserName,
    Guid? ApproverRoleId,
    string? ApproverRoleName,
    bool CanDelegate,
    int? TimeoutHours,
    bool IsActive
);

public record CreateApprovalStepRequest(
    int StepOrder,
    string StepName,
    Guid? ApproverUserId,
    Guid? ApproverRoleId,
    bool CanDelegate,
    int? TimeoutHours,
    bool IsActive = true
);

public record UpdateApprovalStepRequest(
    int StepOrder,
    string StepName,
    Guid? ApproverUserId,
    Guid? ApproverRoleId,
    bool CanDelegate,
    int? TimeoutHours,
    bool IsActive
);
