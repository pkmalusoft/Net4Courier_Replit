using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.DTOs;

public record ServiceCategoryDto(
    Guid Id,
    Guid TenantId,
    string Code,
    string Name,
    string? Description,
    CatalogItemType ItemType,
    bool IsActive,
    int SortOrder,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record ServiceCategoryDetailDto(
    Guid Id,
    Guid TenantId,
    string Code,
    string Name,
    string? Description,
    CatalogItemType ItemType,
    bool IsActive,
    int SortOrder,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    List<ServiceTypeDto> ServiceTypes
);

public record CreateServiceCategoryRequest(
    string Code,
    string Name,
    string? Description,
    CatalogItemType ItemType,
    int SortOrder
);

public record UpdateServiceCategoryRequest(
    string Code,
    string Name,
    string? Description,
    CatalogItemType ItemType,
    int SortOrder,
    bool IsActive
);

public record ServiceTypeDto(
    Guid Id,
    Guid TenantId,
    Guid ServiceCategoryId,
    string? ServiceCategoryName,
    string Code,
    string Name,
    string? Description,
    bool IsActive,
    int SortOrder,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record ServiceTypeDetailDto(
    Guid Id,
    Guid TenantId,
    Guid ServiceCategoryId,
    string? ServiceCategoryName,
    string Code,
    string Name,
    string? Description,
    bool IsActive,
    int SortOrder,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    List<ServiceNameDto> ServiceNames
);

public record CreateServiceTypeRequest(
    Guid ServiceCategoryId,
    string Code,
    string Name,
    string? Description,
    int SortOrder
);

public record UpdateServiceTypeRequest(
    Guid ServiceCategoryId,
    string Code,
    string Name,
    string? Description,
    int SortOrder,
    bool IsActive
);

public record ServiceNameDto(
    Guid Id,
    Guid TenantId,
    Guid ServiceTypeId,
    string? ServiceTypeName,
    string Code,
    string Name,
    string? Description,
    bool IsActive,
    int SortOrder,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record ServiceNameDetailDto(
    Guid Id,
    Guid TenantId,
    Guid ServiceTypeId,
    string? ServiceTypeName,
    string Code,
    string Name,
    string? Description,
    bool IsActive,
    int SortOrder,
    DateTime CreatedAt,
    DateTime? UpdatedAt,
    List<ServiceDetailDto> ServiceDetails
);

public record CreateServiceNameRequest(
    Guid ServiceTypeId,
    string Code,
    string Name,
    string? Description,
    int SortOrder
);

public record UpdateServiceNameRequest(
    Guid ServiceTypeId,
    string Code,
    string Name,
    string? Description,
    int SortOrder,
    bool IsActive
);

public record ServiceDetailDto(
    Guid Id,
    Guid TenantId,
    Guid ServiceNameId,
    string? ServiceName,
    string Code,
    string Name,
    string? Description,
    string? UnitOfMeasure,
    decimal? DefaultRate,
    bool IsActive,
    int SortOrder,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateServiceDetailRequest(
    Guid ServiceNameId,
    string Code,
    string Name,
    string? Description,
    string? UnitOfMeasure,
    decimal? DefaultRate,
    int SortOrder
);

public record UpdateServiceDetailRequest(
    Guid ServiceNameId,
    string Code,
    string Name,
    string? Description,
    string? UnitOfMeasure,
    decimal? DefaultRate,
    int SortOrder,
    bool IsActive
);

public enum RateTypeDto
{
    Retail = 0,
    Wholesale = 1,
    Special = 2
}

public enum RecurringTypeDto
{
    OneTime = 0,
    Hourly = 1,
    Daily = 2,
    Weekly = 3,
    Monthly = 4,
    Yearly = 5
}

public record RateChartDto(
    Guid Id,
    Guid TenantId,
    Guid ServiceDetailId,
    string? ServiceDetailName,
    string? ServiceNameName,
    string? ServiceTypeName,
    string? ServiceCategoryName,
    string Code,
    string Name,
    string? Description,
    RateTypeDto RateType,
    RecurringTypeDto RecurringType,
    Guid? CurrencyId,
    string? CurrencyCode,
    string? CurrencySymbol,
    decimal CostPrice,
    decimal SellingPrice,
    decimal? MinQuantity,
    decimal? MaxQuantity,
    DateTime? EffectiveFrom,
    DateTime? EffectiveTo,
    bool IsActive,
    int SortOrder,
    DateTime CreatedAt,
    DateTime? UpdatedAt
);

public record CreateRateChartRequest(
    Guid ServiceDetailId,
    string Code,
    string Name,
    string? Description,
    RateTypeDto RateType,
    RecurringTypeDto RecurringType,
    Guid? CurrencyId,
    decimal CostPrice,
    decimal SellingPrice,
    decimal? MinQuantity,
    decimal? MaxQuantity,
    DateTime? EffectiveFrom,
    DateTime? EffectiveTo,
    int SortOrder
);

public record UpdateRateChartRequest(
    Guid ServiceDetailId,
    string Code,
    string Name,
    string? Description,
    RateTypeDto RateType,
    RecurringTypeDto RecurringType,
    Guid? CurrencyId,
    decimal CostPrice,
    decimal SellingPrice,
    decimal? MinQuantity,
    decimal? MaxQuantity,
    DateTime? EffectiveFrom,
    DateTime? EffectiveTo,
    int SortOrder,
    bool IsActive
);
