# Truebooks.Platform.Contracts

Shared interfaces, DTOs, and events for TruebooksERP modules.

## Overview

This package contains the contract definitions that enable communication between the Platform and vertical modules (Courier, Ecommerce, HRPayroll, Logistics, etc.).

## Key Interfaces

- `ITenantEntity` - Base interface for multi-tenant entities
- `IModuleManifest` - Module registration contract with routes and menu items
- `IModuleRegistry` - Runtime module registration service

## Installation

```bash
dotnet add package Truebooks.Platform.Contracts
```

## Usage

```csharp
public class Product : ITenantEntity
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Name { get; set; }
}
```

## Version History

- 1.0.0 - Initial release with core interfaces
