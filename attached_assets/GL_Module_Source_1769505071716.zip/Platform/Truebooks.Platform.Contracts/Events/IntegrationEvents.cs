namespace Truebooks.Platform.Contracts.Events;

public interface IIntegrationEvent
{
    Guid EventId { get; }
    Guid TenantId { get; }
    DateTime OccurredOn { get; }
    string EventType { get; }
}

public abstract record IntegrationEventBase : IIntegrationEvent
{
    public Guid EventId { get; init; } = Guid.NewGuid();
    public required Guid TenantId { get; init; }
    public DateTime OccurredOn { get; init; } = DateTime.UtcNow;
    public abstract string EventType { get; }
}

public record InvoicePostedEvent : IntegrationEventBase
{
    public override string EventType => "Invoice.Posted";
    public required Guid InvoiceId { get; init; }
    public required string InvoiceNumber { get; init; }
    public required decimal TotalAmount { get; init; }
    public required Guid CustomerId { get; init; }
    public required string SourceModule { get; init; }
}

public record PaymentReceivedEvent : IntegrationEventBase
{
    public override string EventType => "Payment.Received";
    public required Guid PaymentId { get; init; }
    public required string PaymentNumber { get; init; }
    public required decimal Amount { get; init; }
    public required Guid CustomerId { get; init; }
    public required string SourceModule { get; init; }
}

public record ShipmentCreatedEvent : IntegrationEventBase
{
    public override string EventType => "Shipment.Created";
    public required Guid ShipmentId { get; init; }
    public required string AWBNumber { get; init; }
    public required Guid CustomerId { get; init; }
    public required decimal DeclaredValue { get; init; }
}

public record OrderCreatedEvent : IntegrationEventBase
{
    public override string EventType => "Order.Created";
    public required Guid OrderId { get; init; }
    public required string OrderNumber { get; init; }
    public required Guid CustomerId { get; init; }
    public required decimal TotalAmount { get; init; }
}
