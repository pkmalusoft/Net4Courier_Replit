using Microsoft.Extensions.DependencyInjection;

namespace Truebooks.Platform.Contracts.Modules;

public interface IModuleManifest
{
    string Code { get; }
    string Name { get; }
    string Version { get; }
    string Description { get; }
    string[] Dependencies { get; }
    string[] Routes { get; }
    MenuItem[] MenuItems { get; }
    
    void ConfigureServices(IServiceCollection services);
}

public record MenuItem(
    string Title,
    string Icon,
    string Route,
    string[] RequiredPermissions
);
