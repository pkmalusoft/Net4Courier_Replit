namespace Truebooks.Platform.Contracts.MultiTenancy;

public interface ITenantEntity
{
    Guid TenantId { get; set; }
}
