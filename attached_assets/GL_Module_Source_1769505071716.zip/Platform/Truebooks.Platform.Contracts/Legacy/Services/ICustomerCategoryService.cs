using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Platform.Contracts.Legacy.Services;

public interface ICustomerCategoryService
{
    Task<List<CustomerCategory>> GetAllAsync();
    Task<CustomerCategory?> GetByIdAsync(Guid id);
    Task<Guid> CreateAsync(CustomerCategory category);
    Task UpdateAsync(Guid id, CustomerCategory category);
    Task DeleteAsync(Guid id);
}
