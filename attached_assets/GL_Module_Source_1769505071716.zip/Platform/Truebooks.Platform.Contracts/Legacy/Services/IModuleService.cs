namespace Truebooks.Platform.Contracts.Legacy.Services;

public interface IModuleService
{
    Task<List<ModuleDto>> GetAllAsync();
    Task<List<Guid>> GetCustomerModulesAsync(Guid customerId);
    Task<List<Guid>> GetSupplierModulesAsync(Guid supplierId);
    Task UpdateCustomerModulesAsync(Guid customerId, List<Guid> moduleIds);
    Task UpdateSupplierModulesAsync(Guid supplierId, List<Guid> moduleIds);
}

public class ModuleDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Icon { get; set; }
    public int DisplayOrder { get; set; }
}
