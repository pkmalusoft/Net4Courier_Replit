using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Platform.Contracts.Legacy.Services;

public interface ISupplierService
{
    Task<List<Supplier>> GetAllAsync();
    Task<Supplier?> GetByIdAsync(Guid id);
    Task<Guid> CreateAsync(Supplier supplier);
    Task UpdateAsync(Guid id, Supplier supplier);
    Task DeleteAsync(Guid id, string reason);
    Task RequestCreditAsync(Guid id, decimal limit, string notes);
    Task ApproveCreditAsync(Guid id, decimal approvedLimit, string notes);
    Task RejectCreditAsync(Guid id, string notes);
    Task<List<SupplierCreditApprovalHistory>> GetCreditHistoryAsync(Guid id);
    Task<List<Supplier>> GetPendingCreditApprovalsAsync();
}

public interface ISupplierCategoryService
{
    Task<List<SupplierCategory>> GetAllAsync();
    Task<SupplierCategory?> GetByIdAsync(Guid id);
    Task<Guid> CreateAsync(SupplierCategory category);
    Task UpdateAsync(Guid id, SupplierCategory category);
    Task DeleteAsync(Guid id);
}
