namespace Truebooks.Platform.Contracts.Legacy.Services;

public interface ISystemDiagnosticsHubService
{
    event Action<SystemMetrics>? OnMetricsReceived;
    event Action<GcResult>? OnGcResultReceived;
    event Action<string>? OnGcError;
    event Action? OnConnected;
    event Action<string?>? OnDisconnected;
    event Action<string?>? OnReconnecting;
    event Action<string?>? OnReconnected;

    Task StartAsync(string? accessToken = null, CancellationToken cancellationToken = default);
    Task StopAsync();
    Task RequestMetricsAsync();
    Task TriggerGarbageCollectionAsync();
}

public class SystemMetrics
{
    public ApplicationInfo ApplicationInfo { get; set; } = new();
    public DatabaseHealth DatabaseHealth { get; set; } = new();
    public ResourceUsage ResourceUsage { get; set; } = new();
    public SystemConfiguration Configuration { get; set; } = new();
}

public class ApplicationInfo
{
    public string Name { get; set; } = "Truebooks ERP";
    public string Version { get; set; } = "1.0.0";
    public string Environment { get; set; } = "Development";
    public string DeploymentMode { get; set; } = "Single";
    public bool RlsEnabled { get; set; } = true;
    public TimeSpan Uptime { get; set; }
}

public class DatabaseHealth
{
    public bool IsConnected { get; set; }
    public string PostgresVersion { get; set; } = string.Empty;
    public int LatencyMs { get; set; }
    public string Size { get; set; } = string.Empty;
    public int ActiveConnections { get; set; }
    public int MaxConnections { get; set; }
    public int PoolUtilization { get; set; }
}

public class ResourceUsage
{
    public long WorkingSetMB { get; set; }
    public long PrivateMemoryMB { get; set; }
    public long GcTotalMemoryMB { get; set; }
    public int GcGen0Collections { get; set; }
    public int GcGen1Collections { get; set; }
    public int GcGen2Collections { get; set; }
    public int ThreadCount { get; set; }
    public int HandleCount { get; set; }
    public double CpuTimeSeconds { get; set; }
    public long VirtualMemoryMB { get; set; }
}

public class SystemConfiguration
{
    public string TenancyMode { get; set; } = "Multi-Tenant";
    public bool RlsEnabled { get; set; } = true;
    public bool PartitioningEnabled { get; set; } = false;
    public bool AutoArchivalEnabled { get; set; } = false;
    public int HotDataYears { get; set; } = 3;
    public FeatureFlags Features { get; set; } = new();
}

public class FeatureFlags
{
    public bool SignalR { get; set; } = true;
    public bool BankReconciliation { get; set; } = true;
    public bool MultiCurrency { get; set; } = true;
    public bool MultiBranch { get; set; } = true;
    public bool AdvancedSecurity { get; set; } = true;
    public bool AuditLogs { get; set; } = true;
    public bool ReportExport { get; set; } = true;
}

public class GcResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public long MemoryBeforeMB { get; set; }
    public long MemoryAfterMB { get; set; }
    public long MemoryFreedMB { get; set; }
    public long MemoryFreedBytes { get; set; }
    public int DurationMs { get; set; }
}
