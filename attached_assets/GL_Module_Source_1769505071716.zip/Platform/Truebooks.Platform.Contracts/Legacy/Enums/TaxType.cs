namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum TaxType
{
    Simple = 1,
    GST = 2,
    VAT = 3,
    USSalesTax = 4
}
