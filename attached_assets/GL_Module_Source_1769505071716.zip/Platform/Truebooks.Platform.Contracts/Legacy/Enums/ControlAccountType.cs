namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum ControlAccountType
{
    None,
    AccountsReceivable,
    AccountsPayable,
    Inventory,
    CostOfGoodsSold,
    RetainedEarnings,
    OpeningBalanceEquity
}
