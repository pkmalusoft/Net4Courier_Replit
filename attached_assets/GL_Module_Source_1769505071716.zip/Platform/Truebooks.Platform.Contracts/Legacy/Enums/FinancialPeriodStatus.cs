namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum FinancialPeriodStatus
{
    NotOpened = 0,
    Open = 1,
    SoftClosed = 2,
    HardClosed = 3,
    Archived = 4
}
