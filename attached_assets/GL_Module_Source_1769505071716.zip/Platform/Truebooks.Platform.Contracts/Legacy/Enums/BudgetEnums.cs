using System.Text.Json.Serialization;

namespace Truebooks.Platform.Contracts.Legacy.Enums;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum BudgetStatus
{
    Draft = 0,
    PendingApproval = 1,
    Approved = 2,
    Active = 3,
    Closed = 4,
    Rejected = 5,
    Voided = 6
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum BudgetRevisionStatus
{
    Original = 0,
    Revised = 1
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum BudgetTransferStatus
{
    Pending = 0,
    Approved = 1,
    Rejected = 2
}
