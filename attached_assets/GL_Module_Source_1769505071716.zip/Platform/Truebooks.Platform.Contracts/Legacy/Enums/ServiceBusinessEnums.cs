namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum EnquirySource
{
    Website = 0,
    Referral = 1,
    SocialMedia = 2,
    ColdCall = 3,
    Email = 4,
    Exhibition = 5,
    Partner = 6,
    Other = 7
}

public enum EnquiryStatus
{
    New = 0,
    Contacted = 1,
    Qualified = 2,
    ProposalSent = 3,
    Negotiation = 4,
    Won = 5,
    Lost = 6,
    Converted = 7
}

public enum RequirementType
{
    NewWebsite = 0,
    WebsiteRedesign = 1,
    MobileApp = 2,
    SEORetainer = 3,
    SocialMediaManagement = 4,
    DigitalMarketing = 5,
    ContentCreation = 6,
    BrandingDesign = 7,
    AMC = 8,
    Consulting = 9,
    SoftwareDevelopment = 10,
    CloudServices = 11,
    Other = 99
}

public enum QuotationStatus
{
    Draft = 0,
    Sent = 1,
    UnderReview = 2,
    Revised = 3,
    Accepted = 4,
    Rejected = 5,
    Expired = 6,
    ConvertedToContract = 7
}

public enum PricingType
{
    FixedCost = 0,
    HourlyRate = 1,
    MonthlyRetainer = 2,
    Milestone = 3,
    PerUnit = 4
}

public enum ContractStatus
{
    Draft = 0,
    Active = 1,
    OnHold = 2,
    Completed = 3,
    Cancelled = 4,
    Expired = 5,
    Renewed = 6,
    Invoiced = 7
}

public enum ContractType
{
    OneTime = 0,
    AMC = 1,
    Retainer = 2,
    SLA = 3,
    Subscription = 4
}

public enum BillingFrequency
{
    OneTime = 0,
    Weekly = 1,
    Monthly = 2,
    Quarterly = 3,
    HalfYearly = 4,
    Yearly = 5
}

public enum ServiceTaskStatus
{
    Pending = 0,
    InProgress = 1,
    Completed = 2,
    OnHold = 3,
    Cancelled = 4
}

public enum TimesheetApprovalStatus
{
    Pending = 0,
    Approved = 1,
    Rejected = 2
}

public enum TaskPriority
{
    Low = 0,
    Medium = 1,
    High = 2,
    Urgent = 3
}

public enum SocialPlatform
{
    Instagram = 0,
    Facebook = 1,
    Twitter = 2,
    LinkedIn = 3,
    YouTube = 4,
    TikTok = 5,
    Pinterest = 6,
    GoogleAds = 7,
    MetaAds = 8,
    Website = 9
}

public enum SocialContentType
{
    Post = 0,
    Reel = 1,
    Story = 2,
    Video = 3,
    Blog = 4,
    Infographic = 5,
    Carousel = 6,
    Ad = 7,
    Email = 8
}

public enum ReportPeriodType
{
    Weekly = 0,
    Monthly = 1,
    Quarterly = 2,
    Custom = 3
}

public enum CampaignType
{
    EmailMarketing = 0,
    SocialMedia = 1,
    PaidAds = 2,
    ContentMarketing = 3,
    SEO = 4,
    Events = 5,
    Referral = 6,
    Partnership = 7,
    Other = 99
}

public enum CampaignStatus
{
    Draft = 0,
    Active = 1,
    Paused = 2,
    Completed = 3,
    Cancelled = 4
}

public enum ClientReportStatus
{
    Draft = 0,
    Pending = 1,
    Sent = 2,
    Acknowledged = 3
}

public enum EmployeeType
{
    Regular = 0,
    Hired = 1,
    Freelancer = 2,
    Contractor = 3
}

public enum PaymentType
{
    Monthly = 0,
    Hourly = 1,
    Lumpsum = 2
}
