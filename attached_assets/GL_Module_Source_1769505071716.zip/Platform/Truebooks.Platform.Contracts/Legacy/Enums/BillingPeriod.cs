namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum BillingPeriod
{
    PerHour = 1,
    PerDay = 2,
    PerMonth = 3,
    PerYear = 4,
    Lumpsum = 5
}
