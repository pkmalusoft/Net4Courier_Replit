namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum ModuleAccessLevel
{
    None = 0,
    ReadOnly = 1,
    Full = 2
}
