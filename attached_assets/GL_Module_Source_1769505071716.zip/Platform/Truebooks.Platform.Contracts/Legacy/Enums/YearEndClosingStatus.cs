namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum YearEndClosingStatus
{
    Draft = 0,
    Validated = 1,
    IncomeExpenseClosed = 2,
    SubledgersSnapshotted = 3,
    InventorySnapshotted = 4,
    OpeningJEGenerated = 5,
    Completed = 6,
    RolledBack = 7
}
