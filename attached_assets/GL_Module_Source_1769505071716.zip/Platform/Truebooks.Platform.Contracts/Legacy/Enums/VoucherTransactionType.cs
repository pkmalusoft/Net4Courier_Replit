namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum VoucherTransactionType
{
    CashBankTransaction,
    JournalEntry,
    SalesInvoice,
    CashInvoice,
    ProformaInvoice,
    PurchaseBill,
    PurchaseOrder,
    PurchaseEnquiry,
    PurchaseQuotation,
    SalesOrder,
    SalesEnquiry,
    SalesQuotation,
    SalesOrderRequest,
    GoodsReceivedNote,
    DeliveryNote,
    SalesReturn,
    StockTransfer,
    YearEndClosing,
    AWB,
    PickupRequest,
    DeliveryRunSheet
}
