namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum SerialStatus
{
    InStock = 1,
    Reserved = 2,
    Sold = 3,
    Returned = 4,
    InTransit = 5,
    Damaged = 6,
    Defective = 7,
    WrittenOff = 8
}
