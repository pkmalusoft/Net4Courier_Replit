namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum SalesEnquiryStatus
{
    Draft = 0,
    Submitted = 1,
    Converted = 2,
    Cancelled = 3
}
