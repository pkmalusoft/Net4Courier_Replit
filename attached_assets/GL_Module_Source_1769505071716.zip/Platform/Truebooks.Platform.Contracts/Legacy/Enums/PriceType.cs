namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum PriceType
{
    Retail = 1,
    Wholesale = 2,
    Special = 3,
    Custom = 4
}
