namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum SalesOrderRequestStatus
{
    Draft,
    Submitted,
    Approved,
    Rejected,
    Converted,
    Cancelled
}
