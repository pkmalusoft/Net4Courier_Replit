namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum ItemType
{
    Product = 1,
    Service = 2
}
