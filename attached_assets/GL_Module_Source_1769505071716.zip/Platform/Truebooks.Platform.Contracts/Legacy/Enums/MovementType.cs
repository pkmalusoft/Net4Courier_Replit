namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum MovementType
{
    PurchaseReceipt = 1,
    TransferIn = 2,
    TransferOut = 3,
    SaleIssue = 4,
    ReturnIn = 5,
    ReturnOut = 6,
    AdjustmentGain = 7,
    AdjustmentLoss = 8,
    WarrantySwap = 9
}
