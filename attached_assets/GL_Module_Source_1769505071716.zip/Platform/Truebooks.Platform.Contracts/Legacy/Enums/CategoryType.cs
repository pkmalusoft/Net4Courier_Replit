namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum CategoryType
{
    Product = 1,
    Service = 2,
    Both = 3
}
