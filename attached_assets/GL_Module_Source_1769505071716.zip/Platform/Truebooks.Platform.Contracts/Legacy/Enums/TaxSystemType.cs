namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum TaxSystemType
{
    GST = 1,
    VAT = 2,
    USSalesTax = 3
}
