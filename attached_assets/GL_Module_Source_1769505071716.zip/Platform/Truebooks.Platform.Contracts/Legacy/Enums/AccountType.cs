namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum AccountType
{
    Asset,
    Liability,
    Equity,
    Revenue,
    Expense
}
