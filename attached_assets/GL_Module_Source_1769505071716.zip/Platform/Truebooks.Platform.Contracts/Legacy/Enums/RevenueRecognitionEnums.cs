namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum CalendarType
{
    Statutory = 0,
    ClientFacing = 1,
    Internal = 2
}

public enum RecognitionStatus
{
    Active = 0,
    Completed = 1,
    Cancelled = 2
}

public enum RecognitionLineStatus
{
    Pending = 0,
    Posted = 1,
    Failed = 2,
    Skipped = 3
}

public enum DeferredRevenueAlertType
{
    Recognition = 0,
    Summary = 1,
    Error = 2,
    Pending = 3
}
