namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum SalesReturnStatus
{
    Draft,
    Posted,
    Cancelled
}
