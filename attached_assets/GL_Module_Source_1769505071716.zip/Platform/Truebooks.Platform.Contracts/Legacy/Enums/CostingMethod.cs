namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum CostingMethod
{
    FIFO = 1,
    WeightedAverage = 2,
    StandardCost = 3
}
