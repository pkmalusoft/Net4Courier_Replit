namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum AdjustmentType
{
    Increase = 0,
    Decrease = 1
}
