namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum SalesQuotationStatus
{
    Draft = 0,
    Submitted = 1,
    Accepted = 2,
    Rejected = 3,
    Converted = 4,
    Cancelled = 5
}
