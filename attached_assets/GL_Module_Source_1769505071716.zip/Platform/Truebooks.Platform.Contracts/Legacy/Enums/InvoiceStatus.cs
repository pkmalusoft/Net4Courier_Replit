namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum InvoiceStatus
{
    Draft,
    Posted,
    PartiallyPaid,
    FullyPaid,
    Cancelled
}
