namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum IndustryType
{
    General = 0,
    Service = 1,
    Trading = 2,
    Manufacturing = 3,
    Retail = 4,
    Construction = 5,
    RealEstate = 6,
    Healthcare = 7,
    Logistics = 8,
    NonProfit = 9,
    SmallJob = 10,
    SoftwareCompany = 11
}
