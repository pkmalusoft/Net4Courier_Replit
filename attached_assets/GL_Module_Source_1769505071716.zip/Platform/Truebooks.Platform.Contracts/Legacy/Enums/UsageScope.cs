namespace Truebooks.Platform.Contracts.Legacy.Enums;

public enum UsageScope
{
    Product = 1,
    Service = 2,
    Both = 3
}
