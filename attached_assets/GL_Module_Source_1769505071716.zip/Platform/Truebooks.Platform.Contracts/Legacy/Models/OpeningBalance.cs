using System.ComponentModel.DataAnnotations;

namespace Truebooks.Platform.Contracts.Legacy.Models;

public enum OpeningBalanceStatus
{
    Draft = 0,
    Submitted = 1,
    Posted = 2,
    Closed = 3
}

public enum OpeningBalanceSourceModule
{
    GL = 0,
    AR = 1,
    AP = 2
}

public enum OpeningBalanceReferenceType
{
    Account = 0,
    Customer = 1,
    Supplier = 2
}

public class OpeningBalanceBatch
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid TenantId { get; set; }

    [Required]
    [MaxLength(50)]
    public string BatchNumber { get; set; } = string.Empty;

    public DateTime EffectiveDate { get; set; } = DateTime.UtcNow;

    public OpeningBalanceSourceModule SourceModule { get; set; } = OpeningBalanceSourceModule.GL;

    public OpeningBalanceStatus Status { get; set; } = OpeningBalanceStatus.Draft;

    public Guid? PostedJournalId { get; set; }
    public JournalEntry? PostedJournal { get; set; }

    public Guid? ClosingJournalId { get; set; }
    public JournalEntry? ClosingJournal { get; set; }

    public Guid? PreparedByUserId { get; set; }

    public Guid? ApprovedByUserId { get; set; }

    public DateTime? ApprovedOn { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }

    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;

    public DateTime? ModifiedOn { get; set; }

    public int FiscalYear { get; set; }

    public List<OpeningBalanceLine> Lines { get; set; } = new();

    public decimal TotalDebit => Lines.Sum(l => l.Debit);
    public decimal TotalCredit => Lines.Sum(l => l.Credit);
    public bool IsBalanced => TotalDebit == TotalCredit;
}

public class OpeningBalanceLine
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid TenantId { get; set; }

    public Guid BatchId { get; set; }
    public OpeningBalanceBatch? Batch { get; set; }

    public OpeningBalanceReferenceType ReferenceType { get; set; }

    public Guid ReferenceId { get; set; }

    [MaxLength(200)]
    public string? ReferenceName { get; set; }

    [MaxLength(50)]
    public string? ReferenceCode { get; set; }

    public Guid? CurrencyId { get; set; }

    public decimal ExchangeRate { get; set; } = 1.0m;

    public decimal Debit { get; set; }

    public decimal Credit { get; set; }

    public decimal HomeCurrencyDebit { get; set; }

    public decimal HomeCurrencyCredit { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }

    public int Sequence { get; set; }

    public Guid? BranchId { get; set; }

    public Guid? DepartmentId { get; set; }

    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
}
