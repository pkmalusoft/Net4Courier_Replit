namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public enum BudgetStatus
{
    Draft = 0,
    PendingApproval = 1,
    Approved = 2,
    Active = 3,
    Closed = 4,
    Rejected = 5,
    Voided = 6
}

public enum BudgetRevisionStatus
{
    Original = 0,
    Revised = 1
}

public enum BudgetTransferStatus
{
    Pending = 0,
    Approved = 1,
    Rejected = 2
}

public class BudgetVarianceReportDto
{
    public Guid BudgetHeaderId { get; set; }
    public string BudgetCode { get; set; } = string.Empty;
    public string BudgetName { get; set; } = string.Empty;
    public int FiscalYear { get; set; }
    public string? CostCenterCode { get; set; }
    public string? CostCenterName { get; set; }
    public List<BudgetLineVarianceDto> Lines { get; set; } = new();
    public decimal TotalBudget { get; set; }
    public decimal TotalActual { get; set; }
    public decimal TotalVariance { get; set; }
    public decimal VariancePercent { get; set; }
}

public class BudgetLineVarianceDto
{
    public Guid BudgetLineId { get; set; }
    public Guid ChartOfAccountId { get; set; }
    public string? AccountCode { get; set; }
    public string? AccountName { get; set; }
    public string? LineDescription { get; set; }
    public decimal BudgetAmount { get; set; }
    public decimal RevisedBudget { get; set; }
    public decimal ActualAmount { get; set; }
    public decimal Variance { get; set; }
    public decimal VariancePercent { get; set; }
    public decimal UtilizationPercent { get; set; }
    public decimal RemainingBudget { get; set; }
    public List<MonthlyVarianceDto> MonthlyBreakdown { get; set; } = new();
}

public class MonthlyVarianceDto
{
    public int Month { get; set; }
    public string MonthName { get; set; } = string.Empty;
    public decimal BudgetAmount { get; set; }
    public decimal ActualAmount { get; set; }
    public decimal Variance { get; set; }
}

public class BudgetHeaderDto
{
    public Guid Id { get; set; }
    public string BudgetCode { get; set; } = string.Empty;
    public string BudgetName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int FiscalYear { get; set; }
    public Guid? CostCenterId { get; set; }
    public string? CostCenterName { get; set; }
    public Guid? DepartmentId { get; set; }
    public string? DepartmentName { get; set; }
    public Guid? BranchId { get; set; }
    public string? BranchName { get; set; }
    public BudgetStatus Status { get; set; }
    public decimal TotalBudgetAmount { get; set; }
    public string? CurrencyCode { get; set; }
    public DateTime? EffectiveDate { get; set; }
    public DateTime? ExpiryDate { get; set; }
    public DateTime? ApprovedDate { get; set; }
    public string? Notes { get; set; }
    public List<BudgetLineDto> Lines { get; set; } = new();
}

public class BudgetLineDto
{
    public Guid Id { get; set; }
    public Guid BudgetHeaderId { get; set; }
    public Guid ChartOfAccountId { get; set; }
    public string? AccountCode { get; set; }
    public string? AccountName { get; set; }
    public string? LineDescription { get; set; }
    public decimal BudgetAmount { get; set; }
    public decimal Month01 { get; set; }
    public decimal Month02 { get; set; }
    public decimal Month03 { get; set; }
    public decimal Month04 { get; set; }
    public decimal Month05 { get; set; }
    public decimal Month06 { get; set; }
    public decimal Month07 { get; set; }
    public decimal Month08 { get; set; }
    public decimal Month09 { get; set; }
    public decimal Month10 { get; set; }
    public decimal Month11 { get; set; }
    public decimal Month12 { get; set; }
    public int SortOrder { get; set; }
    public string? Notes { get; set; }
}

public class CreateBudgetRequest
{
    public string BudgetCode { get; set; } = string.Empty;
    public string BudgetName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int FiscalYear { get; set; }
    public Guid? CostCenterId { get; set; }
    public Guid? DepartmentId { get; set; }
    public Guid? BranchId { get; set; }
    public string? CurrencyCode { get; set; }
    public DateTime? EffectiveDate { get; set; }
    public DateTime? ExpiryDate { get; set; }
    public string? Notes { get; set; }
    public List<CreateBudgetLineRequest> Lines { get; set; } = new();
}

public class CreateBudgetLineRequest
{
    public Guid ChartOfAccountId { get; set; }
    public string? LineDescription { get; set; }
    public decimal BudgetAmount { get; set; }
    public decimal Month01 { get; set; }
    public decimal Month02 { get; set; }
    public decimal Month03 { get; set; }
    public decimal Month04 { get; set; }
    public decimal Month05 { get; set; }
    public decimal Month06 { get; set; }
    public decimal Month07 { get; set; }
    public decimal Month08 { get; set; }
    public decimal Month09 { get; set; }
    public decimal Month10 { get; set; }
    public decimal Month11 { get; set; }
    public decimal Month12 { get; set; }
    public int SortOrder { get; set; }
    public string? Notes { get; set; }
}

public class CostCenterDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public Guid? ParentCostCenterId { get; set; }
    public string? ParentCostCenterName { get; set; }
    public Guid? DepartmentId { get; set; }
    public Guid? BranchId { get; set; }
    public bool IsActive { get; set; }
}

public class BudgetCheckResult
{
    public bool IsWithinBudget { get; set; }
    public decimal BudgetAmount { get; set; }
    public decimal UsedAmount { get; set; }
    public decimal RemainingBudget { get; set; }
    public decimal ProposedAmount { get; set; }
    public decimal ExcessAmount { get; set; }
    public string? Message { get; set; }
}
