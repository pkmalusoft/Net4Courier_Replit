namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class CurrencyDto
{
    public Guid id { get; set; }
    public string code { get; set; } = "";
    public string name { get; set; } = "";
    public string symbol { get; set; } = "";
    public bool isActive { get; set; }
}
