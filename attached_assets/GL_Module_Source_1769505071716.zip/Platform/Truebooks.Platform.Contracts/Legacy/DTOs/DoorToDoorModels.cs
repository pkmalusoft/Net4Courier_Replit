namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public enum DTDBranchHubTypeDto
{
    Origin,
    Destination,
    Transit
}

public class DTDBranchDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public DTDBranchHubTypeDto HubType { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public string? Country { get; set; }
    public string? CountryCode { get; set; }
    public string? State { get; set; }
    public string? City { get; set; }
    public string? TimeZone { get; set; }
    public string? Address { get; set; }
    public string? PostalCode { get; set; }
    public string? ContactPhone { get; set; }
    public string? ContactEmail { get; set; }
    public string? ManagerName { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class CountryDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Code3 { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? PhoneCode { get; set; }
    public string? CurrencyCode { get; set; }
    public string? Region { get; set; }
}

public class StateDto
{
    public Guid Id { get; set; }
    public Guid CountryId { get; set; }
    public string? CountryName { get; set; }
    public string? CountryCode { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Region { get; set; }
}

public class CityDto
{
    public Guid Id { get; set; }
    public Guid StateId { get; set; }
    public string? StateName { get; set; }
    public string? StateCode { get; set; }
    public Guid CountryId { get; set; }
    public string? CountryName { get; set; }
    public string? CountryCode { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? AreaCode { get; set; }
    public string? TimeZone { get; set; }
}

public class PostalCodeDto
{
    public Guid Id { get; set; }
    public Guid CityId { get; set; }
    public string? CityName { get; set; }
    public Guid StateId { get; set; }
    public string? StateName { get; set; }
    public Guid CountryId { get; set; }
    public string? CountryName { get; set; }
    public string Code { get; set; } = string.Empty;
    public string? AreaName { get; set; }
}

public class DTDProvinceDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid BranchId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Region { get; set; }
    public string? PostalCodePrefix { get; set; }
    public string? PostalCodeFrom { get; set; }
    public string? PostalCodeTo { get; set; }
    public int DeliveryDays { get; set; }
    public bool IsRemoteArea { get; set; }
    public decimal? RemoteAreaSurcharge { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public DTDBranchDto? Branch { get; set; }
}

public class DTDVehicleDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid BranchId { get; set; }
    public string VehicleCode { get; set; } = string.Empty;
    public string? PlateNumber { get; set; }
    public string? VehicleType { get; set; }
    public string? Make { get; set; }
    public string? Model { get; set; }
    public int? Year { get; set; }
    public string? Color { get; set; }
    public decimal? CapacityKg { get; set; }
    public decimal? CapacityCBM { get; set; }
    public Guid? DefaultDriverId { get; set; }
    public string? Notes { get; set; }
    public bool IsAvailable { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public DTDBranchDto? Branch { get; set; }
    public DTDDriverDto? DefaultDriver { get; set; }
}

public class DTDDriverDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid BranchId { get; set; }
    public string DriverCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? LicenseNumber { get; set; }
    public DateTime? LicenseExpiry { get; set; }
    public string? NationalId { get; set; }
    public string? Notes { get; set; }
    public bool IsAvailable { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public DTDBranchDto? Branch { get; set; }
}

public class DTDJobDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string JobNumber { get; set; } = string.Empty;
    public string AwbNumber { get; set; } = string.Empty;
    public string? MawbNumber { get; set; }
    public DateTime JobDate { get; set; }
    public Guid? OriginBranchId { get; set; }
    public Guid? DestinationBranchId { get; set; }
    public string? OriginBranch { get; set; }
    public string? DestinationBranch { get; set; }
    public string? ProductType { get; set; }
    public string ShipperName { get; set; } = string.Empty;
    public string? ShipperPhone { get; set; }
    public string? ShipperAddress { get; set; }
    public string ConsigneeName { get; set; } = string.Empty;
    public string? ConsigneePhone { get; set; }
    public string? ConsigneeAddress { get; set; }
    public Guid? ConsigneeCountryId { get; set; }
    public Guid? ConsigneeStateId { get; set; }
    public Guid? ConsigneeCityId { get; set; }
    public Guid? ConsigneePostalCodeId { get; set; }
    public string? ConsigneePostalCode { get; set; }
    public Guid? ProvinceId { get; set; }
    public string? ProvinceName { get; set; }
    public int TotalPieces { get; set; }
    public decimal TotalWeight { get; set; }
    public decimal TotalCBM { get; set; }
    public decimal DeclaredValue { get; set; }
    public string? ContentDescription { get; set; }
    public string? SpecialInstructions { get; set; }
    public string Status { get; set; } = "Booked";
    public string? ContainerNumber { get; set; }
    public string? CustomsStatus { get; set; }
    public decimal CustomsDuty { get; set; }
    public DateTime? HoldDate { get; set; }
    public string? HoldReason { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class DTDContainerDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string ContainerNumber { get; set; } = string.Empty;
    public DateTime CreatedDate { get; set; }
    public Guid? OriginBranchId { get; set; }
    public Guid? DestinationBranchId { get; set; }
    public string? OriginBranch { get; set; }
    public string? DestinationBranch { get; set; }
    public string? SealNumber { get; set; }
    public string? Notes { get; set; }
    public int AwbCount { get; set; }
    public int TotalPieces { get; set; }
    public decimal TotalWeight { get; set; }
    public string Status { get; set; } = "Open";
    public DateTime? DispatchDate { get; set; }
    public DateTime? EtaDate { get; set; }
    public DateTime? ReceivedDate { get; set; }
    public string? FlightNumber { get; set; }
    public string? CarrierName { get; set; }
}

public class DTDDeliveryRunDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string RunNumber { get; set; } = string.Empty;
    public DateTime RunDate { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DriverId { get; set; }
    public Guid? VehicleId { get; set; }
    public string? DriverName { get; set; }
    public string? VehicleCode { get; set; }
    public Guid? ProvinceId { get; set; }
    public string? ProvinceName { get; set; }
    public int TotalAwbs { get; set; }
    public int DeliveredAwbs { get; set; }
    public string Status { get; set; } = "Pending";
    public DateTime? StartTime { get; set; }
    public DateTime? EndTime { get; set; }
    public string? Notes { get; set; }
}

public class DTDRateChartDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string? Description { get; set; }
    public Guid OriginBranchId { get; set; }
    public string? OriginBranchName { get; set; }
    public Guid? OriginProvinceId { get; set; }
    public string? OriginProvinceName { get; set; }
    public Guid DestinationBranchId { get; set; }
    public string? DestinationBranchName { get; set; }
    public Guid? DestinationProvinceId { get; set; }
    public string? DestinationProvinceName { get; set; }
    public string Currency { get; set; } = "USD";
    public DateTime EffectiveFrom { get; set; } = DateTime.Today;
    public DateTime? EffectiveTo { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public List<DTDWeightBracketDto> WeightBrackets { get; set; } = new();
}

public class DTDWeightBracketDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid RateChartId { get; set; }
    public decimal WeightFrom { get; set; }
    public decimal WeightTo { get; set; }
    public decimal RatePerKg { get; set; }
    public decimal? MinimumCharge { get; set; }
    public decimal? FlatRate { get; set; }
    public DateTime CreatedAt { get; set; }
}

public enum DTDMovementDirectionDto
{
    Outbound = 0,
    Inbound = 1
}

public enum DTDChargeTypeDto
{
    Freight = 1,
    Handling = 2,
    FuelSurcharge = 3,
    CustomsDuty = 4,
    Insurance = 5,
    Documentation = 6,
    Packaging = 7,
    RemoteArea = 8,
    CODFee = 9,
    Other = 99
}

public class DTDProductTypeDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool RequiresSpecialHandling { get; set; }
    public bool IsRestricted { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public class DTDParcelTypeDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public decimal? MaxWeightKg { get; set; }
    public decimal? MaxLengthCm { get; set; }
    public decimal? MaxWidthCm { get; set; }
    public decimal? MaxHeightCm { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public class DTDMovementTypeDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DTDMovementDirectionDto Direction { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public class DTDRevenueTypeDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DTDChargeTypeDto ChargeType { get; set; }
    public Guid? GLAccountId { get; set; }
    public string? GLAccountCode { get; set; }
    public bool IsTaxable { get; set; } = true;
    public decimal? DefaultTaxRate { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public class DTDOtherChargeDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DTDChargeTypeDto ChargeType { get; set; }
    public decimal? DefaultAmount { get; set; }
    public string? Currency { get; set; }
    public bool IsPercentage { get; set; }
    public decimal? PercentageValue { get; set; }
    public Guid? GLAccountId { get; set; }
    public string? GLAccountCode { get; set; }
    public bool IsTaxable { get; set; } = true;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public class DTDAWBDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid JobId { get; set; }
    public string AWBNumber { get; set; } = string.Empty;
    public string? Barcode { get; set; }
    public int Status { get; set; }
    public string? ShipperName { get; set; }
    public string? ShipperPhone { get; set; }
    public string? ShipperAddress { get; set; }
    public string? ConsigneeName { get; set; }
    public string? ConsigneePhone { get; set; }
    public string? ConsigneeAddress { get; set; }
    public Guid? ConsigneeProvinceId { get; set; }
    public string? ConsigneeProvinceName { get; set; }
    public string? ContentDescription { get; set; }
    public int TotalPieces { get; set; }
    public decimal TotalActualWeightKg { get; set; }
    public decimal TotalChargeableWeightKg { get; set; }
    public decimal DeclaredValue { get; set; }
    public string DeclaredValueCurrency { get; set; } = "USD";
    public decimal TotalFreight { get; set; }
    public decimal TotalCharges { get; set; }
    public bool IsCOD { get; set; }
    public decimal CODAmount { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? DeliveredAt { get; set; }
    public string? ReceivedBy { get; set; }
    public string? DeliveryNotes { get; set; }
    public List<DTDPieceDto> Pieces { get; set; } = new();
}

public class DTDPieceDto
{
    public Guid Id { get; set; }
    public Guid AWBId { get; set; }
    public int PieceSequence { get; set; }
    public int TotalPieces { get; set; }
    public string PieceBarcode { get; set; } = string.Empty;
    public int Status { get; set; }
    public string? ContentSummary { get; set; }
    public decimal LengthCm { get; set; }
    public decimal WidthCm { get; set; }
    public decimal HeightCm { get; set; }
    public decimal ActualWeightKg { get; set; }
    public decimal VolumeWeightKg { get; set; }
    public decimal ChargeableWeightKg { get; set; }
    public decimal DeclaredValue { get; set; }
    public string? CurrentLocation { get; set; }
    public string? BinLocation { get; set; }
    public DateTime? LastScanTime { get; set; }
}

public class DTDScanEventDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid BranchId { get; set; }
    public string? BranchName { get; set; }
    public Guid? AWBId { get; set; }
    public Guid? PieceId { get; set; }
    public string? ScannedBarcode { get; set; }
    public int EventType { get; set; }
    public string? EventTypeName { get; set; }
    public DateTime EventTime { get; set; }
    public string? Location { get; set; }
    public string? BinLocation { get; set; }
    public Guid? ContainerId { get; set; }
    public Guid? VehicleId { get; set; }
    public Guid? DriverId { get; set; }
    public int? PreviousStatus { get; set; }
    public int? NewStatus { get; set; }
    public string? ScannedByUserName { get; set; }
    public string? Notes { get; set; }
    public bool IsException { get; set; }
    public string? ExceptionReason { get; set; }
    public string? PODSignature { get; set; }
    public string? PODPhoto { get; set; }
    public string? ReceivedByName { get; set; }
    public DateTime CreatedAt { get; set; }
}
