namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class CourierServiceTypeDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int DefaultTransitDays { get; set; }
    public bool AllowCOD { get; set; }
    public bool AllowInsurance { get; set; }
    public bool IsExpress { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; }
}

public class CourierZoneDto
{
    public Guid Id { get; set; }
    public string ZoneCode { get; set; } = string.Empty;
    public string ZoneName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public Guid? ZoneCategoryId { get; set; }
    public string? ZoneCategoryName { get; set; }
    public string ZoneType { get; set; } = "Local";
    public bool IsActive { get; set; }
    
    public List<ZoneCountryDto> Countries { get; set; } = new();
    public List<ZoneStateDto> States { get; set; } = new();
    
    public string CountriesDisplay => Countries.Any() ? string.Join(", ", Countries.Select(c => c.CountryName)) : "-";
    public string StatesDisplay => States.Any() ? string.Join(", ", States.Select(s => s.StateName)) : "-";
}

public class ZoneCountryDto
{
    public Guid Id { get; set; }
    public Guid CountryId { get; set; }
    public string CountryName { get; set; } = string.Empty;
    public string CountryCode { get; set; } = string.Empty;
    public int SortOrder { get; set; }
}

public class ZoneStateDto
{
    public Guid Id { get; set; }
    public Guid StateId { get; set; }
    public string StateName { get; set; } = string.Empty;
    public string StateCode { get; set; } = string.Empty;
    public Guid CountryId { get; set; }
    public string CountryName { get; set; } = string.Empty;
    public int SortOrder { get; set; }
}

public class ZoneCategoryDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? CarrierName { get; set; }
    public string? LogoUrl { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; }
    public int ZoneCount { get; set; }
}

public class ZoneRateDto
{
    public Guid Id { get; set; }
    public Guid CourierZoneId { get; set; }
    public string? ZoneName { get; set; }
    public Guid CourierServiceTypeId { get; set; }
    public string? ServiceTypeName { get; set; }
    public string? RateName { get; set; }
    public decimal MinWeight { get; set; }
    public decimal MaxWeight { get; set; }
    public string RateType { get; set; } = "PerKg";
    public decimal BaseRate { get; set; }
    public decimal AdditionalRatePerKg { get; set; }
    public decimal MinCharge { get; set; }
    public decimal FuelSurchargePercent { get; set; }
    public decimal CODChargePercent { get; set; }
    public decimal CODMinCharge { get; set; }
    public DateTime EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public bool IsActive { get; set; }
}

public class CourierAgentDto
{
    public Guid Id { get; set; }
    public string AgentCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string AgentType { get; set; } = "DeliveryAgent";
    public Guid? VendorId { get; set; }
    public string? VendorName { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? Address { get; set; }
    public Guid? CountryId { get; set; }
    public string? Country { get; set; }
    public Guid? StateId { get; set; }
    public string? State { get; set; }
    public Guid? CityId { get; set; }
    public string? City { get; set; }
    public Guid? PostalCodeId { get; set; }
    public decimal CommissionPercent { get; set; }
    public decimal FixedCommission { get; set; }
    public string? BankAccountNo { get; set; }
    public string? BankName { get; set; }
    public bool IsActive { get; set; }
}

public class ShipmentDto
{
    public Guid Id { get; set; }
    public string AWBNumber { get; set; } = string.Empty;
    public DateTime BookingDate { get; set; }
    public Guid CourierServiceTypeId { get; set; }
    public string? ServiceTypeName { get; set; }
    public Guid? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    
    public string SenderName { get; set; } = string.Empty;
    public string? SenderCompany { get; set; }
    public string SenderPhone { get; set; } = string.Empty;
    public string? SenderEmail { get; set; }
    public string SenderAddress { get; set; } = string.Empty;
    public string SenderCity { get; set; } = string.Empty;
    public string? SenderState { get; set; }
    public string SenderPostalCode { get; set; } = string.Empty;
    public string SenderCountry { get; set; } = string.Empty;
    
    public string ReceiverName { get; set; } = string.Empty;
    public string? ReceiverCompany { get; set; }
    public string ReceiverPhone { get; set; } = string.Empty;
    public string? ReceiverEmail { get; set; }
    public string ReceiverAddress { get; set; } = string.Empty;
    public string ReceiverCity { get; set; } = string.Empty;
    public string? ReceiverState { get; set; }
    public string ReceiverPostalCode { get; set; } = string.Empty;
    public string ReceiverCountry { get; set; } = string.Empty;
    
    public Guid? OriginZoneId { get; set; }
    public string? OriginZoneName { get; set; }
    public Guid? DestinationZoneId { get; set; }
    public string? DestinationZoneName { get; set; }
    
    public int Pieces { get; set; }
    public decimal ActualWeight { get; set; }
    public decimal VolumetricWeight { get; set; }
    public decimal ChargeableWeight { get; set; }
    public decimal DeclaredValue { get; set; }
    
    public string PaymentMode { get; set; } = "Prepaid";
    public decimal FreightCharges { get; set; }
    public decimal CODAmount { get; set; }
    public decimal InsuranceCharges { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal TotalCharges { get; set; }
    
    public string Status { get; set; } = "Booked";
    public DateTime? ExpectedDeliveryDate { get; set; }
    public DateTime? ActualDeliveryDate { get; set; }
    
    public Guid? AssignedAgentId { get; set; }
    public string? AssignedAgentName { get; set; }
    
    public string? SpecialInstructions { get; set; }
    public string? InternalNotes { get; set; }
    
    public bool IsVoided { get; set; }
    public string? VoidReason { get; set; }
    
    public List<ShipmentItemDto> Items { get; set; } = new();
    public List<ShipmentTrackingDto> TrackingHistory { get; set; } = new();
    public List<ShipmentChargeDto> Charges { get; set; } = new();
}

public class ShipmentItemDto
{
    public Guid Id { get; set; }
    public string Description { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal Weight { get; set; }
    public decimal Length { get; set; }
    public decimal Width { get; set; }
    public decimal Height { get; set; }
    public decimal DeclaredValue { get; set; }
}

public class ShipmentTrackingDto
{
    public Guid Id { get; set; }
    public string Status { get; set; } = string.Empty;
    public string StatusDescription { get; set; } = string.Empty;
    public string? Location { get; set; }
    public DateTime EventDateTime { get; set; }
    public Guid? AgentId { get; set; }
    public string? AgentName { get; set; }
    public bool IsPublic { get; set; }
}

public class ShipmentChargeDto
{
    public Guid Id { get; set; }
    public Guid? ChargeTypeId { get; set; }
    public string ChargeName { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string? Notes { get; set; }
}

public class CreateShipmentDto
{
    public DateTime BookingDate { get; set; } = DateTime.Today;
    public Guid CourierServiceTypeId { get; set; }
    public Guid? CustomerId { get; set; }
    
    public string SenderName { get; set; } = string.Empty;
    public string? SenderCompany { get; set; }
    public string SenderPhone { get; set; } = string.Empty;
    public string? SenderEmail { get; set; }
    public string SenderAddress { get; set; } = string.Empty;
    public string SenderCity { get; set; } = string.Empty;
    public string? SenderState { get; set; }
    public string SenderPostalCode { get; set; } = string.Empty;
    public string SenderCountry { get; set; } = string.Empty;
    
    public string ReceiverName { get; set; } = string.Empty;
    public string? ReceiverCompany { get; set; }
    public string ReceiverPhone { get; set; } = string.Empty;
    public string? ReceiverEmail { get; set; }
    public string ReceiverAddress { get; set; } = string.Empty;
    public string ReceiverCity { get; set; } = string.Empty;
    public string? ReceiverState { get; set; }
    public string ReceiverPostalCode { get; set; } = string.Empty;
    public string ReceiverCountry { get; set; } = string.Empty;
    
    public Guid? OriginZoneId { get; set; }
    public Guid? DestinationZoneId { get; set; }
    
    public string ShipmentClassification { get; set; } = "ParcelUpto30kg";
    
    public int Pieces { get; set; } = 1;
    public decimal ActualWeight { get; set; }
    public decimal VolumetricWeight { get; set; }
    public decimal DeclaredValue { get; set; }
    
    public string PaymentMode { get; set; } = "Prepaid";
    public decimal CODAmount { get; set; }
    
    public string? SpecialInstructions { get; set; }
    public string? InternalNotes { get; set; }
    
    public List<ShipmentItemDto> Items { get; set; } = new();
    public List<CreateShipmentChargeDto> Charges { get; set; } = new();
}

public class CreateShipmentChargeDto
{
    public Guid? ChargeTypeId { get; set; }
    public string ChargeName { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string? Notes { get; set; }
}

public class UpdateShipmentStatusDto
{
    public string Status { get; set; } = string.Empty;
    public string? Remarks { get; set; }
    public Guid? AgentId { get; set; }
}

public class CustomerLookupDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
}

public class ShipmentDetailModel
{
    public Guid Id { get; set; }
    public string AWBNumber { get; set; } = string.Empty;
    public DateTime BookingDate { get; set; }
    public Guid CourierServiceTypeId { get; set; }
    public string? ServiceTypeName { get; set; }
    public Guid? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    
    public string SenderName { get; set; } = string.Empty;
    public string? SenderCompany { get; set; }
    public string SenderPhone { get; set; } = string.Empty;
    public string? SenderEmail { get; set; }
    public string SenderAddress { get; set; } = string.Empty;
    public string SenderCity { get; set; } = string.Empty;
    public string? SenderState { get; set; }
    public string SenderPostalCode { get; set; } = string.Empty;
    public string SenderCountry { get; set; } = string.Empty;
    
    public string ReceiverName { get; set; } = string.Empty;
    public string? ReceiverCompany { get; set; }
    public string ReceiverPhone { get; set; } = string.Empty;
    public string? ReceiverEmail { get; set; }
    public string ReceiverAddress { get; set; } = string.Empty;
    public string ReceiverCity { get; set; } = string.Empty;
    public string? ReceiverState { get; set; }
    public string ReceiverPostalCode { get; set; } = string.Empty;
    public string ReceiverCountry { get; set; } = string.Empty;
    
    public Guid? OriginZoneId { get; set; }
    public string? OriginZoneName { get; set; }
    public Guid? DestinationZoneId { get; set; }
    public string? DestinationZoneName { get; set; }
    
    public string ShipmentClassification { get; set; } = "ParcelUpto30kg";
    public string ShipmentMode { get; set; } = "Domestic";
    
    public int Pieces { get; set; }
    public decimal ActualWeight { get; set; }
    public decimal VolumetricWeight { get; set; }
    public decimal ChargeableWeight { get; set; }
    public decimal DeclaredValue { get; set; }
    
    public string PaymentMode { get; set; } = "Prepaid";
    public decimal FreightCharges { get; set; }
    public decimal CODAmount { get; set; }
    public decimal InsuranceCharges { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal TotalCharges { get; set; }
    
    public string Status { get; set; } = "Booked";
    public DateTime? ExpectedDeliveryDate { get; set; }
    public DateTime? ActualDeliveryDate { get; set; }
    
    public Guid? AssignedAgentId { get; set; }
    public string? AssignedAgentName { get; set; }
    
    public string? SpecialInstructions { get; set; }
    public string? InternalNotes { get; set; }
    
    public bool IsVoided { get; set; }
    public string? VoidReason { get; set; }
}

public class CalculateChargesResult
{
    public decimal FreightCharges { get; set; }
}

public class ShipmentFormModel
{
    public Guid? CourierServiceTypeId { get; set; }
    public Guid? CustomerId { get; set; }
    public string SenderName { get; set; } = string.Empty;
    public string? SenderCompany { get; set; }
    public string SenderPhone { get; set; } = string.Empty;
    public string? SenderEmail { get; set; }
    public string SenderAddress { get; set; } = string.Empty;
    public string SenderCity { get; set; } = string.Empty;
    public string? SenderState { get; set; }
    public string SenderPostalCode { get; set; } = string.Empty;
    public string SenderCountry { get; set; } = string.Empty;
    public Guid? SenderCountryId { get; set; }
    public Guid? SenderStateId { get; set; }
    public Guid? SenderCityId { get; set; }
    public Guid? SenderPostalCodeId { get; set; }
    public string ReceiverName { get; set; } = string.Empty;
    public string? ReceiverCompany { get; set; }
    public string ReceiverPhone { get; set; } = string.Empty;
    public string? ReceiverEmail { get; set; }
    public string ReceiverAddress { get; set; } = string.Empty;
    public string ReceiverCity { get; set; } = string.Empty;
    public string? ReceiverState { get; set; }
    public string ReceiverPostalCode { get; set; } = string.Empty;
    public string ReceiverCountry { get; set; } = string.Empty;
    public Guid? ReceiverCountryId { get; set; }
    public Guid? ReceiverStateId { get; set; }
    public Guid? ReceiverCityId { get; set; }
    public Guid? ReceiverPostalCodeId { get; set; }
    public Guid? OriginZoneId { get; set; }
    public Guid? DestinationZoneId { get; set; }
    public string ShipmentClassification { get; set; } = "ParcelUpto30kg";
    public int Pieces { get; set; } = 1;
    public decimal ActualWeight { get; set; }
    public decimal VolumetricWeight { get; set; }
    public decimal DeclaredValue { get; set; }
    public string PaymentMode { get; set; } = "Prepaid";
    public decimal CODAmount { get; set; }
    public decimal InsuranceCharges { get; set; }
    public decimal OtherCharges { get; set; }
    public string? SpecialInstructions { get; set; }
    public string? InternalNotes { get; set; }
}

public class ShipmentListItem
{
    public Guid Id { get; set; }
    public string AWBNumber { get; set; } = string.Empty;
    public DateTime BookingDate { get; set; }
    public string? ServiceTypeName { get; set; }
    public string? CustomerName { get; set; }
    public string SenderName { get; set; } = string.Empty;
    public string SenderCity { get; set; } = string.Empty;
    public string ReceiverName { get; set; } = string.Empty;
    public string ReceiverCity { get; set; } = string.Empty;
    public int Pieces { get; set; }
    public decimal ChargeableWeight { get; set; }
    public decimal TotalCharges { get; set; }
    public string Status { get; set; } = string.Empty;
    public string PaymentMode { get; set; } = string.Empty;
    public string? AssignedAgentName { get; set; }
    public DateTime? ExpectedDeliveryDate { get; set; }
}

public class VendorDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
}

public class ProofOfDeliveryDto
{
    public Guid ShipmentId { get; set; }
    public string ReceivedBy { get; set; } = string.Empty;
    public string? ReceiverRelation { get; set; }
    public string? DeliveryNotes { get; set; }
    public string? SignatureBase64 { get; set; }
    public string? PhotoBase64 { get; set; }
    public decimal? CODCollected { get; set; }
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
}

public class AddTrackingEventDto
{
    public Guid ShipmentId { get; set; }
    public string Status { get; set; } = string.Empty;
    public string StatusDescription { get; set; } = string.Empty;
    public string? Location { get; set; }
    public string? City { get; set; }
    public string? Remarks { get; set; }
    public Guid? AgentId { get; set; }
}

public class CustomerRateAssignmentDto
{
    public Guid Id { get; set; }
    public Guid CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerCode { get; set; } = string.Empty;
    public string RateName { get; set; } = string.Empty;
    public DateTime EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public bool IsActive { get; set; }
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class TrackingTimelineItem
{
    public Guid Id { get; set; }
    public string Status { get; set; } = string.Empty;
    public string StatusDescription { get; set; } = string.Empty;
    public string? Location { get; set; }
    public DateTime EventDateTime { get; set; }
    public string? AgentName { get; set; }
    public bool IsPublic { get; set; }
    public string? Remarks { get; set; }
}

public class CourierDashboardData
{
    public int TotalShipments { get; set; }
    public int DeliveredCount { get; set; }
    public int InTransitCount { get; set; }
    public int OutForDeliveryCount { get; set; }
    public int RtoCount { get; set; }
    public int HubCount { get; set; }
    public int DrsCount { get; set; }
    public int ActiveAgents { get; set; }
    public int TotalAgents { get; set; }
    public decimal CodCollected { get; set; }
    public decimal TotalRevenue { get; set; }
    public int CodPendingCount { get; set; }
    public double DeliveryRate { get; set; }
    public double RtoRate { get; set; }
    public int PendingPickupCount { get; set; }
    public int PendingInscanCount { get; set; }
    public int UnassignedDrsCount { get; set; }
    public int PendingManifestCount { get; set; }
    public List<StatusDistributionItem> StatusDistribution { get; set; } = new();
    public List<ZoneDistributionItem> ZoneDistribution { get; set; } = new();
    public List<ServiceTypeDistributionItem> ServiceTypeDistribution { get; set; } = new();
    public ShipmentTrendData TrendData { get; set; } = new();
    public List<RecentShipmentItem> RecentShipments { get; set; } = new();
    public List<TopAgentItem> TopAgents { get; set; } = new();
}

public class StatusDistributionItem
{
    public string Status { get; set; } = string.Empty;
    public int Count { get; set; }
}

public class ZoneDistributionItem
{
    public string ZoneName { get; set; } = string.Empty;
    public int Count { get; set; }
}

public class ServiceTypeDistributionItem
{
    public string ServiceType { get; set; } = string.Empty;
    public int Count { get; set; }
}

public class ShipmentTrendData
{
    public List<string> Labels { get; set; } = new();
    public List<int> BookedData { get; set; } = new();
    public List<int> DeliveredData { get; set; } = new();
}

public class RecentShipmentItem
{
    public Guid Id { get; set; }
    public string AWBNumber { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string SenderName { get; set; } = string.Empty;
    public string ReceiverName { get; set; } = string.Empty;
    public string ReceiverCity { get; set; } = string.Empty;
    public string DestinationCity { get; set; } = string.Empty;
    public string ServiceType { get; set; } = string.Empty;
    public DateTime BookingDate { get; set; }
    public string? AssignedAgentName { get; set; }
}

public class TopAgentItem
{
    public Guid Id { get; set; }
    public string AgentName { get; set; } = string.Empty;
    public string Name { get => AgentName; set => AgentName = value; }
    public int DeliveredCount { get; set; }
    public int ShipmentCount { get => DeliveredCount; set => DeliveredCount = value; }
    public double DeliveryRate { get; set; }
    public decimal CodCollected { get; set; }
    public decimal Revenue { get => CodCollected; set => CodCollected = value; }
}
