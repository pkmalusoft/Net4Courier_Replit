namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class AlertHubSummary
{
    public int PDCAlertCount { get; set; }
    public int DocumentAlertCount { get; set; }
    public int UserMessageCount { get; set; }
    public int SpecialAlertCount { get; set; }
    public int DeferredRevenueAlertCount { get; set; }
    public int TotalUnreadCount { get; set; }
}

public class PDCAlertDto
{
    public Guid Id { get; set; }
    public string Type { get; set; } = string.Empty;
    public string ChequeNumber { get; set; } = string.Empty;
    public string? BankName { get; set; }
    public DateTime ChequeDate { get; set; }
    public DateTime MaturityDate { get; set; }
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "AED";
    public string? CustomerName { get; set; }
    public string? SupplierName { get; set; }
    public string? RelatedInvoiceNumber { get; set; }
    public string Status { get; set; } = string.Empty;
    public int DaysUntilMaturity { get; set; }
    public bool IsAcknowledged { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class DocumentAlertDto
{
    public Guid Id { get; set; }
    public Guid DocumentId { get; set; }
    public string? DocumentType { get; set; }
    public string? EmployeeName { get; set; }
    public DateTime? ExpiryDate { get; set; }
    public int DaysUntilExpiry { get; set; }
    public string Severity { get; set; } = string.Empty;
    public string? AlertMessage { get; set; }
    public bool IsAcknowledged { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class UserMessageDto
{
    public Guid Id { get; set; }
    public Guid SenderUserId { get; set; }
    public string? SenderName { get; set; }
    public string Subject { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string Priority { get; set; } = "Normal";
    public bool IsRead { get; set; }
    public DateTime? ReadAt { get; set; }
    public string? ActionUrl { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class SpecialAlertDto
{
    public Guid Id { get; set; }
    public string AlertType { get; set; } = string.Empty;
    public string Severity { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? RelatedEntityCode { get; set; }
    public decimal? Amount { get; set; }
    public string? Currency { get; set; }
    public DateTime? DueDate { get; set; }
    public int? DaysOverdue { get; set; }
    public string? CreatedByName { get; set; }
    public bool IsAcknowledged { get; set; }
    public bool IsResolved { get; set; }
    public string? ActionUrl { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateMessageRequest
{
    public Guid RecipientUserId { get; set; }
    public string Subject { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string Priority { get; set; } = "Normal";
    public Guid? RelatedEntityId { get; set; }
    public string? RelatedEntityType { get; set; }
    public string? ActionUrl { get; set; }
}

public class CreateSpecialAlertRequest
{
    public string AlertType { get; set; } = "Custom";
    public string Severity { get; set; } = "Warning";
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public Guid? RelatedEntityId { get; set; }
    public string? RelatedEntityType { get; set; }
    public string? RelatedEntityCode { get; set; }
    public decimal? Amount { get; set; }
    public string? Currency { get; set; }
    public DateTime? DueDate { get; set; }
    public int? DaysOverdue { get; set; }
    public Guid? AssignedToUserId { get; set; }
    public string? ActionUrl { get; set; }
}

public class UserListItem
{
    public Guid Id { get; set; }
    public string DisplayName { get; set; } = string.Empty;
    public string? Email { get; set; }
}
