using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class UnitOfMeasure
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public UsageScope UsageScope { get; set; }
    public bool IsActive { get; set; } = true;
    
    public string DisplayName => $"{Code} - {Name}";
    public string UsageScopeText => UsageScope.ToString();
}

public class ItemCategory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    
    public string DisplayName => $"{Code} - {Name}";
}

public class Item
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public ItemType ItemType { get; set; }
    public string? Barcode { get; set; }
    public string? HSNCode { get; set; }
    
    public Guid? DefaultTaxCodeId { get; set; }
    public string? DefaultTaxCodeName { get; set; }
    
    public Guid DefaultUomId { get; set; }
    public string DefaultUomName { get; set; } = string.Empty;
    
    public Guid? ItemGroupId { get; set; }
    public string? ItemGroupName { get; set; }
    public Guid? BrandId { get; set; }
    public string? BrandName { get; set; }
    public string? Model { get; set; }
    public string? Design { get; set; }
    public Guid? SizeId { get; set; }
    public string? SizeName { get; set; }
    public Guid? ColourId { get; set; }
    public string? ColourName { get; set; }
    
    public bool TrackInventory { get; set; }
    public bool RequiresSerialTracking { get; set; }
    public CostingMethod? CostingMethod { get; set; }
    public decimal? ReorderLevel { get; set; }
    public decimal? ReorderQuantity { get; set; }
    
    public decimal? StandardCost { get; set; }
    public decimal? DefaultSellingPrice { get; set; }
    
    public Guid? InventoryAccountId { get; set; }
    public string? InventoryAccountName { get; set; }
    public Guid? COGSAccountId { get; set; }
    public string? COGSAccountName { get; set; }
    public Guid? SalesAccountId { get; set; }
    public string? SalesAccountName { get; set; }
    public Guid? PurchaseAccountId { get; set; }
    public string? PurchaseAccountName { get; set; }
    public Guid? IncomeAccountId { get; set; }
    public string? IncomeAccountName { get; set; }
    
    public bool IsActive { get; set; } = true;
    public List<Guid> CategoryIds { get; set; } = new();
    public List<string> Categories { get; set; } = new();
    
    public string DisplayName => $"{ItemCode} - {Name}";
    public string ItemTypeText => ItemType.ToString();
    public string CategoriesText => Categories.Any() ? string.Join(", ", Categories) : "None";
}

public class ItemSearchResult
{
    public Guid Id { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public ItemType ItemType { get; set; }
    public string? Barcode { get; set; }
    public string? HSNCode { get; set; }
    public decimal? DefaultSellingPrice { get; set; }
    public Guid? DefaultTaxCodeId { get; set; }
    public bool TrackInventory { get; set; }
    public decimal StockQuantity { get; set; }
    
    public string DisplayName => $"{ItemCode} - {Name}";
    public string ItemTypeText => ItemType.ToString();
}

public class ItemInventoryDetail
{
    public Guid Id { get; set; }
    public Guid ItemId { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string ItemName { get; set; } = string.Empty;
    public Guid WarehouseId { get; set; }
    public string WarehouseName { get; set; } = string.Empty;
    public decimal QuantityOnHand { get; set; }
    public decimal QuantityReserved { get; set; }
    public decimal QuantityAvailable => QuantityOnHand - QuantityReserved;
    public decimal? ReorderLevel { get; set; }
    public decimal? ReorderQuantity { get; set; }
    public decimal AverageCost { get; set; }
    public DateTime? LastRestockDate { get; set; }
}

public class SerialNumber
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public Guid ItemId { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string ItemName { get; set; } = string.Empty;
    public Guid? WarehouseId { get; set; }
    public string? WarehouseName { get; set; }
    public string SerialCode { get; set; } = string.Empty;
    public SerialStatus Status { get; set; }
    public string? CurrentLocation { get; set; }
    public string? AcquisitionDocumentType { get; set; }
    public Guid? AcquisitionDocumentId { get; set; }
    public DateTime? AcquisitionDate { get; set; }
    public decimal? Cost { get; set; }
    public DateTime? WarrantyExpiry { get; set; }
    public string? Notes { get; set; }
    
    public string StatusText => Status.ToString();
    public bool IsWarrantyExpired => WarrantyExpiry.HasValue && WarrantyExpiry.Value < DateTime.UtcNow;
}

public class CreateItemDto
{
    public string ItemCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public ItemType ItemType { get; set; }
    public string? Barcode { get; set; }
    public string? HSNCode { get; set; }
    public Guid? DefaultTaxCodeId { get; set; }
    public Guid DefaultUomId { get; set; }
    public Guid? ItemGroupId { get; set; }
    public Guid? BrandId { get; set; }
    public string? Model { get; set; }
    public string? Design { get; set; }
    public Guid? SizeId { get; set; }
    public Guid? ColourId { get; set; }
    public bool TrackInventory { get; set; }
    public bool RequiresSerialTracking { get; set; }
    public CostingMethod? CostingMethod { get; set; }
    public decimal? ReorderLevel { get; set; }
    public decimal? ReorderQuantity { get; set; }
    public decimal? StandardCost { get; set; }
    public decimal? DefaultSellingPrice { get; set; }
    public Guid? InventoryAccountId { get; set; }
    public Guid? COGSAccountId { get; set; }
    public Guid? SalesAccountId { get; set; }
    public Guid? PurchaseAccountId { get; set; }
    public Guid? IncomeAccountId { get; set; }
    public bool IsActive { get; set; } = true;
    public List<Guid> CategoryIds { get; set; } = new();
}

public class UpdateItemDto
{
    public Guid Id { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public ItemType ItemType { get; set; }
    public string? Barcode { get; set; }
    public string? HSNCode { get; set; }
    public Guid? DefaultTaxCodeId { get; set; }
    public Guid DefaultUomId { get; set; }
    public Guid? ItemGroupId { get; set; }
    public Guid? BrandId { get; set; }
    public string? Model { get; set; }
    public string? Design { get; set; }
    public Guid? SizeId { get; set; }
    public Guid? ColourId { get; set; }
    public bool TrackInventory { get; set; }
    public bool RequiresSerialTracking { get; set; }
    public CostingMethod? CostingMethod { get; set; }
    public decimal? ReorderLevel { get; set; }
    public decimal? ReorderQuantity { get; set; }
    public decimal? StandardCost { get; set; }
    public decimal? DefaultSellingPrice { get; set; }
    public Guid? InventoryAccountId { get; set; }
    public Guid? COGSAccountId { get; set; }
    public Guid? SalesAccountId { get; set; }
    public Guid? PurchaseAccountId { get; set; }
    public Guid? IncomeAccountId { get; set; }
    public bool IsActive { get; set; }
    public List<Guid> CategoryIds { get; set; } = new();
}

public class CreateUomDto
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public UsageScope UsageScope { get; set; }
    public bool IsActive { get; set; } = true;
}

public class UpdateUomDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public UsageScope UsageScope { get; set; }
    public bool IsActive { get; set; }
}

public class CreateCategoryDto
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

public class UpdateCategoryDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; }
}

public class CreateSerialNumberDto
{
    public Guid ItemId { get; set; }
    public Guid? WarehouseId { get; set; }
    public string SerialCode { get; set; } = string.Empty;
    public SerialStatus Status { get; set; } = SerialStatus.InStock;
    public string? AcquisitionDocumentType { get; set; }
    public Guid? AcquisitionDocumentId { get; set; }
    public DateTime? AcquisitionDate { get; set; }
    public decimal? Cost { get; set; }
    public DateTime? WarrantyExpiry { get; set; }
    public string? Notes { get; set; }
}

public class BulkCreateSerialNumbersDto
{
    public Guid ItemId { get; set; }
    public Guid WarehouseId { get; set; }
    public List<string> SerialCodes { get; set; } = new();
    public string? AcquisitionDocumentType { get; set; }
    public Guid? AcquisitionDocumentId { get; set; }
    public DateTime? AcquisitionDate { get; set; }
    public decimal? Cost { get; set; }
    public DateTime? WarrantyExpiry { get; set; }
}

public class UpdateSerialNumberDto
{
    public Guid Id { get; set; }
    public Guid? WarehouseId { get; set; }
    public SerialStatus Status { get; set; }
    public string? CurrentLocation { get; set; }
    public string? Notes { get; set; }
}

public class ItemPriceSchedule
{
    public Guid Id { get; set; }
    public Guid ItemId { get; set; }
    public string ItemName { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public Guid? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    public bool IsActive { get; set; }
    public List<ProductPriceTier> ProductPriceTiers { get; set; } = new();
    public List<ServiceRate> ServiceRates { get; set; } = new();
    
    public string DisplayName => $"{Name} ({EffectiveFrom:yyyy-MM-dd})";
    public string DateRangeText => EffectiveTo.HasValue 
        ? $"{EffectiveFrom:yyyy-MM-dd} to {EffectiveTo.Value:yyyy-MM-dd}" 
        : $"From {EffectiveFrom:yyyy-MM-dd}";
}

public class ProductPriceTier
{
    public Guid Id { get; set; }
    public PriceType PriceType { get; set; }
    public decimal UnitPrice { get; set; }
    public DateTime EffectiveDate { get; set; }
    public DateTime? ExpiryDate { get; set; }
    public decimal? MinimumQuantity { get; set; }
    public decimal? MaximumQuantity { get; set; }
    public bool IsActive { get; set; }
    
    public string PriceTypeText => PriceType.ToString();
    public string QuantityRangeText => MinimumQuantity.HasValue && MaximumQuantity.HasValue
        ? $"{MinimumQuantity}-{MaximumQuantity}"
        : MinimumQuantity.HasValue
            ? $"{MinimumQuantity}+"
            : "All";
}

public class ServiceRate
{
    public Guid Id { get; set; }
    public BillingPeriod BillingPeriod { get; set; }
    public decimal Rate { get; set; }
    public decimal? MinimumCharge { get; set; }
    
    public bool IsActive { get; set; }
    public string BillingPeriodText => BillingPeriod.ToString();
}

public class CreateItemPriceScheduleDto
{
    public Guid ItemId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime EffectiveFrom { get; set; } = DateTime.Today;
    public DateTime? EffectiveTo { get; set; }
    public Guid? CustomerId { get; set; }
    public bool IsActive { get; set; } = true;
    public List<CreateProductPriceTierDto> ProductPriceTiers { get; set; } = new();
    public List<CreateServiceRateDto> ServiceRates { get; set; } = new();
}

public class CreateProductPriceTierDto
{
    public PriceType PriceType { get; set; }
    public decimal UnitPrice { get; set; }
    public DateTime EffectiveDate { get; set; } = DateTime.Today;
    public DateTime? ExpiryDate { get; set; }
    public decimal? MinimumQuantity { get; set; }
    public decimal? MaximumQuantity { get; set; }
    public bool IsActive { get; set; } = true;
}

public class CreateServiceRateDto
{
    public BillingPeriod BillingPeriod { get; set; }
    public decimal Rate { get; set; }
    public decimal? MinimumCharge { get; set; }
    public bool IsActive { get; set; } = true;
}

public class UpdateItemPriceScheduleDto
{
    public Guid Id { get; set; }
    public Guid ItemId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public Guid? CustomerId { get; set; }
    public bool IsActive { get; set; }
    public List<CreateProductPriceTierDto> ProductPriceTiers { get; set; } = new();
    public List<CreateServiceRateDto> ServiceRates { get; set; } = new();
}

public class BulkPriceFilterDto
{
    public Guid? ItemGroupId { get; set; }
    public Guid? BrandId { get; set; }
    public string? Model { get; set; }
    public string? Design { get; set; }
    public Guid? SizeId { get; set; }
    public Guid? ColourId { get; set; }
    public ItemType? ItemType { get; set; }
    public Guid? CategoryId { get; set; }
    public bool? IsActive { get; set; }
}

public class BulkPriceAdjustmentDto
{
    public Guid? ItemGroupId { get; set; }
    public Guid? BrandId { get; set; }
    public string? Model { get; set; }
    public string? Design { get; set; }
    public Guid? SizeId { get; set; }
    public Guid? ColourId { get; set; }
    public ItemType? ItemType { get; set; }
    public Guid? CategoryId { get; set; }
    public bool? IsActive { get; set; }
    
    public List<Guid>? SelectedItemIds { get; set; }
    
    public PriceAdjustmentType AdjustmentType { get; set; }
    public decimal? PercentageIncrease { get; set; }
    public decimal? PercentageDecrease { get; set; }
    public decimal? FlatAmount { get; set; }
    
    public List<PriceType> PriceTiers { get; set; } = new();
    public DateTime EffectiveDate { get; set; } = DateTime.Today;
}

public class BulkPriceFilterResultDto
{
    public Guid ItemId { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string ItemName { get; set; } = string.Empty;
    public string? ItemGroupName { get; set; }
    public string? BrandName { get; set; }
    public string? Model { get; set; }
    public string? SizeName { get; set; }
    public string? ColourName { get; set; }
    public decimal? RetailPrice { get; set; }
    public decimal? WholesalePrice { get; set; }
    public decimal? SpecialPrice { get; set; }
}

public class BulkPricePreviewItemDto
{
    public Guid ItemId { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string ItemName { get; set; } = string.Empty;
    public string? ItemGroupName { get; set; }
    public string? BrandName { get; set; }
    public string? Model { get; set; }
    public string? SizeName { get; set; }
    public string? ColourName { get; set; }
    
    public Guid? PriceScheduleId { get; set; }
    public string? PriceScheduleName { get; set; }
    
    public List<PriceTierAdjustmentDto> TierAdjustments { get; set; } = new();
}

public class PriceTierAdjustmentDto
{
    public Guid? PriceTierId { get; set; }
    public PriceType PriceType { get; set; }
    public decimal CurrentPrice { get; set; }
    public decimal NewPrice { get; set; }
    public decimal ChangeAmount { get; set; }
    public decimal ChangePercentage { get; set; }
    public bool IsNewTier { get; set; }
    
    public string PriceTypeText => PriceType.ToString();
    public string CurrentPriceFormatted => CurrentPrice.ToString("C2");
    public string NewPriceFormatted => NewPrice.ToString("C2");
    public string ChangeAmountFormatted => ChangeAmount.ToString("C2");
    public string ChangePercentageFormatted => $"{ChangePercentage:F2}%";
}

public class BulkPriceApplyResult
{
    public bool Success { get; set; }
    public int TotalItemsAffected { get; set; }
    public int TotalTiersUpdated { get; set; }
    public int TotalTiersCreated { get; set; }
    public string? ErrorMessage { get; set; }
    
    public static implicit operator bool(BulkPriceApplyResult result) => result.Success;
}

public class BulkPriceApplyResultDto
{
    public int TotalItemsAffected { get; set; }
    public int TotalTiersUpdated { get; set; }
    public int TotalTiersCreated { get; set; }
    public List<string> UpdatedItemCodes { get; set; } = new();
}

public enum PriceAdjustmentType
{
    PercentageIncrease = 1,
    PercentageDecrease = 2,
    FlatAmount = 3
}

public class StockAdjustment
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string AdjustmentNumber { get; set; } = string.Empty;
    public DateTime AdjustmentDate { get; set; } = DateTime.UtcNow;
    public Guid WarehouseId { get; set; }
    public string WarehouseName { get; set; } = string.Empty;
    public AdjustmentType AdjustmentType { get; set; }
    public string Reason { get; set; } = string.Empty;
    public Guid? JournalEntryId { get; set; }
    public Guid? BranchId { get; set; }
    public string? BranchName { get; set; }
    public Guid? DepartmentId { get; set; }
    public string? DepartmentName { get; set; }
    public List<StockAdjustmentLine> Lines { get; set; } = new();
    
    public string DisplayName => $"{AdjustmentNumber} - {AdjustmentDate:yyyy-MM-dd}";
    public string AdjustmentTypeText => AdjustmentType.ToString();
    public decimal TotalCost => Lines.Sum(l => l.TotalCost);
}

public class StockAdjustmentLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public Guid StockAdjustmentId { get; set; }
    public Guid ItemId { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string ItemName { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal UnitCost { get; set; }
    public decimal TotalCost { get; set; }
}

public class CreateStockAdjustmentDto
{
    public string AdjustmentNumber { get; set; } = string.Empty;
    public DateTime AdjustmentDate { get; set; } = DateTime.Today;
    public Guid WarehouseId { get; set; }
    public AdjustmentType AdjustmentType { get; set; }
    public string Reason { get; set; } = string.Empty;
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public List<CreateStockAdjustmentLineDto> Lines { get; set; } = new();
}

public class CreateStockAdjustmentLineDto
{
    public Guid ItemId { get; set; }
    public decimal Quantity { get; set; }
    public decimal UnitCost { get; set; }
    public decimal TotalCost => Quantity * UnitCost;
}

public class CreateBrandDto
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

public class UpdateBrandDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; }
}

public class CreateItemGroupDto
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

public class UpdateItemGroupDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; }
}

public class CreateWarehouseDto
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? Address { get; set; }
    public bool IsActive { get; set; } = true;
}

public class UpdateWarehouseDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? Address { get; set; }
    public bool IsActive { get; set; }
}

public class ItemPriceScheduleDetail
{
    public Guid Id { get; set; }
    public Guid PriceScheduleId { get; set; }
    public Guid ItemId { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string ItemName { get; set; } = string.Empty;
    public PriceType PriceType { get; set; }
    public decimal Price { get; set; }
    public decimal? MinQuantity { get; set; }
    public decimal? MaxQuantity { get; set; }
}

public class BulkPriceUpdateDto
{
    public List<Guid> ItemIds { get; set; } = new();
    public Guid? ItemGroupId { get; set; }
    public Guid? BrandId { get; set; }
    public Guid? PriceScheduleId { get; set; }
    public PriceType PriceType { get; set; }
    public PriceAdjustmentType AdjustmentType { get; set; }
    public decimal AdjustmentValue { get; set; }
    public bool ApplyToAllItems { get; set; }
}

public class LocationCountry
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Code3 { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? PhoneCode { get; set; }
    public string? CurrencyCode { get; set; }
    public string? Region { get; set; }
}

public class LocationState
{
    public Guid Id { get; set; }
    public Guid CountryId { get; set; }
    public string? CountryName { get; set; }
    public string? CountryCode { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Region { get; set; }
}

public class LocationCity
{
    public Guid Id { get; set; }
    public Guid StateId { get; set; }
    public string? StateName { get; set; }
    public string? StateCode { get; set; }
    public Guid CountryId { get; set; }
    public string? CountryName { get; set; }
    public string? CountryCode { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? AreaCode { get; set; }
    public string? TimeZone { get; set; }
}

public class LocationPostalCode
{
    public Guid Id { get; set; }
    public Guid CityId { get; set; }
    public string? CityName { get; set; }
    public Guid StateId { get; set; }
    public string? StateName { get; set; }
    public Guid CountryId { get; set; }
    public string? CountryName { get; set; }
    public string Code { get; set; } = string.Empty;
    public string? AreaName { get; set; }
}
