using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class RelocationEnquiryDto
{
    public Guid Id { get; set; }
    public string EnquiryNumber { get; set; } = string.Empty;
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string ContactPerson { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string CustomerPhone { get; set; } = string.Empty;
    public string OriginAddress { get; set; } = string.Empty;
    public string OriginCity { get; set; } = string.Empty;
    public string OriginCountry { get; set; } = string.Empty;
    public string DestinationAddress { get; set; } = string.Empty;
    public string DestinationCity { get; set; } = string.Empty;
    public string DestinationCountry { get; set; } = string.Empty;
    public Guid? DestinationZoneId { get; set; }
    public string DestinationZoneName { get; set; } = string.Empty;
    public decimal EstimatedVolumeCBM { get; set; }
    public decimal VolumeCBM { get; set; }
    public string PreferredMode { get; set; } = string.Empty;
    public string ShipmentMode { get; set; } = string.Empty;
    public DateTime? PreferredMoveDate { get; set; }
    public string MoveType { get; set; } = string.Empty;
    public string ServiceType { get; set; } = string.Empty;
    public string SpecialRequirements { get; set; } = string.Empty;
    public decimal DeclaredValue { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public string LeadSource { get; set; } = string.Empty;
    public string SurveyAddress { get; set; } = string.Empty;
    public RelocationEnquiryStatus Status { get; set; }
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime? ModifiedAt { get; set; }
}

public class CreateRelocationEnquiryDto
{
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string ContactPerson { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string OriginAddress { get; set; } = string.Empty;
    public string OriginCity { get; set; } = string.Empty;
    public string OriginCountry { get; set; } = string.Empty;
    public string DestinationAddress { get; set; } = string.Empty;
    public string DestinationCity { get; set; } = string.Empty;
    public string DestinationCountry { get; set; } = string.Empty;
    public Guid? DestinationZoneId { get; set; }
    public decimal EstimatedVolumeCBM { get; set; }
    public string PreferredMode { get; set; } = string.Empty;
    public DateTime? PreferredMoveDate { get; set; }
    public string MoveType { get; set; } = string.Empty;
    public string ServiceType { get; set; } = string.Empty;
    public string SpecialRequirements { get; set; } = string.Empty;
    public decimal DeclaredValue { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public string LeadSource { get; set; } = string.Empty;
}

public class RelocationQuotationDto
{
    public Guid Id { get; set; }
    public string QuotationNumber { get; set; } = string.Empty;
    public Guid EnquiryId { get; set; }
    public string EnquiryNumber { get; set; } = string.Empty;
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string ContactPerson { get; set; } = string.Empty;
    public string OriginCity { get; set; } = string.Empty;
    public string OriginCountry { get; set; } = string.Empty;
    public string DestinationCity { get; set; } = string.Empty;
    public string DestinationCountry { get; set; } = string.Empty;
    public decimal EstimatedVolumeCBM { get; set; }
    public decimal VolumeCBM { get; set; }
    public decimal EstimatedWeightKG { get; set; }
    public string ShipmentMode { get; set; } = string.Empty;
    public string MoveType { get; set; } = string.Empty;
    public string ServiceType { get; set; } = string.Empty;
    public string ContainerType { get; set; } = string.Empty;
    public decimal QuotedAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public DateTime ValidUntil { get; set; }
    public RelocationQuotationStatus Status { get; set; }
    public List<RelocationQuotationDetailDto> Details { get; set; } = new();
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
}

public class RelocationQuotationDetailDto
{
    public Guid Id { get; set; }
    public Guid QuotationId { get; set; }
    public string QuotationNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string OriginCity { get; set; } = string.Empty;
    public string DestinationCity { get; set; } = string.Empty;
    public RelocationShipmentMode ShipmentMode { get; set; }
    public decimal VolumeCBM { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public string Description { get; set; } = string.Empty;
    public string ChargeType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal Rate { get; set; }
    public decimal Amount { get; set; }
    public decimal TotalAmount { get; set; }
    public bool IsMandatory { get; set; }
    public int SortOrder { get; set; }
    public List<RelocationQuotationLineDto> Lines { get; set; } = new();
}

public class RelocationQuotationLineDto
{
    public Guid Id { get; set; }
    public Guid QuotationId { get; set; }
    public string Description { get; set; } = string.Empty;
    public string ChargeType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal Rate { get; set; }
    public decimal Amount { get; set; }
    public decimal TotalAmount { get; set; }
    public int SortOrder { get; set; }
}

public class RelocationRateCalculationResult
{
    public decimal TotalEstimate { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public List<RelocationRateBreakdownItem> Breakdown { get; set; } = new();
}

public class RelocationRateBreakdownItem
{
    public string Description { get; set; } = string.Empty;
    public string ChargeType { get; set; } = string.Empty;
    public string ChargeDescription { get; set; } = string.Empty;
    public decimal Amount { get; set; }
}

public class RelocationRateCalculationRequest
{
    public Guid? ZoneId { get; set; }
    public Guid? DestinationZoneId { get; set; }
    public string ShipmentMode { get; set; } = string.Empty;
    public string MoveType { get; set; } = string.Empty;
    public decimal VolumeCBM { get; set; }
    public decimal DeclaredValue { get; set; }
    public bool IncludeInsurance { get; set; }
}

public class CreateRelocationQuotationDto
{
    public Guid EnquiryId { get; set; }
    public Guid? SurveyId { get; set; }
    public Guid? DestinationZoneId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string CustomerPhone { get; set; } = string.Empty;
    public string OriginCity { get; set; } = string.Empty;
    public string OriginCountry { get; set; } = string.Empty;
    public string DestinationCity { get; set; } = string.Empty;
    public string DestinationCountry { get; set; } = string.Empty;
    public decimal EstimatedVolumeCBM { get; set; }
    public decimal VolumeCBM { get; set; }
    public decimal EstimatedWeightKG { get; set; }
    public decimal WeightKG { get; set; }
    public decimal? DeclaredValue { get; set; }
    public bool IncludeInsurance { get; set; }
    public string ShipmentMode { get; set; } = string.Empty;
    public string MoveType { get; set; } = string.Empty;
    public string ServiceType { get; set; } = string.Empty;
    public string ContainerType { get; set; } = string.Empty;
    public int ValidityDays { get; set; } = 30;
    public DateTime ValidUntil { get; set; }
    public DateTime? ProposedMoveDate { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class UpdateRelocationQuotationStatusDto
{
    public RelocationQuotationStatus Status { get; set; }
    public string RejectionReason { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public class RelocationJobDto
{
    public Guid Id { get; set; }
    public string JobNumber { get; set; } = string.Empty;
    public Guid QuotationId { get; set; }
    public string QuotationNumber { get; set; } = string.Empty;
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string CustomerPhone { get; set; } = string.Empty;
    public string OriginAddress { get; set; } = string.Empty;
    public string OriginCity { get; set; } = string.Empty;
    public string OriginCountry { get; set; } = string.Empty;
    public string DestinationAddress { get; set; } = string.Empty;
    public string DestinationCity { get; set; } = string.Empty;
    public string DestinationCountry { get; set; } = string.Empty;
    public string ShipmentMode { get; set; } = string.Empty;
    public string ContainerType { get; set; } = string.Empty;
    public string ContainerNumbers { get; set; } = string.Empty;
    public string AWBNumber { get; set; } = string.Empty;
    public string BLNumber { get; set; } = string.Empty;
    public string FlightNumber { get; set; } = string.Empty;
    public decimal TotalVolumeCBM { get; set; }
    public decimal TotalWeightKG { get; set; }
    public int TotalPieces { get; set; }
    public decimal DeclaredValue { get; set; }
    public decimal QuotedAmount { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public DateTime? ScheduledPackingDate { get; set; }
    public DateTime? ScheduledLoadingDate { get; set; }
    public DateTime? ScheduledDispatchDate { get; set; }
    public DateTime? ScheduledDeliveryDate { get; set; }
    public DateTime? ActualPackingDate { get; set; }
    public DateTime? ActualLoadingDate { get; set; }
    public DateTime? ActualDispatchDate { get; set; }
    public DateTime? ActualDeliveryDate { get; set; }
    public RelocationJobStatus Status { get; set; }
    public RelocationItemPackingStatus PackingStatus { get; set; }
    public List<RelocationJobItemDto> Items { get; set; } = new();
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
}

public class RelocationJobDetailDto : RelocationJobDto
{
    public string VesselName { get; set; } = string.Empty;
    public string VoyageNumber { get; set; } = string.Empty;
    public string PackingCrewLeader { get; set; } = string.Empty;
    public int PackingCrewSize { get; set; }
    public string LoadingCrewLeader { get; set; } = string.Empty;
    public int LoadingCrewSize { get; set; }
    public decimal? InsuranceValue { get; set; }
    public string InsurancePolicyNumber { get; set; } = string.Empty;
    public string SpecialInstructions { get; set; } = string.Empty;
    public string InternalNotes { get; set; } = string.Empty;
    public List<RelocationShipmentEventDto> TrackingEvents { get; set; } = new();
}

public class CreateRelocationJobItemDto
{
    public Guid JobId { get; set; }
    public string ItemNumber { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Room { get; set; } = string.Empty;
    public int Quantity { get; set; } = 1;
    public decimal LengthCM { get; set; }
    public decimal WidthCM { get; set; }
    public decimal HeightCM { get; set; }
    public decimal WeightKG { get; set; }
    public decimal DeclaredValue { get; set; }
    public bool IsFragile { get; set; }
    public bool RequiresCrating { get; set; }
    public bool RequiresSpecialHandling { get; set; }
    public string PackingMaterials { get; set; } = string.Empty;
    public string SpecialInstructions { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public class RelocationJobItemDto
{
    public Guid Id { get; set; }
    public Guid JobId { get; set; }
    public string ItemNumber { get; set; } = string.Empty;
    public string BoxNumber { get; set; } = string.Empty;
    public string StickerNumber { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Room { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal LengthCM { get; set; }
    public decimal WidthCM { get; set; }
    public decimal HeightCM { get; set; }
    public decimal WeightKG { get; set; }
    public decimal VolumeCBM { get; set; }
    public decimal DeclaredValue { get; set; }
    public bool IsFragile { get; set; }
    public bool RequiresCrating { get; set; }
    public bool RequiresSpecialHandling { get; set; }
    public string PackingMaterials { get; set; } = string.Empty;
    public string SpecialInstructions { get; set; } = string.Empty;
    public RelocationItemPackingStatus PackingStatus { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class UpdateRelocationJobItemDto
{
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public string Room { get; set; } = string.Empty;
    public int? BoxNumber { get; set; }
    public string StickerNumber { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal LengthCM { get; set; }
    public decimal WidthCM { get; set; }
    public decimal HeightCM { get; set; }
    public decimal WeightKG { get; set; }
    public decimal DeclaredValue { get; set; }
    public bool IsFragile { get; set; }
    public bool RequiresCrating { get; set; }
    public bool RequiresSpecialHandling { get; set; }
    public string PackingMaterials { get; set; } = string.Empty;
    public string SpecialInstructions { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public class UpdateRelocationJobDto
{
    public string ContainerNumbers { get; set; } = string.Empty;
    public string AWBNumber { get; set; } = string.Empty;
    public string BLNumber { get; set; } = string.Empty;
    public string FlightNumber { get; set; } = string.Empty;
    public string VesselName { get; set; } = string.Empty;
    public string VoyageNumber { get; set; } = string.Empty;
    public DateTime? ScheduledPackingDate { get; set; }
    public DateTime? ScheduledLoadingDate { get; set; }
    public DateTime? ScheduledDispatchDate { get; set; }
    public DateTime? ScheduledDeliveryDate { get; set; }
    public string PackingCrewLeader { get; set; } = string.Empty;
    public int PackingCrewSize { get; set; }
    public string LoadingCrewLeader { get; set; } = string.Empty;
    public int LoadingCrewSize { get; set; }
    public string SpecialInstructions { get; set; } = string.Empty;
    public string InternalNotes { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public class UpdateRelocationJobStatusDto
{
    public RelocationJobStatus Status { get; set; }
    public string StatusNotes { get; set; } = string.Empty;
    public DateTime? ActualDate { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class RelocationJobTrackingDto
{
    public Guid Id { get; set; }
    public string JobNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string OriginCity { get; set; } = string.Empty;
    public string OriginCountry { get; set; } = string.Empty;
    public string DestinationCity { get; set; } = string.Empty;
    public string DestinationCountry { get; set; } = string.Empty;
    public string ShipmentMode { get; set; } = string.Empty;
    public string VesselName { get; set; } = string.Empty;
    public string VoyageNumber { get; set; } = string.Empty;
    public string FlightNumber { get; set; } = string.Empty;
    public string AWBNumber { get; set; } = string.Empty;
    public string BLNumber { get; set; } = string.Empty;
    public string ContainerNumbers { get; set; } = string.Empty;
    public DateTime? ScheduledDispatchDate { get; set; }
    public DateTime? ActualDispatchDate { get; set; }
    public DateTime? ScheduledDeliveryDate { get; set; }
    public DateTime? EstimatedArrivalDate { get; set; }
    public DateTime? ActualArrivalDate { get; set; }
    public DateTime? ActualDeliveryDate { get; set; }
    public int TotalEvents { get; set; }
    public RelocationJobStatus Status { get; set; }
    public RelocationJobStatus JobStatus { get; set; }
    public List<RelocationShipmentEventDto> Events { get; set; } = new();
}

public class RelocationShipmentEventDto
{
    public Guid Id { get; set; }
    public Guid JobId { get; set; }
    public DateTime EventDate { get; set; }
    public RelocationShipmentEventType EventType { get; set; }
    public string Location { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string VesselName { get; set; } = string.Empty;
    public string VoyageNumber { get; set; } = string.Empty;
    public string FlightNumber { get; set; } = string.Empty;
    public string CarrierName { get; set; } = string.Empty;
    public bool IsException { get; set; }
    public string ExceptionReason { get; set; } = string.Empty;
    public DateTime? ExpectedResolutionDate { get; set; }
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
}

public class CreateRelocationShipmentEventDto
{
    public Guid JobId { get; set; }
    public DateTime EventDate { get; set; }
    public RelocationShipmentEventType EventType { get; set; }
    public string Location { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string VesselName { get; set; } = string.Empty;
    public string VoyageNumber { get; set; } = string.Empty;
    public string FlightNumber { get; set; } = string.Empty;
    public string CarrierName { get; set; } = string.Empty;
    public bool IsException { get; set; }
    public string ExceptionReason { get; set; } = string.Empty;
    public DateTime? ExpectedResolutionDate { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class UpdateRelocationShipmentEventDto
{
    public DateTime EventDate { get; set; }
    public RelocationShipmentEventType EventType { get; set; }
    public string Location { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public bool IsException { get; set; }
    public string ExceptionReason { get; set; } = string.Empty;
    public DateTime? ExpectedResolutionDate { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class RelocationSurveyDto
{
    public Guid Id { get; set; }
    public string SurveyNumber { get; set; } = string.Empty;
    public Guid EnquiryId { get; set; }
    public string EnquiryNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string SurveyAddress { get; set; } = string.Empty;
    public DateTime ScheduledDate { get; set; }
    public TimeSpan? ScheduledTime { get; set; }
    public string SurveyorName { get; set; } = string.Empty;
    public Guid? SurveyorId { get; set; }
    public decimal EstimatedVolumeCBM { get; set; }
    public decimal EstimatedWeightKG { get; set; }
    public int TotalPieces { get; set; }
    public RelocationSurveyStatus Status { get; set; }
    public string Notes { get; set; } = string.Empty;
    public string SurveyReport { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
}

public class CreateRelocationSurveyDto
{
    public Guid EnquiryId { get; set; }
    public string SurveyAddress { get; set; } = string.Empty;
    public DateTime ScheduledDate { get; set; }
    public TimeSpan? ScheduledTime { get; set; }
    public Guid? SurveyorId { get; set; }
    public string SurveyorName { get; set; } = string.Empty;
    public string ContactName { get; set; } = string.Empty;
    public string ContactPhone { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public string InternalNotes { get; set; } = string.Empty;
}

public class UpdateRelocationSurveyDto
{
    public string SurveyAddress { get; set; } = string.Empty;
    public DateTime ScheduledDate { get; set; }
    public TimeSpan? ScheduledTime { get; set; }
    public Guid? SurveyorId { get; set; }
    public string SurveyorName { get; set; } = string.Empty;
    public decimal EstimatedVolumeCBM { get; set; }
    public decimal EstimatedWeightKG { get; set; }
    public int TotalPieces { get; set; }
    public int TotalRooms { get; set; }
    public int FloorNumber { get; set; }
    public bool HasElevator { get; set; }
    public bool ParkingAvailable { get; set; }
    public RelocationSurveyStatus Status { get; set; }
    public string PackingRequirements { get; set; } = string.Empty;
    public string SpecialItems { get; set; } = string.Empty;
    public string Recommendations { get; set; } = string.Empty;
    public string InventoryNotes { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public string InternalNotes { get; set; } = string.Empty;
    public string SurveyReport { get; set; } = string.Empty;
}

public class RelocationInvoiceDto
{
    public Guid Id { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public Guid JobId { get; set; }
    public string JobNumber { get; set; } = string.Empty;
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerEmail { get; set; } = string.Empty;
    public string CustomerPhone { get; set; } = string.Empty;
    public DateTime InvoiceDate { get; set; }
    public DateTime DueDate { get; set; }
    public decimal SubTotal { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal PaidAmount { get; set; }
    public decimal BalanceAmount { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public RelocationInvoiceStatus Status { get; set; }
    public RelocationInvoiceType InvoiceType { get; set; }
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public List<RelocationInvoiceLineDto> Lines { get; set; } = new();
    public List<RelocationPaymentDto> Payments { get; set; } = new();
}

public class RelocationInvoiceLineDto
{
    public Guid Id { get; set; }
    public Guid InvoiceId { get; set; }
    public int LineNumber { get; set; }
    public string Description { get; set; } = string.Empty;
    public string ChargeType { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal Rate { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal Amount { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal LineTotalWithTax { get; set; }
    public int SortOrder { get; set; }
}

public class GenerateInvoiceFromJobDto
{
    public Guid JobId { get; set; }
    public DateTime InvoiceDate { get; set; }
    public DateTime DueDate { get; set; }
    public RelocationInvoiceType InvoiceType { get; set; }
    public RelocationPaymentTerm PaymentTerm { get; set; }
    public bool IncludeAllCharges { get; set; } = true;
    public decimal AdvancePercentage { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class UpdateRelocationInvoiceStatusDto
{
    public RelocationInvoiceStatus Status { get; set; }
    public DateTime? SentDate { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class RelocationPaymentDto
{
    public Guid Id { get; set; }
    public string PaymentNumber { get; set; } = string.Empty;
    public string PaymentReference { get; set; } = string.Empty;
    public Guid InvoiceId { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public DateTime PaymentDate { get; set; }
    public decimal Amount { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public string PaymentMethod { get; set; } = string.Empty;
    public string ReferenceNumber { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
}

public class CreateRelocationPaymentDto
{
    public Guid InvoiceId { get; set; }
    public DateTime PaymentDate { get; set; }
    public decimal Amount { get; set; }
    public string PaymentMethod { get; set; } = string.Empty;
    public string ReferenceNumber { get; set; } = string.Empty;
    public string BankName { get; set; } = string.Empty;
    public string ChequeNumber { get; set; } = string.Empty;
    public DateTime? ChequeDate { get; set; }
    public string TransactionId { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public class RelocationCustomsClearanceDto
{
    public Guid Id { get; set; }
    public string ClearanceNumber { get; set; } = string.Empty;
    public Guid JobId { get; set; }
    public string JobNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public RelocationCustomsType CustomsType { get; set; }
    public string DeclarationNumber { get; set; } = string.Empty;
    public DateTime? DeclarationDate { get; set; }
    public DateTime? SubmissionDate { get; set; }
    public DateTime? ClearedDate { get; set; }
    public DateTime? ReleasedDate { get; set; }
    public DateTime? DutyPaidDate { get; set; }
    public decimal DeclaredValue { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public decimal DutyAmount { get; set; }
    public decimal TotalDutyPayable { get; set; }
    public decimal VATAmount { get; set; }
    public string CustomsOffice { get; set; } = string.Empty;
    public string CustomsBroker { get; set; } = string.Empty;
    public string BrokerReference { get; set; } = string.Empty;
    public string GoodsDescription { get; set; } = string.Empty;
    public string HSCodes { get; set; } = string.Empty;
    public bool HasInspection { get; set; }
    public DateTime? InspectionDate { get; set; }
    public string InspectionNotes { get; set; } = string.Empty;
    public bool HasQuery { get; set; }
    public string QueryDetails { get; set; } = string.Empty;
    public RelocationCustomsStatus Status { get; set; }
    public string DocumentPath { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime? ClearedAt { get; set; }
}

public class CreateRelocationCustomsClearanceDto
{
    public Guid JobId { get; set; }
    public RelocationCustomsType CustomsType { get; set; }
    public string DeclarationNumber { get; set; } = string.Empty;
    public DateTime? DeclarationDate { get; set; }
    public decimal DeclaredValue { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public string CustomsOffice { get; set; } = string.Empty;
    public string CustomsBroker { get; set; } = string.Empty;
    public string BrokerReference { get; set; } = string.Empty;
    public string GoodsDescription { get; set; } = string.Empty;
    public string HSCodes { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public class UpdateRelocationCustomsClearanceDto
{
    public string DeclarationNumber { get; set; } = string.Empty;
    public DateTime? DeclarationDate { get; set; }
    public decimal DeclaredValue { get; set; }
    public decimal DutyAmount { get; set; }
    public string DocumentPath { get; set; } = string.Empty;
    public string CustomsOffice { get; set; } = string.Empty;
    public string CustomsBroker { get; set; } = string.Empty;
    public string BrokerReference { get; set; } = string.Empty;
    public string GoodsDescription { get; set; } = string.Empty;
    public string HSCodes { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public class UpdateRelocationCustomsStatusDto
{
    public RelocationCustomsStatus Status { get; set; }
    public DateTime? ActionDate { get; set; }
    public string StatusNotes { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public class RelocationZoneDto
{
    public Guid Id { get; set; }
    public string ZoneCode { get; set; } = string.Empty;
    public string ZoneName { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Region { get; set; } = string.Empty;
    public int TransitDaysMin { get; set; }
    public int TransitDaysMax { get; set; }
    public decimal BaseMultiplier { get; set; } = 1;
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public int PortCount { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateRelocationZoneDto
{
    public string ZoneCode { get; set; } = string.Empty;
    public string ZoneName { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Region { get; set; } = string.Empty;
    public int TransitDaysMin { get; set; }
    public int TransitDaysMax { get; set; }
    public decimal BaseMultiplier { get; set; } = 1;
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
}

public class RelocationPortDto
{
    public Guid Id { get; set; }
    public string PortCode { get; set; } = string.Empty;
    public string PortName { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string CountryCode { get; set; } = string.Empty;
    public Guid? ZoneId { get; set; }
    public string ZoneName { get; set; } = string.Empty;
    public bool IsSeaPort { get; set; }
    public bool IsAirPort { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public class CreateRelocationPortDto
{
    public string PortCode { get; set; } = string.Empty;
    public string PortName { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;
    public string CountryCode { get; set; } = string.Empty;
    public Guid? ZoneId { get; set; }
    public bool IsSeaPort { get; set; }
    public bool IsAirPort { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
}

public class RelocationRateCardDto
{
    public Guid Id { get; set; }
    public string RateCode { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Guid? ZoneId { get; set; }
    public string ZoneName { get; set; } = string.Empty;
    public Guid? PortId { get; set; }
    public string PortName { get; set; } = string.Empty;
    public string ShipmentMode { get; set; } = string.Empty;
    public string ContainerType { get; set; } = string.Empty;
    public RelocationChargeType ChargeType { get; set; }
    public decimal RatePerCBM { get; set; }
    public decimal FlatRate { get; set; }
    public decimal MinimumCharge { get; set; }
    public bool IsPerCBM { get; set; }
    public bool IsPercentage { get; set; }
    public string PercentageOf { get; set; } = string.Empty;
    public decimal MinVolumeCBM { get; set; }
    public decimal MaxVolumeCBM { get; set; }
    public string VolumeSlab { get; set; } = string.Empty;
    public decimal VolumeDiscountFactor { get; set; }
    public decimal BaseMultiplier { get; set; } = 1;
    public decimal DefaultRate { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public DateTime EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public class CreateRelocationRateCardDto
{
    public string RateCode { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Guid? ZoneId { get; set; }
    public Guid? PortId { get; set; }
    public string ShipmentMode { get; set; } = string.Empty;
    public string ContainerType { get; set; } = string.Empty;
    public RelocationChargeType ChargeType { get; set; }
    public decimal RatePerCBM { get; set; }
    public decimal FlatRate { get; set; }
    public decimal MinimumCharge { get; set; }
    public bool IsPerCBM { get; set; }
    public bool IsPercentage { get; set; }
    public string PercentageOf { get; set; } = string.Empty;
    public decimal MinVolumeCBM { get; set; }
    public decimal MaxVolumeCBM { get; set; }
    public string VolumeSlab { get; set; } = string.Empty;
    public decimal VolumeDiscountFactor { get; set; }
    public decimal BaseMultiplier { get; set; } = 1;
    public decimal DefaultRate { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public DateTime EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public bool IsActive { get; set; } = true;
}

public class RelocationServiceCatalogDto
{
    public Guid Id { get; set; }
    public string ServiceCode { get; set; } = string.Empty;
    public string ServiceName { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public RelocationServiceType ServiceType { get; set; }
    public RelocationChargeType ChargeType { get; set; }
    public string SACCode { get; set; } = string.Empty;
    public Guid? ChartOfAccountId { get; set; }
    public decimal DefaultRate { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public bool IsPerCBM { get; set; }
    public bool IsPercentage { get; set; }
    public string PercentageOf { get; set; } = string.Empty;
    public bool IsMandatory { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
}

public class CreateRelocationServiceCatalogDto
{
    public string ServiceCode { get; set; } = string.Empty;
    public string ServiceName { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public RelocationServiceType ServiceType { get; set; }
    public RelocationChargeType ChargeType { get; set; }
    public string SACCode { get; set; } = string.Empty;
    public Guid? ChartOfAccountId { get; set; }
    public decimal DefaultRate { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public bool IsPerCBM { get; set; }
    public bool IsPercentage { get; set; }
    public string PercentageOf { get; set; } = string.Empty;
    public bool IsMandatory { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
}
