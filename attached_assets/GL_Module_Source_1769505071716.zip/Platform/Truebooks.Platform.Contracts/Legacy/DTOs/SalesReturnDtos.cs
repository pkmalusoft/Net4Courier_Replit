using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class SalesReturnDto
{
    public Guid Id { get; set; }
    public string ReturnNumber { get; set; } = string.Empty;
    public DateTime ReturnDate { get; set; } = DateTime.Today;
    public Guid? SalesInvoiceId { get; set; }
    public string? InvoiceNumber { get; set; }
    public Guid? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    public decimal TotalAmount { get; set; }
    public SalesReturnStatus Status { get; set; } = SalesReturnStatus.Draft;
    public string StatusName => Status.ToString();
    public string? RMANumber { get; set; }
    public string? ReturnReason { get; set; }
    public string? Notes { get; set; }
    public Guid? BranchId { get; set; }
    public string? BranchName { get; set; }
    public Guid? WarehouseId { get; set; }
    public string? WarehouseName { get; set; }
    public string? CurrencyCode { get; set; }
    public bool StockUpdated { get; set; }
    public bool GLPosted { get; set; }
    public List<SalesReturnLineDto> Lines { get; set; } = new();
}

public class SalesReturnLineDto
{
    public Guid Id { get; set; }
    public Guid? ItemId { get; set; }
    public string? ItemCode { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal ReturnedQuantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }
    public Guid? SalesInvoiceLineId { get; set; }
}

public class CreateSalesReturnDto
{
    public DateTime ReturnDate { get; set; } = DateTime.Today;
    public Guid? SalesInvoiceId { get; set; }
    public Guid? CustomerId { get; set; }
    public string? RMANumber { get; set; }
    public string? ReturnReason { get; set; }
    public string? Notes { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? WarehouseId { get; set; }
    public List<CreateSalesReturnLineDto> Lines { get; set; } = new();
}

public class CreateSalesReturnLineDto
{
    public Guid? ItemId { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal ReturnedQuantity { get; set; }
    public decimal UnitPrice { get; set; }
    public Guid? SalesInvoiceLineId { get; set; }
}

public class UpdateSalesReturnDto
{
    public DateTime ReturnDate { get; set; }
    public string? RMANumber { get; set; }
    public string? ReturnReason { get; set; }
    public string? Notes { get; set; }
    public Guid? WarehouseId { get; set; }
    public List<UpdateSalesReturnLineDto> Lines { get; set; } = new();
}

public class UpdateSalesReturnLineDto
{
    public Guid? Id { get; set; }
    public Guid? ItemId { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal ReturnedQuantity { get; set; }
    public decimal UnitPrice { get; set; }
    public Guid? SalesInvoiceLineId { get; set; }
}

public class InvoiceReturnInfoDto
{
    public Guid InvoiceId { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public DateTime InvoiceDate { get; set; }
    public Guid CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public decimal InvoiceTotal { get; set; }
    public string? CurrencyCode { get; set; }
    public List<InvoiceLineForReturnDto> Lines { get; set; } = new();
}

public class InvoiceLineForReturnDto
{
    public Guid LineId { get; set; }
    public Guid InvoiceLineId { get; set; }
    public Guid? ItemId { get; set; }
    public string? ItemCode { get; set; }
    public string? ItemName { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal SoldQuantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal AlreadyReturned { get; set; }
    public decimal AlreadyReturnedQuantity { get; set; }
    public decimal AvailableToReturnQuantity => Quantity - AlreadyReturnedQuantity;
    public decimal Returnable => Quantity - AlreadyReturned;
    public Guid? TaxCodeId { get; set; }
    public string? TaxCodeName { get; set; }
    public decimal CGSTRate { get; set; }
    public decimal SGSTRate { get; set; }
    public decimal IGSTRate { get; set; }
    public Guid? RevenueAccountId { get; set; }
}
