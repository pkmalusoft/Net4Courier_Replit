namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class TaxCodeDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public string TaxType { get; set; } = string.Empty;
}

public class TaxCodeModel
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public Truebooks.Platform.Contracts.Legacy.Enums.TaxType TaxType { get; set; }
}
