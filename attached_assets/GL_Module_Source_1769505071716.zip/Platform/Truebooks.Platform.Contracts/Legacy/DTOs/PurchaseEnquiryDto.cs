namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class PurchaseEnquiryDto
{
    public Guid Id { get; set; }
    public string EnquiryNumber { get; set; } = string.Empty;
    public DateTime EnquiryDate { get; set; }
    public DateTime ValidUntil { get; set; }
    public Guid SupplierId { get; set; }
    public SupplierDto? Supplier { get; set; }
    public Guid CurrencyId { get; set; }
    public string CurrencyCode { get; set; } = string.Empty;
    public decimal ExchangeRate { get; set; } = 1.0m;
    public string? ContactPerson { get; set; }
    public string? ContactEmail { get; set; }
    public string? ContactPhone { get; set; }
    public string? Notes { get; set; }
    public string Status { get; set; } = "Draft";
    public decimal EstimatedValue { get; set; }
    public List<PurchaseEnquiryLineDto> Lines { get; set; } = new();
}

public class PurchaseEnquiryLineDto
{
    public Guid Id { get; set; }
    public Guid ItemId { get; set; }
    public ItemDto? Item { get; set; }
    public decimal Quantity { get; set; }
    public decimal EstimatedUnitPrice { get; set; }
    public decimal LineTotal { get; set; }
}
