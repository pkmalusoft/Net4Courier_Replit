using Truebooks.Platform.Contracts.Enums;
using Truebooks.Platform.Contracts.Enums.Common;

namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public enum CustomerType
{
    Cash,
    Credit
}

public enum CreditApprovalStatus
{
    Pending,
    Approved,
    Rejected
}

public class VoucherNumbering
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public VoucherTransactionType TransactionType { get; set; }
    public string Prefix { get; set; } = string.Empty;
    public int NextNumber { get; set; } = 1;
    public int NumberLength { get; set; } = 6;
    public string Separator { get; set; } = "-";
    public bool IsLocked { get; set; }
    public bool IsActive { get; set; }
    
    // Helper properties for UI
    public string TransactionTypeName => TransactionType.ToString().Replace("Transaction", "").Replace("Note", " Note");
    public string StatusText => IsLocked ? "Locked" : "Unlocked";
    public string NextVoucherPreview => $"{Prefix}{Separator}{NextNumber.ToString().PadLeft(NumberLength, '0')}";
}

public class AccountClassification
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; }
}

public class ChartOfAccount
{
    public Guid Id { get; set; }
    public string? AccountCode { get; set; }
    public string AccountName { get; set; } = string.Empty;
    public AccountType AccountType { get; set; }
    public Guid? ParentAccountId { get; set; }
    public ChartOfAccount? ParentAccount { get; set; }
    public List<ChartOfAccount> SubAccounts { get; set; } = new();
    public bool IsActive { get; set; }
    public bool AllowPosting { get; set; }
    public Guid? AccountClassificationId { get; set; }
    public AccountClassification? AccountClassification { get; set; }
    
    // Helper properties for UI
    public string DisplayName => string.IsNullOrEmpty(AccountCode) ? AccountName : $"{AccountCode} - {AccountName}";
    public int Level { get; set; }
    public string FullPath { get; set; } = string.Empty;
}

public class Currency
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Symbol { get; set; } = string.Empty;
    public decimal ExchangeRate { get; set; } = 1.0m;
    public int DecimalPlaces { get; set; } = 2;
    public bool IsBaseCurrency { get; set; }
    public bool IsActive { get; set; } = true;
    
    // Helper property for UI
    public string DisplayName => $"{Code} - {Name}";
}

public class CustomerCategory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

public class Module
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int DisplayOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsAllModules { get; set; } = false;
}

public class Customer
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid? BranchId { get; set; }
    public string? BranchName { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string CustomerCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? ContactName { get; set; }
    public string Address { get; set; } = string.Empty;
    public string? Country { get; set; }
    public string? State { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public Guid? PostalCodeId { get; set; }
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string TaxIdNumber { get; set; } = string.Empty;
    public Guid? DefaultCurrencyId { get; set; }
    public Currency? DefaultCurrency { get; set; }
    public Guid? PreferredCurrencyId { get; set; }
    public Guid? DefaultARAccountId { get; set; }
    public ChartOfAccount? DefaultARAccount { get; set; }
    
    // Customer Type and Category
    public CustomerType CustomerType { get; set; } = CustomerType.Cash;
    public Guid? CustomerCategoryId { get; set; }
    public CustomerCategory? CustomerCategory { get; set; }
    
    // Credit Management
    public decimal CreditLimit { get; set; }
    public decimal RequestedCreditLimit { get; set; }
    public CreditApprovalStatus CreditApprovalStatus { get; set; } = CreditApprovalStatus.Pending;
    public string? CreditRequestNotes { get; set; }
    public string? CreditApprovalNotes { get; set; }
    public Guid? CreditRequestedByUserId { get; set; }
    public DateTime? CreditRequestedDate { get; set; }
    public Guid? CreditApprovedByUserId { get; set; }
    public DateTime? CreditApprovedDate { get; set; }
    
    public int PaymentTermsDays { get; set; } = 30;
    public bool IsActive { get; set; } = true;
    
    // Helper properties for UI
    public string CustomerTypeDisplay => CustomerType.ToString();
    public string StatusBadge => CreditApprovalStatus.ToString();
    public string StatusColor => CreditApprovalStatus switch
    {
        CreditApprovalStatus.Pending => "Warning",
        CreditApprovalStatus.Approved => "Success",
        CreditApprovalStatus.Rejected => "Error",
        _ => "Default"
    };
}

public class CustomerCreditApprovalHistory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public Guid CustomerId { get; set; }
    public Guid RequestedByUserId { get; set; }
    public DateTime RequestedDate { get; set; }
    public decimal RequestedCreditLimit { get; set; }
    public string? RequestNotes { get; set; }
    public CreditApprovalStatus Status { get; set; }
    public Guid? ApprovedByUserId { get; set; }
    public DateTime? ApprovedDate { get; set; }
    public decimal? ApprovedCreditLimit { get; set; }
    public string? ApprovalNotes { get; set; }
    
    // Helper properties for UI
    public string StatusDisplay => Status.ToString();
    public string StatusColor => Status switch
    {
        CreditApprovalStatus.Pending => "Warning",
        CreditApprovalStatus.Approved => "Success",
        CreditApprovalStatus.Rejected => "Error",
        _ => "Default"
    };
}

public enum SupplierType
{
    Cash,
    Credit
}

public class SupplierCategory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
}

public class Supplier
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string SupplierCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public string? Country { get; set; }
    public string? State { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public Guid? PostalCodeId { get; set; }
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string TaxIdNumber { get; set; } = string.Empty;
    public Guid? DefaultCurrencyId { get; set; }
    public Currency? DefaultCurrency { get; set; }
    public Guid? PreferredCurrencyId { get; set; }
    public Guid? DefaultAPAccountId { get; set; }
    public ChartOfAccount? DefaultAPAccount { get; set; }
    
    // Supplier Type and Category
    public SupplierType SupplierType { get; set; } = SupplierType.Cash;
    public Guid? SupplierCategoryId { get; set; }
    public SupplierCategory? SupplierCategory { get; set; }
    
    // Credit Management
    public decimal CreditLimit { get; set; }
    public decimal RequestedCreditLimit { get; set; }
    public CreditApprovalStatus CreditApprovalStatus { get; set; } = CreditApprovalStatus.Pending;
    public string? CreditRequestNotes { get; set; }
    public string? CreditApprovalNotes { get; set; }
    public Guid? CreditRequestedByUserId { get; set; }
    public DateTime? CreditRequestedDate { get; set; }
    public Guid? CreditApprovedByUserId { get; set; }
    public DateTime? CreditApprovedDate { get; set; }
    
    public int PaymentTermsDays { get; set; } = 30;
    public bool IsActive { get; set; } = true;
    
    // Helper properties for UI
    public string SupplierTypeDisplay => SupplierType.ToString();
    public string StatusBadge => CreditApprovalStatus.ToString();
    public string StatusColor => CreditApprovalStatus switch
    {
        CreditApprovalStatus.Pending => "Warning",
        CreditApprovalStatus.Approved => "Success",
        CreditApprovalStatus.Rejected => "Error",
        _ => "Default"
    };
}

public class SupplierCreditApprovalHistory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public Guid SupplierId { get; set; }
    public Guid RequestedByUserId { get; set; }
    public DateTime RequestedDate { get; set; }
    public decimal RequestedCreditLimit { get; set; }
    public string? RequestNotes { get; set; }
    public CreditApprovalStatus Status { get; set; }
    public Guid? ApprovedByUserId { get; set; }
    public DateTime? ApprovedDate { get; set; }
    public decimal? ApprovedCreditLimit { get; set; }
    public string? ApprovalNotes { get; set; }
    
    // Helper properties for UI
    public string StatusDisplay => Status.ToString();
    public string StatusColor => Status switch
    {
        CreditApprovalStatus.Pending => "Warning",
        CreditApprovalStatus.Approved => "Success",
        CreditApprovalStatus.Rejected => "Error",
        _ => "Default"
    };
}

public class Vendor
{
    public Guid Id { get; set; }
    public string VendorCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public bool IsActive { get; set; }
}

public class Warehouse
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; }
}

public enum LocationType
{
    Warehouse = 0,
    Showroom = 1,
    ThirdParty = 2
}

public class InventoryLocation
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public LocationType Type { get; set; } = LocationType.Warehouse;
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? Country { get; set; }
    public string? PostalCode { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public Guid? PostalCodeId { get; set; }
    public string? ContactPerson { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public bool IsDefault { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public string? DeactivationReason { get; set; }
    
    public string DisplayName => $"{Code} - {Name}";
    public string TypeText => Type.ToString();
    public string TypeColor => Type switch
    {
        LocationType.Warehouse => "Primary",
        LocationType.Showroom => "Success",
        LocationType.ThirdParty => "Warning",
        _ => "Default"
    };
}

public class TaxCode
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public TaxType TaxType { get; set; } = TaxType.Simple;
    public bool IsActive { get; set; }
    
    public string TaxTypeDisplay => TaxType.ToString();
}

public class Project
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    
    public string DisplayName => $"{Code} - {Name}";
}

public class ItemGroup
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    
    public string DisplayName => $"{Code} - {Name}";
}

public class Brand
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    
    public string DisplayName => $"{Code} - {Name}";
}

public class ProductSize
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    
    public string DisplayName => $"{Code} - {Name}";
}


public class Colour
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    
    public string DisplayName => $"{Code} - {Name}";
}

public enum TransferStatus
{
    Draft = 0,
    Approved = 1,
    InTransit = 2,
    Completed = 3,
    Cancelled = 4
}

public class StockTransfer
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string TransferNumber { get; set; } = string.Empty;
    public DateTime TransferDate { get; set; } = DateTime.UtcNow;
    public Guid FromLocationId { get; set; }
    public InventoryLocation? FromLocation { get; set; }
    public Guid ToLocationId { get; set; }
    public InventoryLocation? ToLocation { get; set; }
    public TransferStatus Status { get; set; } = TransferStatus.Draft;
    public string Notes { get; set; } = string.Empty;
    public DateTime? RequestedDate { get; set; }
    public Guid? RequestedByUserId { get; set; }
    public DateTime? ApprovedDate { get; set; }
    public Guid? ApprovedByUserId { get; set; }
    public DateTime? DispatchedDate { get; set; }
    public Guid? DispatchedByUserId { get; set; }
    public DateTime? ReceivedDate { get; set; }
    public Guid? ReceivedByUserId { get; set; }
    public DateTime? CancelledDate { get; set; }
    public Guid? CancelledByUserId { get; set; }
    public string? CancellationReason { get; set; }
    public List<StockTransferLine> Lines { get; set; } = new();
    
    public string StatusText => Status.ToString();
    public string StatusColor => Status switch
    {
        TransferStatus.Draft => "Default",
        TransferStatus.Approved => "Info",
        TransferStatus.InTransit => "Warning",
        TransferStatus.Completed => "Success",
        TransferStatus.Cancelled => "Error",
        _ => "Default"
    };
    public string FromLocationDisplay => FromLocation?.DisplayName ?? "N/A";
    public string ToLocationDisplay => ToLocation?.DisplayName ?? "N/A";
}

public class StockTransferLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public Guid StockTransferId { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public decimal RequestedQuantity { get; set; }
    public decimal DispatchedQuantity { get; set; }
    public decimal ReceivedQuantity { get; set; }
    public decimal UnitCost { get; set; }
    public decimal TotalCost { get; set; }
    public string? Notes { get; set; }
    
    public string ItemDisplay => Item != null ? $"{Item.ItemCode} - {Item.Name}" : "N/A";
}

public enum EmployeeStatus
{
    Active,
    OnLeave,
    Terminated,
    Resigned
}

public enum EmployeeType
{
    Regular = 0,
    Hired = 1,
    Freelancer = 2
}

public enum PaymentType
{
    Monthly = 0,
    Hourly = 1,
    Lumpsum = 2
}

public enum TimesheetApprovalStatus
{
    Pending = 0,
    Approved = 1,
    Rejected = 2,
    Processed = 3
}

public enum DocumentStatus
{
    Valid,
    Expiring,
    Critical,
    Expired
}

public class Employee
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string EmployeeCode { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? Gender { get; set; }
    public string? Nationality { get; set; }
    public Guid? DepartmentId { get; set; }
    public Department? Department { get; set; }
    public string? Designation { get; set; }
    public DateTime? JoiningDate { get; set; }
    public DateTime? TerminationDate { get; set; }
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? Country { get; set; }
    public EmployeeStatus Status { get; set; } = EmployeeStatus.Active;
    public bool IsActive { get; set; } = true;
    
    public EmployeeType EmployeeType { get; set; } = EmployeeType.Regular;
    public PaymentType PaymentType { get; set; } = PaymentType.Monthly;
    public decimal? HourlyRate { get; set; }
    public decimal? MonthlySalary { get; set; }
    public decimal? LumpsumAmount { get; set; }
    
    public string FullName => $"{FirstName} {LastName}".Trim();
    public string DisplayName => string.IsNullOrEmpty(EmployeeCode) ? FullName : $"{EmployeeCode} - {FullName}";
    public string StatusText => Status.ToString();
    public string StatusColor => Status switch
    {
        EmployeeStatus.Active => "Success",
        EmployeeStatus.OnLeave => "Warning",
        EmployeeStatus.Terminated => "Error",
        EmployeeStatus.Resigned => "Default",
        _ => "Default"
    };
}

public class EmployeeDocumentType
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int DefaultAlertDays { get; set; } = 30;
    public int RenewalLeadTimeDays { get; set; } = 60;
    public bool IsRenewalRequired { get; set; } = true;
    public bool IsMandatory { get; set; } = false;
    public string? ResponsibleRole { get; set; } = "PRO";
    public int DisplayOrder { get; set; } = 0;
    public bool IsActive { get; set; } = true;
    public bool IsSystemDefined { get; set; } = false;
}

public class EmployeeDocument
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public Guid EmployeeId { get; set; }
    public Employee? Employee { get; set; }
    public Guid DocumentTypeId { get; set; }
    public EmployeeDocumentType? DocumentType { get; set; }
    public string DocumentNumber { get; set; } = string.Empty;
    public string? DocumentName { get; set; }
    public DateTime IssueDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public string? IssuePlace { get; set; }
    public string? IssuingAuthority { get; set; }
    public string? IssuingCountry { get; set; }
    public string? AttachmentPath { get; set; }
    public string? AttachmentFileName { get; set; }
    public DocumentStatus Status { get; set; } = DocumentStatus.Valid;
    public int AlertDays { get; set; } = 30;
    public bool IsVerified { get; set; } = false;
    public DateTime? VerifiedDate { get; set; }
    public Guid? VerifiedByUserId { get; set; }
    public string? Notes { get; set; }
    public bool IsActive { get; set; } = true;
    
    public int DaysUntilExpiry => (ExpiryDate.Date - DateTime.UtcNow.Date).Days;
    public string StatusText => Status.ToString();
    public string StatusColor => Status switch
    {
        DocumentStatus.Valid => "Success",
        DocumentStatus.Expiring => "Warning",
        DocumentStatus.Critical => "Error",
        DocumentStatus.Expired => "Error",
        _ => "Default"
    };
}

public class Department
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? ParentDepartmentId { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    
    public string DisplayName => string.IsNullOrEmpty(Code) ? Name : $"{Code} - {Name}";
}

public class OpeningBalanceBatchDto
{
    public Guid Id { get; set; }
    public string BatchNumber { get; set; } = string.Empty;
    public DateTime EffectiveDate { get; set; }
    public string SourceModule { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public int FiscalYear { get; set; }
    public string? Notes { get; set; }
    public List<OpeningBalanceLineDto>? Lines { get; set; }
}

public class OpeningBalanceLineDto
{
    public Guid Id { get; set; }
    public string ReferenceType { get; set; } = string.Empty;
    public Guid ReferenceId { get; set; }
    public string? ReferenceName { get; set; }
    public Guid? CurrencyId { get; set; }
    public decimal ExchangeRate { get; set; } = 1m;
    public decimal HomeCurrencyDebit { get; set; }
    public decimal HomeCurrencyCredit { get; set; }
}
