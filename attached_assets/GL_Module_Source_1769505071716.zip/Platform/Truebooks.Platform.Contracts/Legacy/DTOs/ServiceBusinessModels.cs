using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class ServiceEnquiryDto
{
    public Guid Id { get; set; }
    public string EnquiryNumber { get; set; } = string.Empty;
    public DateTime EnquiryDate { get; set; }
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CompanyName { get; set; } = string.Empty;
    public string ContactPerson { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public EnquiryStatus Status { get; set; }
    public EnquirySource Source { get; set; }
    public string SourceDetails { get; set; } = string.Empty;
    public RequirementType RequirementType { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal EstimatedValue { get; set; }
    public decimal EstimatedBudget { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public string AssignedTo { get; set; } = string.Empty;
    public DateTime? FollowUpDate { get; set; }
    public DateTime? NextFollowUpDate { get; set; }
    public DateTime? ExpectedStartDate { get; set; }
    public string RequirementDetails { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class CreateServiceEnquiryRequest
{
    public DateTime EnquiryDate { get; set; } = DateTime.UtcNow;
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CompanyName { get; set; } = string.Empty;
    public string ContactPerson { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public EnquirySource Source { get; set; }
    public string SourceDetails { get; set; } = string.Empty;
    public RequirementType RequirementType { get; set; }
    public string RequirementDetails { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal EstimatedValue { get; set; }
    public decimal EstimatedBudget { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public string AssignedTo { get; set; } = string.Empty;
    public DateTime? FollowUpDate { get; set; }
    public DateTime? NextFollowUpDate { get; set; }
    public DateTime? ExpectedStartDate { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class ServiceQuotationDto
{
    public Guid Id { get; set; }
    public string QuotationNumber { get; set; } = string.Empty;
    public DateTime QuotationDate { get; set; }
    public DateTime ValidUntil { get; set; }
    public Guid? EnquiryId { get; set; }
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public QuotationStatus Status { get; set; }
    public string Subject { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public string Terms { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public List<ServiceQuotationLineDto> Lines { get; set; } = new();
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class ServiceQuotationLineDto
{
    public Guid Id { get; set; }
    public Guid QuotationId { get; set; }
    public int LineNumber { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public string Unit { get; set; } = string.Empty;
    public decimal UnitPrice { get; set; }
    public decimal DiscountPercent { get; set; }
    public decimal TaxPercent { get; set; }
    public decimal LineTotal { get; set; }
}

public class ServiceContractDto
{
    public Guid Id { get; set; }
    public string ContractNumber { get; set; } = string.Empty;
    public Guid? QuotationId { get; set; }
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public string ScopeOfWork { get; set; } = string.Empty;
    public ContractType ContractType { get; set; }
    public ContractStatus Status { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public DateTime? NextBillingDate { get; set; }
    public int BillingDayOfMonth { get; set; }
    public BillingFrequency BillingFrequency { get; set; }
    public decimal ContractValue { get; set; }
    public decimal MonthlyValue { get; set; }
    public decimal RecurringAmount { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public string Description { get; set; } = string.Empty;
    public string Terms { get; set; } = string.Empty;
    public string PaymentTerms { get; set; } = string.Empty;
    public string SLATerms { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public string Deliverables { get; set; } = string.Empty;
    public bool AutoRenew { get; set; }
    public int RenewalNoticeDays { get; set; } = 30;
    public int DaysUntilExpiry { get; set; }
    public bool IsExpiringSoon { get; set; }
    public bool EnableDeferredRevenue { get; set; }
    public Guid? DeferredRevenueAccountId { get; set; }
    public Guid? RevenueAccountId { get; set; }
    public Guid? ClientCalendarId { get; set; }
    public decimal DeferredRevenueBalance { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class CreateServiceContractRequest
{
    public Guid? QuotationId { get; set; }
    public Guid? CustomerId { get; set; }
    public string ProjectName { get; set; } = string.Empty;
    public string ScopeOfWork { get; set; } = string.Empty;
    public ContractType ContractType { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public BillingFrequency BillingFrequency { get; set; }
    public int BillingDayOfMonth { get; set; } = 1;
    public decimal ContractValue { get; set; }
    public decimal RecurringAmount { get; set; }
    public decimal TaxPercent { get; set; } = 0;
    public string CurrencyCode { get; set; } = "AED";
    public string Description { get; set; } = string.Empty;
    public string Terms { get; set; } = string.Empty;
    public string PaymentTerms { get; set; } = string.Empty;
    public string SLATerms { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public string Deliverables { get; set; } = string.Empty;
    public bool AutoRenew { get; set; }
    public int RenewalNoticeDays { get; set; } = 30;
    public bool EnableDeferredRevenue { get; set; }
    public Guid? DeferredRevenueAccountId { get; set; }
    public Guid? RevenueAccountId { get; set; }
    public Guid? ClientCalendarId { get; set; }
}

public class ContractRenewalAlertDto
{
    public Guid ContractId { get; set; }
    public string ContractNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string ProjectName { get; set; } = string.Empty;
    public DateTime EndDate { get; set; }
    public int DaysUntilExpiry { get; set; }
    public decimal ContractValue { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public bool AutoRenew { get; set; }
    public ContractStatus Status { get; set; }
}

public class ServiceTaskLogDto
{
    public Guid Id { get; set; }
    public Guid? ContractId { get; set; }
    public string ContractNumber { get; set; } = string.Empty;
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string TaskNumber { get; set; } = string.Empty;
    public string TaskTitle { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public ServiceTaskStatus Status { get; set; }
    public TaskPriority Priority { get; set; }
    public string AssignedTo { get; set; } = string.Empty;
    public DateTime TaskDate { get; set; }
    public DateTime? DueDate { get; set; }
    public DateTime? CompletedDate { get; set; }
    public decimal HoursWorked { get; set; }
    public decimal HoursSpent { get; set; }
    public decimal BillableHours { get; set; }
    public bool Billable { get; set; }
    public bool IsBillable { get; set; }
    public bool IsInvoiced { get; set; }
    public decimal HourlyRate { get; set; }
    public decimal BillableAmount { get; set; }
    public string Deliverables { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    
    // Timesheet/Payroll fields
    public Guid? EmployeeId { get; set; }
    public string EmployeeName { get; set; } = string.Empty;
    public TimesheetApprovalStatus ApprovalStatus { get; set; } = TimesheetApprovalStatus.Pending;
    public Guid? ApprovedByUserId { get; set; }
    public string ApprovedByName { get; set; } = string.Empty;
    public DateTime? ApprovedDate { get; set; }
    public string? ApprovalNotes { get; set; }
    public bool ProcessedForPayroll { get; set; }
    public Guid? PayrollJournalId { get; set; }
}

public class CampaignMetricsDto
{
    public Guid Id { get; set; }
    public Guid? ContractId { get; set; }
    public string ContractNumber { get; set; } = string.Empty;
    public string CampaignName { get; set; } = string.Empty;
    public string Objective { get; set; } = string.Empty;
    public string TargetAudience { get; set; } = string.Empty;
    public SocialPlatform Platform { get; set; }
    public DateTime ReportDate { get; set; }
    public DateTime GeneratedDate { get; set; }
    public ReportPeriodType PeriodType { get; set; }
    public DateTime PeriodStart { get; set; }
    public DateTime PeriodEnd { get; set; }
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public decimal Budget { get; set; }
    public decimal ActualSpend { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public long Impressions { get; set; }
    public long Reach { get; set; }
    public long Clicks { get; set; }
    public long Engagements { get; set; }
    public long Followers { get; set; }
    public long FollowersGained { get; set; }
    public long FollowersGrowth { get; set; }
    public long Leads { get; set; }
    public long Conversions { get; set; }
    public long VideoViews { get; set; }
    public decimal VideoViewRate { get; set; }
    public decimal Spend { get; set; }
    public decimal Revenue { get; set; }
    public decimal CTR { get; set; }
    public decimal CPC { get; set; }
    public decimal CPM { get; set; }
    public decimal EngagementRate { get; set; }
    public decimal CostPerClick { get; set; }
    public decimal CostPerEngagement { get; set; }
    public decimal CostPerLead { get; set; }
    public decimal CostPerConversion { get; set; }
    public decimal ConversionValue { get; set; }
    public decimal ROAS { get; set; }
    public decimal ChangePercent { get; set; }
    public decimal PerformanceScore { get; set; }
    public long TotalReach { get; set; }
    public bool IsActive { get; set; }
    public string Notes { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
}

public class ContentItemDto
{
    public Guid Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string ContentTitle { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public string Platform { get; set; } = string.Empty;
    public DateTime PublishedDate { get; set; }
    public DateTime PostDate { get; set; }
    public long Impressions { get; set; }
    public long Engagements { get; set; }
    public long Likes { get; set; }
    public long Comments { get; set; }
    public long Shares { get; set; }
    public long Reach { get; set; }
    public decimal EngagementRate { get; set; }
    public decimal PerformanceScore { get; set; }
    public string Url { get; set; } = string.Empty;
}

public class WebsiteAnalyticsDto
{
    public Guid Id { get; set; }
    public string Source { get; set; } = string.Empty;
    public string PageTitle { get; set; } = string.Empty;
    public string PageUrl { get; set; } = string.Empty;
    public long PageViews { get; set; }
    public long UniqueVisitors { get; set; }
    public long Users { get; set; }
    public long Conversions { get; set; }
    public decimal Revenue { get; set; }
    public string CurrencyCode { get; set; } = "AED";
    public decimal BounceRate { get; set; }
    public TimeSpan AvgTimeOnPage { get; set; }
    public TimeSpan AvgSessionDuration { get; set; }
    public long Sessions { get; set; }
    public decimal ConversionRate { get; set; }
}

public class KPISnapshotDto
{
    public Guid Id { get; set; }
    public string Category { get; set; } = string.Empty;
    public string MetricName { get; set; } = string.Empty;
    public decimal PreviousPeriodValue { get; set; }
    public decimal CurrentPeriodValue { get; set; }
    public decimal ChangePercent { get; set; }
    public string Target { get; set; } = string.Empty;
    public bool TargetMet { get; set; }
}

public class ClientReportPeriodDto
{
    public Guid Id { get; set; }
    public Guid ContractId { get; set; }
    public Guid CustomerId { get; set; }
    public string ContractNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string ReportTitle { get; set; } = string.Empty;
    public ReportPeriodType PeriodType { get; set; }
    public DateTime PeriodStart { get; set; }
    public DateTime PeriodEnd { get; set; }
    public DateTime PeriodStartDate { get; set; }
    public DateTime PeriodEndDate { get; set; }
    public DateTime? GeneratedDate { get; set; }
    public string ReportUrl { get; set; } = string.Empty;
    public string? Summary { get; set; }
    public string? Achievements { get; set; }
    public string Issues { get; set; } = string.Empty;
    public string? NextSteps { get; set; }
    public List<CampaignMetricsDto> SocialMetrics { get; set; } = new();
    public List<ContentItemDto> ContentItems { get; set; } = new();
    public List<WebsiteAnalyticsDto> WebsiteAnalytics { get; set; } = new();
    public List<KPISnapshotDto> KPISnapshots { get; set; } = new();
    public bool IsSent { get; set; }
    public DateTime? SentDate { get; set; }
    public string Notes { get; set; } = string.Empty;
}
