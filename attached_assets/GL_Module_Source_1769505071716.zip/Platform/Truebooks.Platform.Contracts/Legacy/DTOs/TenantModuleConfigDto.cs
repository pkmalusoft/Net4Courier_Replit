namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class TenantModuleConfigDto
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid ModuleId { get; set; }
    public string ModuleName { get; set; } = string.Empty;
    public string ModuleCode { get; set; } = string.Empty;
    public string? ModuleDescription { get; set; }
    public string? Description { get; set; }
    public string? Category { get; set; }
    public string? IconClass { get; set; }
    public bool IsEnabled { get; set; }
    public bool IsCore { get; set; }
    public string? ConfigurationJson { get; set; }
    public DateTime? EnabledAt { get; set; }
    public DateTime? EnabledOn { get; set; }
    public DateTime? DisabledAt { get; set; }
    public DateTime? LicenseExpiresAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class ModuleSetupStatusDto
{
    public Guid ModuleId { get; set; }
    public string ModuleCode { get; set; } = string.Empty;
    public bool IsSetupComplete { get; set; }
    public bool RequiresModuleSetup { get; set; }
    public List<string> PendingSteps { get; set; } = new();
    public int CompletedStepsCount { get; set; }
    public int TotalStepsCount { get; set; }
}

public class EnableModuleRequest
{
    public Guid ModuleId { get; set; }
    public bool Enable { get; set; }
    public string? LicenseTier { get; set; }
}
