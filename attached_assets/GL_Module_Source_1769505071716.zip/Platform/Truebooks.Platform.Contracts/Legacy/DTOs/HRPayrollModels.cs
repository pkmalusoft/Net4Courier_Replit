namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class GratuityStats
{
    public int TotalEmployees { get; set; }
    public int TotalEligibleEmployees { get; set; }
    public decimal TotalAccruedGratuity { get; set; }
    public decimal TotalProjectedGratuity { get; set; }
    public decimal AverageServiceYears { get; set; }
    public int EligibleForEOSB { get; set; }
    public decimal MonthlyAccrual { get; set; }
    public int PendingSettlements { get; set; }
    public decimal PendingSettlementAmount { get; set; }
}

public class EmployeeGratuityProjection
{
    public Guid EmployeeId { get; set; }
    public string EmployeeName { get; set; } = string.Empty;
    public string EmployeeCode { get; set; } = string.Empty;
    public DateTime JoiningDate { get; set; }
    public int ServiceYears { get; set; }
    public int ServiceMonths { get; set; }
    public decimal BasicSalary { get; set; }
    public decimal ProjectedGratuity { get; set; }
    public decimal AccruedGratuity { get; set; }
}

public class EmployeeGratuityProjectionDetails : EmployeeGratuityProjection
{
    public decimal DailyRate { get; set; }
    public decimal MonthlyAccrual { get; set; }
    public DateTime? LastAccrualDate { get; set; }
    public decimal Under5YearsAmount { get; set; }
    public decimal Over5YearsAmount { get; set; }
    public List<GratuityAccrualHistoryItem> AccrualHistory { get; set; } = new();
}

public class GratuityAccrualHistoryItem
{
    public Guid Id { get; set; }
    public DateTime AccrualDate { get; set; }
    public string Period { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public decimal RunningTotal { get; set; }
    public decimal Cumulative { get; set; }
    public bool IsProcessed { get; set; }
    public string Description { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
}
