namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class ItemDto
{
    public Guid Id { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string ItemType { get; set; } = string.Empty;
    public decimal? DefaultCostPrice { get; set; }
}
