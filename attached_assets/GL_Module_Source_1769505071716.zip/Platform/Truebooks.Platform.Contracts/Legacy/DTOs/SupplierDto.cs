namespace Truebooks.Platform.Contracts.Legacy.DTOs;

public class SupplierDto
{
    public Guid Id { get; set; }
    public string SupplierCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public Guid? PreferredCurrencyId { get; set; }
}
