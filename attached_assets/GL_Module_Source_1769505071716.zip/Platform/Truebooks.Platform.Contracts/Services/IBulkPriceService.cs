using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IBulkPriceService
{
    Task<bool> UpdatePricesByPercentageAsync(Guid tenantId, decimal percentageChange, List<Guid>? itemIds = null, Guid? categoryId = null);
    Task<bool> UpdatePricesByAmountAsync(Guid tenantId, decimal amountChange, List<Guid>? itemIds = null, Guid? categoryId = null);
    Task<bool> CopyPriceScheduleAsync(Guid tenantId, Guid sourcePriceScheduleId, string newScheduleName, decimal? percentageAdjustment = null);
    Task<IEnumerable<ItemDto>> PreviewPriceChangesAsync(Guid tenantId, decimal percentageChange, List<Guid>? itemIds = null, Guid? categoryId = null);
}
