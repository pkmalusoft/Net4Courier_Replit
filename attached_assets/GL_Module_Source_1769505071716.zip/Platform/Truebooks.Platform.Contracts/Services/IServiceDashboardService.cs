using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IServiceDashboardService
{
    Task<ServiceDashboardDto> GetDashboardAsync(Guid tenantId, CancellationToken cancellationToken = default);
}
