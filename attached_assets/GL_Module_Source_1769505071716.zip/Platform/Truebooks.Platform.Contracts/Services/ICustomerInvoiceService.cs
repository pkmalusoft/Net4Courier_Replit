using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ICustomerInvoiceService
{
    Task<IEnumerable<CustomerInvoiceSummaryDto>> GetAllAsync(Guid tenantId, Guid customerId, DateTime? fromDate = null, DateTime? toDate = null, string? status = null);
    Task<CustomerInvoiceDetailDto?> GetByIdAsync(Guid tenantId, Guid invoiceId);
    Task<byte[]?> ExportPdfAsync(Guid tenantId, Guid invoiceId);
    Task<decimal> GetOutstandingBalanceAsync(Guid tenantId, Guid customerId);
}
