using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IDocumentCategoryService
{
    Task<IEnumerable<DocumentCategoryDto>> GetAllAsync(Guid tenantId, int? categoryType = null, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<DocumentCategoryDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateDocumentCategoryRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateDocumentCategoryRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}
