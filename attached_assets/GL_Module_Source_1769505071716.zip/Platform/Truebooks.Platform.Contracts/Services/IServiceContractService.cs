using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface IServiceContractService
{
    Task<IEnumerable<ServiceContractDto>> GetAllAsync(Guid tenantId, ContractStatus? status = null, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);
    Task<ServiceContractDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ServiceContractDto> CreateAsync(Guid tenantId, CreateServiceContractRequest request, CancellationToken cancellationToken = default);
    Task<ServiceContractDto> UpdateAsync(Guid tenantId, Guid id, UpdateServiceContractRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ServiceContractDto> UpdateStatusAsync(Guid tenantId, Guid id, ContractStatus status, CancellationToken cancellationToken = default);
    Task<ServiceContractDto> RenewContractAsync(Guid tenantId, Guid contractId, DateTime newEndDate, CancellationToken cancellationToken = default);
    Task<IEnumerable<ContractRenewalAlertDto>> GetExpiringContractsAsync(Guid tenantId, int withinDays = 30, CancellationToken cancellationToken = default);
    Task<IEnumerable<ServiceContractDto>> GetActiveContractsAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<IEnumerable<ServiceContractDto>> GetByCustomerAsync(Guid tenantId, Guid customerId, CancellationToken cancellationToken = default);
    Task<IEnumerable<ContractDropdownDto>> GetDropdownAsync(Guid tenantId, CancellationToken cancellationToken = default);
}
