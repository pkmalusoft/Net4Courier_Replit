namespace Truebooks.Platform.Contracts.Services;

public interface ITransactionCheckService
{
    Task<bool> HasAnyTransactionsAsync(Guid tenantId);
}
