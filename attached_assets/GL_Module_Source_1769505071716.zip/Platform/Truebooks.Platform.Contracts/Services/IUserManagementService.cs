namespace Truebooks.Platform.Contracts.Services;

public interface IUserManagementService
{
    Task<IEnumerable<UserDto>> GetAllUsersAsync(Guid tenantId, bool includeInactive = false);
    Task<UserDto?> GetUserByIdAsync(Guid tenantId, Guid userId);
    Task<UserDto> CreateUserAsync(Guid tenantId, CreateUserRequest request);
    Task<UserDto> UpdateUserAsync(Guid tenantId, Guid userId, UpdateUserRequest request);
    Task<bool> DeactivateUserAsync(Guid tenantId, Guid userId);
    Task<bool> ActivateUserAsync(Guid tenantId, Guid userId);
    Task<bool> ResetPasswordAsync(Guid tenantId, Guid userId, string newPassword);
    Task<IEnumerable<RoleDto>> GetRolesAsync(Guid tenantId);
}

public class UserDto
{
    public Guid Id { get; set; }
    public string Email { get; set; } = "";
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? DisplayName { get; set; }
    public Guid? EmployeeId { get; set; }
    public string? EmployeeName { get; set; }
    public List<string> Roles { get; set; } = new();
    public bool IsActive { get; set; }
    public DateTime? LastLoginAt { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class RoleDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public string? Description { get; set; }
}

public class CreateUserRequest
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? DisplayName { get; set; }
    public Guid? EmployeeId { get; set; }
    public List<string> Roles { get; set; } = new();
}

public class UpdateUserRequest
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? DisplayName { get; set; }
    public Guid? EmployeeId { get; set; }
    public List<string> Roles { get; set; } = new();
}
