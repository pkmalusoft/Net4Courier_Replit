namespace Truebooks.Platform.Contracts.Services;

public record WorkingPeriodDto(
    Guid Id,
    Guid TenantId,
    int FiscalYear,
    int Period,
    string PeriodName,
    DateTime StartDate,
    DateTime EndDate,
    int Status,
    string StatusText,
    bool IsCurrentPeriod
);

public interface IWorkingPeriodService
{
    Task<WorkingPeriodDto?> GetCurrentPeriodAsync(Guid tenantId);
    Task<IEnumerable<WorkingPeriodDto>> GetAllPeriodsAsync(Guid tenantId, int fiscalYear);
    Task<IEnumerable<WorkingPeriodDto>> GetOpenPeriodsAsync(Guid tenantId);
    Task<bool> IsDateInOpenPeriodAsync(Guid tenantId, DateTime date);
    Task<WorkingPeriodDto?> GetPeriodForDateAsync(Guid tenantId, DateTime date);
}
