using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IEmployeeService
{
    Task<EmployeeDto?> GetByIdAsync(Guid tenantId, Guid employeeId, CancellationToken cancellationToken = default);
    Task<IEnumerable<EmployeeDto>> SearchAsync(Guid tenantId, string query, int maxResults = 50, CancellationToken cancellationToken = default);
    Task<IEnumerable<EmployeeDto>> GetAllActiveAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<IEnumerable<EmployeeDto>> GetAllAsync(Guid tenantId, bool? isActive = null, CancellationToken cancellationToken = default);
    Task<EmployeeDto?> GetCurrentAsync(Guid tenantId, Guid userId, CancellationToken cancellationToken = default);
    Task<IEnumerable<EmployeeDropdownDto>> GetDropdownAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<EmployeeDto> CreateAsync(Guid tenantId, CreateEmployeeRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid employeeId, UpdateEmployeeRequest request, CancellationToken cancellationToken = default);
    Task DeactivateAsync(Guid tenantId, Guid employeeId, CancellationToken cancellationToken = default);
    Task ActivateAsync(Guid tenantId, Guid employeeId, CancellationToken cancellationToken = default);
}
