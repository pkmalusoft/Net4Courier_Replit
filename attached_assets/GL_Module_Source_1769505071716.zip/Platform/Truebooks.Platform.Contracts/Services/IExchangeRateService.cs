namespace Truebooks.Platform.Contracts.Services;

public interface IExchangeRateService
{
    Task<LiveExchangeRateResultDto> GetLiveRateAsync(Guid tenantId, string fromCurrency, string toCurrency);
}

public class LiveExchangeRateResultDto
{
    public bool Success { get; set; }
    public decimal Rate { get; set; }
    public string FromCurrency { get; set; } = string.Empty;
    public string ToCurrency { get; set; } = string.Empty;
    public string? Source { get; set; }
    public DateTime? FetchedAt { get; set; }
    public string? Error { get; set; }
}
