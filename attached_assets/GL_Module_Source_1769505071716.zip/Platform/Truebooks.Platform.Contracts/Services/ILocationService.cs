using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ILocationService
{
    Task<List<CountryDetailDto>> GetAllCountriesAsync(Guid tenantId, bool activeOnly = true);
    Task<CountryDetailDto?> GetCountryByIdAsync(Guid tenantId, Guid id);
    Task<CountryDetailDto> CreateCountryAsync(Guid tenantId, CreateCountryRequest request);
    Task UpdateCountryAsync(Guid tenantId, Guid id, UpdateCountryRequest request);
    Task ToggleCountryStatusAsync(Guid tenantId, Guid id);

    Task<List<StateDetailDto>> GetAllStatesAsync(Guid tenantId, bool activeOnly = true);
    Task<List<StateDetailDto>> GetStatesByCountryAsync(Guid tenantId, Guid countryId, bool activeOnly = true);
    Task<StateDetailDto?> GetStateByIdAsync(Guid tenantId, Guid id);
    Task<StateDetailDto> CreateStateAsync(Guid tenantId, CreateStateRequest request);
    Task UpdateStateAsync(Guid tenantId, Guid id, UpdateStateRequest request);
    Task ToggleStateStatusAsync(Guid tenantId, Guid id);

    Task<List<CityDetailDto>> GetAllCitiesAsync(Guid tenantId, bool activeOnly = true);
    Task<List<CityDetailDto>> GetCitiesByStateAsync(Guid tenantId, Guid stateId, bool activeOnly = true);
    Task<CityDetailDto?> GetCityByIdAsync(Guid tenantId, Guid id);
    Task<CityDetailDto> CreateCityAsync(Guid tenantId, CreateCityRequest request);
    Task UpdateCityAsync(Guid tenantId, Guid id, UpdateCityRequest request);
    Task ToggleCityStatusAsync(Guid tenantId, Guid id);

    Task<List<PostalCodeDetailDto>> GetAllPostalCodesAsync(Guid tenantId, bool activeOnly = true);
    Task<List<PostalCodeDetailDto>> GetPostalCodesByCityAsync(Guid tenantId, Guid cityId, bool activeOnly = true);
    Task<PostalCodeDetailDto?> GetPostalCodeByIdAsync(Guid tenantId, Guid id);
    Task<PostalCodeDetailDto> CreatePostalCodeAsync(Guid tenantId, CreatePostalCodeRequest request);
    Task UpdatePostalCodeAsync(Guid tenantId, Guid id, UpdatePostalCodeRequest request);
    Task TogglePostalCodeStatusAsync(Guid tenantId, Guid id);
    Task DeletePostalCodeAsync(Guid tenantId, Guid id);
}
