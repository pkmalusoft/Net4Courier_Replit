using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IBranchService
{
    Task<List<BranchDto>> GetAllAsync(Guid tenantId, bool includeInactive = false);
    Task<List<BranchDto>> GetActiveAsync(Guid tenantId);
    Task<BranchDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<BranchDto?> GetHeadOfficeAsync(Guid tenantId);
    Task<List<BranchDto>> GetUserAccessibleBranchesAsync(Guid tenantId);
    Task<Guid> CreateAsync(Guid tenantId, CreateBranchRequest request);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateBranchRequest request);
    Task DeleteAsync(Guid tenantId, Guid id);
}
