using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ICustomerService
{
    Task<IEnumerable<CustomerDto>> GetAllAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<IEnumerable<CustomerDto>> GetActiveAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<IEnumerable<CustomerDto>> GetByCategoryAsync(Guid tenantId, Guid categoryId, CancellationToken cancellationToken = default);
    Task<IEnumerable<CustomerDto>> GetPendingCreditApprovalsAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<IEnumerable<CustomerDto>> SearchAsync(Guid tenantId, string query, int maxResults = 50, CancellationToken cancellationToken = default);
    Task<CustomerDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<CustomerDto?> GetByCodeAsync(Guid tenantId, string customerCode, CancellationToken cancellationToken = default);
    Task<CustomerDto> CreateAsync(Guid tenantId, CreateCustomerRequest request, CancellationToken cancellationToken = default);
    Task<CustomerDto> UpdateAsync(Guid tenantId, Guid id, UpdateCustomerRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<CustomerDto> RequestCreditLimitAsync(Guid tenantId, Guid id, RequestCreditLimitRequest request, Guid requestedByUserId, CancellationToken cancellationToken = default);
    Task<CustomerDto> ApproveCreditLimitAsync(Guid tenantId, Guid id, ApproveCreditLimitRequest request, Guid approvedByUserId, CancellationToken cancellationToken = default);
    Task DeactivateAsync(Guid tenantId, Guid id, string? reason, Guid deactivatedByUserId, CancellationToken cancellationToken = default);
    Task ReactivateAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}
