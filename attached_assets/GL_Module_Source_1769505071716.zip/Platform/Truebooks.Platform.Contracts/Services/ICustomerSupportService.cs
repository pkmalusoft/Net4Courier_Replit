using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ICustomerSupportService
{
    Task<IEnumerable<SupportTicketDto>> GetAllAsync(Guid tenantId, Guid customerId, string? status = null);
    Task<SupportTicketDto?> GetByIdAsync(Guid tenantId, Guid ticketId);
    Task<SupportTicketDto?> CreateAsync(Guid tenantId, CreateSupportTicketRequest request);
    Task<bool> AddMessageAsync(Guid tenantId, AddTicketMessageRequest request);
    Task<bool> CloseTicketAsync(Guid tenantId, Guid ticketId);
}
