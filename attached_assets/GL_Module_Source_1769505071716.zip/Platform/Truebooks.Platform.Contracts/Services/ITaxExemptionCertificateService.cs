using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ITaxExemptionCertificateService
{
    Task<IEnumerable<TaxExemptionCertificateDto>> GetAllAsync(Guid tenantId, string? status = null, CancellationToken cancellationToken = default);
    Task<TaxExemptionCertificateDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateTaxExemptionCertificateRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateTaxExemptionCertificateRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}
