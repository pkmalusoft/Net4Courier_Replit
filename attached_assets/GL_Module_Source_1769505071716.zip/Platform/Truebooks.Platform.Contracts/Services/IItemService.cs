using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IItemService
{
    Task<IEnumerable<ItemDto>> GetAllAsync(Guid tenantId);
    Task<ItemDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<IEnumerable<ItemSearchResultDto>> SearchAsync(Guid tenantId, string? searchTerm = null, bool? activeOnly = true);
    Task<ItemDto> CreateAsync(Guid tenantId, CreateItemRequest request);
    Task<ItemDto> UpdateAsync(Guid tenantId, Guid id, UpdateItemRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id);
    Task<bool> ToggleActiveAsync(Guid tenantId, Guid id);
    Task<IEnumerable<ItemInventoryDetailDto>> GetInventoryDetailsAsync(Guid tenantId, Guid itemId);
    Task<decimal> GetStockQuantityAsync(Guid tenantId, Guid itemId, Guid? warehouseId = null);
}
