using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IUomService
{
    Task<IEnumerable<UomDto>> GetAllAsync(Guid tenantId);
    Task<UomDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<UomDto> CreateAsync(Guid tenantId, CreateUomRequest request);
    Task<UomDto> UpdateAsync(Guid tenantId, Guid id, UpdateUomRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id);
    Task<bool> ToggleActiveAsync(Guid tenantId, Guid id);
}
