using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IGridPreferencesService
{
    Task<GridPreferenceDto?> GetAsync(Guid tenantId, Guid userId, string gridName);
    Task<GridPreferenceDto> SaveAsync(Guid tenantId, Guid userId, SaveGridPreferenceRequest request);
    Task DeleteAsync(Guid tenantId, Guid userId, string gridName);
}
