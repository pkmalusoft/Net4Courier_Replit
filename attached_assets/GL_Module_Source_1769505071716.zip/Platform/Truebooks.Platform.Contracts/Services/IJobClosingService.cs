using Truebooks.Platform.Contracts.DTOs.Logistics;

namespace Truebooks.Platform.Contracts.Services;

public interface IJobClosingService
{
    Task<List<JobWithAccrualStatusDto>> GetJobsWithAccrualStatusAsync(Guid tenantId, DateTime? periodEndDate = null);
    Task<JobClosingSummaryDto?> GetJobClosingSummaryAsync(Guid tenantId, Guid jobId);
    Task<MonthEndAccrualResultDto> PostMonthEndAccrualsAsync(Guid tenantId, MonthEndAccrualRequest request);
    Task<CostLineMatchResultDto> MatchVendorInvoiceToJobAsync(Guid tenantId, VendorInvoiceMatchRequest request);
    Task<JobCloseResultDto> CloseJobAsync(Guid tenantId, JobCloseRequest request);
    Task<RevenueRecognitionResultDto> RecognizeRevenueAsync(Guid tenantId, RevenueRecognitionRequest request);
    Task<List<JobClosingEntryDto>> GetJobClosingEntriesAsync(Guid tenantId, Guid jobId);
    Task<bool> ReverseProvisionAsync(Guid tenantId, Guid jobId, string? reason = null);
    Task<bool> ReopenJobAsync(Guid tenantId, Guid jobId, string? reason = null);
    Task<OpenProvisionsReportDto> GetOpenProvisionsReportAsync(Guid tenantId, DateTime? asOfDate = null);
    Task<DeferredRevenueReportDto> GetDeferredRevenueReportAsync(Guid tenantId, DateTime? asOfDate = null);
    Task<JobProfitabilityReportDto> GetJobProfitabilityReportAsync(Guid tenantId, Guid jobId);
}
