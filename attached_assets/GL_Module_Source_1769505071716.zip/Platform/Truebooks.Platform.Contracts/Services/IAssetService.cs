using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IAssetService
{
    Task<IEnumerable<AssetDto>> GetAllAsync(Guid tenantId, Guid? categoryId = null, int? status = null, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<AssetDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateAssetRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateAssetRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task UpdateStatusAsync(Guid tenantId, Guid id, int status, CancellationToken cancellationToken = default);
}
