using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface IBudgetService
{
    Task<IEnumerable<BudgetHeaderDto>> GetAllAsync(Guid tenantId, int? fiscalYear = null, Guid? costCenterId = null, BudgetStatus? status = null, CancellationToken cancellationToken = default);
    Task<BudgetHeaderDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<BudgetHeaderDto?> GetByCodeAsync(Guid tenantId, string budgetCode, CancellationToken cancellationToken = default);
    Task<BudgetHeaderDto> CreateAsync(Guid tenantId, CreateBudgetRequest request, CancellationToken cancellationToken = default);
    Task<BudgetHeaderDto> UpdateAsync(Guid tenantId, Guid id, UpdateBudgetRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<BudgetHeaderDto> ApproveAsync(Guid tenantId, Guid id, Guid approvedByUserId, string? approvalNotes = null, CancellationToken cancellationToken = default);
    Task<BudgetHeaderDto> RejectAsync(Guid tenantId, Guid id, Guid rejectedByUserId, string? rejectionNotes = null, CancellationToken cancellationToken = default);
    Task<BudgetHeaderDto> CloseAsync(Guid tenantId, Guid id, string? closingNotes = null, CancellationToken cancellationToken = default);
    Task<BudgetHeaderDto> CreateRevisionAsync(Guid tenantId, Guid originalBudgetId, CancellationToken cancellationToken = default);
    Task<BudgetVarianceReportDto> GetVarianceReportAsync(Guid tenantId, Guid budgetId, int? periodNumber = null, CancellationToken cancellationToken = default);
    Task<IEnumerable<BudgetLineVarianceDto>> GetAccountVarianceAsync(Guid tenantId, Guid chartOfAccountId, int fiscalYear, Guid? costCenterId = null, CancellationToken cancellationToken = default);
    Task<BudgetCheckResultDto> CheckAvailabilityAsync(Guid tenantId, Guid chartOfAccountId, int fiscalYear, decimal proposedAmount, Guid? costCenterId = null, CancellationToken cancellationToken = default);
}
