using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ISupplierService
{
    Task<IEnumerable<SupplierDto>> GetAllAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<SupplierDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateSupplierRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateSupplierRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, string reason, CancellationToken cancellationToken = default);
    Task RequestCreditAsync(Guid tenantId, Guid id, decimal limit, string notes, CancellationToken cancellationToken = default);
    Task ApproveCreditAsync(Guid tenantId, Guid id, decimal approvedLimit, string notes, CancellationToken cancellationToken = default);
    Task RejectCreditAsync(Guid tenantId, Guid id, string notes, CancellationToken cancellationToken = default);
    Task<IEnumerable<SupplierCreditApprovalHistoryDto>> GetCreditHistoryAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<IEnumerable<SupplierDto>> GetPendingCreditApprovalsAsync(Guid tenantId, CancellationToken cancellationToken = default);
}
