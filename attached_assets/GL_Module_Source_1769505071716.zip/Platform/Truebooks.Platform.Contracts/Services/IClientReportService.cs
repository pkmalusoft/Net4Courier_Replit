using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface IClientReportService
{
    Task<IEnumerable<ClientReportDto>> GetAllAsync(Guid tenantId, Guid? contractId = null, Guid? customerId = null, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);
    Task<ClientReportDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ClientReportDto> CreateAsync(Guid tenantId, CreateClientReportRequest request, CancellationToken cancellationToken = default);
    Task<ClientReportDto> UpdateAsync(Guid tenantId, Guid id, UpdateClientReportRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ClientReportDto> SendReportAsync(Guid tenantId, Guid id, string recipientEmail, CancellationToken cancellationToken = default);
    Task<byte[]> ExportPdfAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<IEnumerable<ClientReportDto>> GetByContractAsync(Guid tenantId, Guid contractId, CancellationToken cancellationToken = default);
}
