using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IUSStateTaxRateService
{
    Task<IEnumerable<USStateTaxRateDto>> GetAllAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<USStateTaxRateDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateUSStateTaxRateRequest request, CancellationToken cancellationToken = default);
    Task BulkUpdateAsync(Guid tenantId, BulkUpdateUSStateTaxRateRequest request, CancellationToken cancellationToken = default);
}
