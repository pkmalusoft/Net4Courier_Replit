using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IInventoryLocationService
{
    Task<IEnumerable<InventoryLocationDto>> GetAllAsync(Guid tenantId);
    Task<IEnumerable<InventoryLocationDto>> GetByWarehouseAsync(Guid tenantId, Guid warehouseId);
    Task<InventoryLocationDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<InventoryLocationDto> CreateAsync(Guid tenantId, CreateInventoryLocationRequest request);
    Task<InventoryLocationDto> UpdateAsync(Guid tenantId, Guid id, UpdateInventoryLocationRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id);
    Task<bool> ToggleActiveAsync(Guid tenantId, Guid id);
}
