using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface ISalesInvoiceService
{
    Task<List<SalesInvoiceListDto>> GetAllAsync(Guid tenantId);
    Task<SalesInvoiceDetailDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<SalesInvoiceDetailDto> CreateAsync(Guid tenantId, object request);
    Task<SalesInvoiceDetailDto> UpdateAsync(Guid tenantId, Guid id, object request);
    Task<List<InvoiceForAllocationDto>> GetOutstandingAsync(Guid tenantId, Guid customerId);
    Task<bool> PostAsync(Guid tenantId, Guid id);
    Task<bool> VoidAsync(Guid tenantId, Guid id, string reason);
    Task<List<InvoiceableContractDto>> GetInvoiceableContractsAsync(Guid tenantId, Guid? customerId = null);
}
