using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IOpeningBalanceService
{
    Task<IEnumerable<OpeningBalanceDto>> GetAllAsync(Guid tenantId, int? fiscalYear = null, string? status = null);
    Task<OpeningBalanceDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<OpeningBalanceDto?> CreateAsync(Guid tenantId, CreateOpeningBalanceRequest request);
    Task<OpeningBalanceDto?> UpdateAsync(Guid tenantId, Guid id, UpdateOpeningBalanceRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id);
    Task<OpeningBalanceLineDto?> AddLineAsync(Guid tenantId, Guid balanceId, CreateOpeningBalanceLineRequest request);
    Task<bool> UpdateLineAsync(Guid tenantId, Guid balanceId, Guid lineId, CreateOpeningBalanceLineRequest request);
    Task<bool> DeleteLineAsync(Guid tenantId, Guid balanceId, Guid lineId);
    Task<bool> SubmitAsync(Guid tenantId, Guid id);
    Task<bool> PostAsync(Guid tenantId, Guid id);
    Task<IEnumerable<OpeningBalanceBatchDto>> GetBatchesAsync(Guid tenantId, int? fiscalYear = null, string? sourceModule = null, string? status = null);
    Task<OpeningBalanceBatchDto?> GetBatchByIdAsync(Guid tenantId, Guid id);
    Task<OpeningBalanceBatchDto?> CreateBatchAsync(Guid tenantId, CreateOpeningBalanceBatchRequest request);
    Task<bool> UpdateAsync(Guid tenantId, Guid id, UpdateOpeningBalanceBatchRequest request);
    Task<bool> CloseBatchesToRetainedEarningsAsync(Guid tenantId, int fiscalYear);
}
