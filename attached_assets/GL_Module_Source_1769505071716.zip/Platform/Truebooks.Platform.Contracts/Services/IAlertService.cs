using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IAlertService
{
    Task<IEnumerable<AlertDto>> GetAllAsync(Guid tenantId, int? alertType = null, int? priority = null, int? status = null, CancellationToken cancellationToken = default);
    Task<AlertDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateAlertRequest request, CancellationToken cancellationToken = default);
    Task AcknowledgeAsync(Guid tenantId, Guid id, Guid userId, CancellationToken cancellationToken = default);
    Task ResolveAsync(Guid tenantId, Guid id, Guid userId, CancellationToken cancellationToken = default);
    Task DismissAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}
