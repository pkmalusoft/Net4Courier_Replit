using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IPurchaseBillService
{
    Task<List<PurchaseBillListDto>> GetAllAsync(Guid tenantId);
    Task<PurchaseBillDetailDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<List<BillForAllocationDto>> GetOutstandingAsync(Guid tenantId, Guid vendorId);
    Task<bool> VoidAsync(Guid tenantId, Guid id, string reason);
}
