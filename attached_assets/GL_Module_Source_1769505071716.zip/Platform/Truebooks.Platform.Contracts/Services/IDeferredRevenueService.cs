using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IDeferredRevenueService
{
    Task<DeferredRevenueDashboardDto> GetDashboardAsync(Guid tenantId);
    Task<IEnumerable<RevenueScheduleDto>> GetSchedulesAsync(Guid tenantId, string? status = null);
    Task<RevenueScheduleDto?> GetScheduleByIdAsync(Guid tenantId, Guid id);
    Task<IEnumerable<RecognitionLineDto>> GetScheduleLinesAsync(Guid tenantId, Guid scheduleId);
    Task<IEnumerable<DeferredRevenueAlertDto>> GetPendingAlertsAsync(Guid tenantId);
    Task<bool> ProcessRecognitionAsync(Guid tenantId, Guid scheduleId, Guid lineId);
    Task<bool> ProcessBulkRecognitionAsync(Guid tenantId, DateTime throughDate);
}
