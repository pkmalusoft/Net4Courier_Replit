using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface IServiceEnquiryService
{
    Task<IEnumerable<ServiceEnquiryDto>> GetAllAsync(Guid tenantId, EnquiryStatus? status = null, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);
    Task<ServiceEnquiryDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ServiceEnquiryDto> CreateAsync(Guid tenantId, CreateServiceEnquiryRequest request, CancellationToken cancellationToken = default);
    Task<ServiceEnquiryDto> UpdateAsync(Guid tenantId, Guid id, UpdateServiceEnquiryRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ServiceEnquiryDto> UpdateStatusAsync(Guid tenantId, Guid id, EnquiryStatus status, CancellationToken cancellationToken = default);
    Task<ServiceEnquiryDto> ConvertToQuotationAsync(Guid tenantId, Guid enquiryId, CancellationToken cancellationToken = default);
    Task<IEnumerable<ServiceEnquiryDto>> GetFollowUpsDueAsync(Guid tenantId, DateTime asOfDate, CancellationToken cancellationToken = default);
}
