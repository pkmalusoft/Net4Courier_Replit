using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface ISalesQuotationService
{
    Task<List<SalesQuotationListDto>> GetAllAsync(Guid tenantId);
    Task<SalesQuotationDetailDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<SalesQuotationDetailDto> CreateAsync(Guid tenantId, CreateSalesQuotationRequest request);
    Task<SalesQuotationDetailDto> UpdateAsync(Guid tenantId, Guid id, CreateSalesQuotationRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, string reason);
    Task<Guid> ConvertToOrderAsync(Guid tenantId, Guid id);
}
