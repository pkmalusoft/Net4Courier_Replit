using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IWarehouseService
{
    Task<IEnumerable<WarehouseDto>> GetAllAsync(Guid tenantId);
    Task<WarehouseDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<WarehouseDto> CreateAsync(Guid tenantId, CreateWarehouseRequest request);
    Task<WarehouseDto> UpdateAsync(Guid tenantId, Guid id, UpdateWarehouseRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id);
    Task<bool> ToggleActiveAsync(Guid tenantId, Guid id);
}
