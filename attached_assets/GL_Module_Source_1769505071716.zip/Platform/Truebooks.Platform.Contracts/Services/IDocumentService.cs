using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IDocumentService
{
    Task<IEnumerable<DocumentDto>> GetAllAsync(Guid tenantId, Guid? categoryId = null, int? documentType = null, bool? isExpired = null, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<DocumentDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateDocumentRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateDocumentRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}
