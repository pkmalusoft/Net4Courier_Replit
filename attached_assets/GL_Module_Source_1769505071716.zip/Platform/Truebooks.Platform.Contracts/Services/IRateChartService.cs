using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IRateChartService
{
    Task<IEnumerable<RateChartDto>> GetAllAsync(Guid tenantId, Guid? serviceDetailId = null, RateTypeDto? rateType = null, RecurringTypeDto? recurringType = null, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<RateChartDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<IEnumerable<RateChartDto>> GetByServiceDetailAsync(Guid tenantId, Guid serviceDetailId, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateRateChartRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateRateChartRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task ActivateAsync(Guid tenantId, Guid id, bool isActive, CancellationToken cancellationToken = default);
    Task<decimal> CalculateMarginAsync(decimal costPrice, decimal sellingPrice);
}
