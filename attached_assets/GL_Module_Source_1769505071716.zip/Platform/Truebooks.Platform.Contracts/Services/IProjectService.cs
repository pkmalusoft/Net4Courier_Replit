using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IProjectService
{
    Task<List<ProjectDto>> GetAllAsync(Guid tenantId, bool includeInactive = false);
    Task<List<ProjectDto>> GetActiveAsync(Guid tenantId);
    Task<ProjectDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<Guid> CreateAsync(Guid tenantId, CreateProjectRequest request);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateProjectRequest request);
    Task DeleteAsync(Guid tenantId, Guid id);
}
