using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IApprovalWorkflowService
{
    Task<IEnumerable<ApprovalWorkflowDto>> GetAllAsync(Guid tenantId, int? workflowType = null, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<ApprovalWorkflowDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateApprovalWorkflowRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateApprovalWorkflowRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<IEnumerable<ApprovalStepDto>> GetStepsAsync(Guid tenantId, Guid workflowId, CancellationToken cancellationToken = default);
    Task<Guid> CreateStepAsync(Guid tenantId, Guid workflowId, CreateApprovalStepRequest request, CancellationToken cancellationToken = default);
    Task UpdateStepAsync(Guid tenantId, Guid stepId, UpdateApprovalStepRequest request, CancellationToken cancellationToken = default);
    Task DeleteStepAsync(Guid tenantId, Guid stepId, CancellationToken cancellationToken = default);
}
