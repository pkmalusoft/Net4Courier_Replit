using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IAccountService
{
    Task<AccountDto?> GetByCodeAsync(Guid tenantId, string accountCode, CancellationToken cancellationToken = default);
    Task<AccountDto?> GetByIdAsync(Guid tenantId, Guid accountId, CancellationToken cancellationToken = default);
    Task<IEnumerable<AccountDto>> GetByTypeAsync(Guid tenantId, AccountType type, CancellationToken cancellationToken = default);
    Task<IEnumerable<AccountDto>> GetAllAsync(Guid tenantId, CancellationToken cancellationToken = default);
}

public enum AccountType
{
    Asset = 1,
    Liability = 2,
    Equity = 3,
    Revenue = 4,
    Expense = 5
}
