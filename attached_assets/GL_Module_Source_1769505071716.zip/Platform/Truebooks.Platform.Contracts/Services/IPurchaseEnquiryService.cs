using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IPurchaseEnquiryService
{
    Task<List<PurchaseEnquiryDto>> GetAllAsync(Guid tenantId);
    Task<PurchaseEnquiryDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<PurchaseEnquiryDto?> CreateAsync(Guid tenantId, CreatePurchaseEnquiryRequest request);
    Task<PurchaseEnquiryDto?> UpdateAsync(Guid tenantId, Guid id, CreatePurchaseEnquiryRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, string reason);
    Task<Guid?> ConvertToQuotationAsync(Guid tenantId, Guid id);
}
