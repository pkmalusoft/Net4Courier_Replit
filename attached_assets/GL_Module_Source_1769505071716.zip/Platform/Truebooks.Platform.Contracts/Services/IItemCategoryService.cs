using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IItemCategoryService
{
    Task<IEnumerable<ItemCategoryDto>> GetAllAsync(Guid tenantId);
    Task<ItemCategoryDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<ItemCategoryDto> CreateAsync(Guid tenantId, CreateItemCategoryRequest request);
    Task<ItemCategoryDto> UpdateAsync(Guid tenantId, Guid id, UpdateItemCategoryRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id);
    Task<bool> ToggleActiveAsync(Guid tenantId, Guid id);
}
