using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IBackupService
{
    Task<IEnumerable<BackupJobDto>> GetAllBackupsAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<BackupJobDto?> GetBackupByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateBackupAsync(Guid tenantId, CreateBackupRequest request, CancellationToken cancellationToken = default);
    Task ExecuteBackupAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<byte[]> DownloadBackupAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task DeleteBackupAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    
    Task<IEnumerable<RestoreJobDto>> GetAllRestoresAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<Guid> CreateRestoreAsync(Guid tenantId, CreateRestoreRequest request, CancellationToken cancellationToken = default);
    Task ExecuteRestoreAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    
    Task<IEnumerable<BackupScheduleDto>> GetAllSchedulesAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<Guid> CreateScheduleAsync(Guid tenantId, CreateBackupScheduleRequest request, CancellationToken cancellationToken = default);
    Task UpdateScheduleAsync(Guid tenantId, Guid id, UpdateBackupScheduleRequest request, CancellationToken cancellationToken = default);
    Task DeleteScheduleAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task ToggleScheduleAsync(Guid tenantId, Guid id, bool isActive, CancellationToken cancellationToken = default);
}
