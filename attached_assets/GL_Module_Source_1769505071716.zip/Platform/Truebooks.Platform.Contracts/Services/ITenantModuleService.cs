using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface ITenantModuleService
{
    Task<bool> IsModuleEnabledAsync(Guid tenantId, string moduleCode, CancellationToken cancellationToken = default);
    Task<ModuleAccessLevel> GetModuleAccessLevelAsync(Guid tenantId, string moduleCode, CancellationToken cancellationToken = default);
    Task<IEnumerable<string>> GetEnabledModulesAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task EnableModuleAsync(Guid tenantId, string moduleCode, Guid enabledByUserId, CancellationToken cancellationToken = default);
    Task DisableModuleAsync(Guid tenantId, string moduleCode, Guid disabledByUserId, CancellationToken cancellationToken = default);
    Task InvalidateCacheAsync(Guid tenantId, CancellationToken cancellationToken = default);
}
