using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IGLPostingService
{
    Task<JournalEntryResult> PostJournalEntryAsync(JournalEntryRequest request, CancellationToken cancellationToken = default);
    Task<VoucherResult> CreateVoucherAsync(VoucherRequest request, CancellationToken cancellationToken = default);
}

public record JournalEntryRequest(
    Guid TenantId,
    DateTime TransactionDate,
    string Reference,
    string Description,
    string SourceModule,
    Guid? SourceDocumentId,
    IEnumerable<JournalEntryLine> Lines
);

public record JournalEntryLine(
    string AccountCode,
    decimal DebitAmount,
    decimal CreditAmount,
    string? CostCenterCode = null,
    string? Description = null
);

public record JournalEntryResult(
    bool Success,
    string? VoucherNumber,
    Guid? JournalEntryId,
    string? ErrorMessage
);

public record VoucherRequest(
    Guid TenantId,
    string VoucherType,
    DateTime TransactionDate,
    string Reference,
    string Description,
    string SourceModule,
    Guid? SourceDocumentId,
    IEnumerable<JournalEntryLine> Lines
);

public record VoucherResult(
    bool Success,
    string? VoucherNumber,
    Guid? VoucherId,
    string? ErrorMessage
);
