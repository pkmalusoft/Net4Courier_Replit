using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IPurchaseOrderService
{
    Task<List<PurchaseOrderDto>> GetAllAsync(Guid tenantId);
    Task<List<PurchaseOrderDto>> GetByStatusAsync(Guid tenantId, string status);
    Task<PurchaseOrderDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<bool> ApproveAsync(Guid tenantId, Guid id);
    Task<bool> RejectAsync(Guid tenantId, Guid id, string reason);
}
