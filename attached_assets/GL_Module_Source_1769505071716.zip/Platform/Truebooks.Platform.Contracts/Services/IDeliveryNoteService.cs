using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IDeliveryNoteService
{
    Task<List<DeliveryNoteListDto>> GetAllAsync(Guid tenantId);
    Task<DeliveryNoteDetailDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<DeliveryNoteDetailDto> CreateAsync(Guid tenantId, CreateDeliveryNoteRequest request);
    Task<DeliveryNoteDetailDto> UpdateAsync(Guid tenantId, Guid id, CreateDeliveryNoteRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, string reason);
    Task<bool> ConfirmAsync(Guid tenantId, Guid id);
    Task<bool> VoidAsync(Guid tenantId, Guid id, string reason);
    Task<byte[]> PrintAsync(Guid tenantId, Guid id);
}
