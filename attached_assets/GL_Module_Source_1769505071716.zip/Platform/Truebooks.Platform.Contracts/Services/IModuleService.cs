using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IModuleService
{
    Task<IEnumerable<ModuleDto>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<IEnumerable<Guid>> GetCustomerModulesAsync(Guid tenantId, Guid customerId, CancellationToken cancellationToken = default);
    Task<IEnumerable<Guid>> GetSupplierModulesAsync(Guid tenantId, Guid supplierId, CancellationToken cancellationToken = default);
    Task UpdateCustomerModulesAsync(Guid tenantId, Guid customerId, IEnumerable<Guid> moduleIds, CancellationToken cancellationToken = default);
    Task UpdateSupplierModulesAsync(Guid tenantId, Guid supplierId, IEnumerable<Guid> moduleIds, CancellationToken cancellationToken = default);
}
