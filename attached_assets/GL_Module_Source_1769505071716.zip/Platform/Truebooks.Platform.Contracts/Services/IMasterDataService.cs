using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IMasterDataService
{
    Task<IEnumerable<CurrencyDto>> GetCurrenciesAsync(Guid tenantId);
    Task<IEnumerable<CountryDto>> GetCountriesAsync(Guid tenantId);
    Task<IEnumerable<StateDto>> GetStatesAsync(Guid tenantId, Guid? countryId = null);
    Task<IEnumerable<CityDto>> GetCitiesAsync(Guid tenantId, Guid? stateId = null);
    Task<IEnumerable<PostalCodeDto>> GetPostalCodesAsync(Guid tenantId, Guid? cityId = null);
    Task<IEnumerable<BranchDto>> GetBranchesAsync(Guid tenantId);
    Task<CurrencyDto?> GetBaseCurrencyAsync(Guid tenantId);
}
