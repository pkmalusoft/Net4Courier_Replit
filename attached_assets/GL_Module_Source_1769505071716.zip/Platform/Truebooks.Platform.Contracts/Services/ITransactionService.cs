namespace Truebooks.Platform.Contracts.Services;

public interface ITransactionService
{
    Task<bool> HasTransactionsAsync(Guid tenantId, DateTime fromDate, DateTime toDate);
    Task<int> GetTransactionCountAsync(Guid tenantId, DateTime fromDate, DateTime toDate);
    Task<bool> HasPendingTransactionsAsync(Guid tenantId);
    Task<bool> ValidateTransactionDateAsync(Guid tenantId, DateTime transactionDate);
}
