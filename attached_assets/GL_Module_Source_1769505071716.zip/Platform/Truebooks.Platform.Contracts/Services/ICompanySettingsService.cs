namespace Truebooks.Platform.Contracts.Services;

public interface ICompanySettingsService
{
    Task<CompanyProfileDto?> GetProfileAsync(Guid tenantId);
    Task<CompanySettingsFullDto?> GetSettingsAsync(Guid tenantId);
    Task<bool> UpdateSettingsAsync(Guid tenantId, UpdateCompanySettingsRequest request);
}

public class CompanyProfileDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public string? State { get; set; }
    public string? Country { get; set; }
    public Guid? BaseCurrencyId { get; set; }
    public string? BaseCurrencyCode { get; set; }
}

public class CompanySettingsFullDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = "";
    public string? Subdomain { get; set; }
    public string? Address { get; set; }
    public string? AdminEmail { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public Guid? PostalCodeId { get; set; }
    public string? State { get; set; }
    public string? Country { get; set; }
    public string? City { get; set; }
    public string? PostalCode { get; set; }
    public int TaxSystem { get; set; }
    public string? GSTIN { get; set; }
    public string? TRN { get; set; }
    public string? EIN { get; set; }
    public Guid? BaseCurrencyId { get; set; }
    public string? BaseCurrencyCode { get; set; }
    public string? BaseCurrencyName { get; set; }
    public bool IsFieldsLocked { get; set; }
    public bool IsGSTINLocked { get; set; }
    public bool EnableMultipleCalendars { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? SubscriptionExpiresAt { get; set; }
}

public class UpdateCompanySettingsRequest
{
    public string Name { get; set; } = "";
    public string? Address { get; set; }
    public string AdminEmail { get; set; } = "";
    public string? State { get; set; }
    public string? Country { get; set; }
    public string? City { get; set; }
    public string? PostalCode { get; set; }
    public int TaxSystem { get; set; }
    public string? GSTIN { get; set; }
    public string? TRN { get; set; }
    public string? EIN { get; set; }
    public Guid? BaseCurrencyId { get; set; }
    public bool EnableMultipleCalendars { get; set; }
}
