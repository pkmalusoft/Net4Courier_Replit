using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface ISalesReturnService
{
    Task<List<SalesReturnListDto>> GetAllAsync(Guid tenantId);
    Task<SalesReturnDetailDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<InvoiceReturnInfoDto?> GetInvoiceForReturnAsync(Guid tenantId, string invoiceNumber);
    Task<SalesReturnDetailDto> CreateAsync(Guid tenantId, CreateSalesReturnRequest request);
    Task<SalesReturnDetailDto> UpdateAsync(Guid tenantId, Guid id, CreateSalesReturnRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, string reason);
    Task<bool> PostStockAsync(Guid tenantId, Guid id);
    Task<bool> PostGLAsync(Guid tenantId, Guid id);
    Task<bool> ApproveAsync(Guid tenantId, Guid id);
}

public record InvoiceReturnInfoDto(
    Guid InvoiceId,
    string InvoiceNumber,
    Guid? CustomerId,
    string? CustomerName,
    List<InvoiceReturnLineDto> Lines
);

public record InvoiceReturnLineDto(
    Guid InvoiceLineId,
    Guid? ItemId,
    string? ItemName,
    decimal SoldQuantity,
    decimal AlreadyReturnedQuantity,
    decimal AvailableToReturnQuantity,
    decimal UnitPrice,
    Guid? TaxCodeId,
    string? TaxCodeName,
    decimal CGSTRate,
    decimal SGSTRate,
    decimal IGSTRate,
    Guid? RevenueAccountId
);
