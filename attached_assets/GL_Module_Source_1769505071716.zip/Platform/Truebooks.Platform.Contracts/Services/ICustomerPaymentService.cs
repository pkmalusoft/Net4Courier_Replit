using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ICustomerPaymentService
{
    Task<IEnumerable<CustomerPaymentDto>> GetPaymentHistoryAsync(Guid tenantId, Guid customerId, DateTime? fromDate = null, DateTime? toDate = null);
    Task<CustomerPaymentResultDto> InitiatePaymentAsync(Guid tenantId, CustomerPaymentRequestDto request);
    Task<CustomerPaymentDto?> GetPaymentByIdAsync(Guid tenantId, Guid paymentId);
    Task<IEnumerable<PaymentMethodDto>> GetPaymentMethodsAsync(Guid tenantId);
}
