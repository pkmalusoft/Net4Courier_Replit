using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IBankReconciliationService
{
    Task<List<BankReconciliationDto>> GetAllAsync(Guid tenantId);
    Task<BankReconciliationDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<List<BankReconciliationDto>> GetByBankAccountAsync(Guid tenantId, Guid bankAccountId);
    Task<BankReconciliationDto?> CreateAsync(Guid tenantId, CreateBankReconciliationRequest request);
    Task<BankReconciliationDto?> StartAsync(Guid tenantId, StartReconciliationRequest request);
    Task<bool> ImportStatementAsync(Guid tenantId, Guid reconciliationId, ImportStatementRequest request);
    Task<AutoMatchResultDto?> AutoMatchAsync(Guid tenantId, Guid reconciliationId);
    Task<bool> FinalizeAsync(Guid tenantId, Guid reconciliationId);
    Task<List<BankReconciliationLineDto>> GetLinesAsync(Guid tenantId, Guid reconciliationId);
    Task<bool> MatchLineAsync(Guid tenantId, Guid reconciliationId, MatchReconciliationLineRequest request);
    Task<bool> MatchAllAsync(Guid tenantId, Guid reconciliationId, List<Guid> lineIds);
    Task<bool> UnmatchLineAsync(Guid tenantId, Guid reconciliationId, Guid lineId);
    Task<bool> CompleteReconciliationAsync(Guid tenantId, Guid id);
    Task<bool> ReopenReconciliationAsync(Guid tenantId, Guid id);
    Task<decimal> GetUnreconciledBalanceAsync(Guid tenantId, Guid bankAccountId);
}
