using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ICustomerStatementService
{
    Task<CustomerStatementDto?> GenerateStatementAsync(Guid tenantId, CustomerStatementRequestDto request);
    Task<byte[]?> ExportPdfAsync(Guid tenantId, CustomerStatementRequestDto request);
}
