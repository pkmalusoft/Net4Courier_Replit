using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface ISalesEnquiryService
{
    Task<List<SalesEnquiryListDto>> GetAllAsync(Guid tenantId);
    Task<SalesEnquiryDetailDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<SalesEnquiryDetailDto> CreateAsync(Guid tenantId, CreateSalesEnquiryRequest request);
    Task<SalesEnquiryDetailDto> UpdateAsync(Guid tenantId, Guid id, CreateSalesEnquiryRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, string reason);
    Task<Guid> ConvertToQuotationAsync(Guid tenantId, Guid id);
}
