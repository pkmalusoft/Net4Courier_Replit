using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IPurchaseQuotationService
{
    Task<List<PurchaseQuotationDto>> GetAllAsync(Guid tenantId);
    Task<PurchaseQuotationDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<PurchaseQuotationDto?> CreateAsync(Guid tenantId, CreatePurchaseQuotationRequest request);
    Task<PurchaseQuotationDto?> UpdateAsync(Guid tenantId, Guid id, CreatePurchaseQuotationRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, string reason);
    Task<Guid?> ConvertToOrderAsync(Guid tenantId, Guid id);
}
