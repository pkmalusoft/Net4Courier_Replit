using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ICostCenterService
{
    Task<IEnumerable<CostCenterDto>> GetAllAsync(Guid tenantId, bool activeOnly = true, CancellationToken cancellationToken = default);
    Task<CostCenterDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<CostCenterDto?> GetByCodeAsync(Guid tenantId, string code, CancellationToken cancellationToken = default);
    Task<CostCenterDto> CreateAsync(Guid tenantId, CreateCostCenterRequest request, CancellationToken cancellationToken = default);
    Task<CostCenterDto> UpdateAsync(Guid tenantId, Guid id, UpdateCostCenterRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<IEnumerable<CostCenterDto>> GetHierarchyAsync(Guid tenantId, CancellationToken cancellationToken = default);
}
