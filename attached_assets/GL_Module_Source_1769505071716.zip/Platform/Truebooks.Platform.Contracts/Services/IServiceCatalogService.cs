using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface IServiceCatalogService
{
    Task<IEnumerable<ServiceCategoryDto>> GetCategoriesAsync(Guid tenantId, CatalogItemType? itemType = null, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<ServiceCategoryDetailDto?> GetCategoryWithTypesAsync(Guid tenantId, Guid categoryId, CancellationToken cancellationToken = default);
    Task<Guid> CreateCategoryAsync(Guid tenantId, CreateServiceCategoryRequest request, CancellationToken cancellationToken = default);
    Task UpdateCategoryAsync(Guid tenantId, Guid id, UpdateServiceCategoryRequest request, CancellationToken cancellationToken = default);
    Task DeleteCategoryAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task ActivateCategoryAsync(Guid tenantId, Guid id, bool isActive, CancellationToken cancellationToken = default);

    Task<IEnumerable<ServiceTypeDto>> GetTypesAsync(Guid tenantId, Guid? categoryId = null, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<ServiceTypeDetailDto?> GetTypeWithNamesAsync(Guid tenantId, Guid typeId, CancellationToken cancellationToken = default);
    Task<Guid> CreateTypeAsync(Guid tenantId, CreateServiceTypeRequest request, CancellationToken cancellationToken = default);
    Task UpdateTypeAsync(Guid tenantId, Guid id, UpdateServiceTypeRequest request, CancellationToken cancellationToken = default);
    Task DeleteTypeAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task ActivateTypeAsync(Guid tenantId, Guid id, bool isActive, CancellationToken cancellationToken = default);

    Task<IEnumerable<ServiceNameDto>> GetNamesAsync(Guid tenantId, Guid? typeId = null, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<ServiceNameDetailDto?> GetNameWithDetailsAsync(Guid tenantId, Guid nameId, CancellationToken cancellationToken = default);
    Task<Guid> CreateNameAsync(Guid tenantId, CreateServiceNameRequest request, CancellationToken cancellationToken = default);
    Task UpdateNameAsync(Guid tenantId, Guid id, UpdateServiceNameRequest request, CancellationToken cancellationToken = default);
    Task DeleteNameAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task ActivateNameAsync(Guid tenantId, Guid id, bool isActive, CancellationToken cancellationToken = default);

    Task<IEnumerable<ServiceDetailDto>> GetDetailsAsync(Guid tenantId, Guid? nameId = null, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<ServiceDetailDto?> GetDetailByIdAsync(Guid tenantId, Guid detailId, CancellationToken cancellationToken = default);
    Task<Guid> CreateDetailAsync(Guid tenantId, CreateServiceDetailRequest request, CancellationToken cancellationToken = default);
    Task UpdateDetailAsync(Guid tenantId, Guid id, UpdateServiceDetailRequest request, CancellationToken cancellationToken = default);
    Task DeleteDetailAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task ActivateDetailAsync(Guid tenantId, Guid id, bool isActive, CancellationToken cancellationToken = default);
}
