using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IAssetCategoryService
{
    Task<IEnumerable<AssetCategoryDto>> GetAllAsync(Guid tenantId, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<AssetCategoryDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateAssetCategoryRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateAssetCategoryRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task ActivateAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}
