using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IYearEndService
{
    Task<YearEndStatusDto> GetStatusAsync(Guid tenantId, int fiscalYear);
    Task<YearEndPreviewDto> PreviewClosingAsync(Guid tenantId, int fiscalYear);
    Task<bool> ExecuteClosingAsync(Guid tenantId, int fiscalYear, YearEndClosingRequest request);
    Task<bool> RollbackClosingAsync(Guid tenantId, int fiscalYear);
    Task<IEnumerable<int>> GetAvailableFiscalYearsAsync(Guid tenantId);
    
    Task<IEnumerable<YearEndClosingDto>> GetAllClosingsAsync(Guid tenantId);
    Task<YearEndClosingDto?> GetClosingByIdAsync(Guid tenantId, Guid closingId);
    Task<YearEndClosingDto?> StartClosingAsync(Guid tenantId, Guid periodId);
    Task<YearEndValidationResultDto> ValidateAsync(Guid tenantId, Guid closingId);
    Task<bool> CloseIncomeExpenseAsync(Guid tenantId, Guid closingId);
    Task<bool> SnapshotSubledgersAsync(Guid tenantId, Guid closingId);
    Task<bool> SnapshotInventoryAsync(Guid tenantId, Guid closingId);
    Task<bool> GenerateOpeningJEAsync(Guid tenantId, Guid closingId);
    Task<bool> CompleteClosingAsync(Guid tenantId, Guid closingId);
    Task<bool> RollbackClosingAsync(Guid tenantId, Guid closingId, string reason);
}
