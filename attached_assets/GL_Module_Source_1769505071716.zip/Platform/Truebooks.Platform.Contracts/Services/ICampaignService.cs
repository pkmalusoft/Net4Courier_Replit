using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface ICampaignService
{
    Task<IEnumerable<CampaignDto>> GetAllAsync(Guid tenantId, CampaignStatus? status = null, CancellationToken cancellationToken = default);
    Task<CampaignDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<CampaignDto> CreateAsync(Guid tenantId, CreateCampaignRequest request, CancellationToken cancellationToken = default);
    Task<CampaignDto> UpdateAsync(Guid tenantId, Guid id, UpdateCampaignRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<CampaignDto> UpdateStatusAsync(Guid tenantId, Guid id, CampaignStatus status, CancellationToken cancellationToken = default);
    Task<IEnumerable<CampaignMetricsDto>> GetMetricsAsync(Guid tenantId, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);
    Task<CampaignMetricsDto?> GetCampaignMetricsAsync(Guid tenantId, Guid campaignId, CancellationToken cancellationToken = default);
}
