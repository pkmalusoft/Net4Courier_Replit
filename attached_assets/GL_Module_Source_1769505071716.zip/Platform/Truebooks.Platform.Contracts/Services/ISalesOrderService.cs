using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface ISalesOrderService
{
    Task<List<SalesOrderListDto>> GetAllAsync(Guid tenantId);
    Task<List<SalesOrderListDto>> GetByStatusAsync(Guid tenantId, string status);
    Task<SalesOrderDetailDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<SalesOrderDetailDto> CreateAsync(Guid tenantId, CreateSalesOrderRequest request);
    Task<SalesOrderDetailDto> UpdateAsync(Guid tenantId, Guid id, CreateSalesOrderRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, string reason);
    Task<bool> ApproveAsync(Guid tenantId, Guid id);
    Task<bool> RejectAsync(Guid tenantId, Guid id, string reason);
}
