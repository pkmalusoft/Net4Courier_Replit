using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IFinancialCalendarService
{
    Task<IEnumerable<FinancialCalendarDto>> GetAllAsync(Guid tenantId);
    Task<FinancialCalendarDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<FinancialCalendarDto?> GetPrimaryAsync(Guid tenantId);
    Task<FinancialCalendarDto?> CreateAsync(Guid tenantId, CreateFinancialCalendarRequest request);
    Task<FinancialCalendarDto?> UpdateAsync(Guid tenantId, Guid id, UpdateFinancialCalendarRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id);
    Task<bool> SetAsPrimaryAsync(Guid tenantId, Guid id);
    Task<bool> IsMultiCalendarEnabledAsync(Guid tenantId);
    Task<bool> EnableMultiCalendarAsync(Guid tenantId, bool enable);
}
