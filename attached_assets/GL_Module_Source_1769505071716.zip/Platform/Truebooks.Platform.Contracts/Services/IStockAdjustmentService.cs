using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IStockAdjustmentService
{
    Task<List<StockAdjustmentDto>> GetAllAsync(Guid tenantId, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);
    Task<List<StockAdjustmentDto>> GetAllAsync(Guid tenantId, Guid? warehouseId, int? adjustmentType, CancellationToken cancellationToken = default);
    Task<StockAdjustmentDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<StockAdjustmentDto?> CreateAsync(Guid tenantId, CreateStockAdjustmentRequest request, CancellationToken cancellationToken = default);
    Task<bool> ApproveAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<bool> RejectAsync(Guid tenantId, Guid id, string reason, CancellationToken cancellationToken = default);
}
