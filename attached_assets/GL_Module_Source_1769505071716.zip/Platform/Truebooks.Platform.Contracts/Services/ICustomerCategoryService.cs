using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ICustomerCategoryService
{
    Task<IEnumerable<CustomerCategoryDto>> GetAllAsync(Guid tenantId, bool includeInactive = false, CancellationToken cancellationToken = default);
    Task<CustomerCategoryDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateCustomerCategoryRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateCustomerCategoryRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task ActivateAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}
