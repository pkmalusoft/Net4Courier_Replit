using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ICourierDashboardService
{
    Task<CourierDashboardDto?> GetDashboardAsync(Guid tenantId, DateTime fromDate, DateTime toDate, CancellationToken cancellationToken = default);
}
