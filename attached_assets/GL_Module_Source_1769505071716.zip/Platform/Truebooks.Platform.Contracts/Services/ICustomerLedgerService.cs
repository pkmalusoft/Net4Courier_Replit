using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface ICustomerLedgerService
{
    Task<IEnumerable<CustomerLedgerEntryDto>> GetLedgerEntriesAsync(Guid tenantId, CustomerLedgerRequestDto request);
    Task<decimal> GetBalanceAsync(Guid tenantId, Guid customerId, DateTime? asOfDate = null);
}
