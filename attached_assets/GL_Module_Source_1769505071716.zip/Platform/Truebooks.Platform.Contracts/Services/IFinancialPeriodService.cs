using Truebooks.Platform.Contracts.DTOs.Finance;

namespace Truebooks.Platform.Contracts.Services;

public interface IFinancialPeriodService
{
    Task<IEnumerable<FinancialPeriodDto>> GetAllAsync(Guid tenantId, int? fiscalYear = null);
    Task<FinancialPeriodDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<FinancialPeriodDto?> GetCurrentPeriodAsync(Guid tenantId);
    Task<FinancialPeriodDto?> CreateAsync(Guid tenantId, CreateFinancialPeriodRequest request);
    Task<FinancialPeriodDto?> UpdateAsync(Guid tenantId, Guid id, UpdateFinancialPeriodRequest request);
    Task<bool> OpenPeriodAsync(Guid tenantId, Guid id);
    Task<bool> SoftClosePeriodAsync(Guid tenantId, Guid id);
    Task<bool> HardClosePeriodAsync(Guid tenantId, Guid id);
    Task<bool> ClosePeriodAsync(Guid tenantId, Guid id);
    Task<bool> ReopenPeriodAsync(Guid tenantId, Guid id);
    Task<bool> ArchivePeriodAsync(Guid tenantId, Guid id);
    Task<bool> GeneratePeriodsAsync(Guid tenantId, int fiscalYear, DateTime startDate);
    Task<bool> CreateFiscalYearAsync(Guid tenantId, DateTime startDate, DateTime endDate);
    Task<TransactionCountsDto?> GetTransactionCountsAsync(Guid tenantId, int fiscalYear);
    Task<bool> ResetFiscalYearAsync(Guid tenantId, int fiscalYear, bool resetDocumentNumbers);
}
