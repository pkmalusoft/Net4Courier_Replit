using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IStockTransferService
{
    Task<List<StockTransferDto>> GetAllAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<StockTransferDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<Guid> CreateAsync(Guid tenantId, CreateStockTransferRequest request, CancellationToken cancellationToken = default);
    Task<bool> UpdateAsync(Guid tenantId, Guid id, UpdateStockTransferRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<string> GetNextTransferNumberAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<bool> ApproveAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<bool> DispatchAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<bool> ReceiveAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<bool> CompleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<bool> CancelAsync(Guid tenantId, Guid id, string reason, CancellationToken cancellationToken = default);
    Task<List<StockTransferDto>> GetByStatusAsync(Guid tenantId, int status, CancellationToken cancellationToken = default);
}
