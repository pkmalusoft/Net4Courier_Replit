using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IInventoryService
{
    Task<bool> CheckStockAsync(Guid tenantId, Guid productId, decimal quantity, Guid? warehouseId = null, CancellationToken cancellationToken = default);
    Task<StockMovementResult> UpdateStockAsync(StockMovementRequest request, CancellationToken cancellationToken = default);
    Task<ProductDto?> GetProductAsync(Guid tenantId, Guid productId, CancellationToken cancellationToken = default);
    Task<IEnumerable<ProductDto>> SearchProductsAsync(Guid tenantId, string query, int maxResults = 50, CancellationToken cancellationToken = default);
}

public record StockMovementRequest(
    Guid TenantId,
    Guid ProductId,
    decimal Quantity,
    string MovementType,
    Guid? WarehouseId,
    string Reference,
    string SourceModule,
    Guid? SourceDocumentId
);

public record StockMovementResult(
    bool Success,
    Guid? MovementId,
    string? ErrorMessage
);
