using Truebooks.Platform.Contracts.DTOs;

namespace Truebooks.Platform.Contracts.Services;

public interface IDepartmentService
{
    Task<List<DepartmentDto>> GetAllAsync(Guid tenantId, bool includeInactive = false, Guid? branchId = null);
    Task<List<DepartmentDto>> GetActiveAsync(Guid tenantId, Guid? branchId = null);
    Task<DepartmentDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<List<DepartmentDto>> GetHierarchyAsync(Guid tenantId, Guid? branchId = null);
    Task<List<DepartmentDto>> GetUserAccessibleDepartmentsAsync(Guid tenantId);
    Task<Guid> CreateAsync(Guid tenantId, CreateDepartmentRequest request);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateDepartmentRequest request);
    Task DeleteAsync(Guid tenantId, Guid id);
}
