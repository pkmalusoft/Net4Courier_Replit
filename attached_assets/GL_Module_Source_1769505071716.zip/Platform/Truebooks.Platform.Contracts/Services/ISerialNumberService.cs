using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface ISerialNumberService
{
    Task<IEnumerable<SerialNumberDto>> GetAllAsync(Guid tenantId);
    Task<IEnumerable<SerialNumberDto>> GetByItemAsync(Guid tenantId, Guid itemId);
    Task<IEnumerable<SerialNumberDto>> GetByWarehouseAsync(Guid tenantId, Guid warehouseId);
    Task<IEnumerable<SerialNumberDto>> GetByStatusAsync(Guid tenantId, SerialStatus status);
    Task<SerialNumberDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<SerialNumberDto?> GetBySerialCodeAsync(Guid tenantId, string serialCode);
    Task<SerialNumberDto> CreateAsync(Guid tenantId, CreateSerialNumberRequest request);
    Task<SerialNumberDto> UpdateAsync(Guid tenantId, Guid id, UpdateSerialNumberRequest request);
    Task<bool> UpdateStatusAsync(Guid tenantId, Guid id, SerialStatus status);
    Task<bool> DeleteAsync(Guid tenantId, Guid id);
}
