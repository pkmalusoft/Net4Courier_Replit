using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface IServiceQuotationService
{
    Task<IEnumerable<ServiceQuotationDto>> GetAllAsync(Guid tenantId, QuotationStatus? status = null, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);
    Task<ServiceQuotationDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ServiceQuotationDto> CreateAsync(Guid tenantId, CreateServiceQuotationRequest request, CancellationToken cancellationToken = default);
    Task<ServiceQuotationDto> UpdateAsync(Guid tenantId, Guid id, UpdateServiceQuotationRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ServiceQuotationDto> UpdateStatusAsync(Guid tenantId, Guid id, QuotationStatus status, CancellationToken cancellationToken = default);
    Task<ServiceQuotationDto> CreateRevisionAsync(Guid tenantId, Guid quotationId, CancellationToken cancellationToken = default);
    Task<ServiceQuotationDto> ConvertToContractAsync(Guid tenantId, Guid quotationId, CancellationToken cancellationToken = default);
    Task<byte[]> ExportPdfAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}
