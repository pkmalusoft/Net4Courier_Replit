using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface IServiceTaskLogService
{
    Task<IEnumerable<ServiceTaskLogDto>> GetAllAsync(Guid tenantId, ServiceTaskStatus? status = null, Guid? contractId = null, Guid? employeeId = null, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);
    Task<ServiceTaskLogDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ServiceTaskLogDto> CreateAsync(Guid tenantId, CreateServiceTaskLogRequest request, CancellationToken cancellationToken = default);
    Task<ServiceTaskLogDto> UpdateAsync(Guid tenantId, Guid id, UpdateServiceTaskLogRequest request, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<ServiceTaskLogDto> UpdateStatusAsync(Guid tenantId, Guid id, ServiceTaskStatus status, CancellationToken cancellationToken = default);
    Task<ServiceTaskLogDto> CompleteTaskAsync(Guid tenantId, Guid id, DateTime completedDate, CancellationToken cancellationToken = default);
    Task<IEnumerable<ServiceTaskLogDto>> GetPendingApprovalsAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<ServiceTaskLogDto> ApproveTimesheetAsync(Guid tenantId, Guid id, Guid approvedByUserId, string? approvalNotes = null, CancellationToken cancellationToken = default);
    Task<ServiceTaskLogDto> RejectTimesheetAsync(Guid tenantId, Guid id, Guid rejectedByUserId, string? rejectionNotes = null, CancellationToken cancellationToken = default);
    Task<IEnumerable<ServiceTaskLogDto>> GetBillableTasksAsync(Guid tenantId, Guid? contractId = null, bool uninvoicedOnly = true, CancellationToken cancellationToken = default);
    Task<IEnumerable<ServiceTaskLogDto>> GetByContractAsync(Guid tenantId, Guid contractId, CancellationToken cancellationToken = default);
    Task<IEnumerable<ServiceTaskLogDto>> GetOverdueTasksAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<IEnumerable<ServiceTaskLogDto>> BulkApproveTimesheetsAsync(Guid tenantId, IEnumerable<Guid> taskLogIds, Guid approvedByUserId, CancellationToken cancellationToken = default);
    Task<bool> MarkProcessedForPayrollAsync(Guid tenantId, IEnumerable<Guid> taskLogIds, Guid payrollJournalId, CancellationToken cancellationToken = default);
    Task<ServiceTaskLogDto> SubmitDailyEntryAsync(Guid tenantId, DailyTimesheetEntryRequest request, CancellationToken cancellationToken = default);
    Task<byte[]> ExportTimesheetReportAsync(Guid tenantId, TimesheetReportRequest request, string format, CancellationToken cancellationToken = default);
    Task<TimesheetReportDto> GetTimesheetReportAsync(Guid tenantId, TimesheetReportRequest request, CancellationToken cancellationToken = default);
}
