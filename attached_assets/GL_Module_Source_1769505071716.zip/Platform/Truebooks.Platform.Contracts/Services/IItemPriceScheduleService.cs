using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Contracts.Services;

public interface IItemPriceScheduleService
{
    Task<IEnumerable<ItemPriceScheduleDto>> GetAllAsync(Guid tenantId);
    Task<IEnumerable<ItemPriceScheduleDto>> GetActiveAsync(Guid tenantId);
    Task<IEnumerable<ItemPriceScheduleDto>> GetByPriceTypeAsync(Guid tenantId, PriceType priceType);
    Task<ItemPriceScheduleDto?> GetByIdAsync(Guid tenantId, Guid id);
    Task<ItemPriceScheduleDto> CreateAsync(Guid tenantId, CreateItemPriceScheduleRequest request);
    Task<ItemPriceScheduleDto> UpdateAsync(Guid tenantId, Guid id, UpdateItemPriceScheduleRequest request);
    Task<bool> DeleteAsync(Guid tenantId, Guid id);
    Task<bool> ToggleActiveAsync(Guid tenantId, Guid id);
    Task<decimal?> GetItemPriceAsync(Guid tenantId, Guid itemId, PriceType priceType, decimal quantity);
}
