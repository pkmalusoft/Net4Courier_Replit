namespace Truebooks.Platform.Contracts.Enums.Common;

public enum AccountType
{
    Asset = 0,
    Liability = 1,
    Equity = 2,
    Revenue = 3,
    Expense = 4
}

public enum TaxType
{
    None = 0,
    Simple = 1,
    GST = 2,
    VAT = 3,
    Compound = 4,
    Group = 5
}

public enum CustomerType
{
    Cash,
    Credit
}

public enum SupplierType
{
    Cash,
    Credit
}

public enum CreditApprovalStatus
{
    Pending,
    Approved,
    Rejected
}

public enum LocationType
{
    Warehouse = 0,
    Showroom = 1,
    ThirdParty = 2
}

public enum TransferStatus
{
    Draft = 0,
    Approved = 1,
    InTransit = 2,
    Completed = 3,
    Cancelled = 4
}
