namespace Truebooks.Platform.Contracts.Enums;

public enum ItemType
{
    Product = 1,
    Service = 2
}

public enum CostingMethod
{
    FIFO = 1,
    WeightedAverage = 2,
    StandardCost = 3
}

public enum UsageScope
{
    Sales = 1,
    Purchase = 2,
    Both = 3
}

public enum SerialStatus
{
    Available = 0,
    InStock = 1,
    Reserved = 2,
    Sold = 3,
    Returned = 4,
    InTransit = 5,
    Damaged = 6,
    Defective = 7,
    WrittenOff = 8,
    Lost = 9
}

public enum MovementType
{
    PurchaseReceipt = 1,
    TransferIn = 2,
    TransferOut = 3,
    SaleIssue = 4,
    ReturnIn = 5,
    ReturnOut = 6,
    AdjustmentGain = 7,
    AdjustmentLoss = 8,
    WarrantySwap = 9
}

public enum AdjustmentType
{
    Increase = 0,
    Decrease = 1
}

public enum PriceType
{
    Retail = 1,
    Wholesale = 2,
    Special = 3,
    Promotional = 4,
    Cost = 5,
    Custom = 6
}
