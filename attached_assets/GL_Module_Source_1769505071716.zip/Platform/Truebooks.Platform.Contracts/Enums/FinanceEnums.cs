namespace Truebooks.Platform.Contracts.Enums;

public enum ControlAccountType
{
    None,
    AccountsReceivable,
    AccountsPayable,
    Inventory,
    CostOfGoodsSold,
    RetainedEarnings,
    OpeningBalanceEquity,
    ProvisionalCost,
    AccruedCostPayable,
    DeferredRevenue,
    JobRevenue,
    JobCostOfSales
}

public enum InvoiceStatus
{
    Draft,
    Posted,
    PartiallyPaid,
    FullyPaid,
    Cancelled
}

public enum FinancialPeriodStatus
{
    NotOpened = 0,
    Open = 1,
    SoftClosed = 2,
    HardClosed = 3,
    Archived = 4
}

public enum BillingPeriod
{
    PerHour = 1,
    PerDay = 2,
    PerMonth = 3,
    PerYear = 4,
    Lumpsum = 5
}

public enum JobClosingStatus
{
    Open = 0,
    ProvisionPosted = 1,
    PartiallyMatched = 2,
    FullyMatched = 3,
    Closed = 4
}

public enum JobClosingEntryType
{
    MonthEndProvision = 1,
    ProvisionReversal = 2,
    VendorInvoiceMatching = 3,
    RevenueRecognition = 4,
    VarianceAdjustment = 5
}

public enum CostLineMatchingStatus
{
    NotProvisioned = 0,
    Provisioned = 1,
    Matched = 2,
    MatchedWithVariance = 3
}
