namespace Truebooks.Platform.Contracts.Enums;

public enum VoucherTransactionType
{
    JournalEntry = 0,
    PaymentVoucher = 1,
    ReceiptVoucher = 2,
    SalesInvoice = 3,
    PurchaseInvoice = 4,
    CreditNote = 5,
    DebitNote = 6,
    ContraVoucher = 7,
    BankTransfer = 8,
    PettyCash = 9,
    SalesOrder = 10,
    PurchaseOrder = 11,
    DeliveryNote = 12,
    GoodsReceiptNote = 13,
    StockTransfer = 14,
    StockAdjustment = 15,
    Quotation = 16,
    ProformaInvoice = 17
}

public enum ApprovalStatus
{
    None,
    Pending,
    InProgress,
    Approved,
    Rejected,
    Returned,
    Cancelled
}
