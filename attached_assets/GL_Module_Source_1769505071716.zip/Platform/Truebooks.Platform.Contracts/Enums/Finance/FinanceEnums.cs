namespace Truebooks.Platform.Contracts.Enums.Finance;

public enum FinancialPeriodStatus
{
    Open = 0,
    SoftClosed = 1,
    HardClosed = 2,
    YearEndClosed = 3
}

public enum YearEndClosingStatus
{
    NotStarted = 0,
    InProgress = 1,
    Completed = 2,
    Reversed = 3
}

public enum CalendarType
{
    Gregorian = 0,
    Fiscal = 1,
    Islamic = 2,
    Custom = 3
}

