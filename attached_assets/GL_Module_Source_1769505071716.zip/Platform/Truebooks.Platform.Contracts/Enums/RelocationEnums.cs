using System.Text.Json.Serialization;

namespace Truebooks.Platform.Contracts.Enums;

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationMoveType
{
    DoorToDoor = 0,
    DoorToPort = 1,
    PortToDoor = 2,
    PortToPort = 3
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationShipmentMode
{
    LCL = 0,
    FCL = 1,
    Air = 2,
    Road = 3
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationContainerType
{
    Standard20ft = 0,
    Standard40ft = 1,
    HighCube40ft = 2,
    Premium20ft = 3,
    Premium40ft = 4
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationVolumeSlab
{
    Slab1_1to3CBM = 0,
    Slab2_4to6CBM = 1,
    Slab3_7to10CBM = 2,
    Slab4_11to15CBM = 3,
    Slab5_16to20CBM = 4,
    Slab6_21to30CBM = 5,
    Slab7_31Plus = 6
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationJobStatus
{
    Draft = 0,
    EnquiryReceived = 1,
    SurveyScheduled = 2,
    SurveyCompleted = 3,
    QuotationSent = 4,
    QuotationAccepted = 5,
    QuotationRejected = 6,
    JobConfirmed = 7,
    PackingInProgress = 8,
    LoadingCompleted = 9,
    InTransit = 10,
    AtDestinationPort = 11,
    CustomsClearance = 12,
    OutForDelivery = 13,
    Delivered = 14,
    Completed = 15,
    Cancelled = 16
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationSurveyStatus
{
    Pending = 0,
    Scheduled = 1,
    InProgress = 2,
    Completed = 3,
    Cancelled = 4
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationChargeType
{
    PackingCharges = 0,
    LabourCharges = 1,
    TransportationLocal = 2,
    FreightCharges = 3,
    CustomsClearance = 4,
    DestinationCharges = 5,
    Insurance = 6,
    StorageCharges = 7,
    Documentation = 8,
    OtherCharges = 9
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationServiceType
{
    InternationalRelocation = 0,
    LocalRelocation = 1,
    PackingOnly = 2,
    StorageOnly = 3,
    VehicleShipping = 4,
    PetRelocation = 5,
    CorporateRelocation = 6
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationEnquiryStatus
{
    New = 0,
    Contacted = 1,
    SurveyScheduled = 2,
    SurveyCompleted = 3,
    QuotationSent = 4,
    FollowUp = 5,
    Converted = 6,
    Lost = 7,
    Cancelled = 8
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationQuotationStatus
{
    Draft = 0,
    Sent = 1,
    Viewed = 2,
    Accepted = 3,
    Rejected = 4,
    Expired = 5,
    Revised = 6
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationItemPackingStatus
{
    Pending = 0,
    InProgress = 1,
    Packed = 2,
    Loaded = 3,
    Delivered = 4,
    Damaged = 5
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationContainerStatus
{
    Empty = 0,
    Loading = 1,
    Loaded = 2,
    Sealed = 3,
    Dispatched = 4,
    InTransit = 5,
    AtDestination = 6,
    Unloading = 7,
    Unloaded = 8
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationShipmentEventType
{
    BookingConfirmed = 0,
    PickedUp = 1,
    AtOriginWarehouse = 2,
    LoadedOnVessel = 3,
    DepartedOriginPort = 4,
    InTransit = 5,
    ArrivedTransshipmentPort = 6,
    DepartedTransshipmentPort = 7,
    ArrivedDestinationPort = 8,
    CustomsCleared = 9,
    ReleasedFromPort = 10,
    AtDestinationWarehouse = 11,
    OutForDelivery = 12,
    Delivered = 13,
    Exception = 14,
    Delayed = 15,
    DocumentReceived = 16,
    InspectionScheduled = 17,
    InspectionCompleted = 18,
    HoldRelease = 19
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationCustomsStatus
{
    NotStarted = 0,
    DocumentsSubmitted = 1,
    UnderReview = 2,
    QueryRaised = 3,
    QueryResolved = 4,
    DutyAssessed = 5,
    DutyPaid = 6,
    InspectionRequired = 7,
    InspectionCompleted = 8,
    Cleared = 9,
    Released = 10,
    OnHold = 11,
    Rejected = 12
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationCustomsType
{
    Export = 0,
    Import = 1
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationDocumentType
{
    AWB = 0,
    BillOfLading = 1,
    PackingList = 2,
    CommercialInvoice = 3,
    CertificateOfOrigin = 4,
    InsuranceCertificate = 5,
    CustomsDeclaration = 6,
    ImportPermit = 7,
    ExportPermit = 8,
    DeliveryOrder = 9,
    ProofOfDelivery = 10,
    SurveyReport = 11,
    DamageReport = 12,
    PhotoInventory = 13,
    CustomerSignoff = 14,
    Other = 99
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationInvoiceStatus
{
    Draft = 0,
    Pending = 1,
    Sent = 2,
    PartiallyPaid = 3,
    Paid = 4,
    Overdue = 5,
    Cancelled = 6,
    Disputed = 7
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationInvoiceType
{
    AdvancePayment = 0,
    ProgressBilling = 1,
    FinalInvoice = 2,
    SupplementaryInvoice = 3,
    CreditNote = 4,
    DebitNote = 5
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationPaymentTerm
{
    Immediate = 0,
    Net7 = 7,
    Net15 = 15,
    Net30 = 30,
    Net45 = 45,
    Net60 = 60,
    Net90 = 90
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RelocationCostCategory
{
    OriginCharges = 0,
    FreightCharges = 1,
    DestinationCharges = 2,
    InsuranceCharges = 3,
    CustomsCharges = 4,
    StorageCharges = 5,
    AdditionalServices = 6,
    Adjustments = 7
}
