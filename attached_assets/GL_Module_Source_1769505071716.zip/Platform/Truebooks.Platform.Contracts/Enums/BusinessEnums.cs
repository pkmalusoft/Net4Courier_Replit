namespace Truebooks.Platform.Contracts.Enums;

public enum IndustryType
{
    General = 0,
    Service = 1,
    Trading = 2,
    Manufacturing = 3,
    Retail = 4,
    Construction = 5,
    RealEstate = 6,
    Healthcare = 7,
    Logistics = 8,
    NonProfit = 9,
    SmallJob = 10,
    SoftwareCompany = 11
}

public enum CategoryType
{
    Product = 1,
    Service = 2,
    Both = 3
}

public enum CustomerType
{
    Regular = 0,
    Wholesale = 1,
    Retail = 2
}

public enum SupplierType
{
    Regular = 0,
    Manufacturer = 1,
    Distributor = 2,
    ServiceProvider = 3
}

public enum CreditStatus
{
    Good = 0,
    OnHold = 1,
    Suspended = 2,
    Blacklisted = 3
}

public enum BudgetStatus
{
    Draft = 0,
    PendingApproval = 1,
    Approved = 2,
    Active = 3,
    Closed = 4,
    Rejected = 5,
    Voided = 6
}

public enum BudgetRevisionStatus
{
    Original = 0,
    Revised = 1
}

public enum BudgetTransferStatus
{
    Pending = 0,
    Approved = 1,
    Rejected = 2
}

public enum SalesReturnStatus
{
    Draft = 0,
    Posted = 1,
    Cancelled = 2
}
