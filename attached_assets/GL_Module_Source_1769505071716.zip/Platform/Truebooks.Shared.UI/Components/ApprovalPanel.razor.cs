using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using MudBlazor;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Shared.UI.Components;

public partial class ApprovalPanel : ComponentBase
{
    [Inject] private HttpClient Http { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;
    [Inject] private ISnackbar Snackbar { get; set; } = default!;

    [Parameter] public string EntityType { get; set; } = string.Empty;
    [Parameter] public Guid EntityId { get; set; }
    [Parameter] public string? EntityCode { get; set; }
    [Parameter] public string? EntityDescription { get; set; }
    [Parameter] public decimal? Amount { get; set; }
    [Parameter] public string? Currency { get; set; }
    [Parameter] public string? ActionUrl { get; set; }
    [Parameter] public bool ShowHistory { get; set; } = true;
    [Parameter] public bool AllowActions { get; set; } = true;
    [Parameter] public EventCallback<ApprovalStatus> OnStatusChanged { get; set; }

    private ApprovalRequestDto? _approvalRequest;
    private List<ApprovalHistoryDto> _history = new();
    private bool _isLoading = true;
    private bool _isProcessing = false;
    private string _actionComments = string.Empty;
    private bool _showCommentsDialog = false;
    private ApprovalAction _pendingAction;
    private Guid _currentUserId;

    protected override async Task OnInitializedAsync()
    {
        await LoadCurrentUserId();
        await LoadApprovalStatus();
    }

    protected override async Task OnParametersSetAsync()
    {
        if (EntityId != Guid.Empty && !string.IsNullOrEmpty(EntityType))
        {
            await LoadApprovalStatus();
        }
    }

    private async Task LoadCurrentUserId()
    {
        var userId = await JS.InvokeAsync<string?>("localStorage.getItem", "userId");
        if (!string.IsNullOrEmpty(userId) && Guid.TryParse(userId, out var id))
        {
            _currentUserId = id;
        }
    }

    private async Task LoadApprovalStatus()
    {
        if (EntityId == Guid.Empty || string.IsNullOrEmpty(EntityType))
            return;

        _isLoading = true;
        StateHasChanged();

        try
        {
            await SetAuthHeader();
            var response = await Http.GetAsync($"api/approval/status/{EntityType}/{EntityId}");

            if (response.IsSuccessStatusCode)
            {
                _approvalRequest = await response.Content.ReadFromJsonAsync<ApprovalRequestDto>();

                if (_approvalRequest != null && ShowHistory)
                {
                    await LoadHistory();
                }
            }
            else if (response.StatusCode != System.Net.HttpStatusCode.NotFound)
            {
                Snackbar.Add("Failed to load approval status", Severity.Warning);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading approval status: {ex.Message}");
        }
        finally
        {
            _isLoading = false;
            StateHasChanged();
        }
    }

    private async Task LoadHistory()
    {
        if (_approvalRequest == null) return;

        try
        {
            await SetAuthHeader();
            var response = await Http.GetAsync($"api/approval/{_approvalRequest.Id}/history");

            if (response.IsSuccessStatusCode)
            {
                _history = await response.Content.ReadFromJsonAsync<List<ApprovalHistoryDto>>() ?? new();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading history: {ex.Message}");
        }
    }

    private async Task SetAuthHeader()
    {
        var token = await JS.InvokeAsync<string?>("localStorage.getItem", "authToken");
        var tenantId = await JS.InvokeAsync<string?>("localStorage.getItem", "tenantId");

        if (!string.IsNullOrEmpty(token))
        {
            Http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        if (!string.IsNullOrEmpty(tenantId))
        {
            Http.DefaultRequestHeaders.Remove("X-Tenant-Id");
            Http.DefaultRequestHeaders.Add("X-Tenant-Id", tenantId);
        }
    }

    public async Task InitiateApproval()
    {
        if (EntityId == Guid.Empty || string.IsNullOrEmpty(EntityType))
        {
            Snackbar.Add("Entity information is required", Severity.Error);
            return;
        }

        _isProcessing = true;
        StateHasChanged();

        try
        {
            await SetAuthHeader();

            var request = new
            {
                EntityType = EntityType,
                EntityId = EntityId,
                EntityCode = EntityCode,
                EntityDescription = EntityDescription,
                Amount = Amount,
                Currency = Currency,
                ActionUrl = ActionUrl
            };

            var response = await Http.PostAsJsonAsync("api/approval/initiate", request);

            if (response.IsSuccessStatusCode)
            {
                _approvalRequest = await response.Content.ReadFromJsonAsync<ApprovalRequestDto>();
                Snackbar.Add("Approval request submitted successfully", Severity.Success);
                await OnStatusChanged.InvokeAsync(ApprovalStatus.Pending);
            }
            else
            {
                var error = await response.Content.ReadAsStringAsync();
                Snackbar.Add($"Failed to submit approval: {error}", Severity.Error);
            }
        }
        catch (Exception ex)
        {
            Snackbar.Add($"Error: {ex.Message}", Severity.Error);
        }
        finally
        {
            _isProcessing = false;
            StateHasChanged();
        }
    }

    private void ShowApproveDialog()
    {
        _pendingAction = ApprovalAction.Approve;
        _actionComments = string.Empty;
        _showCommentsDialog = true;
    }

    private void ShowRejectDialog()
    {
        _pendingAction = ApprovalAction.Reject;
        _actionComments = string.Empty;
        _showCommentsDialog = true;
    }

    private void ShowReturnDialog()
    {
        _pendingAction = ApprovalAction.Return;
        _actionComments = string.Empty;
        _showCommentsDialog = true;
    }

    private async Task ExecuteAction()
    {
        _showCommentsDialog = false;
        _isProcessing = true;
        StateHasChanged();

        try
        {
            await SetAuthHeader();

            var endpoint = _pendingAction switch
            {
                ApprovalAction.Approve => $"api/approval/{_approvalRequest!.Id}/approve",
                ApprovalAction.Reject => $"api/approval/{_approvalRequest!.Id}/reject",
                ApprovalAction.Return => $"api/approval/{_approvalRequest!.Id}/return",
                _ => throw new ArgumentException("Invalid action")
            };

            var response = await Http.PostAsJsonAsync(endpoint, new { Comments = _actionComments });

            if (response.IsSuccessStatusCode)
            {
                _approvalRequest = await response.Content.ReadFromJsonAsync<ApprovalRequestDto>();
                await LoadHistory();

                var message = _pendingAction switch
                {
                    ApprovalAction.Approve => "Request approved",
                    ApprovalAction.Reject => "Request rejected",
                    ApprovalAction.Return => "Request returned for correction",
                    _ => "Action completed"
                };

                Snackbar.Add(message, Severity.Success);

                var status = _pendingAction switch
                {
                    ApprovalAction.Approve => _approvalRequest?.Status == "Approved" 
                        ? ApprovalStatus.Approved 
                        : ApprovalStatus.InProgress,
                    ApprovalAction.Reject => ApprovalStatus.Rejected,
                    ApprovalAction.Return => ApprovalStatus.Returned,
                    _ => ApprovalStatus.Pending
                };

                await OnStatusChanged.InvokeAsync(status);
            }
            else
            {
                var error = await response.Content.ReadAsStringAsync();
                Snackbar.Add($"Action failed: {error}", Severity.Error);
            }
        }
        catch (Exception ex)
        {
            Snackbar.Add($"Error: {ex.Message}", Severity.Error);
        }
        finally
        {
            _isProcessing = false;
            StateHasChanged();
        }
    }

    private async Task CancelRequest()
    {
        if (_approvalRequest == null) return;

        _isProcessing = true;
        StateHasChanged();

        try
        {
            await SetAuthHeader();

            var response = await Http.PostAsJsonAsync(
                $"api/approval/{_approvalRequest.Id}/cancel", 
                new { Comments = "Cancelled by requester" });

            if (response.IsSuccessStatusCode)
            {
                _approvalRequest = await response.Content.ReadFromJsonAsync<ApprovalRequestDto>();
                await LoadHistory();
                Snackbar.Add("Request cancelled", Severity.Info);
                await OnStatusChanged.InvokeAsync(ApprovalStatus.Cancelled);
            }
            else
            {
                Snackbar.Add("Failed to cancel request", Severity.Error);
            }
        }
        catch (Exception ex)
        {
            Snackbar.Add($"Error: {ex.Message}", Severity.Error);
        }
        finally
        {
            _isProcessing = false;
            StateHasChanged();
        }
    }

    private bool IsCurrentApprover()
    {
        return _approvalRequest?.CurrentApproverId == _currentUserId;
    }

    private bool CanApprove()
    {
        return AllowActions 
            && _approvalRequest != null 
            && _approvalRequest.Status == "InProgress" 
            && IsCurrentApprover();
    }

    private bool CanCancel()
    {
        return AllowActions 
            && _approvalRequest != null 
            && _approvalRequest.RequesterId == _currentUserId 
            && (_approvalRequest.Status == "Pending" || _approvalRequest.Status == "InProgress" || _approvalRequest.Status == "Returned");
    }

    private Color GetStatusColor()
    {
        return _approvalRequest?.Status switch
        {
            "Pending" => Color.Info,
            "InProgress" => Color.Warning,
            "Approved" => Color.Success,
            "Rejected" => Color.Error,
            "Returned" => Color.Secondary,
            "Cancelled" => Color.Dark,
            _ => Color.Default
        };
    }

    private Color GetStepColor(ApprovalStepDto step)
    {
        return step.Status switch
        {
            "Approved" => Color.Success,
            "Rejected" => Color.Error,
            "ReturnedForCorrection" => Color.Secondary,
            "Pending" => Color.Warning,
            "Waiting" => Color.Default,
            "Skipped" => Color.Dark,
            _ => Color.Default
        };
    }

    private string GetStepIcon(ApprovalStepDto step)
    {
        return step.Status switch
        {
            "Approved" => Icons.Material.Filled.CheckCircle,
            "Rejected" => Icons.Material.Filled.Cancel,
            "ReturnedForCorrection" => Icons.Material.Filled.Undo,
            "Pending" => Icons.Material.Filled.HourglassTop,
            "Waiting" => Icons.Material.Filled.Schedule,
            "Skipped" => Icons.Material.Filled.SkipNext,
            _ => Icons.Material.Filled.Circle
        };
    }

    private string GetActionIcon(string actionType)
    {
        return actionType switch
        {
            "Submitted" => Icons.Material.Filled.Send,
            "Approved" => Icons.Material.Filled.ThumbUp,
            "Rejected" => Icons.Material.Filled.ThumbDown,
            "ReturnedForCorrection" => Icons.Material.Filled.Undo,
            "Cancelled" => Icons.Material.Filled.Cancel,
            "Escalated" => Icons.Material.Filled.ArrowUpward,
            _ => Icons.Material.Filled.Info
        };
    }

    private Color GetActionColor(string actionType)
    {
        return actionType switch
        {
            "Submitted" => Color.Info,
            "Approved" => Color.Success,
            "Rejected" => Color.Error,
            "ReturnedForCorrection" => Color.Secondary,
            "Cancelled" => Color.Dark,
            "Escalated" => Color.Warning,
            _ => Color.Default
        };
    }

    private enum ApprovalAction
    {
        Approve,
        Reject,
        Return
    }

    public class ApprovalRequestDto
    {
        public Guid Id { get; set; }
        public string EntityType { get; set; } = string.Empty;
        public Guid EntityId { get; set; }
        public string? EntityCode { get; set; }
        public string? EntityDescription { get; set; }
        public decimal? Amount { get; set; }
        public string? Currency { get; set; }
        public Guid RequesterId { get; set; }
        public string? RequesterName { get; set; }
        public Guid? CurrentApproverId { get; set; }
        public string? CurrentApproverName { get; set; }
        public int CurrentStepNumber { get; set; }
        public int TotalSteps { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime? SubmittedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        public DateTime? DueDate { get; set; }
        public string? Notes { get; set; }
        public string? ActionUrl { get; set; }
        public List<ApprovalStepDto>? Steps { get; set; }
    }

    public class ApprovalStepDto
    {
        public Guid Id { get; set; }
        public int StepNumber { get; set; }
        public string ApproverRole { get; set; } = string.Empty;
        public Guid ApproverId { get; set; }
        public string? ApproverName { get; set; }
        public Guid? ActualApproverId { get; set; }
        public string? ActualApproverName { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime? ActionDate { get; set; }
        public string? Comments { get; set; }
    }

    public class ApprovalHistoryDto
    {
        public Guid Id { get; set; }
        public int StepNumber { get; set; }
        public Guid ActionByUserId { get; set; }
        public string? ActionByUserName { get; set; }
        public string ActionType { get; set; } = string.Empty;
        public string? Comments { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
