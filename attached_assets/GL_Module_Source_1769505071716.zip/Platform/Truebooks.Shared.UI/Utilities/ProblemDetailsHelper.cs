using System.Net;
using System.Text.Json;

namespace Truebooks.Shared.UI.Utilities
{
    public static class ProblemDetailsHelper
    {
        public static bool IsSessionExpired(HttpResponseMessage response)
        {
            return response.StatusCode == HttpStatusCode.Unauthorized;
        }

        public static async Task<string> ParseErrorFromResponseAsync(HttpResponseMessage response, string defaultMessage)
        {
            try
            {
                var content = await response.Content.ReadAsStringAsync();
                if (string.IsNullOrWhiteSpace(content))
                    return defaultMessage;

                var trimmed = content.Trim();
                if (!trimmed.StartsWith("{"))
                    return string.IsNullOrEmpty(trimmed) ? defaultMessage : trimmed;

                var doc = JsonDocument.Parse(trimmed);
                
                if (doc.RootElement.TryGetProperty("errors", out var errors))
                {
                    var messages = new List<string>();
                    foreach (var prop in errors.EnumerateObject())
                    {
                        foreach (var msg in prop.Value.EnumerateArray())
                        {
                            var msgStr = msg.GetString();
                            if (!string.IsNullOrEmpty(msgStr))
                                messages.Add(msgStr);
                        }
                    }
                    if (messages.Count > 0)
                        return string.Join("; ", messages);
                }
                
                if (doc.RootElement.TryGetProperty("detail", out var detail))
                {
                    var detailStr = detail.GetString();
                    if (!string.IsNullOrEmpty(detailStr))
                        return detailStr;
                }
                
                if (doc.RootElement.TryGetProperty("title", out var title))
                {
                    var titleStr = title.GetString();
                    if (!string.IsNullOrEmpty(titleStr))
                        return titleStr;
                }
                
                if (doc.RootElement.TryGetProperty("message", out var message))
                {
                    var messageStr = message.GetString();
                    if (!string.IsNullOrEmpty(messageStr))
                        return messageStr;
                }
            }
            catch
            {
            }

            return defaultMessage;
        }

        public static string ParseErrorMessage(string? error, string defaultMessage)
        {
            if (string.IsNullOrWhiteSpace(error))
                return defaultMessage;

            var trimmed = error.Trim();
            if (string.IsNullOrEmpty(trimmed))
                return defaultMessage;

            if (!trimmed.StartsWith("{"))
                return trimmed;

            try
            {
                var doc = JsonDocument.Parse(trimmed);

                if (doc.RootElement.TryGetProperty("errors", out var errors))
                {
                    var messages = new List<string>();
                    foreach (var prop in errors.EnumerateObject())
                    {
                        foreach (var msg in prop.Value.EnumerateArray())
                        {
                            var msgStr = msg.GetString();
                            if (!string.IsNullOrEmpty(msgStr))
                                messages.Add(msgStr);
                        }
                    }
                    if (messages.Count > 0)
                        return string.Join("; ", messages);
                }

                if (doc.RootElement.TryGetProperty("title", out var title))
                {
                    var titleStr = title.GetString();
                    if (!string.IsNullOrEmpty(titleStr))
                        return titleStr;
                }
            }
            catch
            {
            }

            return trimmed;
        }
    }
}
