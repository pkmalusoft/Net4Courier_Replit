using Microsoft.Extensions.DependencyInjection;
using MudBlazor.Services;
using Truebooks.Shared.UI.Services;
using Truebooks.Shared.UI.Services.Legacy;

namespace Truebooks.Shared.UI.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddSharedUI(this IServiceCollection services)
    {
        services.AddMudServices();
        
        // Legacy services (from src/Web/Services)
        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<IMasterDataService, MasterDataService>();
        services.AddScoped<IBranchService, BranchService>();
        services.AddScoped<IDepartmentService, DepartmentService>();
        services.AddScoped<ICurrencyService, CurrencyService>();
        services.AddScoped<ICustomerService, CustomerService>();
        services.AddScoped<IItemService, ItemService>();
        services.AddScoped<IChartOfAccountsService, ChartOfAccountsService>();
        services.AddScoped<IProjectService, ProjectService>();
        services.AddScoped<IAccountClassificationService, AccountClassificationService>();
        services.AddScoped<IInventoryLocationService, InventoryLocationService>();
        services.AddScoped<ICashBankTransactionService, CashBankTransactionService>();
        
        // Inventory services
        services.AddScoped<IItemCategoryService, ItemCategoryService>();
        services.AddScoped<IItemGroupService, ItemGroupService>();
        services.AddScoped<IItemPriceScheduleService, ItemPriceScheduleService>();
        services.AddScoped<IBrandService, BrandService>();
        services.AddScoped<IColourService, ColourService>();
        services.AddScoped<ISizeService, SizeService>();
        services.AddScoped<IUomService, UomService>();
        services.AddScoped<IWarehouseService, WarehouseService>();
        services.AddScoped<ISerialNumberService, SerialNumberService>();
        services.AddScoped<IBulkPriceService, BulkPriceService>();
        
        // Core services
        services.AddScoped<ITransactionService, TransactionService>();
        services.AddScoped<IWorkingPeriodStateProvider, Truebooks.Shared.UI.Services.Legacy.WorkingPeriodStateProvider>();
        services.AddScoped<IKnowledgeBaseService, KnowledgeBaseService>();
        services.AddScoped<IGridPreferencesService, GridPreferencesService>();
        
        // Module access service for read-only mode support
        services.AddScoped<IModuleAccessService, ModuleAccessService>();
        
        return services;
    }
}
