using System.Text.Json;
using System.Text.Json.Serialization;

namespace Truebooks.Shared.UI.Helpers;

public static class JsonOptionsHelper
{
    private static JsonSerializerOptions? _options;
    
    public static JsonSerializerOptions Options
    {
        get
        {
            if (_options == null)
            {
                _options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true,
                    DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
                };
                _options.Converters.Add(new JsonStringEnumConverter());
            }
            return _options;
        }
    }
}
