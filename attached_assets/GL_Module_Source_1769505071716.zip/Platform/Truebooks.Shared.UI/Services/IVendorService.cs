using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services;

public interface IVendorService
{
    Task<List<VendorDto>> GetAllAsync();
    Task<List<VendorDto>> GetActiveAsync();
    Task<VendorDto?> GetByIdAsync(Guid id);
    Task<Guid> CreateAsync(VendorDto vendor);
    Task UpdateAsync(Guid id, VendorDto vendor);
    Task DeleteAsync(Guid id);
    Task<decimal> GetOutstandingBalanceAsync(Guid vendorId);
}
