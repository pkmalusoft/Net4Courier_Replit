namespace Truebooks.Shared.UI.Services;

public class DashboardKPIData
{
    public KPIItem Revenue { get; set; } = new();
    public KPIItem Expenses { get; set; } = new();
    public KPIItem NetProfit { get; set; } = new();
    public KPIItem ARDue { get; set; } = new();
    public KPIItem APDue { get; set; } = new();
    public KPIItem InventoryValue { get; set; } = new();
    public KPIItem TotalOrders { get; set; } = new();
    public KPIItem ActiveUsers { get; set; } = new();
}

public class KPIItem
{
    public decimal Value { get; set; }
    public string Delta { get; set; } = string.Empty;
    public string Trend { get; set; } = "neutral";
}

public class DashboardChartsData
{
    public List<RevenueTrendItem> RevenueTrend { get; set; } = new();
    public List<ModuleSalesItem> ModuleSales { get; set; } = new();
    public List<CashflowItem> Cashflow { get; set; } = new();
    public List<RecentActivityItem> RecentActivity { get; set; } = new();
}

public class RevenueTrendItem
{
    public string Month { get; set; } = string.Empty;
    public decimal Revenue { get; set; }
    public decimal Expenses { get; set; }
}

public class ModuleSalesItem
{
    public string Module { get; set; } = string.Empty;
    public decimal Value { get; set; }
}

public class CashflowItem
{
    public string Month { get; set; } = string.Empty;
    public decimal Inflow { get; set; }
    public decimal Outflow { get; set; }
}

public class RecentActivityItem
{
    public string DocumentId { get; set; } = string.Empty;
    public string ClientVendor { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime Date { get; set; }
}
