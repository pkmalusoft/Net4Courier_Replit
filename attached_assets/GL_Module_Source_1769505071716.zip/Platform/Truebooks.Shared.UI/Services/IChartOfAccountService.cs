using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Enums;
using Truebooks.Platform.Contracts.Enums.Common;

namespace Truebooks.Shared.UI.Services;

public interface IChartOfAccountService
{
    Task<List<ChartOfAccount>> GetAllAsync();
    Task<List<ChartOfAccount>> GetPostableAccountsAsync();
    Task<ChartOfAccount?> GetByIdAsync(Guid id);
    Task<Guid> CreateAsync(ChartOfAccount account);
    Task UpdateAsync(Guid id, ChartOfAccount account);
    Task DeleteAsync(Guid id);
    Task<List<ChartOfAccount>> GetByTypeAsync(AccountType accountType);
}
