namespace Truebooks.Shared.UI.Services;

public interface IModuleAccessService
{
    Task<ModuleAccessInfo> GetModuleAccessAsync(string moduleCode);
    Task<bool> IsModuleReadOnlyAsync(string moduleCode);
    Task<bool> IsModuleEnabledAsync(string moduleCode);
    void InvalidateCache();
}

public class ModuleAccessInfo
{
    public string ModuleCode { get; set; } = string.Empty;
    public string AccessLevel { get; set; } = "none";
    public bool IsReadOnly { get; set; }
    public bool IsEnabled { get; set; }
    public bool IsCoreModule { get; set; }
}
