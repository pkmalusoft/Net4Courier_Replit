using System.Net.Http.Json;
using System.Text.Json;

using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IAuthService
{
    Task<AuthResponse?> LoginAsync(string tenantId, string email, string password);
    Task<AuthResponse?> LoginWithBranchAsync(string tenantId, string email, string password, Guid? branchId);
    Task<AuthResponse?> RegisterTenantAsync(string tenantName, string email, string password);
    Task LogoutAsync();
    string? GetAccessToken();
    string? GetTenantId();
    string? GetTenantName();
    string? GetBranchId();
    string? GetBranchName();
    string? GetUserEmail();
    List<string> GetUserRoles();
    Guid? GetUserId();
}

public class AuthService : IAuthService
{
    private readonly HttpClient _http;
    private const string ACCESS_TOKEN_KEY = "accessToken";
    private const string REFRESH_TOKEN_KEY = "refreshToken";
    private const string TENANT_ID_KEY = "tenantId";
    
    private string? _accessToken;
    private string? _tenantId;
    private string? _tenantName;
    private string? _branchId;
    private string? _branchName;
    private string? _userEmail;
    private List<string> _userRoles = new();
    private Guid? _userId;

    public AuthService(HttpClient http)
    {
        _http = http;
    }

    public async Task<AuthResponse?> LoginAsync(string tenantId, string email, string password)
    {
        return await LoginWithBranchAsync(tenantId, email, password, null);
    }

    public async Task<AuthResponse?> LoginWithBranchAsync(string tenantId, string email, string password, Guid? branchId)
    {
        try
        {
            _http.DefaultRequestHeaders.Remove("X-Tenant-Id");
            _http.DefaultRequestHeaders.Add("X-Tenant-Id", tenantId);

            var response = await _http.PostAsJsonAsync("api/Auth/login", new
            {
                Email = email,
                Password = password,
                BranchId = branchId
            });

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<AuthResponse>();
                if (result != null)
                {
                    await StoreTokensAsync(result);
                }
                return result;
            }

            return null;
        }
        catch
        {
            return null;
        }
    }

    public async Task<AuthResponse?> RegisterTenantAsync(string tenantName, string email, string password)
    {
        try
        {
            var response = await _http.PostAsJsonAsync("api/Auth/register-tenant", new
            {
                TenantName = tenantName,
                Email = email,
                Password = password
            });

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<AuthResponse>();
                if (result != null)
                {
                    await StoreTokensAsync(result);
                }
                return result;
            }

            return null;
        }
        catch
        {
            return null;
        }
    }

    public async Task LogoutAsync()
    {
        _accessToken = null;
        _tenantId = null;
        _tenantName = null;
        _branchId = null;
        _branchName = null;
        _userEmail = null;
        _userRoles = new();
        _userId = null;
        
        _http.DefaultRequestHeaders.Remove("Authorization");
        _http.DefaultRequestHeaders.Remove("X-Tenant-Id");
        
        await Task.CompletedTask;
    }

    public string? GetAccessToken()
    {
        return _accessToken;
    }

    public string? GetTenantId()
    {
        return _tenantId;
    }

    public string? GetTenantName()
    {
        return _tenantName;
    }

    public string? GetBranchId()
    {
        return _branchId;
    }

    public string? GetBranchName()
    {
        return _branchName;
    }

    public string? GetUserEmail()
    {
        return _userEmail;
    }

    public List<string> GetUserRoles()
    {
        return _userRoles ?? new();
    }

    public Guid? GetUserId()
    {
        return _userId;
    }

    private async Task StoreTokensAsync(AuthResponse response)
    {
        _accessToken = response.AccessToken;
        _tenantId = response.TenantId.ToString();
        _tenantName = response.TenantName;
        _branchId = response.BranchId?.ToString();
        _branchName = response.BranchName;
        _userEmail = response.Email;
        _userRoles = response.Roles ?? new List<string>();
        _userId = response.UserId;
        
        // Set authorization header for future requests
        _http.DefaultRequestHeaders.Remove("Authorization");
        _http.DefaultRequestHeaders.Add("Authorization", $"Bearer {response.AccessToken}");
        
        _http.DefaultRequestHeaders.Remove("X-Tenant-Id");
        _http.DefaultRequestHeaders.Add("X-Tenant-Id", response.TenantId.ToString());
        
        await Task.CompletedTask;
    }
}

public class AuthResponse
{
    public string AccessToken { get; set; } = string.Empty;
    public string RefreshToken { get; set; } = string.Empty;
    public Guid UserId { get; set; }
    public Guid TenantId { get; set; }
    public string TenantName { get; set; } = string.Empty;
    public Guid? BranchId { get; set; }
    public string? BranchName { get; set; }
    public string Email { get; set; } = string.Empty;
    public List<string> Roles { get; set; } = new();
}
