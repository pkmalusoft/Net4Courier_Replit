using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface ISizeService
{
    Task<List<ProductSize>> GetAllAsync(bool? isActive = null);
    Task<ProductSize?> GetByIdAsync(Guid id);
    Task<ProductSize?> CreateAsync(ProductSize size);
    Task<ProductSize?> UpdateAsync(ProductSize size);
    Task<bool> DeleteAsync(Guid id);
}

public class SizeService : ISizeService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public SizeService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<ProductSize>> GetAllAsync(bool? isActive = null)
    {
        var query = isActive.HasValue ? $"?isActive={isActive.Value}" : "";
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Size{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<ProductSize>();
        return await response.Content.ReadFromJsonAsync<List<ProductSize>>(_jsonOptions) ?? new();
    }

    public async Task<ProductSize?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Size/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ProductSize>(_jsonOptions);
    }

    public async Task<ProductSize?> CreateAsync(ProductSize size)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/Size");
        request.Content = JsonContent.Create(size, options: _jsonOptions);
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ProductSize>(_jsonOptions);
    }

    public async Task<ProductSize?> UpdateAsync(ProductSize size)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/Size/{size.Id}");
        request.Content = JsonContent.Create(size, options: _jsonOptions);
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ProductSize>(_jsonOptions);
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, $"api/Size/{id}");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }
}
