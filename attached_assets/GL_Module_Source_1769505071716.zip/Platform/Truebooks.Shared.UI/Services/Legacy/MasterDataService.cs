using System.Net.Http.Json;
using System.Net.Http.Headers;


using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IMasterDataService
{
    Task<List<ChartOfAccount>> GetChartOfAccountsAsync();
    Task<List<Currency>> GetCurrenciesAsync();
    Task<List<Currency>> GetAllCurrenciesAsync(); // Get ALL currencies including inactive
    Task<List<Customer>> GetCustomersAsync();
    Task<List<Vendor>> GetVendorsAsync();
    Task<List<Item>> GetItemsAsync();
    Task<List<ItemSearchResult>> SearchItemsAsync(string? query = null, string? itemType = null, int maxResults = 50);
    Task<List<Warehouse>> GetWarehousesAsync();
    Task<List<TaxCode>> GetTaxCodesAsync();
}

public class MasterDataService : IMasterDataService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;

    public MasterDataService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<ChartOfAccount>> GetChartOfAccountsAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/ChartOfAccounts/active");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<ChartOfAccount>();
        var result = await response.Content.ReadFromJsonAsync<List<ChartOfAccount>>();
        return result ?? new List<ChartOfAccount>();
    }

    public async Task<List<Currency>> GetCurrenciesAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Currency/active");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Currency>();
        var result = await response.Content.ReadFromJsonAsync<List<Currency>>();
        return result ?? new List<Currency>();
    }

    public async Task<List<Currency>> GetAllCurrenciesAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Currency");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Currency>();
        var result = await response.Content.ReadFromJsonAsync<List<Currency>>();
        return result ?? new List<Currency>();
    }

    public async Task<List<Customer>> GetCustomersAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Customers/active");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Customer>();
        var result = await response.Content.ReadFromJsonAsync<List<Customer>>();
        return result ?? new List<Customer>();
    }

    public async Task<List<Vendor>> GetVendorsAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Vendors/active");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Vendor>();
        var result = await response.Content.ReadFromJsonAsync<List<Vendor>>();
        return result ?? new List<Vendor>();
    }

    public async Task<List<Item>> GetItemsAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Items/active");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Item>();
        var result = await response.Content.ReadFromJsonAsync<List<Item>>();
        return result ?? new List<Item>();
    }

    public async Task<List<ItemSearchResult>> SearchItemsAsync(string? query = null, string? itemType = null, int maxResults = 50)
    {
        var queryParams = new List<string>();
        if (!string.IsNullOrWhiteSpace(query))
            queryParams.Add($"query={Uri.EscapeDataString(query)}");
        if (!string.IsNullOrWhiteSpace(itemType))
            queryParams.Add($"itemType={Uri.EscapeDataString(itemType)}");
        queryParams.Add($"maxResults={maxResults}");

        var queryString = string.Join("&", queryParams);
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Items/search?{queryString}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<ItemSearchResult>();
        var result = await response.Content.ReadFromJsonAsync<List<ItemSearchResult>>();
        return result ?? new List<ItemSearchResult>();
    }

    public async Task<List<Warehouse>> GetWarehousesAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Warehouses/active");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Warehouse>();
        var result = await response.Content.ReadFromJsonAsync<List<Warehouse>>();
        return result ?? new List<Warehouse>();
    }

    public async Task<List<TaxCode>> GetTaxCodesAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/TaxCodes/active");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<TaxCode>();
        var result = await response.Content.ReadFromJsonAsync<List<TaxCode>>();
        return result ?? new List<TaxCode>();
    }
}
