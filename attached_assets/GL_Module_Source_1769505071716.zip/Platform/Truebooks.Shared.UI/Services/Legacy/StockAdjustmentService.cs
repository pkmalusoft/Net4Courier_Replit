using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IStockAdjustmentService
{
    Task<List<StockAdjustment>> GetAllAsync(DateTime? fromDate = null, DateTime? toDate = null);
    Task<List<StockAdjustment>> GetAllAsync(Guid? warehouseId, AdjustmentType? adjustmentType);
    Task<StockAdjustment?> GetByIdAsync(Guid id);
    Task<StockAdjustment?> CreateAsync(CreateStockAdjustmentDto dto);
    Task<bool> ApproveAsync(Guid id);
    Task<bool> RejectAsync(Guid id, string reason);
}

public class StockAdjustmentService : IStockAdjustmentService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public StockAdjustmentService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<StockAdjustment>> GetAllAsync(DateTime? fromDate = null, DateTime? toDate = null)
    {
        var queryParams = new List<string>();
        if (fromDate.HasValue) queryParams.Add($"fromDate={fromDate.Value:yyyy-MM-dd}");
        if (toDate.HasValue) queryParams.Add($"toDate={toDate.Value:yyyy-MM-dd}");
        var query = queryParams.Any() ? "?" + string.Join("&", queryParams) : "";
        
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/StockAdjustment{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<StockAdjustment>();
        return await response.Content.ReadFromJsonAsync<List<StockAdjustment>>(_jsonOptions) ?? new();
    }

    public async Task<List<StockAdjustment>> GetAllAsync(Guid? warehouseId, AdjustmentType? adjustmentType)
    {
        var queryParams = new List<string>();
        if (warehouseId.HasValue) queryParams.Add($"warehouseId={warehouseId.Value}");
        if (adjustmentType.HasValue) queryParams.Add($"adjustmentType={adjustmentType.Value}");
        var query = queryParams.Any() ? "?" + string.Join("&", queryParams) : "";
        
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/StockAdjustment{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<StockAdjustment>();
        return await response.Content.ReadFromJsonAsync<List<StockAdjustment>>(_jsonOptions) ?? new();
    }

    public async Task<StockAdjustment?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/StockAdjustment/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<StockAdjustment>(_jsonOptions);
    }

    public async Task<StockAdjustment?> CreateAsync(CreateStockAdjustmentDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/StockAdjustment");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<StockAdjustment>(_jsonOptions);
    }

    public async Task<bool> ApproveAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, $"api/StockAdjustment/{id}/approve");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> RejectAsync(Guid id, string reason)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, $"api/StockAdjustment/{id}/reject");
        request.Content = new StringContent(JsonSerializer.Serialize(new { reason }, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }
}
