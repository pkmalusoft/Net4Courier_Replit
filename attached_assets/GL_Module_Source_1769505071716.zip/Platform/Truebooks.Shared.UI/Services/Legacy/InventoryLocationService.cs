using System.Net.Http.Json;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Serialization;


using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IInventoryLocationService
{
    Task<List<InventoryLocation>> GetAllAsync();
    Task<List<InventoryLocation>> GetActiveAsync();
    Task<List<InventoryLocation>> GetByTypeAsync(LocationType type);
    Task<InventoryLocation?> GetByIdAsync(Guid id);
    Task<InventoryLocation?> CreateAsync(InventoryLocation location);
    Task<bool> UpdateAsync(InventoryLocation location);
    Task<bool> DeactivateAsync(Guid id, string? reason);
    Task<bool> ActivateAsync(Guid id);
    Task<bool> DeleteAsync(Guid id);
}

public class InventoryLocationService : IInventoryLocationService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private readonly JsonSerializerOptions _jsonOptions;

    public InventoryLocationService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            Converters = { new JsonStringEnumConverter() }
        };
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<InventoryLocation>> GetAllAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/inventorylocations");
        var response = await _httpClient.SendAsync(request);
        if (response.IsSuccessStatusCode)
        {
            return await response.Content.ReadFromJsonAsync<List<InventoryLocation>>(_jsonOptions) ?? new List<InventoryLocation>();
        }
        return new List<InventoryLocation>();
    }

    public async Task<List<InventoryLocation>> GetActiveAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/inventorylocations/active");
        var response = await _httpClient.SendAsync(request);
        if (response.IsSuccessStatusCode)
        {
            return await response.Content.ReadFromJsonAsync<List<InventoryLocation>>(_jsonOptions) ?? new List<InventoryLocation>();
        }
        return new List<InventoryLocation>();
    }

    public async Task<List<InventoryLocation>> GetByTypeAsync(LocationType type)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/inventorylocations/by-type/{(int)type}");
        var response = await _httpClient.SendAsync(request);
        if (response.IsSuccessStatusCode)
        {
            return await response.Content.ReadFromJsonAsync<List<InventoryLocation>>(_jsonOptions) ?? new List<InventoryLocation>();
        }
        return new List<InventoryLocation>();
    }

    public async Task<InventoryLocation?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/inventorylocations/{id}");
        var response = await _httpClient.SendAsync(request);
        if (response.IsSuccessStatusCode)
        {
            return await response.Content.ReadFromJsonAsync<InventoryLocation>(_jsonOptions);
        }
        return null;
    }

    public async Task<InventoryLocation?> CreateAsync(InventoryLocation location)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/inventorylocations");
        request.Content = JsonContent.Create(location, options: _jsonOptions);
        var response = await _httpClient.SendAsync(request);
        if (response.IsSuccessStatusCode)
        {
            return await response.Content.ReadFromJsonAsync<InventoryLocation>(_jsonOptions);
        }
        return null;
    }

    public async Task<bool> UpdateAsync(InventoryLocation location)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/inventorylocations/{location.Id}");
        request.Content = JsonContent.Create(location, options: _jsonOptions);
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> DeactivateAsync(Guid id, string? reason)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, $"api/inventorylocations/{id}/deactivate");
        request.Content = JsonContent.Create(new { Reason = reason });
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> ActivateAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, $"api/inventorylocations/{id}/activate");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, $"api/inventorylocations/{id}");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }
}
