using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.JSInterop;
using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IChartOfAccountsService
{
    Task<List<ChartOfAccount>> GetAllAsync();
    Task<List<ChartOfAccount>> GetHierarchyAsync();
    Task<ChartOfAccount?> GetByIdAsync(Guid id);
    Task<List<ChartOfAccount>> GetFilteredAccountsAsync(string? accountType = null, Guid? classificationId = null, bool onlyAllowPosting = true);
    Task<bool> CodeExistsAsync(string code, Guid? excludeId = null);
    Task<bool> NameExistsAsync(string name, Guid? excludeId = null);
    Task<bool> HasChildrenAsync(Guid id);
    Task<Guid> CreateAsync(ChartOfAccount account);
    Task UpdateAsync(Guid id, ChartOfAccount account);
    Task DeleteAsync(Guid id);
    Task<bool> HasAccountsAsync();
    Task SeedFromTemplateAsync(IndustryType industryType);
    Task ResetFromTemplateAsync(IndustryType industryType);
    Task<bool> ExportPdfAsync();
    Task<bool> ExportExcelAsync();
}

public class ChartOfAccountsService : IChartOfAccountsService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private readonly IJSRuntime _jsRuntime;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public ChartOfAccountsService(HttpClient httpClient, IAuthService authService, IJSRuntime jsRuntime)
    {
        _httpClient = httpClient;
        _authService = authService;
        _jsRuntime = jsRuntime;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    private void SetAuthHeader()
    {
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            _httpClient.DefaultRequestHeaders.Remove("X-Tenant-Id");
            _httpClient.DefaultRequestHeaders.Add("X-Tenant-Id", tenantId);
        }
    }

    public async Task<List<ChartOfAccount>> GetAllAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/ChartOfAccount");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<ChartOfAccount>();
        var result = await response.Content.ReadFromJsonAsync<List<ChartOfAccount>>(_jsonOptions);
        return result ?? new List<ChartOfAccount>();
    }

    public async Task<List<ChartOfAccount>> GetHierarchyAsync()
    {
        SetAuthHeader();
        var result = await _httpClient.GetFromJsonAsync<List<ChartOfAccount>>("api/ChartOfAccount/hierarchy", _jsonOptions);
        
        if (result != null)
        {
            CalculateLevelsAndPaths(result, 0, "");
        }
        
        return result ?? new List<ChartOfAccount>();
    }

    public async Task<ChartOfAccount?> GetByIdAsync(Guid id)
    {
        SetAuthHeader();
        var result = await _httpClient.GetFromJsonAsync<ChartOfAccount>($"api/ChartOfAccount/{id}", _jsonOptions);
        return result;
    }

    public async Task<List<ChartOfAccount>> GetFilteredAccountsAsync(string? accountType = null, Guid? classificationId = null, bool onlyAllowPosting = true)
    {
        SetAuthHeader();
        var queryParams = new List<string>();
        
        if (!string.IsNullOrEmpty(accountType))
        {
            queryParams.Add($"accountType={Uri.EscapeDataString(accountType)}");
        }
        
        if (classificationId.HasValue)
        {
            queryParams.Add($"classificationId={classificationId.Value}");
        }
        
        queryParams.Add($"onlyAllowPosting={onlyAllowPosting.ToString().ToLower()}");
        
        var queryString = queryParams.Any() ? $"?{string.Join("&", queryParams)}" : "";
        var result = await _httpClient.GetFromJsonAsync<List<ChartOfAccount>>($"api/ChartOfAccount/filter{queryString}", _jsonOptions);
        return result ?? new List<ChartOfAccount>();
    }

    public async Task<bool> CodeExistsAsync(string code, Guid? excludeId = null)
    {
        SetAuthHeader();
        var url = $"api/ChartOfAccount/validate/code-exists?code={Uri.EscapeDataString(code)}";
        if (excludeId.HasValue)
        {
            url += $"&excludeId={excludeId.Value}";
        }
        var result = await _httpClient.GetFromJsonAsync<bool>(url);
        return result;
    }

    public async Task<bool> NameExistsAsync(string name, Guid? excludeId = null)
    {
        SetAuthHeader();
        var url = $"api/ChartOfAccount/validate/name-exists?name={Uri.EscapeDataString(name)}";
        if (excludeId.HasValue)
        {
            url += $"&excludeId={excludeId.Value}";
        }
        var result = await _httpClient.GetFromJsonAsync<bool>(url);
        return result;
    }

    public async Task<bool> HasChildrenAsync(Guid id)
    {
        SetAuthHeader();
        var result = await _httpClient.GetFromJsonAsync<bool>($"api/ChartOfAccount/{id}/has-children");
        return result;
    }

    public async Task<Guid> CreateAsync(ChartOfAccount account)
    {
        SetAuthHeader();
        var response = await _httpClient.PostAsJsonAsync("api/ChartOfAccount", account);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
        
        var created = await response.Content.ReadFromJsonAsync<ChartOfAccount>(_jsonOptions);
        return created?.Id ?? Guid.Empty;
    }

    public async Task UpdateAsync(Guid id, ChartOfAccount account)
    {
        SetAuthHeader();
        var response = await _httpClient.PutAsJsonAsync($"api/ChartOfAccount/{id}", account);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }

    public async Task DeleteAsync(Guid id)
    {
        SetAuthHeader();
        var response = await _httpClient.DeleteAsync($"api/ChartOfAccount/{id}");
        response.EnsureSuccessStatusCode();
    }

    public async Task<bool> HasAccountsAsync()
    {
        SetAuthHeader();
        var result = await _httpClient.GetFromJsonAsync<bool>("api/ChartOfAccount/has-accounts");
        return result;
    }

    public async Task SeedFromTemplateAsync(IndustryType industryType)
    {
        SetAuthHeader();
        var request = new { IndustryType = industryType };
        var response = await _httpClient.PostAsJsonAsync("api/ChartOfAccount/seed-from-template", request);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }

    public async Task ResetFromTemplateAsync(IndustryType industryType)
    {
        SetAuthHeader();
        var request = new { IndustryType = industryType };
        var response = await _httpClient.PostAsJsonAsync("api/ChartOfAccount/reset-from-template", request);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }

    public async Task<bool> ExportPdfAsync()
    {
        SetAuthHeader();
        var response = await _httpClient.GetAsync("api/ChartOfAccount/export-pdf");
        
        if (response.IsSuccessStatusCode)
        {
            var content = await response.Content.ReadAsByteArrayAsync();
            var fileName = GetFileNameFromResponse(response) ?? $"Chart_of_Accounts_{DateTime.Now:yyyyMMdd}.pdf";
            await DownloadFile(content, fileName, "application/pdf");
            return true;
        }
        
        return false;
    }

    public async Task<bool> ExportExcelAsync()
    {
        SetAuthHeader();
        var response = await _httpClient.GetAsync("api/ChartOfAccount/export-excel");
        
        if (response.IsSuccessStatusCode)
        {
            var content = await response.Content.ReadAsByteArrayAsync();
            var fileName = GetFileNameFromResponse(response) ?? $"Chart_of_Accounts_{DateTime.Now:yyyyMMdd}.xlsx";
            await DownloadFile(content, fileName, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            return true;
        }
        
        return false;
    }

    private string? GetFileNameFromResponse(HttpResponseMessage response)
    {
        if (response.Content.Headers.ContentDisposition?.FileName != null)
        {
            return response.Content.Headers.ContentDisposition.FileName.Trim('"');
        }
        return null;
    }

    private async Task DownloadFile(byte[] content, string fileName, string contentType)
    {
        var base64 = Convert.ToBase64String(content);
        var dataUrl = $"data:{contentType};base64,{base64}";
        
        await _jsRuntime.InvokeVoidAsync("downloadFile", fileName, dataUrl);
    }

    private void CalculateLevelsAndPaths(List<ChartOfAccount> accounts, int level, string parentPath)
    {
        foreach (var account in accounts)
        {
            account.Level = level;
            account.FullPath = string.IsNullOrEmpty(parentPath) 
                ? account.AccountName 
                : $"{parentPath} > {account.AccountName}";
            
            if (account.SubAccounts.Any())
            {
                CalculateLevelsAndPaths(account.SubAccounts, level + 1, account.FullPath);
            }
        }
    }
}
