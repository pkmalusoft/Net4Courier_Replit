using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IGridPreferencesService
{
    Task<GridPreference?> GetAsync(string gridKey);
    Task SaveAsync(string gridKey, GridPreference preference);
    Task<List<string>> GetVisibleColumnsAsync(string gridKey);
    Task SaveVisibleColumnsAsync(string gridKey, List<string> columns);
    Task ResetToDefaultAsync(string gridKey);
}

public class GridPreference
{
    public string GridKey { get; set; } = string.Empty;
    public int PageSize { get; set; } = 10;
    public string? SortColumn { get; set; }
    public bool SortDescending { get; set; }
    public List<string> VisibleColumns { get; set; } = new();
    public Dictionary<string, int> ColumnWidths { get; set; } = new();
}

public class GridPreferencesService : IGridPreferencesService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public GridPreferencesService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<GridPreference?> GetAsync(string gridKey)
    {
        try
        {
            var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/GridPreferences/{gridKey}");
            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode) return null;
            return await response.Content.ReadFromJsonAsync<GridPreference>(_jsonOptions);
        }
        catch
        {
            return null;
        }
    }

    public async Task SaveAsync(string gridKey, GridPreference preference)
    {
        try
        {
            preference.GridKey = gridKey;
            var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/GridPreferences");
            request.Content = new StringContent(JsonSerializer.Serialize(preference, _jsonOptions), Encoding.UTF8, "application/json");
            await _httpClient.SendAsync(request);
        }
        catch
        {
        }
    }

    public async Task<List<string>> GetVisibleColumnsAsync(string gridKey)
    {
        try
        {
            var pref = await GetAsync(gridKey);
            return pref?.VisibleColumns ?? new List<string>();
        }
        catch
        {
            return new List<string>();
        }
    }

    public async Task SaveVisibleColumnsAsync(string gridKey, List<string> columns)
    {
        try
        {
            var pref = await GetAsync(gridKey) ?? new GridPreference { GridKey = gridKey };
            pref.VisibleColumns = columns;
            await SaveAsync(gridKey, pref);
        }
        catch
        {
        }
    }

    public async Task ResetToDefaultAsync(string gridKey)
    {
        try
        {
            var request = CreateAuthenticatedRequest(HttpMethod.Delete, $"api/GridPreferences/{gridKey}");
            await _httpClient.SendAsync(request);
        }
        catch
        {
        }
    }
}
