using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface ISerialNumberService
{
    Task<List<SerialNumber>> GetAllAsync(Guid? itemId = null, bool? isAvailable = null, string? search = null);
    Task<List<SerialNumber>> GetAllAsync(Guid? itemId, bool? isAvailable, SerialStatus? status);
    Task<SerialNumber?> GetByIdAsync(Guid id);
    Task<List<SerialNumber>> GetByItemIdAsync(Guid itemId);
}

public class SerialNumberService : ISerialNumberService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public SerialNumberService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<SerialNumber>> GetAllAsync(Guid? itemId = null, bool? isAvailable = null, string? search = null)
    {
        var queryParams = new List<string>();
        if (itemId.HasValue) queryParams.Add($"itemId={itemId.Value}");
        if (isAvailable.HasValue) queryParams.Add($"isAvailable={isAvailable.Value}");
        if (!string.IsNullOrEmpty(search)) queryParams.Add($"search={Uri.EscapeDataString(search)}");
        var query = queryParams.Any() ? "?" + string.Join("&", queryParams) : "";
        
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/SerialNumber{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<SerialNumber>();
        return await response.Content.ReadFromJsonAsync<List<SerialNumber>>(_jsonOptions) ?? new();
    }

    public async Task<List<SerialNumber>> GetAllAsync(Guid? itemId, bool? isAvailable, SerialStatus? status)
    {
        var queryParams = new List<string>();
        if (itemId.HasValue) queryParams.Add($"itemId={itemId.Value}");
        if (isAvailable.HasValue) queryParams.Add($"isAvailable={isAvailable.Value}");
        if (status.HasValue) queryParams.Add($"status={status.Value}");
        var query = queryParams.Any() ? "?" + string.Join("&", queryParams) : "";
        
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/SerialNumber{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<SerialNumber>();
        return await response.Content.ReadFromJsonAsync<List<SerialNumber>>(_jsonOptions) ?? new();
    }

    public async Task<SerialNumber?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/SerialNumber/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<SerialNumber>(_jsonOptions);
    }

    public async Task<List<SerialNumber>> GetByItemIdAsync(Guid itemId)
    {
        return await GetAllAsync(itemId: itemId);
    }
}
