using System.Net.Http.Json;
using System.Net.Http.Headers;


using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface ITransactionService
{
    Task<JournalEntryDto> CreateJournalEntryAsync(JournalEntryDto entry);
    Task UpdateJournalEntryAsync(Guid id, JournalEntryDto entry);
    Task<JournalEntryDto> PostJournalEntryAsync(Guid id);
    Task<SalesInvoiceDto> CreateSalesInvoiceAsync(SalesInvoiceDto invoice);
    Task<SalesInvoiceDto> PostSalesInvoiceAsync(Guid id);
    Task<PurchaseBillDto> CreatePurchaseBillAsync(PurchaseBillDto bill);
    Task<PurchaseBillDto> PostPurchaseBillAsync(Guid id);
}

public class TransactionService : ITransactionService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;

    public TransactionService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private void SetAuthHeader()
    {
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            _httpClient.DefaultRequestHeaders.Remove("X-Tenant-Id");
            _httpClient.DefaultRequestHeaders.Add("X-Tenant-Id", tenantId);
        }
    }

    public async Task<JournalEntryDto> CreateJournalEntryAsync(JournalEntryDto entry)
    {
        SetAuthHeader();
        var response = await _httpClient.PostAsJsonAsync("api/JournalEntry", entry);
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
        return await response.Content.ReadFromJsonAsync<JournalEntryDto>() ?? entry;
    }

    public async Task UpdateJournalEntryAsync(Guid id, JournalEntryDto entry)
    {
        SetAuthHeader();
        var response = await _httpClient.PutAsJsonAsync($"api/JournalEntry/{id}", entry);
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }

    public async Task<JournalEntryDto> PostJournalEntryAsync(Guid id)
    {
        SetAuthHeader();
        var response = await _httpClient.PostAsync($"api/JournalEntry/{id}/post", null);
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
        return await response.Content.ReadFromJsonAsync<JournalEntryDto>() ?? new JournalEntryDto();
    }

    public async Task<SalesInvoiceDto> CreateSalesInvoiceAsync(SalesInvoiceDto invoice)
    {
        SetAuthHeader();
        var response = await _httpClient.PostAsJsonAsync("api/SalesInvoices", invoice);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<SalesInvoiceDto>() ?? invoice;
    }

    public async Task<SalesInvoiceDto> PostSalesInvoiceAsync(Guid id)
    {
        SetAuthHeader();
        var response = await _httpClient.PostAsync($"api/SalesInvoices/{id}/post", null);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<SalesInvoiceDto>() ?? new SalesInvoiceDto();
    }

    public async Task<PurchaseBillDto> CreatePurchaseBillAsync(PurchaseBillDto bill)
    {
        SetAuthHeader();
        var response = await _httpClient.PostAsJsonAsync("api/PurchaseBills", bill);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<PurchaseBillDto>() ?? bill;
    }

    public async Task<PurchaseBillDto> PostPurchaseBillAsync(Guid id)
    {
        SetAuthHeader();
        var response = await _httpClient.PostAsync($"api/PurchaseBills/{id}/post", null);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<PurchaseBillDto>() ?? new PurchaseBillDto();
    }
}
