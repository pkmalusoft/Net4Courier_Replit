using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IColourService
{
    Task<List<Colour>> GetAllAsync(bool? isActive = null);
    Task<Colour?> GetByIdAsync(Guid id);
    Task<Colour?> CreateAsync(Colour colour);
    Task<Colour?> UpdateAsync(Colour colour);
    Task<bool> DeleteAsync(Guid id);
}

public class ColourService : IColourService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public ColourService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<Colour>> GetAllAsync(bool? isActive = null)
    {
        var query = isActive.HasValue ? $"?isActive={isActive.Value}" : "";
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Colour{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Colour>();
        return await response.Content.ReadFromJsonAsync<List<Colour>>(_jsonOptions) ?? new();
    }

    public async Task<Colour?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Colour/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Colour>(_jsonOptions);
    }

    public async Task<Colour?> CreateAsync(Colour colour)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/Colour");
        request.Content = JsonContent.Create(colour, options: _jsonOptions);
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Colour>(_jsonOptions);
    }

    public async Task<Colour?> UpdateAsync(Colour colour)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/Colour/{colour.Id}");
        request.Content = JsonContent.Create(colour, options: _jsonOptions);
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Colour>(_jsonOptions);
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, $"api/Colour/{id}");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }
}
