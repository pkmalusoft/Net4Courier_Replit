using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IItemCategoryService
{
    Task<List<ItemCategory>> GetAllAsync(bool? isActive = null);
    Task<ItemCategory?> GetByIdAsync(Guid id);
    Task<ItemCategory?> CreateAsync(CreateCategoryDto dto);
    Task<ItemCategory?> UpdateAsync(UpdateCategoryDto dto);
    Task<bool> DeleteAsync(Guid id);
}

public class ItemCategoryService : IItemCategoryService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public ItemCategoryService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<ItemCategory>> GetAllAsync(bool? isActive = null)
    {
        var query = isActive.HasValue ? $"?isActive={isActive.Value}" : "";
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/ItemCategory{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<ItemCategory>();
        return await response.Content.ReadFromJsonAsync<List<ItemCategory>>(_jsonOptions) ?? new();
    }

    public async Task<ItemCategory?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/ItemCategory/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ItemCategory>(_jsonOptions);
    }

    public async Task<ItemCategory?> CreateAsync(CreateCategoryDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/ItemCategory");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ItemCategory>(_jsonOptions);
    }

    public async Task<ItemCategory?> UpdateAsync(UpdateCategoryDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/ItemCategory/{dto.Id}");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ItemCategory>(_jsonOptions);
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, $"api/ItemCategory/{id}");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }
}
