using System.Net.Http.Json;

namespace Truebooks.Shared.UI.Services.Legacy;

public class WorkingPeriodStateProvider : IWorkingPeriodStateProvider
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private WorkingPeriodInfo? _currentPeriod;
    private bool _apiCallFailed;

    public WorkingPeriodInfo? CurrentPeriod => _currentPeriod;

    public event Action? OnPeriodChanged;

    public WorkingPeriodStateProvider(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    public async Task InitializeAsync()
    {
        if (string.IsNullOrEmpty(_authService.GetAccessToken()))
        {
            _currentPeriod = null;
            _apiCallFailed = false;
            OnPeriodChanged?.Invoke();
            return;
        }

        try
        {
            var selectablePeriods = await GetSelectablePeriodsAsync();
            
            if (selectablePeriods.Any())
            {
                var today = DateTime.UtcNow.Date;
                var currentPeriod = selectablePeriods
                    .FirstOrDefault(p => p.StartDate <= today && p.EndDate >= today && p.Status == "Open");
                
                if (currentPeriod == null)
                {
                    currentPeriod = selectablePeriods
                        .FirstOrDefault(p => p.Status == "Open");
                }
                
                if (currentPeriod == null)
                {
                    currentPeriod = selectablePeriods.FirstOrDefault();
                }

                _currentPeriod = currentPeriod;
            }
            else
            {
                _currentPeriod = null;
            }
            
            OnPeriodChanged?.Invoke();
        }
        catch
        {
            _currentPeriod = null;
            _apiCallFailed = true;
            OnPeriodChanged?.Invoke();
        }
    }

    public async Task SetPeriodAsync(WorkingPeriodInfo period)
    {
        _currentPeriod = period;
        OnPeriodChanged?.Invoke();
        await Task.CompletedTask;
    }

    public async Task<List<WorkingPeriodInfo>> GetSelectablePeriodsAsync()
    {
        var token = _authService.GetAccessToken();
        var tenantId = _authService.GetTenantId();
        
        if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(tenantId))
        {
            _apiCallFailed = false;
            return new List<WorkingPeriodInfo>();
        }

        try
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "api/financialperiod/selectable");
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            request.Headers.Add("X-Tenant-Id", tenantId);
            
            var response = await _httpClient.SendAsync(request);
            
            if (response.IsSuccessStatusCode)
            {
                var periods = await response.Content.ReadFromJsonAsync<List<FinancialPeriodDto>>();
                if (periods != null && periods.Any())
                {
                    _apiCallFailed = false;
                    return periods.Select(p => new WorkingPeriodInfo
                    {
                        PeriodId = p.Id,
                        PeriodName = p.PeriodName,
                        FiscalYear = p.FiscalYear,
                        PeriodNumber = p.PeriodNumber,
                        StartDate = p.StartDate,
                        EndDate = p.EndDate,
                        Status = p.Status,
                        IsYearEnd = p.IsYearEnd
                    }).ToList();
                }
                
                _apiCallFailed = false;
                return new List<WorkingPeriodInfo>();
            }
            else
            {
                _apiCallFailed = true;
                return GetFallbackPeriods();
            }
        }
        catch
        {
            _apiCallFailed = true;
            return GetFallbackPeriods();
        }
    }

    private List<WorkingPeriodInfo> GetFallbackPeriods()
    {
        var today = DateTime.UtcNow;
        var fiscalYear = today.Month >= 4 ? today.Year : today.Year - 1;
        
        return new List<WorkingPeriodInfo>
        {
            new WorkingPeriodInfo
            {
                PeriodName = $"Period {today.Month} - {today:MMMM yyyy}",
                FiscalYear = fiscalYear,
                PeriodNumber = today.Month,
                StartDate = new DateTime(today.Year, today.Month, 1),
                EndDate = new DateTime(today.Year, today.Month, DateTime.DaysInMonth(today.Year, today.Month)),
                Status = "Open"
            },
            new WorkingPeriodInfo
            {
                PeriodName = $"Period {today.AddMonths(-1).Month} - {today.AddMonths(-1):MMMM yyyy}",
                FiscalYear = fiscalYear,
                PeriodNumber = today.AddMonths(-1).Month,
                StartDate = new DateTime(today.AddMonths(-1).Year, today.AddMonths(-1).Month, 1),
                EndDate = new DateTime(today.AddMonths(-1).Year, today.AddMonths(-1).Month, DateTime.DaysInMonth(today.AddMonths(-1).Year, today.AddMonths(-1).Month)),
                Status = "Open"
            }
        };
    }

    public bool IsDateInWorkingPeriod(DateTime date)
    {
        if (_currentPeriod == null)
            return true;

        return date.Date >= _currentPeriod.StartDate.Date && 
               date.Date <= _currentPeriod.EndDate.Date;
    }

    public DateTime GetDefaultTransactionDate()
    {
        if (_currentPeriod == null)
            return DateTime.UtcNow.Date;

        var today = DateTime.UtcNow.Date;
        
        if (today >= _currentPeriod.StartDate.Date && today <= _currentPeriod.EndDate.Date)
            return today;

        return _currentPeriod.EndDate.Date;
    }

    public DateTime? GetPeriodMinDate()
    {
        return _currentPeriod?.StartDate.Date;
    }

    public DateTime? GetPeriodMaxDate()
    {
        return _currentPeriod?.EndDate.Date;
    }
}

public class FinancialPeriodDto
{
    public Guid Id { get; set; }
    public string PeriodName { get; set; } = string.Empty;
    public int FiscalYear { get; set; }
    public int PeriodNumber { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Status { get; set; } = string.Empty;
    public bool IsYearEnd { get; set; }
}
