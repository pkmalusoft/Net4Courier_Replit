using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IWarehouseService
{
    Task<List<Warehouse>> GetAllAsync(bool? isActive = null);
    Task<Warehouse?> GetByIdAsync(Guid id);
    Task<Warehouse?> CreateAsync(CreateWarehouseDto dto);
    Task<Warehouse?> UpdateAsync(UpdateWarehouseDto dto);
    Task<bool> DeleteAsync(Guid id);
}

public class WarehouseService : IWarehouseService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public WarehouseService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<Warehouse>> GetAllAsync(bool? isActive = null)
    {
        var query = isActive.HasValue ? $"?isActive={isActive.Value}" : "";
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Warehouse{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Warehouse>();
        return await response.Content.ReadFromJsonAsync<List<Warehouse>>(_jsonOptions) ?? new();
    }

    public async Task<Warehouse?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Warehouse/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Warehouse>(_jsonOptions);
    }

    public async Task<Warehouse?> CreateAsync(CreateWarehouseDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/Warehouse");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Warehouse>(_jsonOptions);
    }

    public async Task<Warehouse?> UpdateAsync(UpdateWarehouseDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/Warehouse/{dto.Id}");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Warehouse>(_jsonOptions);
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, $"api/Warehouse/{id}");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }
}
