using System.Net.Http.Json;
using System.Net.Http.Headers;

using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface ICurrencyService
{
    Task<string> GetBaseCurrencySymbolAsync();
    string FormatAmount(decimal amount);
}

public class CurrencyService : ICurrencyService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private string? _cachedSymbol;
    private DateTime? _cacheTime;
    private readonly TimeSpan _cacheExpiration = TimeSpan.FromMinutes(30);

    public CurrencyService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    public async Task<string> GetBaseCurrencySymbolAsync()
    {
        if (_cachedSymbol != null && _cacheTime.HasValue && 
            DateTime.UtcNow - _cacheTime.Value < _cacheExpiration)
        {
            return _cachedSymbol;
        }

        try
        {
            var token = _authService.GetAccessToken();
            var tenantId = _authService.GetTenantId();

            using var request = new HttpRequestMessage(HttpMethod.Get, "api/Currencies");
            
            if (!string.IsNullOrEmpty(token))
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            
            if (!string.IsNullOrEmpty(tenantId))
            {
                request.Headers.Add("X-Tenant-Id", tenantId);
            }

            var response = await _httpClient.SendAsync(request);
            
            if (response.IsSuccessStatusCode)
            {
                var currencies = await response.Content.ReadFromJsonAsync<List<CurrencyDto>>();
                var baseCurrency = currencies?.FirstOrDefault(c => c.IsBaseCurrency);
                
                if (baseCurrency != null)
                {
                    _cachedSymbol = baseCurrency.Symbol;
                    _cacheTime = DateTime.UtcNow;
                    return _cachedSymbol;
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error fetching base currency: {ex.Message}");
        }

        return "₹";
    }

    public string FormatAmount(decimal amount)
    {
        var symbol = _cachedSymbol ?? "₹";
        return $"{symbol}{amount:N2}";
    }

    private class CurrencyDto
    {
        public Guid Id { get; set; }
        public string Code { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Symbol { get; set; } = string.Empty;
        public bool IsBaseCurrency { get; set; }
        public bool IsActive { get; set; }
    }
}
