using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IUomService
{
    Task<List<UnitOfMeasure>> GetAllAsync(bool? isActive = null);
    Task<UnitOfMeasure?> GetByIdAsync(Guid id);
    Task<UnitOfMeasure?> CreateAsync(CreateUomDto dto);
    Task<UnitOfMeasure?> UpdateAsync(UpdateUomDto dto);
    Task<bool> DeleteAsync(Guid id);
}

public class UomService : IUomService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public UomService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<UnitOfMeasure>> GetAllAsync(bool? isActive = null)
    {
        var query = isActive.HasValue ? $"?isActive={isActive.Value}" : "";
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/UnitOfMeasure{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<UnitOfMeasure>();
        return await response.Content.ReadFromJsonAsync<List<UnitOfMeasure>>(_jsonOptions) ?? new();
    }

    public async Task<UnitOfMeasure?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/UnitOfMeasure/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<UnitOfMeasure>(_jsonOptions);
    }

    public async Task<UnitOfMeasure?> CreateAsync(CreateUomDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/UnitOfMeasure");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<UnitOfMeasure>(_jsonOptions);
    }

    public async Task<UnitOfMeasure?> UpdateAsync(UpdateUomDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/UnitOfMeasure/{dto.Id}");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<UnitOfMeasure>(_jsonOptions);
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, $"api/UnitOfMeasure/{id}");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }
}
