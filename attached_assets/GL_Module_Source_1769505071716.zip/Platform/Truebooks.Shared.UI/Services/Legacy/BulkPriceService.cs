using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IBulkPriceService
{
    Task<List<BulkPriceFilterResultDto>> FilterItemsAsync(BulkPriceFilterDto filter);
    Task<List<BulkPricePreviewItemDto>> PreviewChangesAsync(BulkPriceUpdateDto update);
    Task<List<BulkPricePreviewItemDto>> PreviewAdjustmentAsync(BulkPriceUpdateDto update);
    Task<List<BulkPricePreviewItemDto>> PreviewAdjustmentAsync(BulkPriceAdjustmentDto adjustment);
    Task<bool> ApplyBulkPriceUpdateAsync(BulkPriceUpdateDto update);
    Task<bool> ApplyAdjustmentAsync(BulkPriceUpdateDto update);
    Task<BulkPriceApplyResult> ApplyAdjustmentAsync(BulkPriceAdjustmentDto adjustment);
}

public class BulkPriceService : IBulkPriceService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public BulkPriceService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<BulkPriceFilterResultDto>> FilterItemsAsync(BulkPriceFilterDto filter)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/BulkPrice/filter");
        request.Content = new StringContent(JsonSerializer.Serialize(filter, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<BulkPriceFilterResultDto>();
        return await response.Content.ReadFromJsonAsync<List<BulkPriceFilterResultDto>>(_jsonOptions) ?? new();
    }

    public async Task<List<BulkPricePreviewItemDto>> PreviewChangesAsync(BulkPriceUpdateDto update)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/BulkPrice/preview");
        request.Content = new StringContent(JsonSerializer.Serialize(update, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<BulkPricePreviewItemDto>();
        return await response.Content.ReadFromJsonAsync<List<BulkPricePreviewItemDto>>(_jsonOptions) ?? new();
    }

    public async Task<bool> ApplyBulkPriceUpdateAsync(BulkPriceUpdateDto update)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/BulkPrice/apply");
        request.Content = new StringContent(JsonSerializer.Serialize(update, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public Task<List<BulkPricePreviewItemDto>> PreviewAdjustmentAsync(BulkPriceUpdateDto update)
        => PreviewChangesAsync(update);

    public async Task<List<BulkPricePreviewItemDto>> PreviewAdjustmentAsync(BulkPriceAdjustmentDto adjustment)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/BulkPrice/preview-adjustment");
        request.Content = new StringContent(JsonSerializer.Serialize(adjustment, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<BulkPricePreviewItemDto>();
        return await response.Content.ReadFromJsonAsync<List<BulkPricePreviewItemDto>>(_jsonOptions) ?? new();
    }

    public Task<bool> ApplyAdjustmentAsync(BulkPriceUpdateDto update)
        => ApplyBulkPriceUpdateAsync(update);

    public async Task<BulkPriceApplyResult> ApplyAdjustmentAsync(BulkPriceAdjustmentDto adjustment)
    {
        try
        {
            var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/BulkPrice/apply-adjustment");
            request.Content = new StringContent(JsonSerializer.Serialize(adjustment, _jsonOptions), Encoding.UTF8, "application/json");
            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                return new BulkPriceApplyResult { Success = false, ErrorMessage = "Failed to apply price adjustment" };
            }
            return await response.Content.ReadFromJsonAsync<BulkPriceApplyResult>(_jsonOptions) 
                ?? new BulkPriceApplyResult { Success = true };
        }
        catch (Exception ex)
        {
            return new BulkPriceApplyResult { Success = false, ErrorMessage = ex.Message };
        }
    }
}
