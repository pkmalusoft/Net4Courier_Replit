using System.Net.Http.Json;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IItemService
{
    Task<List<Item>> GetAllAsync(ItemType? itemType = null, Guid? categoryId = null, bool? isActive = null);
    Task<Item?> GetByIdAsync(Guid id);
    Task<Item?> CreateAsync(CreateItemDto dto);
    Task<Item?> UpdateAsync(UpdateItemDto dto);
    Task<bool> DeleteAsync(Guid id, string? reason = null);
    Task<List<ItemInventoryDetail>> GetInventoryDetailsAsync(Guid itemId);
    Task<byte[]?> ExportPdfAsync(ItemType? itemType = null, bool? isActive = null);
    Task<byte[]?> ExportExcelAsync(ItemType? itemType = null, bool? isActive = null);
}

public class ItemService : IItemService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public ItemService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<Item>> GetAllAsync(ItemType? itemType = null, Guid? categoryId = null, bool? isActive = null)
    {
        var queryParams = new List<string>();
        if (itemType.HasValue) queryParams.Add($"itemType={itemType.Value}");
        if (categoryId.HasValue) queryParams.Add($"categoryId={categoryId.Value}");
        if (isActive.HasValue) queryParams.Add($"includeInactive={!isActive.Value}");
        
        var query = queryParams.Any() ? "?" + string.Join("&", queryParams) : "";
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Item{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode)
        {
            var error = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"Failed to load items: {response.StatusCode} - {error}");
        }
        var result = await response.Content.ReadFromJsonAsync<List<Item>>(_jsonOptions);
        return result ?? new List<Item>();
    }

    public async Task<Item?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Item/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Item>(_jsonOptions);
    }

    public async Task<Item?> CreateAsync(CreateItemDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/Item");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Item>(_jsonOptions);
    }

    public async Task<Item?> UpdateAsync(UpdateItemDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/Item/{dto.Id}");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Item>(_jsonOptions);
    }

    public async Task<bool> DeleteAsync(Guid id, string? reason = null)
    {
        var url = $"api/Item/{id}";
        if (!string.IsNullOrEmpty(reason))
        {
            url += $"?reason={Uri.EscapeDataString(reason)}";
        }
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, url);
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<List<ItemInventoryDetail>> GetInventoryDetailsAsync(Guid itemId)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Item/{itemId}/inventory");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<ItemInventoryDetail>();
        var result = await response.Content.ReadFromJsonAsync<List<ItemInventoryDetail>>(_jsonOptions);
        return result ?? new List<ItemInventoryDetail>();
    }

    public async Task<byte[]?> ExportPdfAsync(ItemType? itemType = null, bool? isActive = null)
    {
        var queryParams = new List<string>();
        if (itemType.HasValue) queryParams.Add($"itemType={itemType.Value}");
        if (isActive.HasValue) queryParams.Add($"isActive={isActive.Value}");
        
        var query = queryParams.Any() ? "?" + string.Join("&", queryParams) : "";
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Items/export-pdf{query}");
        var response = await _httpClient.SendAsync(request);
        
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadAsByteArrayAsync();
    }

    public async Task<byte[]?> ExportExcelAsync(ItemType? itemType = null, bool? isActive = null)
    {
        var queryParams = new List<string>();
        if (itemType.HasValue) queryParams.Add($"itemType={itemType.Value}");
        if (isActive.HasValue) queryParams.Add($"isActive={isActive.Value}");
        
        var query = queryParams.Any() ? "?" + string.Join("&", queryParams) : "";
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Items/export-excel{query}");
        var response = await _httpClient.SendAsync(request);
        
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadAsByteArrayAsync();
    }
}
