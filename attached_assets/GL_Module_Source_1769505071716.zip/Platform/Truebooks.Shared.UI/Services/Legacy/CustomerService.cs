using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.JSInterop;


using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface ICustomerService
{
    Task<List<Customer>> GetAllAsync();
    Task<Customer?> GetByIdAsync(Guid id);
    Task<List<Customer>> GetPendingCreditApprovalsAsync();
    Task<List<CustomerCreditApprovalHistory>> GetCreditHistoryAsync(Guid customerId);
    Task<List<Customer>> GetByModuleCodeAsync(string moduleCode, string? search = null);
    Task<Guid> CreateAsync(Customer customer);
    Task UpdateAsync(Guid id, Customer customer);
    Task DeleteAsync(Guid id, string? reason = null);
    Task RequestCreditAsync(Guid customerId, decimal requestedLimit, string notes);
    Task ApproveCreditAsync(Guid customerId, decimal approvedLimit, string notes);
    Task RejectCreditAsync(Guid customerId, string notes);
    Task<bool> ExportPdfAsync();
    Task<bool> ExportExcelAsync();
}

public class CustomerService : ICustomerService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private readonly IJSRuntime _jsRuntime;
    
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public CustomerService(HttpClient httpClient, IAuthService authService, IJSRuntime jsRuntime)
    {
        _httpClient = httpClient;
        _authService = authService;
        _jsRuntime = jsRuntime;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    private void SetAuthHeader()
    {
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            _httpClient.DefaultRequestHeaders.Remove("X-Tenant-Id");
            _httpClient.DefaultRequestHeaders.Add("X-Tenant-Id", tenantId);
        }
    }

    public async Task<List<Customer>> GetAllAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Customer");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Customer>();
        var result = await response.Content.ReadFromJsonAsync<List<Customer>>(_jsonOptions);
        return result ?? new List<Customer>();
    }

    public async Task<Customer?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Customer/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<Customer>(_jsonOptions);
    }

    public async Task<List<Customer>> GetPendingCreditApprovalsAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Customer/pending-credit-requests");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Customer>();
        var result = await response.Content.ReadFromJsonAsync<List<Customer>>(_jsonOptions);
        return result ?? new List<Customer>();
    }

    public async Task<List<CustomerCreditApprovalHistory>> GetCreditHistoryAsync(Guid customerId)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/Customer/{customerId}/credit-history");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<CustomerCreditApprovalHistory>();
        var result = await response.Content.ReadFromJsonAsync<List<CustomerCreditApprovalHistory>>(_jsonOptions);
        return result ?? new List<CustomerCreditApprovalHistory>();
    }

    public async Task<List<Customer>> GetByModuleCodeAsync(string moduleCode, string? search = null)
    {
        var url = $"api/Customer/by-module/{moduleCode}";
        if (!string.IsNullOrEmpty(search))
        {
            url += $"?search={Uri.EscapeDataString(search)}";
        }
        var request = CreateAuthenticatedRequest(HttpMethod.Get, url);
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<Customer>();
        var result = await response.Content.ReadFromJsonAsync<List<Customer>>(_jsonOptions);
        return result ?? new List<Customer>();
    }

    public async Task<Guid> CreateAsync(Customer customer)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/Customer");
        var createRequest = new
        {
            CustomerCode = customer.CustomerCode,
            Name = customer.Name,
            ContactName = customer.ContactName,
            BranchId = customer.BranchId,
            Address = customer.Address,
            Country = customer.Country,
            State = customer.State,
            CountryId = customer.CountryId,
            StateId = customer.StateId,
            CityId = customer.CityId,
            PostalCodeId = customer.PostalCodeId,
            Email = customer.Email,
            Phone = customer.Phone,
            TaxIdNumber = customer.TaxIdNumber,
            DefaultCurrencyId = customer.DefaultCurrencyId,
            PreferredCurrencyId = customer.PreferredCurrencyId,
            DefaultARAccountId = customer.DefaultARAccountId,
            CustomerType = (int)customer.CustomerType,
            CustomerCategoryId = customer.CustomerCategoryId,
            CreditLimit = customer.CreditLimit,
            PaymentTermsDays = customer.PaymentTermsDays,
            IsActive = customer.IsActive
        };
        request.Content = JsonContent.Create(createRequest);
        var response = await _httpClient.SendAsync(request);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException(ParseErrorResponse(errorContent, response.StatusCode));
        }
        
        var created = await response.Content.ReadFromJsonAsync<Customer>(_jsonOptions);
        return created?.Id ?? Guid.Empty;
    }

    public async Task UpdateAsync(Guid id, Customer customer)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/Customer/{id}");
        var updateRequest = new
        {
            Id = id,
            CustomerCode = customer.CustomerCode,
            Name = customer.Name,
            ContactName = customer.ContactName,
            BranchId = customer.BranchId,
            Address = customer.Address,
            Country = customer.Country,
            State = customer.State,
            CountryId = customer.CountryId,
            StateId = customer.StateId,
            CityId = customer.CityId,
            PostalCodeId = customer.PostalCodeId,
            Email = customer.Email,
            Phone = customer.Phone,
            TaxIdNumber = customer.TaxIdNumber,
            DefaultCurrencyId = customer.DefaultCurrencyId,
            PreferredCurrencyId = customer.PreferredCurrencyId,
            DefaultARAccountId = customer.DefaultARAccountId,
            CustomerType = (int)customer.CustomerType,
            CustomerCategoryId = customer.CustomerCategoryId,
            CreditLimit = customer.CreditLimit,
            PaymentTermsDays = customer.PaymentTermsDays,
            IsActive = customer.IsActive
        };
        request.Content = JsonContent.Create(updateRequest);
        var response = await _httpClient.SendAsync(request);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException(ParseErrorResponse(errorContent, response.StatusCode));
        }
    }

    private static string ParseErrorResponse(string errorContent, System.Net.HttpStatusCode statusCode)
    {
        try
        {
            using var doc = JsonDocument.Parse(errorContent);
            var root = doc.RootElement;
            
            if (root.TryGetProperty("title", out var title))
            {
                var message = title.GetString() ?? "An error occurred";
                
                if (root.TryGetProperty("errors", out var errors))
                {
                    var errorMessages = new List<string>();
                    foreach (var error in errors.EnumerateObject())
                    {
                        if (error.Value.ValueKind == JsonValueKind.Array)
                        {
                            foreach (var msg in error.Value.EnumerateArray())
                            {
                                var errorMsg = msg.GetString();
                                if (!string.IsNullOrEmpty(errorMsg) && !errorMsg.Contains("JSON value could not be converted"))
                                {
                                    errorMessages.Add(errorMsg);
                                }
                            }
                        }
                    }
                    if (errorMessages.Count > 0)
                    {
                        return string.Join("; ", errorMessages);
                    }
                }
                return message;
            }
            
            if (root.TryGetProperty("message", out var msg2))
            {
                return msg2.GetString() ?? "An error occurred";
            }
        }
        catch
        {
            if (!string.IsNullOrEmpty(errorContent) && !errorContent.StartsWith("{"))
            {
                return errorContent;
            }
        }

        return statusCode switch
        {
            System.Net.HttpStatusCode.BadRequest => "Invalid data provided. Please check your input and try again.",
            System.Net.HttpStatusCode.NotFound => "The requested customer was not found.",
            System.Net.HttpStatusCode.Unauthorized => "You are not authorized to perform this action. Please log in again.",
            System.Net.HttpStatusCode.Forbidden => "You do not have permission to perform this action.",
            System.Net.HttpStatusCode.Conflict => "A customer with this code already exists.",
            System.Net.HttpStatusCode.InternalServerError => "A server error occurred. Please try again later.",
            _ => "An unexpected error occurred. Please try again."
        };
    }

    public async Task DeleteAsync(Guid id, string? reason = null)
    {
        var url = $"api/Customer/{id}";
        if (!string.IsNullOrEmpty(reason))
        {
            url += $"?reason={Uri.EscapeDataString(reason)}";
        }
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, url);
        var response = await _httpClient.SendAsync(request);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }

    public async Task RequestCreditAsync(Guid customerId, decimal requestedLimit, string notes)
    {
        var requestMessage = CreateAuthenticatedRequest(HttpMethod.Post, $"api/Customer/{customerId}/request-credit");
        var requestData = new { RequestedCreditLimit = requestedLimit, RequestNotes = notes };
        requestMessage.Content = JsonContent.Create(requestData, options: _jsonOptions);
        var response = await _httpClient.SendAsync(requestMessage);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }

    public async Task ApproveCreditAsync(Guid customerId, decimal approvedLimit, string notes)
    {
        var requestMessage = CreateAuthenticatedRequest(HttpMethod.Post, $"api/Customer/{customerId}/approve-credit");
        var requestData = new { ApprovedCreditLimit = approvedLimit, ApprovalNotes = notes };
        requestMessage.Content = JsonContent.Create(requestData, options: _jsonOptions);
        var response = await _httpClient.SendAsync(requestMessage);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }

    public async Task RejectCreditAsync(Guid customerId, string notes)
    {
        var requestMessage = CreateAuthenticatedRequest(HttpMethod.Post, $"api/Customer/{customerId}/reject-credit");
        var requestData = new { RejectionNotes = notes };
        requestMessage.Content = JsonContent.Create(requestData, options: _jsonOptions);
        var response = await _httpClient.SendAsync(requestMessage);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }

    public async Task<bool> ExportPdfAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Customer/export-pdf");
        var response = await _httpClient.SendAsync(request);
        
        if (response.IsSuccessStatusCode)
        {
            var content = await response.Content.ReadAsByteArrayAsync();
            var fileName = GetFileNameFromResponse(response) ?? $"Customers_{DateTime.Now:yyyyMMdd}.pdf";
            await DownloadFile(content, fileName, "application/pdf");
            return true;
        }
        
        return false;
    }

    public async Task<bool> ExportExcelAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/Customer/export-excel");
        var response = await _httpClient.SendAsync(request);
        
        if (response.IsSuccessStatusCode)
        {
            var content = await response.Content.ReadAsByteArrayAsync();
            var fileName = GetFileNameFromResponse(response) ?? $"Customers_{DateTime.Now:yyyyMMdd}.xlsx";
            await DownloadFile(content, fileName, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            return true;
        }
        
        return false;
    }

    private string? GetFileNameFromResponse(HttpResponseMessage response)
    {
        if (response.Content.Headers.ContentDisposition != null)
        {
            return response.Content.Headers.ContentDisposition.FileName?.Trim('"');
        }
        return null;
    }

    private async Task DownloadFile(byte[] content, string fileName, string mimeType)
    {
        var base64 = Convert.ToBase64String(content);
        var dataUrl = $"data:{mimeType};base64,{base64}";
        await _jsRuntime.InvokeVoidAsync("downloadFile", fileName, dataUrl);
    }
}
