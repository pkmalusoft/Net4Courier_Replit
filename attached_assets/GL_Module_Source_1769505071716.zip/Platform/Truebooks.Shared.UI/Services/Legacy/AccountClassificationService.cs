using System.Net.Http.Json;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IAccountClassificationService
{
    Task<List<AccountClassification>> GetAllAsync();
    Task<List<AccountClassification>> GetActiveAsync();
}

public class AccountClassificationService : IAccountClassificationService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;

    public AccountClassificationService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    public async Task<List<AccountClassification>> GetAllAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<AccountClassification>>("api/AccountClassifications") ?? new();
        }
        catch { return new(); }
    }

    public async Task<List<AccountClassification>> GetActiveAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<AccountClassification>>("api/AccountClassifications/active") ?? new();
        }
        catch { return new(); }
    }
}
