using System.Net.Http.Json;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface ICourierDashboardService
{
    Task<CourierDashboardData?> GetDashboardAsync(DateTime fromDate, DateTime toDate);
}

public class CourierDashboardService : ICourierDashboardService
{
    private readonly HttpClient _httpClient;

    public CourierDashboardService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<CourierDashboardData?> GetDashboardAsync(DateTime fromDate, DateTime toDate)
    {
        try
        {
            var response = await _httpClient.GetFromJsonAsync<CourierDashboardData>(
                $"api/courier/dashboard?fromDate={fromDate:yyyy-MM-dd}&toDate={toDate:yyyy-MM-dd}");
            return response;
        }
        catch
        {
            return new CourierDashboardData();
        }
    }
}
