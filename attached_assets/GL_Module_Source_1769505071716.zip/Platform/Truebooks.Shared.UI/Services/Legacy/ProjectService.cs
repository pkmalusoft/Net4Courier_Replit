using System.Net.Http.Json;


using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IProjectService
{
    Task<List<Project>> GetAllAsync();
    Task<List<Project>> GetActiveAsync();
    Task<Project?> GetByIdAsync(Guid id);
    Task<Guid> CreateAsync(Project project);
    Task UpdateAsync(Guid id, Project project);
    Task DeleteAsync(Guid id);
}

public class ProjectService : IProjectService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;

    public ProjectService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private void SetAuthHeader()
    {
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            _httpClient.DefaultRequestHeaders.Remove("X-Tenant-Id");
            _httpClient.DefaultRequestHeaders.Add("X-Tenant-Id", tenantId);
        }
    }

    public async Task<List<Project>> GetAllAsync()
    {
        SetAuthHeader();
        var result = await _httpClient.GetFromJsonAsync<List<Project>>("api/Project");
        return result ?? new List<Project>();
    }

    public async Task<List<Project>> GetActiveAsync()
    {
        SetAuthHeader();
        var result = await _httpClient.GetFromJsonAsync<List<Project>>("api/Project/active");
        return result ?? new List<Project>();
    }

    public async Task<Project?> GetByIdAsync(Guid id)
    {
        SetAuthHeader();
        var result = await _httpClient.GetFromJsonAsync<Project>($"api/Project/{id}");
        return result;
    }

    public async Task<Guid> CreateAsync(Project project)
    {
        SetAuthHeader();
        var response = await _httpClient.PostAsJsonAsync("api/Project", project);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
        
        var created = await response.Content.ReadFromJsonAsync<Project>();
        return created?.Id ?? Guid.Empty;
    }

    public async Task UpdateAsync(Guid id, Project project)
    {
        SetAuthHeader();
        var response = await _httpClient.PutAsJsonAsync($"api/Project/{id}", project);
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }

    public async Task DeleteAsync(Guid id)
    {
        SetAuthHeader();
        var response = await _httpClient.DeleteAsync($"api/Project/{id}");
        
        if (!response.IsSuccessStatusCode)
        {
            var errorContent = await response.Content.ReadAsStringAsync();
            throw new HttpRequestException($"{response.StatusCode}: {errorContent}");
        }
    }
}
