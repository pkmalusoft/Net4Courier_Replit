using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IItemPriceScheduleService
{
    Task<List<ItemPriceSchedule>> GetAllAsync(bool? isActive = null, bool? includeInactive = null, Guid? itemId = null);
    Task<ItemPriceSchedule?> GetByIdAsync(Guid id);
    Task<ItemPriceSchedule?> CreateAsync(CreateItemPriceScheduleDto dto);
    Task<ItemPriceSchedule?> UpdateAsync(UpdateItemPriceScheduleDto dto);
    Task<ItemPriceSchedule?> UpdateAsync(Guid id, UpdateItemPriceScheduleDto dto);
    Task<ItemPriceSchedule?> UpdateAsync(Guid id, CreateItemPriceScheduleDto dto);
    Task<bool> DeleteAsync(Guid id);
    Task<List<ItemPriceScheduleDetail>> GetScheduleDetailsAsync(Guid scheduleId);
}

public class ItemPriceScheduleService : IItemPriceScheduleService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public ItemPriceScheduleService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<ItemPriceSchedule>> GetAllAsync(bool? isActive = null, bool? includeInactive = null, Guid? itemId = null)
    {
        var queryParams = new List<string>();
        if (isActive.HasValue) queryParams.Add($"isActive={isActive.Value}");
        if (includeInactive.HasValue) queryParams.Add($"includeInactive={includeInactive.Value}");
        if (itemId.HasValue) queryParams.Add($"itemId={itemId.Value}");
        var query = queryParams.Count > 0 ? "?" + string.Join("&", queryParams) : "";
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/ItemPriceSchedule{query}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<ItemPriceSchedule>();
        return await response.Content.ReadFromJsonAsync<List<ItemPriceSchedule>>(_jsonOptions) ?? new();
    }

    public async Task<ItemPriceSchedule?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/ItemPriceSchedule/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ItemPriceSchedule>(_jsonOptions);
    }

    public async Task<ItemPriceSchedule?> CreateAsync(CreateItemPriceScheduleDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/ItemPriceSchedule");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ItemPriceSchedule>(_jsonOptions);
    }

    public async Task<ItemPriceSchedule?> UpdateAsync(UpdateItemPriceScheduleDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/ItemPriceSchedule/{dto.Id}");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ItemPriceSchedule>(_jsonOptions);
    }

    public async Task<ItemPriceSchedule?> UpdateAsync(Guid id, UpdateItemPriceScheduleDto dto)
    {
        dto.Id = id;
        return await UpdateAsync(dto);
    }

    public async Task<ItemPriceSchedule?> UpdateAsync(Guid id, CreateItemPriceScheduleDto dto)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/ItemPriceSchedule/{id}");
        request.Content = new StringContent(JsonSerializer.Serialize(dto, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<ItemPriceSchedule>(_jsonOptions);
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, $"api/ItemPriceSchedule/{id}");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<List<ItemPriceScheduleDetail>> GetScheduleDetailsAsync(Guid scheduleId)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/ItemPriceSchedule/{scheduleId}/details");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<ItemPriceScheduleDetail>();
        return await response.Content.ReadFromJsonAsync<List<ItemPriceScheduleDetail>>(_jsonOptions) ?? new();
    }
}
