using System.Net.Http.Json;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Serialization;


using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IDepartmentService
{
    Task<List<DepartmentDto>> GetAllAsync(bool includeInactive = false, Guid? branchId = null);
    Task<List<DepartmentDto>> GetActiveAsync(Guid? branchId = null);
    Task<DepartmentDto?> GetByIdAsync(Guid id);
    Task<List<DepartmentDto>> GetHierarchyAsync(Guid? branchId = null);
    Task<List<DepartmentDto>> GetUserAccessibleDepartmentsAsync();
}

public class DepartmentService : IDepartmentService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public DepartmentService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<DepartmentDto>> GetAllAsync(bool includeInactive = false, Guid? branchId = null)
    {
        var url = $"api/department?includeInactive={includeInactive}";
        if (branchId.HasValue)
        {
            url += $"&branchId={branchId.Value}";
        }
        var request = CreateAuthenticatedRequest(HttpMethod.Get, url);
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<DepartmentDto>();
        var result = await response.Content.ReadFromJsonAsync<List<DepartmentDto>>(_jsonOptions);
        return result ?? new List<DepartmentDto>();
    }

    public async Task<List<DepartmentDto>> GetActiveAsync(Guid? branchId = null)
    {
        return await GetAllAsync(false, branchId);
    }

    public async Task<DepartmentDto?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/department/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<DepartmentDto>(_jsonOptions);
    }

    public async Task<List<DepartmentDto>> GetHierarchyAsync(Guid? branchId = null)
    {
        var url = "api/department/hierarchy";
        if (branchId.HasValue)
        {
            url += $"?branchId={branchId.Value}";
        }
        var request = CreateAuthenticatedRequest(HttpMethod.Get, url);
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<DepartmentDto>();
        var result = await response.Content.ReadFromJsonAsync<List<DepartmentDto>>(_jsonOptions);
        return result ?? new List<DepartmentDto>();
    }

    public async Task<List<DepartmentDto>> GetUserAccessibleDepartmentsAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/userdepartment/my-departments");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode)
        {
            return await GetActiveAsync();
        }
        var result = await response.Content.ReadFromJsonAsync<List<DepartmentDto>>(_jsonOptions);
        return result ?? new List<DepartmentDto>();
    }
}
