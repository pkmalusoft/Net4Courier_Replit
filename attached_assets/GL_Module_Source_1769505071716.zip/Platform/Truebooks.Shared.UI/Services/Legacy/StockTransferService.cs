using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public class StockTransferService : IStockTransferService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public StockTransferService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<StockTransfer>> GetAllAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/StockTransfer");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<StockTransfer>();
        return await response.Content.ReadFromJsonAsync<List<StockTransfer>>(_jsonOptions) ?? new();
    }

    public async Task<StockTransfer?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/StockTransfer/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<StockTransfer>(_jsonOptions);
    }

    public async Task<Guid> CreateAsync(StockTransfer transfer)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, "api/StockTransfer");
        request.Content = new StringContent(JsonSerializer.Serialize(transfer, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return Guid.Empty;
        var result = await response.Content.ReadFromJsonAsync<StockTransfer>(_jsonOptions);
        return result?.Id ?? Guid.Empty;
    }

    public async Task<bool> UpdateAsync(Guid id, StockTransfer transfer)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Put, $"api/StockTransfer/{id}");
        request.Content = new StringContent(JsonSerializer.Serialize(transfer, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> DeleteAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Delete, $"api/StockTransfer/{id}");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<string> GetNextTransferNumberAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/StockTransfer/next-number");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return $"TRF-{DateTime.Now:yyyyMMdd}-001";
        return await response.Content.ReadAsStringAsync() ?? $"TRF-{DateTime.Now:yyyyMMdd}-001";
    }

    public async Task<bool> ApproveAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, $"api/StockTransfer/{id}/approve");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> DispatchAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, $"api/StockTransfer/{id}/dispatch");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> ReceiveAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, $"api/StockTransfer/{id}/receive");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> CompleteAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, $"api/StockTransfer/{id}/complete");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<bool> CancelAsync(Guid id, string reason)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Post, $"api/StockTransfer/{id}/cancel");
        request.Content = new StringContent(JsonSerializer.Serialize(new { reason }, _jsonOptions), Encoding.UTF8, "application/json");
        var response = await _httpClient.SendAsync(request);
        return response.IsSuccessStatusCode;
    }

    public async Task<List<StockTransfer>> GetByStatusAsync(TransferStatus status)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/StockTransfer?status={status}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<StockTransfer>();
        return await response.Content.ReadFromJsonAsync<List<StockTransfer>>(_jsonOptions) ?? new();
    }
}
