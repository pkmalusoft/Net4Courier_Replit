using System.Net.Http.Json;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Serialization;


using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Legacy.Enums;

namespace Truebooks.Shared.UI.Services.Legacy;

public interface IBranchService
{
    Task<List<BranchDto>> GetAllAsync(bool includeInactive = false);
    Task<List<BranchDto>> GetActiveAsync();
    Task<BranchDto?> GetByIdAsync(Guid id);
    Task<BranchDto?> GetHeadOfficeAsync();
    Task<List<BranchDto>> GetUserAccessibleBranchesAsync();
}

public class BranchService : IBranchService
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public BranchService(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private HttpRequestMessage CreateAuthenticatedRequest(HttpMethod method, string requestUri)
    {
        var request = new HttpRequestMessage(method, requestUri);
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
        return request;
    }

    public async Task<List<BranchDto>> GetAllAsync(bool includeInactive = false)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/branch?includeInactive={includeInactive}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return new List<BranchDto>();
        var result = await response.Content.ReadFromJsonAsync<List<BranchDto>>(_jsonOptions);
        return result ?? new List<BranchDto>();
    }

    public async Task<List<BranchDto>> GetActiveAsync()
    {
        return await GetAllAsync(false);
    }

    public async Task<BranchDto?> GetByIdAsync(Guid id)
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, $"api/branch/{id}");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<BranchDto>(_jsonOptions);
    }

    public async Task<BranchDto?> GetHeadOfficeAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/branch/head-office");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return null;
        return await response.Content.ReadFromJsonAsync<BranchDto>(_jsonOptions);
    }

    public async Task<List<BranchDto>> GetUserAccessibleBranchesAsync()
    {
        var request = CreateAuthenticatedRequest(HttpMethod.Get, "api/userbranch/my-branches");
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode)
        {
            return await GetActiveAsync();
        }
        var result = await response.Content.ReadFromJsonAsync<List<BranchDto>>(_jsonOptions);
        return result ?? new List<BranchDto>();
    }
}
