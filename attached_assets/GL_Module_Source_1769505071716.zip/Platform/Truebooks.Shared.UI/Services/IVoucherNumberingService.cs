using System.Net.Http.Json;
using Truebooks.Platform.Contracts.Enums;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services;

public interface IVoucherNumberingService
{
    Task<List<VoucherNumbering>> GetAllAsync();
    Task<VoucherNumbering?> GetByIdAsync(Guid id);
    Task<VoucherNumbering?> GetByTransactionTypeAsync(VoucherTransactionType transactionType);
    Task<Guid> CreateAsync(VoucherNumbering voucherNumbering);
    Task UpdateAsync(VoucherNumbering voucherNumbering);
    Task DeleteAsync(Guid id);
    Task<string> GetNextVoucherNumberAsync(VoucherTransactionType transactionType);
    Task<bool> CanEditAsync(Guid id);
    Task<string> PreviewNextVoucherAsync(Guid id);
}
