using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services;

public interface IPurchaseBillService
{
    Task<List<PurchaseBillDto>> GetAllAsync();
    Task<PurchaseBillDto?> GetByIdAsync(Guid id);
    Task<Guid> CreateAsync(PurchaseBillDto bill);
    Task UpdateAsync(Guid id, PurchaseBillDto bill);
    Task DeleteAsync(Guid id);
    Task<string> GetNextBillNumberAsync();
    Task PostAsync(Guid id);
    Task VoidAsync(Guid id, string reason);
}
