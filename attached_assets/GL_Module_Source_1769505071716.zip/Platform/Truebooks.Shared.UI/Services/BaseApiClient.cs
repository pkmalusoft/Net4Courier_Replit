using System.Net.Http.Json;

namespace Truebooks.Shared.UI.Services;

public abstract class BaseApiClient
{
    protected readonly HttpClient Http;
    
    protected BaseApiClient(HttpClient http)
    {
        Http = http;
    }
    
    protected async Task<T?> GetAsync<T>(string url)
    {
        try
        {
            return await Http.GetFromJsonAsync<T>(url);
        }
        catch (HttpRequestException)
        {
            return default;
        }
    }
    
    protected async Task<TResponse?> PostAsync<TRequest, TResponse>(string url, TRequest data)
    {
        try
        {
            var response = await Http.PostAsJsonAsync(url, data);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<TResponse>();
        }
        catch (HttpRequestException)
        {
            return default;
        }
    }
    
    protected async Task<bool> PostAsync<TRequest>(string url, TRequest data)
    {
        try
        {
            var response = await Http.PostAsJsonAsync(url, data);
            return response.IsSuccessStatusCode;
        }
        catch (HttpRequestException)
        {
            return false;
        }
    }
    
    protected async Task<bool> PutAsync<TRequest>(string url, TRequest data)
    {
        try
        {
            var response = await Http.PutAsJsonAsync(url, data);
            return response.IsSuccessStatusCode;
        }
        catch (HttpRequestException)
        {
            return false;
        }
    }
    
    protected async Task<bool> DeleteAsync(string url)
    {
        try
        {
            var response = await Http.DeleteAsync(url);
            return response.IsSuccessStatusCode;
        }
        catch (HttpRequestException)
        {
            return false;
        }
    }
}
