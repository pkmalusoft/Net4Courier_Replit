using System.Net.Http.Json;
using System.Collections.Concurrent;

namespace Truebooks.Shared.UI.Services;

public class ModuleAccessService : IModuleAccessService
{
    private readonly HttpClient _httpClient;
    private readonly ConcurrentDictionary<string, (ModuleAccessInfo info, DateTime expiry)> _cache = new();
    private static readonly TimeSpan CacheDuration = TimeSpan.FromMinutes(5);

    public ModuleAccessService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<ModuleAccessInfo> GetModuleAccessAsync(string moduleCode)
    {
        var cacheKey = moduleCode;
        
        if (_cache.TryGetValue(cacheKey, out var cached) && cached.expiry > DateTime.UtcNow)
        {
            return cached.info;
        }
        
        try
        {
            var response = await _httpClient.GetAsync($"/api/ModuleConfiguration/{moduleCode}/access");
            if (response.IsSuccessStatusCode)
            {
                var accessInfo = await response.Content.ReadFromJsonAsync<ModuleAccessInfo>();
                if (accessInfo != null)
                {
                    _cache[cacheKey] = (accessInfo, DateTime.UtcNow.Add(CacheDuration));
                    return accessInfo;
                }
            }
        }
        catch
        {
        }
        
        var defaultAccess = GetDefaultReadOnlyAccess(moduleCode);
        _cache[cacheKey] = (defaultAccess, DateTime.UtcNow.Add(CacheDuration));
        return defaultAccess;
    }

    public async Task<bool> IsModuleReadOnlyAsync(string moduleCode)
    {
        var accessInfo = await GetModuleAccessAsync(moduleCode);
        return accessInfo.IsReadOnly;
    }

    public async Task<bool> IsModuleEnabledAsync(string moduleCode)
    {
        var accessInfo = await GetModuleAccessAsync(moduleCode);
        return accessInfo.IsEnabled;
    }

    public void InvalidateCache()
    {
        _cache.Clear();
    }

    private static ModuleAccessInfo GetDefaultReadOnlyAccess(string moduleCode)
    {
        return new ModuleAccessInfo
        {
            ModuleCode = moduleCode,
            AccessLevel = "read-only",
            IsReadOnly = true,
            IsEnabled = false,
            IsCoreModule = false
        };
    }
}
