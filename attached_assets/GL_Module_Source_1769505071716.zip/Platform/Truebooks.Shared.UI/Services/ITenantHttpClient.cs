using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Truebooks.Shared.UI.Services.Legacy;

namespace Truebooks.Shared.UI.Services;

public interface ITenantHttpClient
{
    Task<T?> GetFromJsonAsync<T>(string requestUri);
    Task<HttpResponseMessage> GetAsync(string requestUri);
    Task<HttpResponseMessage> PostAsJsonAsync<T>(string requestUri, T value);
    Task<HttpResponseMessage> PutAsJsonAsync<T>(string requestUri, T value);
    Task<HttpResponseMessage> DeleteAsync(string requestUri);
    Task<HttpResponseMessage> PostAsync(string requestUri, HttpContent? content);
    Task<HttpResponseMessage> PutAsync(string requestUri, HttpContent? content);
}

public class TenantHttpClient : ITenantHttpClient
{
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public TenantHttpClient(HttpClient httpClient, IAuthService authService)
    {
        _httpClient = httpClient;
        _authService = authService;
    }

    private void SetAuthHeaders(HttpRequestMessage request)
    {
        var token = _authService.GetAccessToken();
        if (!string.IsNullOrEmpty(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }
        var tenantId = _authService.GetTenantId();
        if (!string.IsNullOrEmpty(tenantId))
        {
            request.Headers.Add("X-Tenant-Id", tenantId);
        }
    }

    public async Task<T?> GetFromJsonAsync<T>(string requestUri)
    {
        var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
        SetAuthHeaders(request);
        var response = await _httpClient.SendAsync(request);
        if (!response.IsSuccessStatusCode) return default;
        return await response.Content.ReadFromJsonAsync<T>(_jsonOptions);
    }

    public async Task<HttpResponseMessage> GetAsync(string requestUri)
    {
        var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
        SetAuthHeaders(request);
        return await _httpClient.SendAsync(request);
    }

    public async Task<HttpResponseMessage> PostAsJsonAsync<T>(string requestUri, T value)
    {
        var request = new HttpRequestMessage(HttpMethod.Post, requestUri);
        SetAuthHeaders(request);
        request.Content = new StringContent(JsonSerializer.Serialize(value, _jsonOptions), Encoding.UTF8, "application/json");
        return await _httpClient.SendAsync(request);
    }

    public async Task<HttpResponseMessage> PutAsJsonAsync<T>(string requestUri, T value)
    {
        var request = new HttpRequestMessage(HttpMethod.Put, requestUri);
        SetAuthHeaders(request);
        request.Content = new StringContent(JsonSerializer.Serialize(value, _jsonOptions), Encoding.UTF8, "application/json");
        return await _httpClient.SendAsync(request);
    }

    public async Task<HttpResponseMessage> DeleteAsync(string requestUri)
    {
        var request = new HttpRequestMessage(HttpMethod.Delete, requestUri);
        SetAuthHeaders(request);
        return await _httpClient.SendAsync(request);
    }

    public async Task<HttpResponseMessage> PostAsync(string requestUri, HttpContent? content)
    {
        var request = new HttpRequestMessage(HttpMethod.Post, requestUri);
        SetAuthHeaders(request);
        request.Content = content;
        return await _httpClient.SendAsync(request);
    }

    public async Task<HttpResponseMessage> PutAsync(string requestUri, HttpContent? content)
    {
        var request = new HttpRequestMessage(HttpMethod.Put, requestUri);
        SetAuthHeaders(request);
        request.Content = content;
        return await _httpClient.SendAsync(request);
    }
}
