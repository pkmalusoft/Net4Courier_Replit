using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services;

public interface ISalesInvoiceService
{
    Task<List<SalesInvoiceDto>> GetAllAsync();
    Task<SalesInvoiceDto?> GetByIdAsync(Guid id);
    Task<Guid> CreateAsync(SalesInvoiceDto invoice);
    Task UpdateAsync(Guid id, SalesInvoiceDto invoice);
    Task DeleteAsync(Guid id);
    Task<string> GetNextInvoiceNumberAsync();
    Task PostAsync(Guid id);
    Task VoidAsync(Guid id, string reason);
}
