using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Shared.UI.Services;

public interface IStockTransferService
{
    Task<List<StockTransfer>> GetAllAsync();
    Task<StockTransfer?> GetByIdAsync(Guid id);
    Task<Guid> CreateAsync(StockTransfer transfer);
    Task<bool> UpdateAsync(Guid id, StockTransfer transfer);
    Task<bool> DeleteAsync(Guid id);
    Task<string> GetNextTransferNumberAsync();
    Task<bool> ApproveAsync(Guid id);
    Task<bool> DispatchAsync(Guid id);
    Task<bool> ReceiveAsync(Guid id);
    Task<bool> CompleteAsync(Guid id);
    Task<bool> CancelAsync(Guid id, string reason);
    Task<List<StockTransfer>> GetByStatusAsync(TransferStatus status);
}
