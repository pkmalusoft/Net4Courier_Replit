using System.Net.Http.Json;
using Markdig;

namespace Truebooks.Shared.UI.Services;

public interface IKnowledgeBaseService
{
    Task<string> GetMarkdownContentAsync();
    Task<string> GetMarkdownContentAsync(string moduleCode);
    string ConvertToHtml(string markdown);
}

public class KnowledgeBaseArticle
{
    public Guid Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}

public class KnowledgeBaseService : IKnowledgeBaseService
{
    public KnowledgeBaseService() { }

    public async Task<string> GetMarkdownContentAsync()
    {
        return await GetMarkdownContentAsync("platform");
    }

    public async Task<string> GetMarkdownContentAsync(string moduleCode)
    {
        var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wwwroot", "docs", $"{moduleCode}-knowledge-base.md");
        if (File.Exists(path))
        {
            return await File.ReadAllTextAsync(path);
        }
        
        var defaultPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wwwroot", "docs", "knowledge-base.md");
        if (File.Exists(defaultPath))
        {
            return await File.ReadAllTextAsync(defaultPath);
        }
        
        throw new FileNotFoundException("Knowledge base documentation file not found.");
    }

    public string ConvertToHtml(string markdown)
    {
        if (string.IsNullOrWhiteSpace(markdown))
            return string.Empty;
            
        var pipeline = new MarkdownPipelineBuilder()
            .UseAutoLinks()
            .UseEmphasisExtras()
            .UseListExtras()
            .UsePipeTables()
            .UseGenericAttributes()
            .Build();
        return Markdown.ToHtml(markdown, pipeline);
    }
}
