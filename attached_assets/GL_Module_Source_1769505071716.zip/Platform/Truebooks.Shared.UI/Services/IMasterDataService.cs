using System.Net.Http.Json;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Shared.UI.Services;

// IMasterDataService, IBranchService, IDepartmentService moved to Legacy namespace

// ITransactionService moved to Truebooks.Shared.UI.Services.Legacy

public interface IWorkingPeriodStateProvider
{
    WorkingPeriodInfo? CurrentPeriod { get; }
    event Action? OnPeriodChanged;
    Task InitializeAsync();
    Task SetPeriodAsync(WorkingPeriodInfo period);
    Task<List<WorkingPeriodInfo>> GetSelectablePeriodsAsync();
    bool IsDateInWorkingPeriod(DateTime date);
    DateTime GetDefaultTransactionDate();
    DateTime? GetPeriodMinDate();
    DateTime? GetPeriodMaxDate();
}

public class WorkingPeriodInfo
{
    public Guid? PeriodId { get; set; }
    public string PeriodName { get; set; } = string.Empty;
    public int FiscalYear { get; set; }
    public int PeriodNumber { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Status { get; set; } = string.Empty;
    public bool IsYearEnd { get; set; }
}

public class ItemSearchResultDto
{
    public Guid Id { get; set; }
    public string ItemCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Barcode { get; set; }
    public string? HSNCode { get; set; }
    public decimal? DefaultSellingPrice { get; set; }
    public Guid? DefaultTaxCodeId { get; set; }
    public bool TrackInventory { get; set; }
    public decimal StockQuantity { get; set; }
    public int ItemType { get; set; }
    public string DisplayName => $"{ItemCode} - {Name}";
}

// BranchDto and DepartmentDto moved to Platform.Contracts.Legacy.DTOs

public class CurrencyDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Symbol { get; set; } = string.Empty;
    public decimal ExchangeRate { get; set; } = 1;
}

public class TaxCodeDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public decimal Rate { get; set; }
}

public class AccountDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string AccountType { get; set; } = string.Empty;
    public bool IsActive { get; set; }
}

public class CustomerDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string CustomerCode { get => Code; set => Code = value; }
    public string Name { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public bool IsActive { get; set; }
}

public class SupplierDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public bool IsActive { get; set; }
}

// MasterDataService, BranchService, DepartmentService, TransactionService implementations moved to Legacy namespace

public class WorkingPeriodStateProvider : IWorkingPeriodStateProvider
{
    private readonly HttpClient _http;
    private WorkingPeriodInfo? _currentPeriod;

    public WorkingPeriodInfo? CurrentPeriod => _currentPeriod;
    public event Action? OnPeriodChanged;

    public WorkingPeriodStateProvider(HttpClient http)
    {
        _http = http;
    }

    public async Task InitializeAsync()
    {
        var periods = await GetSelectablePeriodsAsync();
        if (periods.Any())
        {
            var today = DateTime.UtcNow.Date;
            _currentPeriod = periods.FirstOrDefault(p => p.StartDate <= today && p.EndDate >= today && p.Status == "Open")
                ?? periods.FirstOrDefault(p => p.Status == "Open")
                ?? periods.FirstOrDefault();
            OnPeriodChanged?.Invoke();
        }
    }

    public Task SetPeriodAsync(WorkingPeriodInfo period)
    {
        _currentPeriod = period;
        OnPeriodChanged?.Invoke();
        return Task.CompletedTask;
    }

    public async Task<List<WorkingPeriodInfo>> GetSelectablePeriodsAsync()
    {
        try
        {
            return await _http.GetFromJsonAsync<List<WorkingPeriodInfo>>("api/financial-periods/selectable") ?? new();
        }
        catch { return new(); }
    }

    public bool IsDateInWorkingPeriod(DateTime date)
    {
        return _currentPeriod != null && date >= _currentPeriod.StartDate && date <= _currentPeriod.EndDate;
    }

    public DateTime GetDefaultTransactionDate()
    {
        var today = DateTime.UtcNow.Date;
        if (_currentPeriod == null) return today;
        if (today >= _currentPeriod.StartDate && today <= _currentPeriod.EndDate) return today;
        return _currentPeriod.EndDate;
    }

    public DateTime? GetPeriodMinDate() => _currentPeriod?.StartDate;
    public DateTime? GetPeriodMaxDate() => _currentPeriod?.EndDate;
}

public class FinancialPeriodDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public bool IsClosed { get; set; }
}
