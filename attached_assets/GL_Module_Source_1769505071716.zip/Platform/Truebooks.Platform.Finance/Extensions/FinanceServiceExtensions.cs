using Microsoft.Extensions.DependencyInjection;
using Truebooks.Platform.Contracts.Services;
using Truebooks.Platform.Finance.Services;

namespace Truebooks.Platform.Finance.Extensions;

public static class FinanceServiceExtensions
{
    public static IServiceCollection AddPlatformFinance(this IServiceCollection services)
    {
        services.AddScoped<IGLPostingService, GLPostingService>();

        return services;
    }
}
