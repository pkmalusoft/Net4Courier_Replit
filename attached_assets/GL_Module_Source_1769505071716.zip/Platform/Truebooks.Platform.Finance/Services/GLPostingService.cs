using Microsoft.Extensions.Logging;
using Truebooks.Platform.Contracts.Services;

namespace Truebooks.Platform.Finance.Services;

public class GLPostingService : IGLPostingService
{
    private readonly ILogger<GLPostingService> _logger;

    public GLPostingService(ILogger<GLPostingService> logger)
    {
        _logger = logger;
    }

    public async Task<JournalEntryResult> PostJournalEntryAsync(JournalEntryRequest request, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Posting journal entry for tenant {TenantId}, reference: {Reference}", 
            request.TenantId, request.Reference);

        var voucherNumber = GenerateVoucherNumber(request.TransactionDate);
        var journalEntryId = Guid.NewGuid();

        _logger.LogInformation("Journal entry posted: {VoucherNumber}", voucherNumber);

        return await Task.FromResult(new JournalEntryResult(
            Success: true,
            VoucherNumber: voucherNumber,
            JournalEntryId: journalEntryId,
            ErrorMessage: null
        ));
    }

    public async Task<VoucherResult> CreateVoucherAsync(VoucherRequest request, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Creating voucher for tenant {TenantId}, type: {VoucherType}", 
            request.TenantId, request.VoucherType);

        var voucherNumber = GenerateVoucherNumber(request.TransactionDate);
        var voucherId = Guid.NewGuid();

        _logger.LogInformation("Voucher created: {VoucherNumber}", voucherNumber);

        return await Task.FromResult(new VoucherResult(
            Success: true,
            VoucherNumber: voucherNumber,
            VoucherId: voucherId,
            ErrorMessage: null
        ));
    }

    private static string GenerateVoucherNumber(DateTime transactionDate)
    {
        return $"JV-{transactionDate:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..8].ToUpper()}";
    }
}
