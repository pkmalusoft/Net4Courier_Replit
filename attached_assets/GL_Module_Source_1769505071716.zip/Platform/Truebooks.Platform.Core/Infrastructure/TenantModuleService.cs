using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Truebooks.Platform.Contracts.Enums;
using Truebooks.Platform.Contracts.Services;

namespace Truebooks.Platform.Core.Infrastructure;

public class TenantModuleService : ITenantModuleService
{
    private readonly IMemoryCache _cache;
    private readonly ILogger<TenantModuleService> _logger;
    private readonly IDbContextFactory<PlatformDbContext> _contextFactory;
    private static readonly TimeSpan CacheDuration = TimeSpan.FromMinutes(5);

    public TenantModuleService(
        IMemoryCache cache,
        ILogger<TenantModuleService> logger,
        IDbContextFactory<PlatformDbContext> contextFactory)
    {
        _cache = cache;
        _logger = logger;
        _contextFactory = contextFactory;
    }

    public async Task<bool> IsModuleEnabledAsync(Guid tenantId, string moduleCode, CancellationToken cancellationToken = default)
    {
        var accessLevel = await GetModuleAccessLevelAsync(tenantId, moduleCode, cancellationToken);
        return accessLevel == ModuleAccessLevel.Full;
    }

    public async Task<ModuleAccessLevel> GetModuleAccessLevelAsync(Guid tenantId, string moduleCode, CancellationToken cancellationToken = default)
    {
        if (ModuleDefinitions.IsCoreModule(moduleCode))
        {
            return ModuleAccessLevel.Full;
        }

        var cacheKey = $"tenant:{tenantId}:module:{moduleCode}:access";

        var result = await _cache.GetOrCreateAsync(cacheKey, async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = CacheDuration;

            await using var context = await _contextFactory.CreateDbContextAsync(cancellationToken);
            
            var moduleCatalog = await context.ModuleCatalogs
                .FirstOrDefaultAsync(m => m.ModuleCode == moduleCode && m.IsActive, cancellationToken);
            
            if (moduleCatalog == null)
            {
                var module = await context.Modules.FirstOrDefaultAsync(m => m.Code == moduleCode && (m.IsAllModules || m.TenantId == tenantId), cancellationToken);
                if (module == null) return ModuleAccessLevel.ReadOnly;
                
                var tenantModule = await context.TenantModules
                    .FirstOrDefaultAsync(m => m.TenantId == tenantId && m.ModuleId == module.Id, cancellationToken);
                
                return GetAccessLevelFromStatus(tenantModule?.Status);
            }
            
            var tenantModuleFromCatalog = await context.TenantModules
                .FirstOrDefaultAsync(m => m.TenantId == tenantId && m.ModuleId == moduleCatalog.Id, cancellationToken);
            
            return GetAccessLevelFromStatus(tenantModuleFromCatalog?.Status);
        });
        
        return result;
    }

    private static ModuleAccessLevel GetAccessLevelFromStatus(TenantModuleStatus? status)
    {
        return status switch
        {
            TenantModuleStatus.Enabled => ModuleAccessLevel.Full,
            TenantModuleStatus.ReadOnly => ModuleAccessLevel.ReadOnly,
            TenantModuleStatus.Disabled => ModuleAccessLevel.ReadOnly,
            TenantModuleStatus.Expired => ModuleAccessLevel.ReadOnly,
            TenantModuleStatus.Suspended => ModuleAccessLevel.None,
            null => ModuleAccessLevel.ReadOnly,
            _ => ModuleAccessLevel.ReadOnly
        };
    }

    public async Task<IEnumerable<string>> GetEnabledModulesAsync(Guid tenantId, CancellationToken cancellationToken = default)
    {
        var cacheKey = $"tenant:{tenantId}:modules";

        return await _cache.GetOrCreateAsync(cacheKey, async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = CacheDuration;

            await using var context = await _contextFactory.CreateDbContextAsync(cancellationToken);
            
            var enabledModuleIds = await context.TenantModules
                .Where(m => m.TenantId == tenantId && m.Status == TenantModuleStatus.Enabled)
                .Select(m => m.ModuleId)
                .ToListAsync(cancellationToken);

            // First try ModuleCatalogs (primary source)
            var moduleCodes = await context.ModuleCatalogs
                .Where(m => enabledModuleIds.Contains(m.Id) && m.IsActive)
                .Select(m => m.ModuleCode)
                .ToListAsync(cancellationToken);

            // Fallback to Modules table for legacy compatibility
            if (!moduleCodes.Any())
            {
                moduleCodes = await context.Modules
                    .Where(m => enabledModuleIds.Contains(m.Id) && (m.IsAllModules || m.TenantId == tenantId))
                    .Select(m => m.Code)
                    .ToListAsync(cancellationToken);
            }

            return moduleCodes;
        }) ?? Enumerable.Empty<string>();
    }

    public async Task EnableModuleAsync(Guid tenantId, string moduleCode, Guid enabledByUserId, CancellationToken cancellationToken = default)
    {
        await using var context = await _contextFactory.CreateDbContextAsync(cancellationToken);

        var module = await context.Modules.FirstOrDefaultAsync(m => m.Code == moduleCode && (m.IsAllModules || m.TenantId == tenantId), cancellationToken);
        if (module == null)
        {
            _logger.LogWarning("Module {ModuleCode} not found in Modules table for tenant {TenantId}", moduleCode, tenantId);
            throw new InvalidOperationException($"Module not found: {moduleCode}");
        }

        var existing = await context.TenantModules
            .FirstOrDefaultAsync(m => m.TenantId == tenantId && m.ModuleId == module.Id, cancellationToken);

        if (existing != null)
        {
            existing.Status = TenantModuleStatus.Enabled;
            existing.EnabledOn = DateTimeOffset.UtcNow;
            existing.EnabledByUserId = enabledByUserId;
            existing.UpdatedAt = DateTimeOffset.UtcNow;
        }
        else
        {
            context.TenantModules.Add(new TenantModule
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                ModuleId = module.Id,
                Status = TenantModuleStatus.Enabled,
                LicenseTier = 0,
                EnabledOn = DateTimeOffset.UtcNow,
                EnabledByUserId = enabledByUserId,
                CreatedAt = DateTimeOffset.UtcNow
            });
        }

        await context.SaveChangesAsync(cancellationToken);
        await InvalidateCacheAsync(tenantId, cancellationToken);

        _logger.LogInformation("Module {ModuleCode} enabled for tenant {TenantId}", moduleCode, tenantId);
    }

    public async Task DisableModuleAsync(Guid tenantId, string moduleCode, Guid disabledByUserId, CancellationToken cancellationToken = default)
    {
        if (ModuleDefinitions.IsCoreModule(moduleCode))
        {
            _logger.LogWarning("Attempted to disable core module {ModuleCode} for tenant {TenantId}", moduleCode, tenantId);
            throw new InvalidOperationException($"Cannot disable core module: {moduleCode}");
        }

        await using var context = await _contextFactory.CreateDbContextAsync(cancellationToken);

        var module = await context.Modules.FirstOrDefaultAsync(m => m.Code == moduleCode && (m.IsAllModules || m.TenantId == tenantId), cancellationToken);
        if (module == null) return;

        var existing = await context.TenantModules
            .FirstOrDefaultAsync(m => m.TenantId == tenantId && m.ModuleId == module.Id, cancellationToken);

        if (existing != null)
        {
            existing.Status = TenantModuleStatus.Disabled;
            existing.DisabledOn = DateTimeOffset.UtcNow;
            existing.DisabledByUserId = disabledByUserId;
            existing.UpdatedAt = DateTimeOffset.UtcNow;
            await context.SaveChangesAsync(cancellationToken);
            await InvalidateCacheAsync(tenantId, cancellationToken);

            _logger.LogInformation("Module {ModuleCode} disabled for tenant {TenantId} by user {UserId}", moduleCode, tenantId, disabledByUserId);
        }
    }

    public async Task<IEnumerable<TenantModule>> GetAllModulesWithStatusAsync(Guid tenantId, CancellationToken cancellationToken = default)
    {
        await using var context = await _contextFactory.CreateDbContextAsync(cancellationToken);
        
        var tenantModules = await context.TenantModules
            .Where(m => m.TenantId == tenantId)
            .ToListAsync(cancellationToken);

        return tenantModules;
    }

    public async Task InitializeCoreModulesAsync(Guid tenantId, Guid userId, CancellationToken cancellationToken = default)
    {
        await using var context = await _contextFactory.CreateDbContextAsync(cancellationToken);

        foreach (var coreModuleCode in ModuleDefinitions.CoreModuleCodes)
        {
            var module = await context.Modules.FirstOrDefaultAsync(m => m.Code == coreModuleCode && (m.IsAllModules || m.TenantId == tenantId), cancellationToken);
            if (module == null) continue;

            var existing = await context.TenantModules
                .FirstOrDefaultAsync(m => m.TenantId == tenantId && m.ModuleId == module.Id, cancellationToken);

            if (existing == null)
            {
                context.TenantModules.Add(new TenantModule
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    ModuleId = module.Id,
                    Status = TenantModuleStatus.Enabled,
                    LicenseTier = 0,
                    EnabledOn = DateTimeOffset.UtcNow,
                    EnabledByUserId = userId,
                    CreatedAt = DateTimeOffset.UtcNow
                });
            }
            else if (existing.Status != TenantModuleStatus.Enabled)
            {
                existing.Status = TenantModuleStatus.Enabled;
                existing.EnabledOn = DateTimeOffset.UtcNow;
                existing.EnabledByUserId = userId;
                existing.UpdatedAt = DateTimeOffset.UtcNow;
            }
        }

        await context.SaveChangesAsync(cancellationToken);
        await InvalidateCacheAsync(tenantId, cancellationToken);
    }

    public Task InvalidateCacheAsync(Guid tenantId, CancellationToken cancellationToken = default)
    {
        _cache.Remove($"tenant:{tenantId}:modules");
        _logger.LogDebug("Cache invalidated for tenant {TenantId}", tenantId);
        return Task.CompletedTask;
    }
}
