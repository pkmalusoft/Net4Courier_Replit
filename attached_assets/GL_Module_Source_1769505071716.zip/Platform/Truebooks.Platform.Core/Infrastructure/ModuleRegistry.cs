using Truebooks.Platform.Contracts.Modules;

namespace Truebooks.Platform.Core.Infrastructure;

public interface IModuleRegistry
{
    void RegisterModule(IModuleManifest manifest);
    IEnumerable<IModuleManifest> GetAllManifests();
    IModuleManifest? GetManifest(string moduleCode);
    IEnumerable<MenuItem> GetMenuItemsForModules(IEnumerable<string> enabledModuleCodes);
}

public class ModuleRegistry : IModuleRegistry
{
    private readonly Dictionary<string, IModuleManifest> _manifests = new(StringComparer.OrdinalIgnoreCase);

    public void RegisterModule(IModuleManifest manifest)
    {
        _manifests[manifest.Code] = manifest;
    }

    public IEnumerable<IModuleManifest> GetAllManifests() => _manifests.Values;

    public IModuleManifest? GetManifest(string moduleCode)
    {
        return _manifests.TryGetValue(moduleCode, out var manifest) ? manifest : null;
    }

    public IEnumerable<MenuItem> GetMenuItemsForModules(IEnumerable<string> enabledModuleCodes)
    {
        var enabledSet = enabledModuleCodes.ToHashSet(StringComparer.OrdinalIgnoreCase);

        return _manifests
            .Where(m => enabledSet.Contains(m.Key))
            .SelectMany(m => m.Value.MenuItems);
    }
}
