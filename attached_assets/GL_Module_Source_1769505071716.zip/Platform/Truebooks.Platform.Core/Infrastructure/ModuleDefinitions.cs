namespace Truebooks.Platform.Core.Infrastructure;

public static class ModuleDefinitions
{
    public static readonly ModuleInfo[] AllModules = new[]
    {
        // Core Modules (Row 1)
        new ModuleInfo("AccountsFinance", "Accounts & Finance", "General Ledger, AR, AP, Period Management", true),
        new ModuleInfo("SystemSettings", "System Settings", "Company Settings, Preferences, Configuration", true),
        new ModuleInfo("SystemProfile", "System Profile", "Company Profile, Branding, Information", true),
        new ModuleInfo("HRCore", "HR Core", "Employee profiles, documents, basic HR management", true),
        
        // Industry Modules (in specified order)
        new ModuleInfo("ServiceBusiness", "Service Business", "AMCs, SLAs, task management", false),
        new ModuleInfo("Inventory", "Inventory Management", "Item Master, Categories, Stock, GRN, Pricing", false),
        new ModuleInfo("Ecommerce", "E-Commerce", "Product catalog, orders, payments", false),
        new ModuleInfo("Courier", "Courier", "Shipment booking, AWB tracking, COD management", false),
        new ModuleInfo("DoorToDoor", "Door-To-Door Cargo", "International cargo, customs clearance", false),
        new ModuleInfo("ShippingFreight", "Shipping & Freight Forwarding", "Sea/Air freight, container tracking", false),
        new ModuleInfo("Relocation", "Relocation", "International household goods moving", false),
        new ModuleInfo("LandTransport", "Land Transport", "Road freight, fleet management", false),
        new ModuleInfo("HRPayroll", "HR & Payroll", "Full HR, payroll processing, WPS", false),
        new ModuleInfo("BudgetingForecast", "Budgeting", "Cost centers, budget allocation", false),
        
        // Legacy modules (kept for compatibility, hidden from UI)
        new ModuleInfo("CommonModules", "Common Modules", "Company Profile, System Settings, Security", true, isLegacy: true)
    };

    public static readonly string[] CoreModuleCodes = new[] { "AccountsFinance", "SystemSettings", "SystemProfile", "HRCore", "CommonModules" };

    public static bool IsCoreModule(string moduleCode)
    {
        return CoreModuleCodes.Contains(moduleCode);
    }

    public static ModuleInfo? GetModuleInfo(string moduleCode)
    {
        return AllModules.FirstOrDefault(m => m.Code == moduleCode);
    }

    public static IEnumerable<ModuleInfo> GetCoreModules()
    {
        return AllModules.Where(m => m.IsCoreModule);
    }

    public static IEnumerable<ModuleInfo> GetOptionalModules()
    {
        return AllModules.Where(m => !m.IsCoreModule);
    }
    
    public static IEnumerable<ModuleInfo> GetActiveModules()
    {
        return AllModules.Where(m => !m.IsLegacy);
    }
    
    public static int GetDisplayOrder(string moduleCode)
    {
        for (int i = 0; i < AllModules.Length; i++)
        {
            if (AllModules[i].Code == moduleCode)
                return i + 1;
        }
        return 99;
    }
    
    public static bool IsLegacyModule(string moduleCode)
    {
        var module = AllModules.FirstOrDefault(m => m.Code == moduleCode);
        return module?.IsLegacy ?? false;
    }
}

public class ModuleInfo
{
    public string Code { get; }
    public string Name { get; }
    public string Description { get; }
    public bool IsCoreModule { get; }
    public bool IsLegacy { get; }

    public ModuleInfo(string code, string name, string description, bool isCoreModule, bool isLegacy = false)
    {
        Code = code;
        Name = name;
        Description = description;
        IsCoreModule = isCoreModule;
        IsLegacy = isLegacy;
    }
}
