using Microsoft.EntityFrameworkCore;
using Truebooks.Platform.Contracts.Legacy.Models;
using Truebooks.Platform.Contracts.Legacy.DTOs;
using Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Core.Infrastructure;

public class PlatformDbContext : DbContext
{
    public PlatformDbContext(DbContextOptions<PlatformDbContext> options) : base(options)
    {
    }

    public DbSet<TenantModule> TenantModules => Set<TenantModule>();
    public DbSet<Module> Modules => Set<Module>();
    public DbSet<ModuleCatalog> ModuleCatalogs => Set<ModuleCatalog>();
    public DbSet<Tenant> Tenants => Set<Tenant>();
    public DbSet<Branch> Branches => Set<Branch>();
    public DbSet<UserBranch> UserBranches => Set<UserBranch>();
    public DbSet<FinancialPeriod> FinancialPeriods => Set<FinancialPeriod>();
    public DbSet<FinancialCalendar> FinancialCalendars => Set<FinancialCalendar>();
    public DbSet<Currency> Currencies => Set<Currency>();
    public DbSet<ExchangeRate> ExchangeRates => Set<ExchangeRate>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Project> Projects => Set<Project>();
    public DbSet<TaxCode> TaxCodes => Set<TaxCode>();
    public DbSet<VoucherNumbering> VoucherNumberings => Set<VoucherNumbering>();
    public DbSet<Country> Countries => Set<Country>();
    public DbSet<State> States => Set<State>();
    public DbSet<City> Cities => Set<City>();
    public DbSet<PostalCode> PostalCodes => Set<PostalCode>();
    public DbSet<Asset> Assets => Set<Asset>();
    public DbSet<AssetCategory> AssetCategories => Set<AssetCategory>();
    public DbSet<Document> Documents => Set<Document>();
    public DbSet<DocumentCategory> DocumentCategories => Set<DocumentCategory>();
    public DbSet<Alert> Alerts => Set<Alert>();
    public DbSet<ApprovalWorkflow> ApprovalWorkflows => Set<ApprovalWorkflow>();
    public DbSet<ApprovalStep> ApprovalSteps => Set<ApprovalStep>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<GridPreference> GridPreferences => Set<GridPreference>();
    public DbSet<EmailVerificationToken> EmailVerificationTokens => Set<EmailVerificationToken>();
    public DbSet<SuperAdmin> SuperAdmins => Set<SuperAdmin>();
    public DbSet<SubscriptionPlan> SubscriptionPlans => Set<SubscriptionPlan>();
    public DbSet<SubscriptionPayment> SubscriptionPayments => Set<SubscriptionPayment>();
    public DbSet<ApplicationUser> ApplicationUsers => Set<ApplicationUser>();
    public DbSet<ChartOfAccount> ChartOfAccounts => Set<ChartOfAccount>();
    public DbSet<AccountClassification> AccountClassifications => Set<AccountClassification>();
    public DbSet<Brand> Brands => Set<Brand>();
    public DbSet<Colour> Colours => Set<Colour>();
    public DbSet<Size> Sizes => Set<Size>();
    public DbSet<ItemGroup> ItemGroups => Set<ItemGroup>();
    public DbSet<InventoryLocation> InventoryLocations => Set<InventoryLocation>();
    public DbSet<CustomerCategory> CustomerCategories => Set<CustomerCategory>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<SupplierCategory> SupplierCategories => Set<SupplierCategory>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();
    public DbSet<SupplierChargeType> SupplierChargeTypes => Set<SupplierChargeType>();
    public DbSet<UserMenuFavourite> UserMenuFavourites => Set<UserMenuFavourite>();
    public DbSet<Item> Items => Set<Item>();
    public DbSet<SalesEnquiry> SalesEnquiries => Set<SalesEnquiry>();
    public DbSet<SalesEnquiryLine> SalesEnquiryLines => Set<SalesEnquiryLine>();
    public DbSet<SalesQuotation> SalesQuotations => Set<SalesQuotation>();
    public DbSet<SalesQuotationLine> SalesQuotationLines => Set<SalesQuotationLine>();
    public DbSet<SalesOrder> SalesOrders => Set<SalesOrder>();
    public DbSet<SalesOrderLine> SalesOrderLines => Set<SalesOrderLine>();
    public DbSet<SalesOrderRequest> SalesOrderRequests => Set<SalesOrderRequest>();
    public DbSet<SalesOrderRequestLine> SalesOrderRequestLines => Set<SalesOrderRequestLine>();
    public DbSet<DeliveryNote> DeliveryNotes => Set<DeliveryNote>();
    public DbSet<DeliveryNoteLine> DeliveryNoteLines => Set<DeliveryNoteLine>();
    public DbSet<Warehouse> Warehouses => Set<Warehouse>();
    public DbSet<ChargeType> ChargeTypes => Set<ChargeType>();
    public DbSet<CargoType> CargoTypes => Set<CargoType>();
    public DbSet<ContainerType> ContainerTypes => Set<ContainerType>();
    public DbSet<Port> Ports => Set<Port>();
    public DbSet<ShippingLine> ShippingLines => Set<ShippingLine>();
    public DbSet<Vessel> Vessels => Set<Vessel>();
    public DbSet<Carrier> Carriers => Set<Carrier>();
    public DbSet<LogisticsJobMode> LogisticsJobModes => Set<LogisticsJobMode>();
    public DbSet<LogisticsJobType> LogisticsJobTypes => Set<LogisticsJobType>();
    public DbSet<LogisticsEnquiry> LogisticsEnquiries => Set<LogisticsEnquiry>();
    public DbSet<ShippingDocumentType> ShippingDocumentTypes => Set<ShippingDocumentType>();
    public DbSet<EnquiryDocument> EnquiryDocuments => Set<EnquiryDocument>();
    public DbSet<LogisticsEstimation> LogisticsEstimations => Set<LogisticsEstimation>();
    public DbSet<LogisticsEstimationVersion> LogisticsEstimationVersions => Set<LogisticsEstimationVersion>();
    public DbSet<LogisticsEstimationVersionLine> LogisticsEstimationVersionLines => Set<LogisticsEstimationVersionLine>();
    public DbSet<LogisticsQuotation> LogisticsQuotations => Set<LogisticsQuotation>();
    public DbSet<QuotationLine> QuotationLines => Set<QuotationLine>();
    public DbSet<LogisticsJob> LogisticsJobs => Set<LogisticsJob>();
    public DbSet<JobCostLine> JobCostLines => Set<JobCostLine>();
    public DbSet<JobClosingEntry> JobClosingEntries => Set<JobClosingEntry>();
    public DbSet<JobActivityLog> JobActivityLogs => Set<JobActivityLog>();
    public DbSet<LogisticsVendorInvoice> LogisticsVendorInvoices => Set<LogisticsVendorInvoice>();
    public DbSet<LogisticsVendorInvoiceLine> LogisticsVendorInvoiceLines => Set<LogisticsVendorInvoiceLine>();
    public DbSet<LogisticsCustomerInvoice> LogisticsCustomerInvoices => Set<LogisticsCustomerInvoice>();
    public DbSet<LogisticsCustomerInvoiceLine> LogisticsCustomerInvoiceLines => Set<LogisticsCustomerInvoiceLine>();
    public DbSet<JobDocument> JobDocuments => Set<JobDocument>();
    public DbSet<PurchaseEnquiry> PurchaseEnquiries => Set<PurchaseEnquiry>();
    public DbSet<PurchaseEnquiryLine> PurchaseEnquiryLines => Set<PurchaseEnquiryLine>();
    public DbSet<PurchaseQuotation> PurchaseQuotations => Set<PurchaseQuotation>();
    public DbSet<PurchaseQuotationLine> PurchaseQuotationLines => Set<PurchaseQuotationLine>();
    public DbSet<PurchaseOrder> PurchaseOrders => Set<PurchaseOrder>();
    public DbSet<PurchaseOrderLine> PurchaseOrderLines => Set<PurchaseOrderLine>();
    public DbSet<SalesReturn> SalesReturns => Set<SalesReturn>();
    public DbSet<SalesReturnLine> SalesReturnLines => Set<SalesReturnLine>();
    public DbSet<SalesInvoice> SalesInvoices => Set<SalesInvoice>();
    public DbSet<SalesInvoiceLine> SalesInvoiceLines => Set<SalesInvoiceLine>();
    public DbSet<PurchaseBill> PurchaseBills => Set<PurchaseBill>();
    public DbSet<PurchaseBillLine> PurchaseBillLines => Set<PurchaseBillLine>();
    public DbSet<BankAccount> BankAccounts => Set<BankAccount>();
    public DbSet<Vendor> Vendors => Set<Vendor>();
    public DbSet<CashBankTransaction> CashBankTransactions => Set<CashBankTransaction>();
    public DbSet<CashBankTransactionLine> CashBankTransactionLines => Set<CashBankTransactionLine>();
    public DbSet<JournalEntry> JournalEntries => Set<JournalEntry>();
    public DbSet<JournalEntryLine> JournalEntryLines => Set<JournalEntryLine>();
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<EmployeeDocumentType> EmployeeDocumentTypes => Set<EmployeeDocumentType>();
    public DbSet<EmployeeDocument> EmployeeDocuments => Set<EmployeeDocument>();
    public DbSet<OpeningBalanceBatch> OpeningBalanceBatches => Set<OpeningBalanceBatch>();
    public DbSet<OpeningBalanceLine> OpeningBalanceLines => Set<OpeningBalanceLine>();
    public DbSet<ServiceEnquiry> ServiceEnquiries => Set<ServiceEnquiry>();
    public DbSet<ServiceEnquiryFollowUp> ServiceEnquiryFollowUps => Set<ServiceEnquiryFollowUp>();
    public DbSet<ServiceQuotation> ServiceQuotations => Set<ServiceQuotation>();
    public DbSet<ServiceQuotationLine> ServiceQuotationLines => Set<ServiceQuotationLine>();
    public DbSet<ServiceContract> ServiceContracts => Set<ServiceContract>();
    public DbSet<ServiceTaskLog> ServiceTaskLogs => Set<ServiceTaskLog>();
    public DbSet<CustomerModuleAssignment> CustomerModuleAssignments => Set<CustomerModuleAssignment>();
    public DbSet<SupplierModuleAssignment> SupplierModuleAssignments => Set<SupplierModuleAssignment>();
    public DbSet<Campaign> Campaigns => Set<Campaign>();
    public DbSet<ClientReport> ClientReports => Set<ClientReport>();
    public DbSet<ServiceCategory> ServiceCategories => Set<ServiceCategory>();
    public DbSet<ServiceType> ServiceTypes => Set<ServiceType>();
    public DbSet<ServiceName> ServiceNames => Set<ServiceName>();
    public DbSet<ServiceDetail> ServiceDetails => Set<ServiceDetail>();
    public DbSet<RateChart> RateCharts => Set<RateChart>();
    public DbSet<DemoDataTracking> DemoDataTrackings => Set<DemoDataTracking>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<TenantModule>(entity =>
        {
            entity.ToTable("TenantModules");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.ModuleId }).IsUnique();
            entity.Property(e => e.EnabledFeaturesJson).HasMaxLength(4000);
            entity.Property(e => e.LicenseKey).HasMaxLength(200);
            entity.Ignore(e => e.IsEnabled);
        });

        modelBuilder.Entity<Module>(entity =>
        {
            entity.ToTable("Modules");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.Code);
            entity.Property(e => e.Code).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<ModuleCatalog>(entity =>
        {
            entity.ToTable("ModuleCatalogs");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.ModuleCode).IsUnique(); // Prevent duplicate module codes
            entity.Property(e => e.ModuleCode).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.Version).HasMaxLength(50).IsRequired();
            entity.Property(e => e.IconClass).HasMaxLength(100);
            entity.Property(e => e.DependsOn).HasMaxLength(500);
        });

        modelBuilder.Entity<Tenant>(entity =>
        {
            entity.ToTable("Tenants");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Subdomain).HasMaxLength(100);
            entity.Property(e => e.AdminEmail).HasMaxLength(200);
            entity.HasIndex(e => e.Subdomain).IsUnique();
        });

        modelBuilder.Entity<EmailVerificationToken>(entity =>
        {
            entity.ToTable("EmailVerificationTokens");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Email).HasMaxLength(200).IsRequired();
            entity.Property(e => e.TokenHash).HasMaxLength(128).IsRequired();
            entity.HasIndex(e => new { e.TenantId, e.Email });
            entity.HasIndex(e => e.ExpiresAt);
        });

        modelBuilder.Entity<Branch>(entity =>
        {
            entity.ToTable("Branches");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Country).HasMaxLength(100);
            entity.Property(e => e.State).HasMaxLength(100);
            entity.Property(e => e.City).HasMaxLength(100);
            entity.Property(e => e.Address).HasMaxLength(500);
            entity.Property(e => e.Phone).HasMaxLength(50);
            entity.Property(e => e.Email).HasMaxLength(100);
        });

        modelBuilder.Entity<UserBranch>(entity =>
        {
            entity.ToTable("UserBranches");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.UserId, e.BranchId }).IsUnique();
        });

        modelBuilder.Entity<FinancialPeriod>(entity =>
        {
            entity.ToTable("FinancialPeriods");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.FiscalYear, e.PeriodNumber });
            entity.Property(e => e.PeriodName).HasMaxLength(100);
            entity.Property(e => e.Notes).HasMaxLength(500);
        });

        modelBuilder.Entity<FinancialCalendar>(entity =>
        {
            entity.ToTable("FinancialCalendars");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Code).HasMaxLength(50).IsRequired();
            entity.Property(e => e.CountryCode).HasMaxLength(10);
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<Currency>(entity =>
        {
            entity.ToTable("Currencies");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(10).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Symbol).HasMaxLength(10);
        });

        modelBuilder.Entity<Department>(entity =>
        {
            entity.ToTable("Departments");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.DeactivationReason).HasMaxLength(500);
            entity.Ignore(e => e.DisplayName);
        });

        modelBuilder.Entity<TaxCode>(entity =>
        {
            entity.ToTable("TaxCodes");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(200);
            entity.Property(e => e.Rate).HasPrecision(5, 2);
        });

        modelBuilder.Entity<VoucherNumbering>(entity =>
        {
            entity.ToTable("VoucherNumberings");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.TransactionType }).IsUnique();
            entity.Property(e => e.Prefix).HasMaxLength(10).IsRequired();
            entity.Property(e => e.Separator).HasMaxLength(5).IsRequired();
        });

        modelBuilder.Entity<Country>(entity =>
        {
            entity.ToTable("Countries");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(10).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.IsoCode2).HasMaxLength(2);
            entity.Property(e => e.IsoCode3).HasMaxLength(3);
        });

        modelBuilder.Entity<State>(entity =>
        {
            entity.ToTable("States");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.CountryId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
        });

        modelBuilder.Entity<City>(entity =>
        {
            entity.ToTable("Cities");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.StateId, e.Name });
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
        });

        modelBuilder.Entity<PostalCode>(entity =>
        {
            entity.ToTable("PostalCodes");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.CityId, e.Code });
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.AreaName).HasMaxLength(100);
        });

        modelBuilder.Entity<AssetCategory>(entity =>
        {
            entity.ToTable("AssetCategories");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<Asset>(entity =>
        {
            entity.ToTable("Assets");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.AssetCode }).IsUnique();
            entity.Property(e => e.AssetCode).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(1000);
            entity.Property(e => e.SerialNumber).HasMaxLength(100);
            entity.Property(e => e.Location).HasMaxLength(200);
            entity.Property(e => e.PurchasePrice).HasPrecision(18, 2);
            entity.Property(e => e.CurrentValue).HasPrecision(18, 2);
            entity.Property(e => e.DepreciationRate).HasPrecision(5, 2);
        });

        modelBuilder.Entity<DocumentCategory>(entity =>
        {
            entity.ToTable("DocumentCategories");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
        });

        modelBuilder.Entity<Document>(entity =>
        {
            entity.ToTable("Documents");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.DocumentType, e.RelatedEntityId });
            entity.Property(e => e.DocumentName).HasMaxLength(200).IsRequired();
            entity.Property(e => e.FileName).HasMaxLength(500);
            entity.Property(e => e.FilePath).HasMaxLength(1000);
            entity.Property(e => e.FileType).HasMaxLength(50);
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<Alert>(entity =>
        {
            entity.ToTable("Alerts");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.AlertType, e.Status });
            entity.Property(e => e.Title).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Message).HasMaxLength(2000);
        });

        modelBuilder.Entity<ApprovalWorkflow>(entity =>
        {
            entity.ToTable("ApprovalWorkflows");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.WorkflowType }).IsUnique();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<ApprovalStep>(entity =>
        {
            entity.ToTable("ApprovalSteps");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.WorkflowId, e.StepOrder });
            entity.Property(e => e.StepName).HasMaxLength(100).IsRequired();
        });

        modelBuilder.Entity<Permission>(entity =>
        {
            entity.ToTable("Permissions");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Module).HasMaxLength(100);
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.ToTable("Roles");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Name }).IsUnique();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<RolePermission>(entity =>
        {
            entity.ToTable("RolePermissions");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.RoleId, e.PermissionId }).IsUnique();
        });

        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.ToTable("UserRoles");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.UserId, e.RoleId }).IsUnique();
        });

        modelBuilder.Entity<AuditLog>(entity =>
        {
            entity.ToTable("AuditLogs");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Timestamp });
            entity.HasIndex(e => new { e.TenantId, e.EntityType, e.EntityId });
            entity.Property(e => e.EntityType).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Action).HasMaxLength(50).IsRequired();
            entity.Property(e => e.UserEmail).HasMaxLength(200);
        });

        modelBuilder.Entity<SuperAdmin>(entity =>
        {
            entity.ToTable("SuperAdmins");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.Email).IsUnique();
            entity.Property(e => e.Email).HasMaxLength(200).IsRequired();
            entity.Property(e => e.PasswordHash).HasMaxLength(256).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
        });

        modelBuilder.Entity<SubscriptionPlan>(entity =>
        {
            entity.ToTable("SubscriptionPlans");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.Code).IsUnique();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Code).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.PriceINR).HasPrecision(18, 2);
            entity.Property(e => e.PriceUSD).HasPrecision(18, 2);
        });

        modelBuilder.Entity<SubscriptionPayment>(entity =>
        {
            entity.ToTable("SubscriptionPayments");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.RazorpayOrderId).IsUnique();
            entity.HasIndex(e => e.TenantId);
            entity.Property(e => e.RazorpayOrderId).HasMaxLength(100).IsRequired();
            entity.Property(e => e.RazorpayPaymentId).HasMaxLength(100);
            entity.Property(e => e.RazorpaySignature).HasMaxLength(256);
            entity.Property(e => e.Amount).HasPrecision(18, 2);
            entity.Property(e => e.Currency).HasMaxLength(10).IsRequired();
            entity.Property(e => e.PaymentMethod).HasMaxLength(50);
            entity.Property(e => e.CustomerEmail).HasMaxLength(200);
            entity.Property(e => e.CustomerPhone).HasMaxLength(50);
            entity.Property(e => e.FailureReason).HasMaxLength(500);
        });

        modelBuilder.Entity<ApplicationUser>(entity =>
        {
            entity.ToTable("AspNetUsers");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.NormalizedUserName).IsUnique();
            entity.HasIndex(e => e.NormalizedEmail);
            entity.HasIndex(e => e.TenantId);
            entity.Property(e => e.UserName).HasMaxLength(256);
            entity.Property(e => e.NormalizedUserName).HasMaxLength(256);
            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.NormalizedEmail).HasMaxLength(256);
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.DisplayName).HasMaxLength(100);
        });

        modelBuilder.Entity<ChartOfAccount>(entity =>
        {
            entity.ToTable("ChartOfAccounts");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.AccountCode }).IsUnique();
            entity.Property(e => e.AccountCode).HasMaxLength(50);
            entity.Property(e => e.AccountName).HasMaxLength(200).IsRequired();
            entity.HasOne(e => e.AccountClassification)
                  .WithMany()
                  .HasForeignKey(e => e.AccountClassificationId)
                  .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<AccountClassification>(entity =>
        {
            entity.ToTable("AccountClassifications");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Name }).IsUnique();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<Brand>(entity =>
        {
            entity.ToTable("Brands");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<Colour>(entity =>
        {
            entity.ToTable("Colours");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<Size>(entity =>
        {
            entity.ToTable("Sizes");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<ItemGroup>(entity =>
        {
            entity.ToTable("ItemGroups");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<InventoryLocation>(entity =>
        {
            entity.ToTable("InventoryLocations");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<CustomerCategory>(entity =>
        {
            entity.ToTable("CustomerCategories");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<SupplierCategory>(entity =>
        {
            entity.ToTable("SupplierCategories");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.ToTable("Customers");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.CustomerCode }).IsUnique();
            entity.Property(e => e.CustomerCode).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Address).HasMaxLength(500);
            entity.Property(e => e.Email).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Phone).HasMaxLength(50).IsRequired();
            entity.Property(e => e.TaxIdNumber).HasMaxLength(50);
            entity.Property(e => e.CreditLimit).HasPrecision(18, 2);
            entity.Property(e => e.RequestedCreditLimit).HasPrecision(18, 2);
            entity.HasOne(e => e.DefaultCurrency).WithMany().HasForeignKey(e => e.DefaultCurrencyId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne(e => e.DefaultARAccount).WithMany().HasForeignKey(e => e.DefaultARAccountId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne(e => e.CustomerCategory).WithMany().HasForeignKey(e => e.CustomerCategoryId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Supplier>(entity =>
        {
            entity.ToTable("Suppliers");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.SupplierCode }).IsUnique();
            entity.Property(e => e.SupplierCode).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Address).HasMaxLength(500);
            entity.Property(e => e.Email).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Phone).HasMaxLength(50).IsRequired();
            entity.Property(e => e.TaxIdNumber).HasMaxLength(50);
            entity.Property(e => e.CreditLimit).HasPrecision(18, 2);
            entity.Property(e => e.RequestedCreditLimit).HasPrecision(18, 2);
            entity.HasOne(e => e.DefaultCurrency).WithMany().HasForeignKey(e => e.DefaultCurrencyId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne(e => e.DefaultAPAccount).WithMany().HasForeignKey(e => e.DefaultAPAccountId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne(e => e.SupplierCategory).WithMany().HasForeignKey(e => e.SupplierCategoryId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Item>(entity =>
        {
            entity.ToTable("Items");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.ItemCode }).IsUnique();
            entity.Property(e => e.ItemCode).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.UnitOfMeasure).HasMaxLength(20);
            entity.Property(e => e.CostPrice).HasPrecision(18, 4);
            entity.Property(e => e.SellingPrice).HasPrecision(18, 4);
            entity.Property(e => e.ReorderLevel).HasPrecision(18, 4);
            entity.Property(e => e.ReorderQuantity).HasPrecision(18, 4);
            entity.HasOne(e => e.ItemGroup).WithMany().HasForeignKey(e => e.ItemGroupId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne(e => e.Brand).WithMany().HasForeignKey(e => e.BrandId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne(e => e.Colour).WithMany().HasForeignKey(e => e.ColourId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne(e => e.Size).WithMany().HasForeignKey(e => e.SizeId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<JournalEntry>(entity =>
        {
            entity.ToTable("JournalEntries");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.EntryNumber }).IsUnique();
            entity.HasIndex(e => new { e.TenantId, e.FiscalYear });
            entity.Property(e => e.EntryNumber).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.AdjustmentReason).HasMaxLength(500);
            entity.Property(e => e.VoidReason).HasMaxLength(500);
            entity.HasMany(e => e.Lines).WithOne(l => l.JournalEntry).HasForeignKey(l => l.JournalEntryId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<JournalEntryLine>(entity =>
        {
            entity.ToTable("JournalEntryLines");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.JournalEntryId });
            entity.HasIndex(e => new { e.TenantId, e.AccountId });
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.Debit).HasPrecision(18, 2);
            entity.Property(e => e.Credit).HasPrecision(18, 2);
            entity.Property(e => e.ExchangeRate).HasPrecision(18, 6);
            entity.HasOne(e => e.Account).WithMany().HasForeignKey(e => e.AccountId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.ToTable("Employees");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.EmployeeCode }).IsUnique();
            entity.Property(e => e.EmployeeCode).HasMaxLength(20).IsRequired();
            entity.Property(e => e.FirstName).HasMaxLength(100).IsRequired();
            entity.Property(e => e.LastName).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Email).HasMaxLength(200);
            entity.Property(e => e.Phone).HasMaxLength(50);
            entity.Property(e => e.Gender).HasMaxLength(20);
            entity.Property(e => e.Nationality).HasMaxLength(100);
            entity.Property(e => e.Designation).HasMaxLength(100);
            entity.Property(e => e.Address).HasMaxLength(500);
            entity.Property(e => e.City).HasMaxLength(100);
            entity.Property(e => e.Country).HasMaxLength(100);
            entity.Property(e => e.HourlyRate).HasPrecision(18, 2);
            entity.Property(e => e.MonthlySalary).HasPrecision(18, 2);
            entity.Property(e => e.LumpsumAmount).HasPrecision(18, 2);
            entity.Ignore(e => e.FullName);
            entity.Ignore(e => e.DisplayName);
            entity.Ignore(e => e.StatusText);
            entity.Ignore(e => e.StatusColor);
            
            entity.HasOne(e => e.Department)
                .WithMany()
                .HasForeignKey(e => e.DepartmentId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<EmployeeDocumentType>(entity =>
        {
            entity.ToTable("EmployeeDocumentTypes");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(20).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(100).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.ResponsibleRole).HasMaxLength(50);
        });

        modelBuilder.Entity<EmployeeDocument>(entity =>
        {
            entity.ToTable("EmployeeDocuments");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.EmployeeId });
            entity.HasIndex(e => new { e.TenantId, e.DocumentTypeId });
            entity.Property(e => e.DocumentNumber).HasMaxLength(100).IsRequired();
            entity.Property(e => e.DocumentName).HasMaxLength(200);
            entity.Property(e => e.IssuePlace).HasMaxLength(200);
            entity.Property(e => e.IssuingAuthority).HasMaxLength(200);
            entity.Property(e => e.IssuingCountry).HasMaxLength(100);
            entity.Property(e => e.AttachmentPath).HasMaxLength(500);
            entity.Property(e => e.AttachmentFileName).HasMaxLength(200);
            entity.Property(e => e.Notes).HasMaxLength(1000);
            entity.Ignore(e => e.DaysUntilExpiry);
            entity.Ignore(e => e.StatusText);
            entity.Ignore(e => e.StatusColor);
        });

        modelBuilder.Entity<OpeningBalanceBatch>(entity =>
        {
            entity.ToTable("OpeningBalanceBatches");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.BatchNumber }).IsUnique();
            entity.HasIndex(e => new { e.TenantId, e.FiscalYear });
            entity.HasIndex(e => new { e.TenantId, e.Status });
            entity.Property(e => e.BatchNumber).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Notes).HasMaxLength(500);
            entity.HasMany(e => e.Lines).WithOne(l => l.Batch).HasForeignKey(l => l.BatchId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(e => e.PostedJournal).WithMany().HasForeignKey(e => e.PostedJournalId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne(e => e.ClosingJournal).WithMany().HasForeignKey(e => e.ClosingJournalId).OnDelete(DeleteBehavior.SetNull);
            entity.Ignore(e => e.TotalDebit);
            entity.Ignore(e => e.TotalCredit);
            entity.Ignore(e => e.IsBalanced);
        });

        modelBuilder.Entity<OpeningBalanceLine>(entity =>
        {
            entity.ToTable("OpeningBalanceLines");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.BatchId });
            entity.HasIndex(e => new { e.TenantId, e.ReferenceType, e.ReferenceId });
            entity.Property(e => e.ReferenceName).HasMaxLength(200);
            entity.Property(e => e.ReferenceCode).HasMaxLength(50);
            entity.Property(e => e.Notes).HasMaxLength(500);
            entity.Property(e => e.Debit).HasPrecision(18, 2);
            entity.Property(e => e.Credit).HasPrecision(18, 2);
            entity.Property(e => e.HomeCurrencyDebit).HasPrecision(18, 2);
            entity.Property(e => e.HomeCurrencyCredit).HasPrecision(18, 2);
            entity.Property(e => e.ExchangeRate).HasPrecision(18, 6);
        });

        modelBuilder.Entity<ServiceEnquiry>(entity =>
        {
            entity.ToTable("ServiceEnquiries");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.EnquiryNumber }).IsUnique();
            entity.HasIndex(e => new { e.TenantId, e.Status });
            entity.HasIndex(e => new { e.TenantId, e.IsActive });
            entity.Property(e => e.EnquiryNumber).HasMaxLength(50).IsRequired();
            entity.Property(e => e.CompanyName).HasMaxLength(200);
            entity.Property(e => e.ContactPerson).HasMaxLength(100);
            entity.Property(e => e.Email).HasMaxLength(200);
            entity.Property(e => e.Phone).HasMaxLength(50);
            entity.Property(e => e.Address).HasMaxLength(500);
            entity.Property(e => e.SourceDetails).HasMaxLength(500);
            entity.Property(e => e.RequirementDetails).HasMaxLength(4000);
            entity.Property(e => e.Description).HasMaxLength(2000);
            entity.Property(e => e.CurrencyCode).HasMaxLength(10);
            entity.Property(e => e.AssignedTo).HasMaxLength(100);
            entity.Property(e => e.Notes).HasMaxLength(2000);
            entity.Property(e => e.LostReason).HasMaxLength(500);
            entity.Property(e => e.EstimatedValue).HasPrecision(18, 2);
            entity.Property(e => e.EstimatedBudget).HasPrecision(18, 2);
            entity.HasOne(e => e.Customer).WithMany().HasForeignKey(e => e.CustomerId).OnDelete(DeleteBehavior.SetNull);
            entity.HasMany(e => e.FollowUps).WithOne(f => f.ServiceEnquiry).HasForeignKey(f => f.ServiceEnquiryId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<ServiceEnquiryFollowUp>(entity =>
        {
            entity.ToTable("ServiceEnquiryFollowUps");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.ServiceEnquiryId });
            entity.Property(e => e.FollowUpType).HasMaxLength(50);
            entity.Property(e => e.Notes).HasMaxLength(2000);
            entity.Property(e => e.Outcome).HasMaxLength(500);
        });

        modelBuilder.Entity<ServiceQuotation>(entity =>
        {
            entity.ToTable("ServiceQuotations");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.QuotationNumber }).IsUnique();
            entity.HasIndex(e => new { e.TenantId, e.Status });
            entity.HasIndex(e => new { e.TenantId, e.IsActive });
            entity.Property(e => e.QuotationNumber).HasMaxLength(50).IsRequired();
            entity.Property(e => e.ProjectName).HasMaxLength(200);
            entity.Property(e => e.ScopeOfWork).HasMaxLength(4000);
            entity.Property(e => e.TermsAndConditions).HasMaxLength(4000);
            entity.Property(e => e.PaymentTerms).HasMaxLength(1000);
            entity.Property(e => e.Deliverables).HasMaxLength(4000);
            entity.Property(e => e.CurrencyCode).HasMaxLength(10);
            entity.Property(e => e.Notes).HasMaxLength(2000);
            entity.Property(e => e.RejectionReason).HasMaxLength(500);
            entity.Property(e => e.SubTotal).HasPrecision(18, 2);
            entity.Property(e => e.TaxPercent).HasPrecision(5, 2);
            entity.Property(e => e.TaxAmount).HasPrecision(18, 2);
            entity.Property(e => e.TotalAmount).HasPrecision(18, 2);
            entity.Property(e => e.DiscountPercent).HasPrecision(5, 2);
            entity.Property(e => e.DiscountAmount).HasPrecision(18, 2);
            entity.Property(e => e.ExchangeRate).HasPrecision(18, 6);
            entity.HasOne(e => e.Customer).WithMany().HasForeignKey(e => e.CustomerId).OnDelete(DeleteBehavior.SetNull);
            entity.HasOne(e => e.Enquiry).WithMany().HasForeignKey(e => e.EnquiryId).OnDelete(DeleteBehavior.SetNull);
            entity.HasMany(e => e.Lines).WithOne(l => l.Quotation).HasForeignKey(l => l.QuotationId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<ServiceQuotationLine>(entity =>
        {
            entity.ToTable("ServiceQuotationLines");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.QuotationId });
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.Unit).HasMaxLength(50);
            entity.Property(e => e.Quantity).HasPrecision(18, 4);
            entity.Property(e => e.UnitPrice).HasPrecision(18, 2);
            entity.Property(e => e.LineTotal).HasPrecision(18, 2);
            entity.Property(e => e.DiscountPercent).HasPrecision(5, 2);
            entity.Property(e => e.TaxPercent).HasPrecision(5, 2);
        });

        modelBuilder.Entity<ServiceContract>(entity =>
        {
            entity.ToTable("ServiceContracts");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => new { e.TenantId, e.ContractNumber }).IsUnique();
            entity.HasIndex(e => new { e.TenantId, e.Status });
            entity.HasIndex(e => new { e.TenantId, e.CustomerId });
            entity.HasIndex(e => new { e.TenantId, e.IsActive });
            entity.Property(e => e.ContractNumber).HasMaxLength(50).IsRequired();
            entity.Property(e => e.ProjectName).HasMaxLength(200);
            entity.Property(e => e.ScopeOfWork).HasMaxLength(4000);
            entity.Property(e => e.TermsAndConditions).HasMaxLength(4000);
            entity.Property(e => e.PaymentTerms).HasMaxLength(1000);
            entity.Property(e => e.SLATerms).HasMaxLength(2000);
            entity.Property(e => e.Notes).HasMaxLength(2000);
            entity.Property(e => e.CurrencyCode).HasMaxLength(10);
            entity.Property(e => e.CancellationReason).HasMaxLength(500);
            entity.Property(e => e.ContractValue).HasPrecision(18, 2);
            entity.Property(e => e.RecurringAmount).HasPrecision(18, 2);
            entity.HasOne(e => e.Customer).WithMany().HasForeignKey(e => e.CustomerId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.Quotation).WithMany().HasForeignKey(e => e.QuotationId).OnDelete(DeleteBehavior.SetNull);
            entity.HasMany(e => e.TaskLogs).WithOne(t => t.ServiceContract).HasForeignKey(t => t.ServiceContractId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<ServiceTaskLog>(entity =>
        {
            entity.ToTable("ServiceTaskLogs");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.ServiceContractId).HasColumnName("ContractId");
            entity.HasIndex(e => new { e.TenantId, e.ServiceContractId });
            entity.HasIndex(e => new { e.TenantId, e.TaskDate });
            entity.HasIndex(e => new { e.TenantId, e.EmployeeId });
            entity.HasIndex(e => new { e.TenantId, e.ApprovalStatus });
            entity.Property(e => e.TaskType).HasColumnName("TaskTitle").HasMaxLength(100);
            entity.Property(e => e.Description).HasMaxLength(2000);
            entity.Property(e => e.PerformedByUserId).HasColumnName("AssignedToUserId");
        });

        modelBuilder.Entity<CustomerModuleAssignment>(entity =>
        {
            entity.ToTable("CustomerModuleAssignments");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.CustomerId });
            entity.HasIndex(e => new { e.TenantId, e.CustomerId, e.ModuleId }).IsUnique();
        });

        modelBuilder.Entity<SupplierModuleAssignment>(entity =>
        {
            entity.ToTable("SupplierModuleAssignments");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.SupplierId });
            entity.HasIndex(e => new { e.TenantId, e.SupplierId, e.ModuleId }).IsUnique();
        });

        modelBuilder.Entity<Campaign>(entity =>
        {
            entity.ToTable("Campaigns");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.Status });
            entity.HasIndex(e => new { e.TenantId, e.StartDate });
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(2000);
            entity.Property(e => e.TargetAudience).HasMaxLength(500);
            entity.Property(e => e.Goals).HasMaxLength(1000);
            entity.Property(e => e.Notes).HasMaxLength(2000);
            entity.Property(e => e.Budget).HasPrecision(18, 2);
            entity.Property(e => e.SpentAmount).HasPrecision(18, 2);
        });

        modelBuilder.Entity<ClientReport>(entity =>
        {
            entity.ToTable("ClientReports");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.ServiceContractId });
            entity.HasIndex(e => new { e.TenantId, e.CustomerId });
            entity.HasIndex(e => new { e.TenantId, e.Status });
            entity.Property(e => e.ReportTitle).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Summary).HasMaxLength(4000);
            entity.Property(e => e.Achievements).HasMaxLength(4000);
            entity.Property(e => e.Issues).HasMaxLength(4000);
            entity.Property(e => e.NextSteps).HasMaxLength(4000);
            entity.Property(e => e.SentTo).HasMaxLength(500);
            entity.Property(e => e.HoursWorked).HasPrecision(10, 2);
            entity.Property(e => e.BillableAmount).HasPrecision(18, 2);
            entity.HasOne(e => e.ServiceContract).WithMany().HasForeignKey(e => e.ServiceContractId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ServiceCategory>(entity =>
        {
            entity.ToTable("ServiceCategories");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
        });

        modelBuilder.Entity<ServiceType>(entity =>
        {
            entity.ToTable("ServiceTypes");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.ServiceCategoryId });
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.HasOne(e => e.ServiceCategory).WithMany(c => c.ServiceTypes).HasForeignKey(e => e.ServiceCategoryId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ServiceName>(entity =>
        {
            entity.ToTable("ServiceNames");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.ServiceTypeId });
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(1000);
            entity.HasOne(e => e.ServiceType).WithMany(t => t.ServiceNames).HasForeignKey(e => e.ServiceTypeId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ServiceDetail>(entity =>
        {
            entity.ToTable("ServiceDetails");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.ServiceNameId });
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(2000);
            entity.Property(e => e.UnitOfMeasure).HasMaxLength(50);
            entity.Property(e => e.DefaultRate).HasPrecision(18, 2);
            entity.HasOne(e => e.ServiceName).WithMany(n => n.ServiceDetails).HasForeignKey(e => e.ServiceNameId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RateChart>(entity =>
        {
            entity.ToTable("RateCharts");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.ServiceDetailId });
            entity.HasIndex(e => new { e.TenantId, e.Code }).IsUnique();
            entity.Property(e => e.Code).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
            entity.Property(e => e.Description).HasMaxLength(500);
            entity.Property(e => e.CostPrice).HasPrecision(18, 2);
            entity.Property(e => e.SellingPrice).HasPrecision(18, 2);
            entity.Property(e => e.MinQuantity).HasPrecision(18, 4);
            entity.Property(e => e.MaxQuantity).HasPrecision(18, 4);
            entity.HasOne(e => e.ServiceDetail).WithMany(d => d.RateCharts).HasForeignKey(e => e.ServiceDetailId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(e => e.Currency).WithMany().HasForeignKey(e => e.CurrencyId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<LogisticsQuotation>(entity =>
        {
            entity.ToTable("LogisticsQuotations");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.QuotationNumber }).IsUnique();
            entity.HasIndex(e => new { e.TenantId, e.Status });
            entity.HasMany(e => e.Lines).WithOne(l => l.Quotation).HasForeignKey(l => l.QuotationId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<QuotationLine>(entity =>
        {
            entity.ToTable("QuotationLines");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.TenantId);
            entity.HasIndex(e => new { e.TenantId, e.QuotationId });
        });
    }
}

public class ServiceCategory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public CatalogItemType ItemType { get; set; } = CatalogItemType.Service;
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<ServiceType> ServiceTypes { get; set; } = new List<ServiceType>();
}

public class ServiceType
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid ServiceCategoryId { get; set; }
    public ServiceCategory? ServiceCategory { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<ServiceName> ServiceNames { get; set; } = new List<ServiceName>();
}

public class ServiceName
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid ServiceTypeId { get; set; }
    public ServiceType? ServiceType { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<ServiceDetail> ServiceDetails { get; set; } = new List<ServiceDetail>();
}

public class ServiceDetail
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid ServiceNameId { get; set; }
    public ServiceName? ServiceName { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public string? UnitOfMeasure { get; set; }
    public decimal? DefaultRate { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<RateChart> RateCharts { get; set; } = new List<RateChart>();
}

public enum RateType
{
    Retail = 0,
    Wholesale = 1,
    Special = 2
}

public enum RecurringType
{
    OneTime = 0,
    Hourly = 1,
    Daily = 2,
    Weekly = 3,
    Monthly = 4,
    Yearly = 5
}

public class RateChart
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid ServiceDetailId { get; set; }
    public ServiceDetail? ServiceDetail { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public RateType RateType { get; set; } = RateType.Retail;
    public RecurringType RecurringType { get; set; } = RecurringType.OneTime;
    public Guid? CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal CostPrice { get; set; }
    public decimal SellingPrice { get; set; }
    public decimal? MinQuantity { get; set; }
    public decimal? MaxQuantity { get; set; }
    public DateTime? EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class TenantModule
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid ModuleId { get; set; }
    public TenantModuleStatus Status { get; set; }
    public int LicenseTier { get; set; }
    public string? EnabledFeaturesJson { get; set; }
    public DateTimeOffset? EnabledOn { get; set; }
    public Guid? EnabledByUserId { get; set; }
    public DateTimeOffset? DisabledOn { get; set; }
    public Guid? DisabledByUserId { get; set; }
    public DateTimeOffset? LicenseExpiresAt { get; set; }
    public string? LicenseKey { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
    
    public bool IsEnabled => Status == TenantModuleStatus.Enabled;
}

public enum TenantModuleStatus
{
    Disabled = 0,
    Enabled = 1,
    Expired = 2,
    Suspended = 3,
    ReadOnly = 4
}


public class Module
{
    public Guid Id { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public int DisplayOrder { get; set; }
    public bool IsActive { get; set; }
    public bool IsAllModules { get; set; }
    public Guid TenantId { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class ModuleCatalog
{
    public Guid Id { get; set; }
    public required string ModuleCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public required string Version { get; set; }
    public string? IconClass { get; set; }
    public string? DependsOn { get; set; }
    public int Category { get; set; }
    public bool IsCore { get; set; }
    public bool IsActive { get; set; }
    public bool RequiresLicense { get; set; }
    public int DisplayOrder { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
}

public class Tenant
{
    public Guid Id { get; set; }
    public required string Name { get; set; }
    public string? Subdomain { get; set; }
    public string? Address { get; set; }
    public string? State { get; set; }
    public string? Country { get; set; }
    public string? City { get; set; }
    public string? PostalCode { get; set; }
    public int TaxSystem { get; set; }
    public string? GSTIN { get; set; }
    public string? TRN { get; set; }
    public string? EIN { get; set; }
    public Guid? BaseCurrencyId { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? SubscriptionExpiresAt { get; set; }
    public bool EnableMultipleCalendars { get; set; }
    public bool IsDemo { get; set; }
    public bool HasConfiguredModules { get; set; }
    public string? AdminEmail { get; set; }
    public DateTime? EmailVerifiedAt { get; set; }
    public DateTime? TrialStartDate { get; set; }
    public DateTime? TrialEndDate { get; set; }
    public SubscriptionStatus SubscriptionStatus { get; set; } = SubscriptionStatus.Trial;
    public string? Notes { get; set; }
    public string? RegistrationOrigin { get; set; }
}

public enum SubscriptionStatus
{
    Trial = 0,
    Active = 1,
    Expired = 2,
    Cancelled = 3,
    Suspended = 4
}

public class SuperAdmin
{
    public Guid Id { get; set; }
    public required string Email { get; set; }
    public required string PasswordHash { get; set; }
    public required string Name { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? LastLoginAt { get; set; }
}

public class SubscriptionPlan
{
    public Guid Id { get; set; }
    public required string Name { get; set; }
    public required string Code { get; set; }
    public string? Description { get; set; }
    public decimal PriceINR { get; set; }
    public decimal PriceUSD { get; set; }
    public int DurationMonths { get; set; } = 1;
    public int MaxUsers { get; set; } = 5;
    public int MaxBranches { get; set; } = 1;
    public string? IncludedModules { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class SubscriptionPayment
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid? PlanId { get; set; }
    public required string RazorpayOrderId { get; set; }
    public string? RazorpayPaymentId { get; set; }
    public string? RazorpaySignature { get; set; }
    public decimal Amount { get; set; }
    public required string Currency { get; set; }
    public PaymentStatus Status { get; set; } = PaymentStatus.Pending;
    public string? PaymentMethod { get; set; }
    public string? CustomerEmail { get; set; }
    public string? CustomerPhone { get; set; }
    public string? FailureReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }
    public string? Notes { get; set; }
}

public enum PaymentStatus
{
    Pending = 0,
    Completed = 1,
    Failed = 2,
    Refunded = 3
}

public class EmailVerificationToken
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Email { get; set; }
    public required string TokenHash { get; set; }
    public DateTime ExpiresAt { get; set; }
    public DateTime? UsedAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public TokenPurpose Purpose { get; set; } = TokenPurpose.EmailVerification;
}

public enum TokenPurpose
{
    EmailVerification = 0,
    PasswordReset = 1
}

public class Branch
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Country { get; set; }
    public string? State { get; set; }
    public string? City { get; set; }
    public string? Address { get; set; }
    public string? PostalCode { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? TaxRegistrationNumber { get; set; }
    public string? CurrencyCode { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public bool IsHeadOffice { get; set; }
    public bool IsHub { get; set; }
    public bool EnableLogin { get; set; } = true;
    public bool IsActive { get; set; } = true;
    public bool IsDefault { get; set; }
    public int SortOrder { get; set; }
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class UserBranch
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public Guid BranchId { get; set; }
    public Guid TenantId { get; set; }
    public bool IsDefault { get; set; }
    public DateTime AssignedAt { get; set; } = DateTime.UtcNow;
}

public class FinancialPeriod
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string? PeriodName { get; set; }
    public int FiscalYear { get; set; }
    public int PeriodNumber { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public int Status { get; set; }
    public bool IsYearEnd { get; set; }
    public DateTime? OpenedDate { get; set; }
    public Guid? OpenedByUserId { get; set; }
    public DateTime? ClosedDate { get; set; }
    public Guid? ClosedByUserId { get; set; }
    public DateTime? LockedDate { get; set; }
    public Guid? LockedByUserId { get; set; }
    public string? Notes { get; set; }
    public Guid? PreviousPeriodId { get; set; }
    public Guid? NextPeriodId { get; set; }
    public Guid? FinancialCalendarId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class FinancialCalendar
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Name { get; set; } = "";
    public string Code { get; set; } = "";
    public int Type { get; set; } // 0=Gregorian, 1=Fiscal, 2=Islamic, 3=Custom
    public int StartMonth { get; set; } = 1;
    public string? CountryCode { get; set; }
    public bool IsPrimary { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Description { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class Currency
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string Symbol { get; set; } = "";
    public decimal ExchangeRate { get; set; } = 1.0m;
    public int DecimalPlaces { get; set; } = 2;
    public bool IsBaseCurrency { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class ExchangeRate
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string FromCurrency { get; set; }
    public required string ToCurrency { get; set; }
    public decimal Rate { get; set; }
    public DateTime EffectiveDate { get; set; }
    public string Source { get; set; } = "Manual";
    public DateTime FetchedAt { get; set; } = DateTime.UtcNow;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}


public class Project
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string Description { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class TaxCode
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public string? Description { get; set; }
    public decimal Rate { get; set; }
    public TaxType TaxType { get; set; } = TaxType.Simple;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class VoucherNumbering
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public VoucherTransactionType TransactionType { get; set; }
    public required string Prefix { get; set; }
    public int NextNumber { get; set; } = 1;
    public int NumberLength { get; set; } = 6;
    public required string Separator { get; set; }
    public bool IsLocked { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public enum TaxType
{
    Simple = 0,
    VAT = 1,
    GST = 2
}

public enum VoucherTransactionType
{
    JournalEntry = 0,
    SalesInvoice = 1,
    SalesReceipt = 2,
    CreditNote = 3,
    PurchaseInvoice = 4,
    PurchasePayment = 5,
    DebitNote = 6,
    CashReceipt = 7,
    CashPayment = 8,
    BankTransfer = 9,
    StockAdjustment = 10,
    StockTransfer = 11
}

public enum FinancialPeriodStatus
{
    NotOpened = 0,
    Open = 1,
    SoftClosed = 2,
    HardClosed = 3,
    Archived = 4
}

public class Country
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public string? Code3 { get; set; }
    public required string Name { get; set; }
    public string? IsoCode2 { get; set; }
    public string? IsoCode3 { get; set; }
    public string? PhoneCode { get; set; }
    public string? CurrencyCode { get; set; }
    public string? Region { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class State
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid CountryId { get; set; }
    public Country? Country { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Region { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class City
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid StateId { get; set; }
    public State? State { get; set; }
    public required string Name { get; set; }
    public string? AreaCode { get; set; }
    public string? TimeZone { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class PostalCode
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid CityId { get; set; }
    public required string Code { get; set; }
    public string? AreaName { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class AssetCategory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public AssetCategoryType CategoryType { get; set; }
    public Guid? ParentCategoryId { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class Asset
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid CategoryId { get; set; }
    public required string AssetCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public string? SerialNumber { get; set; }
    public string? Make { get; set; }
    public string? Model { get; set; }
    public DateTime? PurchaseDate { get; set; }
    public decimal PurchasePrice { get; set; }
    public decimal CurrentValue { get; set; }
    public decimal DepreciationRate { get; set; }
    public string? Location { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public Guid? AssignedToUserId { get; set; }
    public AssetStatus Status { get; set; } = AssetStatus.Active;
    public DateTime? WarrantyExpiryDate { get; set; }
    public DateTime? LastMaintenanceDate { get; set; }
    public DateTime? NextMaintenanceDate { get; set; }
    public string? Notes { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public enum AssetCategoryType
{
    Vehicles = 0,
    OfficeEquipment = 1,
    FurnitureFixtures = 2,
    ToolsAccessories = 3,
    PlantMachineries = 4,
    ITEquipment = 5,
    Other = 99
}

public enum AssetStatus
{
    Active = 0,
    UnderMaintenance = 1,
    Disposed = 2,
    Sold = 3,
    Lost = 4,
    Damaged = 5
}

public class DocumentCategory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public DocumentType CategoryType { get; set; }
    public bool RequiresExpiry { get; set; }
    public int? ReminderDaysBefore { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class Document
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid CategoryId { get; set; }
    public DocumentType DocumentType { get; set; }
    public Guid? RelatedEntityId { get; set; }
    public required string DocumentName { get; set; }
    public string? Description { get; set; }
    public string? FileName { get; set; }
    public string? FilePath { get; set; }
    public string? FileType { get; set; }
    public long? FileSize { get; set; }
    public DateTime? IssueDate { get; set; }
    public DateTime? ExpiryDate { get; set; }
    public bool IsExpired { get; set; }
    public DateTime? ReminderDate { get; set; }
    public bool ReminderSent { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
}

public class Alert
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public AlertType AlertType { get; set; }
    public required string Title { get; set; }
    public string? Message { get; set; }
    public AlertPriority Priority { get; set; }
    public AlertStatus Status { get; set; }
    public Guid? RelatedEntityId { get; set; }
    public string? RelatedEntityType { get; set; }
    public Guid? AssignedToUserId { get; set; }
    public DateTime? DueDate { get; set; }
    public DateTime? AcknowledgedDate { get; set; }
    public Guid? AcknowledgedByUserId { get; set; }
    public DateTime? ResolvedDate { get; set; }
    public Guid? ResolvedByUserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class ApprovalWorkflow
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public ApprovalWorkflowType WorkflowType { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public bool RequireAllApprovers { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class ApprovalStep
{
    public Guid Id { get; set; }
    public Guid WorkflowId { get; set; }
    public Guid TenantId { get; set; }
    public int StepOrder { get; set; }
    public required string StepName { get; set; }
    public Guid? ApproverUserId { get; set; }
    public Guid? ApproverRoleId { get; set; }
    public bool CanDelegate { get; set; }
    public int? TimeoutHours { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public enum DocumentType
{
    Employee = 0,
    Office = 1,
    Asset = 2,
    Vendor = 3,
    Customer = 4,
    Other = 99
}

public enum AlertType
{
    PDCReminder = 0,
    DocumentExpiry = 1,
    UserNotification = 2,
    DeferredRevenue = 3,
    Custom = 4,
    SystemAlert = 5
}

public enum AlertPriority
{
    Low = 0,
    Medium = 1,
    High = 2,
    Critical = 3
}

public enum AlertStatus
{
    Pending = 0,
    Acknowledged = 1,
    InProgress = 2,
    Resolved = 3,
    Dismissed = 4
}

public enum ApprovalWorkflowType
{
    JournalEntry = 0,
    SalesOrder = 1,
    PurchaseOrder = 2,
    LeaveRequest = 3,
    LoanRequest = 4,
    ExpenseClaim = 5,
    PaymentVoucher = 6,
    Custom = 99
}

public class Permission
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Module { get; set; }
    public string? Description { get; set; }
    public bool IsSystemPermission { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class Role
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsSystemRole { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class RolePermission
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid RoleId { get; set; }
    public Guid PermissionId { get; set; }
    public bool CanCreate { get; set; }
    public bool CanRead { get; set; }
    public bool CanUpdate { get; set; }
    public bool CanDelete { get; set; }
    public DateTime AssignedAt { get; set; } = DateTime.UtcNow;
    public Guid? AssignedByUserId { get; set; }
}

public class UserRole
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid UserId { get; set; }
    public Guid RoleId { get; set; }
    public DateTime AssignedAt { get; set; } = DateTime.UtcNow;
    public Guid? AssignedByUserId { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public bool IsActive { get; set; } = true;
}

public class AuditLog
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid? UserId { get; set; }
    public string? UserEmail { get; set; }
    public required string EntityType { get; set; }
    public Guid? EntityId { get; set; }
    public required string Action { get; set; }
    public string? OldValues { get; set; }
    public string? NewValues { get; set; }
    public string? IpAddress { get; set; }
    public string? UserAgent { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
}

public class GridPreference
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid UserId { get; set; }
    public required string GridName { get; set; }
    public required string ColumnSettings { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public enum AccountType
{
    Asset = 1,
    Liability = 2,
    Equity = 3,
    Revenue = 4,
    Expense = 5
}

public class AccountClassification
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class ChartOfAccount
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string? AccountCode { get; set; }
    public required string AccountName { get; set; }
    public AccountType AccountType { get; set; }
    public Guid? ParentAccountId { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public bool AllowPosting { get; set; } = true;
    public Guid? AccountClassificationId { get; set; }
    public AccountClassification? AccountClassification { get; set; }
    public int ControlAccountType { get; set; }
    public bool IsSystemAccount { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class Brand
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class Colour
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class Size
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class ItemGroup
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public enum InventoryLocationType
{
    Warehouse = 0,
    Store = 1,
    ProductionFloor = 2,
    Transit = 3,
    Quarantine = 4,
    Scrap = 5
}

public class InventoryLocation
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public InventoryLocationType LocationType { get; set; }
    public Guid? BranchId { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class CustomerCategory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class SupplierCategory
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public enum CustomerType
{
    Cash = 0,
    Credit = 1,
    WalkIn = 2
}

public enum SupplierType
{
    Cash = 0,
    Credit = 1
}

public enum CreditApprovalStatus
{
    None = 0,
    Pending = 1,
    Approved = 2,
    Rejected = 3
}

public class Customer
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid? BranchId { get; set; }
    public Branch? Branch { get; set; }
    public required string CustomerCode { get; set; }
    public required string Name { get; set; }
    public string? ContactName { get; set; }
    public string? Address { get; set; }
    public string? Country { get; set; }
    public string? State { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public Guid? PostalCodeId { get; set; }
    public required string Email { get; set; }
    public required string Phone { get; set; }
    public string? TaxIdNumber { get; set; }
    public Guid? DefaultCurrencyId { get; set; }
    public Currency? DefaultCurrency { get; set; }
    public Guid? PreferredCurrencyId { get; set; }
    public Currency? PreferredCurrency { get; set; }
    public Guid? DefaultARAccountId { get; set; }
    public ChartOfAccount? DefaultARAccount { get; set; }
    public CustomerType CustomerType { get; set; }
    public Guid? CustomerCategoryId { get; set; }
    public CustomerCategory? CustomerCategory { get; set; }
    public decimal CreditLimit { get; set; }
    public decimal RequestedCreditLimit { get; set; }
    public CreditApprovalStatus CreditApprovalStatus { get; set; }
    public string? CreditRequestNotes { get; set; }
    public string? CreditApprovalNotes { get; set; }
    public Guid? CreditRequestedByUserId { get; set; }
    public DateTime? CreditRequestedDate { get; set; }
    public Guid? CreditApprovedByUserId { get; set; }
    public DateTime? CreditApprovedDate { get; set; }
    public int PaymentTermsDays { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class Supplier
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string SupplierCode { get; set; }
    public required string Name { get; set; }
    public string? Address { get; set; }
    public string? Country { get; set; }
    public string? State { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public Guid? PostalCodeId { get; set; }
    public required string Email { get; set; }
    public required string Phone { get; set; }
    public string? TaxIdNumber { get; set; }
    public Guid? DefaultCurrencyId { get; set; }
    public Currency? DefaultCurrency { get; set; }
    public Guid? DefaultAPAccountId { get; set; }
    public ChartOfAccount? DefaultAPAccount { get; set; }
    public SupplierType SupplierType { get; set; }
    public Guid? SupplierCategoryId { get; set; }
    public SupplierCategory? SupplierCategory { get; set; }
    public decimal CreditLimit { get; set; }
    public decimal RequestedCreditLimit { get; set; }
    public CreditApprovalStatus CreditApprovalStatus { get; set; }
    public string? CreditRequestNotes { get; set; }
    public string? CreditApprovalNotes { get; set; }
    public Guid? CreditRequestedByUserId { get; set; }
    public DateTime? CreditRequestedDate { get; set; }
    public Guid? CreditApprovedByUserId { get; set; }
    public DateTime? CreditApprovedDate { get; set; }
    public int PaymentTermsDays { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class SupplierChargeType
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid SupplierId { get; set; }
    public Supplier? Supplier { get; set; }
    public Guid ChargeTypeId { get; set; }
    public ChargeType? ChargeType { get; set; }
    public bool IsPreferred { get; set; } = false;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class UserMenuFavourite
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid UserId { get; set; }
    public string ModuleCode { get; set; } = string.Empty;
    public string MenuCode { get; set; } = string.Empty;
    public string MenuName { get; set; } = string.Empty;
    public string MenuIcon { get; set; } = string.Empty;
    public string MenuUrl { get; set; } = string.Empty;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public enum ItemType
{
    Inventory = 0,
    NonInventory = 1,
    Service = 2,
    Kit = 3
}

public class Item
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public required string ItemCode { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public ItemType ItemType { get; set; }
    public Guid? ItemGroupId { get; set; }
    public ItemGroup? ItemGroup { get; set; }
    public Guid? BrandId { get; set; }
    public Brand? Brand { get; set; }
    public Guid? ColourId { get; set; }
    public Colour? Colour { get; set; }
    public Guid? SizeId { get; set; }
    public Size? Size { get; set; }
    public string? UnitOfMeasure { get; set; }
    public decimal CostPrice { get; set; }
    public decimal SellingPrice { get; set; }
    public decimal ReorderLevel { get; set; }
    public decimal ReorderQuantity { get; set; }
    public bool TrackInventory { get; set; } = true;
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public enum SalesEnquiryStatus
{
    Draft = 0,
    Submitted = 1,
    Converted = 2,
    Cancelled = 3
}

public class SalesEnquiry
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string EnquiryNumber { get; set; } = string.Empty;
    public DateTime EnquiryDate { get; set; } = DateTime.UtcNow;
    public Guid CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public Guid CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1.0m;
    public string ContactPerson { get; set; } = string.Empty;
    public string ContactEmail { get; set; } = string.Empty;
    public string ContactPhone { get; set; } = string.Empty;
    public DateTime ValidUntil { get; set; }
    public SalesEnquiryStatus Status { get; set; } = SalesEnquiryStatus.Draft;
    public string Notes { get; set; } = string.Empty;
    public decimal EstimatedValue { get; set; }
    public bool IsVoided { get; set; } = false;
    public Guid? VoidedBy { get; set; }
    public DateTime? VoidedDate { get; set; }
    public string VoidReason { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<SalesEnquiryLine> Lines { get; set; } = new List<SalesEnquiryLine>();
}

public class SalesEnquiryLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid SalesEnquiryId { get; set; }
    public SalesEnquiry? SalesEnquiry { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal EstimatedUnitPrice { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public enum SalesQuotationStatus
{
    Draft = 0,
    Submitted = 1,
    Accepted = 2,
    Rejected = 3,
    Cancelled = 4
}

public class SalesQuotation
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string QuotationNumber { get; set; } = string.Empty;
    public DateTime QuotationDate { get; set; } = DateTime.UtcNow;
    public DateTime ValidUntil { get; set; }
    public Guid CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public Guid? SalesEnquiryId { get; set; }
    public SalesEnquiry? SalesEnquiry { get; set; }
    public Guid CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1.0m;
    public string ContactPerson { get; set; } = string.Empty;
    public string ContactEmail { get; set; } = string.Empty;
    public string ContactPhone { get; set; } = string.Empty;
    public SalesQuotationStatus Status { get; set; } = SalesQuotationStatus.Draft;
    public string Terms { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public DateTime? SubmittedDate { get; set; }
    public DateTime? ResponseDate { get; set; }
    public bool IsVoided { get; set; } = false;
    public Guid? VoidedBy { get; set; }
    public DateTime? VoidedDate { get; set; }
    public string VoidReason { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<SalesQuotationLine> Lines { get; set; } = new List<SalesQuotationLine>();
}

public class SalesQuotationLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid SalesQuotationId { get; set; }
    public SalesQuotation? SalesQuotation { get; set; }
    public Guid? SalesEnquiryLineId { get; set; }
    public SalesEnquiryLine? SalesEnquiryLine { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public Guid? TaxCodeId { get; set; }
    public TaxCode? TaxCode { get; set; }
    public decimal LineTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public enum SalesOrderStatus
{
    Draft = 0,
    Approved = 1,
    PartiallyDelivered = 2,
    FullyDelivered = 3,
    Cancelled = 4
}

public class SalesOrder
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string SONumber { get; set; } = string.Empty;
    public DateTime SODate { get; set; } = DateTime.UtcNow;
    public DateTime ExpectedDate { get; set; }
    public Guid CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public Guid? WarehouseId { get; set; }
    public Guid CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1.0m;
    public SalesOrderStatus Status { get; set; } = SalesOrderStatus.Draft;
    public string Notes { get; set; } = string.Empty;
    public bool IsVoided { get; set; } = false;
    public Guid? VoidedBy { get; set; }
    public DateTime? VoidedDate { get; set; }
    public string VoidReason { get; set; } = string.Empty;
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<SalesOrderLine> Lines { get; set; } = new List<SalesOrderLine>();
}

public class SalesOrderLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid SalesOrderId { get; set; }
    public SalesOrder? SalesOrder { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public decimal OrderedQuantity { get; set; }
    public decimal DeliveredQuantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public enum SalesOrderRequestStatus
{
    Draft = 0,
    Submitted = 1,
    Approved = 2,
    Rejected = 3,
    Cancelled = 4,
    ConvertedToOrder = 5
}

public class SalesOrderRequest
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string RequestNumber { get; set; } = string.Empty;
    public DateTime RequestDate { get; set; } = DateTime.UtcNow;
    public Guid CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public Guid? SalesQuotationId { get; set; }
    public SalesQuotation? SalesQuotation { get; set; }
    public Guid CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1.0m;
    public string ContactPerson { get; set; } = string.Empty;
    public string ContactEmail { get; set; } = string.Empty;
    public string ContactPhone { get; set; } = string.Empty;
    public DateTime ExpectedDeliveryDate { get; set; }
    public SalesOrderRequestStatus Status { get; set; } = SalesOrderRequestStatus.Draft;
    public string Terms { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public string RequestedBy { get; set; } = string.Empty;
    public string ApprovalNotes { get; set; } = string.Empty;
    public Guid? ApprovedBy { get; set; }
    public DateTime? ApprovedDate { get; set; }
    public Guid? RejectedBy { get; set; }
    public DateTime? RejectedDate { get; set; }
    public string RejectionReason { get; set; } = string.Empty;
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public DateTime? SubmittedDate { get; set; }
    public bool IsVoided { get; set; } = false;
    public Guid? VoidedBy { get; set; }
    public DateTime? VoidedDate { get; set; }
    public string VoidReason { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<SalesOrderRequestLine> Lines { get; set; } = new List<SalesOrderRequestLine>();
}

public class SalesOrderRequestLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid SalesOrderRequestId { get; set; }
    public SalesOrderRequest? SalesOrderRequest { get; set; }
    public Guid? SalesQuotationLineId { get; set; }
    public SalesQuotationLine? SalesQuotationLine { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public Guid? TaxCodeId { get; set; }
    public TaxCode? TaxCode { get; set; }
    public decimal LineTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class Warehouse
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public Guid? BranchId { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string DeactivationReason { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class DeliveryNote
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string DNNumber { get; set; } = string.Empty;
    public DateTime DNDate { get; set; } = DateTime.UtcNow;
    public Guid? SalesOrderId { get; set; }
    public SalesOrder? SalesOrder { get; set; }
    public Guid? WarehouseId { get; set; }
    public Warehouse? Warehouse { get; set; }
    public string Notes { get; set; } = string.Empty;
    public Guid? JournalEntryId { get; set; }
    public bool IsVoided { get; set; } = false;
    public Guid? VoidedBy { get; set; }
    public DateTime? VoidedDate { get; set; }
    public string VoidReason { get; set; } = string.Empty;
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<DeliveryNoteLine> Lines { get; set; } = new List<DeliveryNoteLine>();
}

public class DeliveryNoteLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid DeliveryNoteId { get; set; }
    public DeliveryNote? DeliveryNote { get; set; }
    public Guid? SalesOrderLineId { get; set; }
    public SalesOrderLine? SalesOrderLine { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public decimal DeliveredQuantity { get; set; }
    public decimal UnitCost { get; set; }
    public decimal TotalCost { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public enum SalesInvoiceStatus
{
    Draft = 0,
    Posted = 1,
    PartiallyPaid = 2,
    Paid = 3,
    Cancelled = 4
}

public class SalesInvoice
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public int InvoiceType { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public DateTime InvoiceDate { get; set; } = DateTime.UtcNow;
    public DateTime DueDate { get; set; }
    public Guid CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string CustomerPhone { get; set; } = string.Empty;
    public string CustomerAddress { get; set; } = string.Empty;
    public Guid CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1.0m;
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal BaseSubTotal { get; set; }
    public decimal BaseTaxAmount { get; set; }
    public decimal BaseTotalAmount { get; set; }
    public decimal PaidAmount { get; set; }
    public decimal BalanceAmount { get; set; }
    public SalesInvoiceStatus Status { get; set; } = SalesInvoiceStatus.Draft;
    public string Notes { get; set; } = string.Empty;
    public bool IsVoided { get; set; } = false;
    public DateTime? VoidedDate { get; set; }
    public Guid? VoidedByUserId { get; set; }
    public string VoidReason { get; set; } = string.Empty;
    public Guid? JournalEntryId { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public Guid? ModuleId { get; set; }
    public ModuleCatalog? Module { get; set; }
    public string? ModuleCode { get; set; }
    public Guid? ContractId { get; set; }
    public ServiceContract? Contract { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<SalesInvoiceLine> Lines { get; set; } = new List<SalesInvoiceLine>();
}

public class SalesInvoiceLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid SalesInvoiceId { get; set; }
    public SalesInvoice? SalesInvoice { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }
    public Guid? TaxCodeId { get; set; }
    public TaxCode? TaxCode { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal CGSTRate { get; set; }
    public decimal CGSTAmount { get; set; }
    public decimal SGSTRate { get; set; }
    public decimal SGSTAmount { get; set; }
    public decimal IGSTRate { get; set; }
    public decimal IGSTAmount { get; set; }
    public Guid? RevenueAccountId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class SalesReturn
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string ReturnNumber { get; set; } = string.Empty;
    public DateTime ReturnDate { get; set; } = DateTime.UtcNow;
    public Guid SalesInvoiceId { get; set; }
    public SalesInvoice? SalesInvoice { get; set; }
    public Guid CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1.0m;
    public Guid? WarehouseId { get; set; }
    public Warehouse? Warehouse { get; set; }
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal BaseSubTotal { get; set; }
    public decimal BaseTaxAmount { get; set; }
    public decimal BaseTotalAmount { get; set; }
    public string RMANumber { get; set; } = string.Empty;
    public string ReturnReason { get; set; } = string.Empty;
    public int Status { get; set; }
    public bool StockUpdated { get; set; } = false;
    public bool GLPosted { get; set; } = false;
    public string Notes { get; set; } = string.Empty;
    public bool IsVoided { get; set; } = false;
    public DateTime? VoidedDate { get; set; }
    public Guid? VoidedByUserId { get; set; }
    public string VoidReason { get; set; } = string.Empty;
    public Guid? JournalEntryId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<SalesReturnLine> Lines { get; set; } = new List<SalesReturnLine>();
}

public class SalesReturnLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid SalesReturnId { get; set; }
    public SalesReturn? SalesReturn { get; set; }
    public Guid? SalesInvoiceLineId { get; set; }
    public SalesInvoiceLine? SalesInvoiceLine { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal ReturnedQuantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }
    public Guid? TaxCodeId { get; set; }
    public TaxCode? TaxCode { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal CGSTRate { get; set; }
    public decimal CGSTAmount { get; set; }
    public decimal SGSTRate { get; set; }
    public decimal SGSTAmount { get; set; }
    public decimal IGSTRate { get; set; }
    public decimal IGSTAmount { get; set; }
    public Guid? RevenueAccountId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class ChargeType
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public int ChargeCategory { get; set; }
    public bool IsRevenue { get; set; }
    public bool IsCost { get; set; }
    public Guid? DefaultRevenueAccountId { get; set; }
    public Guid? DefaultCostAccountId { get; set; }
    public Guid? TaxCodeId { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Description { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class CargoType
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool RequiresTemperatureControl { get; set; }
    public bool IsHazardous { get; set; }
    public string? HazardClass { get; set; }
    public string? UNNumber { get; set; }
    public bool RequiresSpecialHandling { get; set; }
    public string? HandlingInstructions { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class ContainerType
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? ISOCode { get; set; }
    public int? LengthFeet { get; set; }
    public decimal? WidthFeet { get; set; }
    public decimal? HeightFeet { get; set; }
    public decimal? MaxGrossWeightKg { get; set; }
    public decimal? TareWeightKg { get; set; }
    public decimal? MaxPayloadKg { get; set; }
    public decimal? CubicCapacityM3 { get; set; }
    public decimal? TEUEquivalent { get; set; }
    public bool IsReefer { get; set; }
    public bool IsHazmat { get; set; }
    public bool IsOpenTop { get; set; }
    public bool IsFlatRack { get; set; }
    public bool IsTank { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class PurchaseEnquiry
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string EnquiryNumber { get; set; } = string.Empty;
    public DateTime EnquiryDate { get; set; } = DateTime.UtcNow;
    public Guid SupplierId { get; set; }
    public Supplier? Supplier { get; set; }
    public Guid CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1.0m;
    public string? ContactPerson { get; set; }
    public string? ContactEmail { get; set; }
    public string? ContactPhone { get; set; }
    public DateTime ValidUntil { get; set; }
    public string Status { get; set; } = "Draft";
    public string? Notes { get; set; }
    public decimal EstimatedValue { get; set; }
    public bool IsVoided { get; set; } = false;
    public Guid? VoidedBy { get; set; }
    public DateTime? VoidedDate { get; set; }
    public string? VoidReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<PurchaseEnquiryLine> Lines { get; set; } = new List<PurchaseEnquiryLine>();
}

public class PurchaseEnquiryLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid PurchaseEnquiryId { get; set; }
    public PurchaseEnquiry? PurchaseEnquiry { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public decimal Quantity { get; set; }
    public decimal EstimatedUnitPrice { get; set; }
    public decimal LineTotal { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class PurchaseQuotation
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string QuotationNumber { get; set; } = string.Empty;
    public DateTime QuotationDate { get; set; } = DateTime.UtcNow;
    public DateTime ValidUntil { get; set; }
    public Guid SupplierId { get; set; }
    public Supplier? Supplier { get; set; }
    public Guid? PurchaseEnquiryId { get; set; }
    public Guid CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1.0m;
    public string? ContactPerson { get; set; }
    public string? ContactEmail { get; set; }
    public string? ContactPhone { get; set; }
    public string Status { get; set; } = "Draft";
    public string? Terms { get; set; }
    public string? Notes { get; set; }
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public DateTime? SubmittedDate { get; set; }
    public DateTime? ResponseDate { get; set; }
    public bool IsVoided { get; set; } = false;
    public Guid? VoidedBy { get; set; }
    public DateTime? VoidedDate { get; set; }
    public string? VoidReason { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<PurchaseQuotationLine> Lines { get; set; } = new List<PurchaseQuotationLine>();
}

public class PurchaseQuotationLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid PurchaseQuotationId { get; set; }
    public PurchaseQuotation? PurchaseQuotation { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }
    public Guid? TaxCodeId { get; set; }
    public decimal TaxAmount { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class PurchaseOrder
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string PONumber { get; set; } = string.Empty;
    public DateTime PODate { get; set; } = DateTime.UtcNow;
    public DateTime ExpectedDate { get; set; }
    public Guid VendorId { get; set; }
    public Supplier? Vendor { get; set; }
    public Guid WarehouseId { get; set; }
    public Warehouse? Warehouse { get; set; }
    public int Status { get; set; } = 0;
    public string? Notes { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<PurchaseOrderLine> Lines { get; set; } = new List<PurchaseOrderLine>();
}

public class PurchaseOrderLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid PurchaseOrderId { get; set; }
    public PurchaseOrder? PurchaseOrder { get; set; }
    public Guid ItemId { get; set; }
    public Item? Item { get; set; }
    public decimal OrderedQuantity { get; set; }
    public decimal ReceivedQuantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class PurchaseBill
{
    public Guid Id { get; set; }
    public string BillNumber { get; set; } = string.Empty;
    public DateTime BillDate { get; set; }
    public DateTime DueDate { get; set; }
    public Guid VendorId { get; set; }
    public Supplier? Vendor { get; set; }
    public Guid CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1;
    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal PaidAmount { get; set; }
    public decimal BalanceAmount { get; set; }
    public int Status { get; set; }
    public string Notes { get; set; } = string.Empty;
    public bool IsVoided { get; set; }
    public DateTime? VoidedDate { get; set; }
    public Guid? VoidedByUserId { get; set; }
    public string? VoidReason { get; set; }
    public Guid? JournalEntryId { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<PurchaseBillLine> Lines { get; set; } = new List<PurchaseBillLine>();
}

public class PurchaseBillLine
{
    public Guid Id { get; set; }
    public Guid PurchaseBillId { get; set; }
    public PurchaseBill? PurchaseBill { get; set; }
    public Guid? ItemId { get; set; }
    public Item? Item { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; set; }
    public Guid? TaxCodeId { get; set; }
    public TaxCode? TaxCode { get; set; }
    public decimal TaxAmount { get; set; }
    public Guid? ExpenseAccountId { get; set; }
    public ChartOfAccount? ExpenseAccount { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class BankAccount
{
    public Guid Id { get; set; }
    public string AccountNumber { get; set; } = string.Empty;
    public string AccountName { get; set; } = string.Empty;
    public string BankName { get; set; } = string.Empty;
    public string? BranchName { get; set; }
    public string? SwiftCode { get; set; }
    public string? IbanNumber { get; set; }
    public Guid ChartOfAccountId { get; set; }
    public ChartOfAccount? ChartOfAccount { get; set; }
    public Guid? CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal OpeningBalance { get; set; }
    public DateTime OpeningBalanceDate { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeactivatedDate { get; set; }
    public Guid? DeactivatedByUserId { get; set; }
    public string? DeactivationReason { get; set; }
    public string? Notes { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class Vendor
{
    public Guid Id { get; set; }
    public string VendorCode { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string TaxIdNumber { get; set; } = string.Empty;
    public Guid? DefaultCurrencyId { get; set; }
    public Guid? DefaultAPAccountId { get; set; }
    public int PaymentTermsDays { get; set; }
    public bool IsActive { get; set; } = true;
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class CashBankTransaction
{
    public Guid Id { get; set; }
    public string VoucherNo { get; set; } = string.Empty;
    public DateTime VoucherDate { get; set; }
    public int TransactionType { get; set; }
    public int RecPayType { get; set; }
    public int TransactionCategory { get; set; }
    public Guid SourceAccountId { get; set; }
    public ChartOfAccount? SourceAccount { get; set; }
    public Guid? BankAccountId { get; set; }
    public BankAccount? BankAccount { get; set; }
    public decimal TotalAmount { get; set; }
    public string? ChequeNo { get; set; }
    public DateTime? ChequeDate { get; set; }
    public bool IsPDC { get; set; }
    public string? BankName { get; set; }
    public string? BranchName { get; set; }
    public string? ReferenceNo { get; set; }
    public int Status { get; set; }
    public int ReceiptType { get; set; }
    public Guid? CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public Guid? VendorId { get; set; }
    public Vendor? Vendor { get; set; }
    public int DepositStatus { get; set; }
    public DateTime? ActualDepositDate { get; set; }
    public int ClearanceStatus { get; set; }
    public DateTime? ClearanceDate { get; set; }
    public string? BouncedReason { get; set; }
    public DateTime? PostedDate { get; set; }
    public Guid? PostedByUserId { get; set; }
    public bool IsVoided { get; set; }
    public DateTime? VoidedDate { get; set; }
    public Guid? VoidedByUserId { get; set; }
    public string? VoidReason { get; set; }
    public decimal TDSAmount { get; set; }
    public decimal TDSPercent { get; set; }
    public string? TDSCertificateNo { get; set; }
    public Guid? ServiceContractId { get; set; }
    public Guid? JournalEntryId { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public int FiscalYear { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<CashBankTransactionLine> Lines { get; set; } = new List<CashBankTransactionLine>();
}

public class CashBankTransactionLine
{
    public Guid Id { get; set; }
    public Guid CashBankTransactionId { get; set; }
    public CashBankTransaction? CashBankTransaction { get; set; }
    public Guid AccountId { get; set; }
    public ChartOfAccount? Account { get; set; }
    public string? Description { get; set; }
    public decimal Amount { get; set; }
    public Guid? TaxCodeId { get; set; }
    public decimal TaxAmount { get; set; }
    public Guid TenantId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class ServiceEnquiry
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string EnquiryNumber { get; set; } = string.Empty;
    public DateTime EnquiryDate { get; set; }
    public Guid? CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public string? CompanyName { get; set; }
    public string? ContactPerson { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public Truebooks.Platform.Contracts.Enums.EnquiryStatus Status { get; set; }
    public Truebooks.Platform.Contracts.Enums.EnquirySource Source { get; set; }
    public string? SourceDetails { get; set; }
    public Truebooks.Platform.Contracts.Enums.RequirementType RequirementType { get; set; }
    public string? RequirementDetails { get; set; }
    public string? Description { get; set; }
    public decimal EstimatedValue { get; set; }
    public decimal EstimatedBudget { get; set; }
    public string? CurrencyCode { get; set; } = "AED";
    public string? AssignedTo { get; set; }
    public Guid? AssignedToUserId { get; set; }
    public DateTime? FollowUpDate { get; set; }
    public DateTime? NextFollowUpDate { get; set; }
    public DateTime? ExpectedStartDate { get; set; }
    public string? Notes { get; set; }
    public Guid? ConvertedToQuotationId { get; set; }
    public Guid? ConvertedToCustomerId { get; set; }
    public DateTime? ConvertedDate { get; set; }
    public string? LostReason { get; set; }
    public bool IsActive { get; set; } = true;
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<ServiceEnquiryFollowUp> FollowUps { get; set; } = new List<ServiceEnquiryFollowUp>();
}

public class ServiceEnquiryFollowUp
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid ServiceEnquiryId { get; set; }
    public ServiceEnquiry? ServiceEnquiry { get; set; }
    public DateTime FollowUpDate { get; set; }
    public string? FollowUpType { get; set; }
    public string? Notes { get; set; }
    public string? Outcome { get; set; }
    public DateTime? NextFollowUpDate { get; set; }
    public Guid? FollowedByUserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class ServiceQuotation
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string QuotationNumber { get; set; } = string.Empty;
    public int VersionNumber { get; set; } = 1;
    public DateTime QuotationDate { get; set; }
    public DateTime ValidUntil { get; set; }
    public Guid? EnquiryId { get; set; }
    public ServiceEnquiry? Enquiry { get; set; }
    public Guid? CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public string? ProjectName { get; set; }
    public string? ScopeOfWork { get; set; }
    public Truebooks.Platform.Contracts.Enums.QuotationStatus Status { get; set; }
    public string? TermsAndConditions { get; set; }
    public string? PaymentTerms { get; set; }
    public string? Deliverables { get; set; }
    public string? CurrencyCode { get; set; } = "AED";
    public decimal ExchangeRate { get; set; } = 1;
    public decimal SubTotal { get; set; }
    public decimal TaxPercent { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal DiscountPercent { get; set; }
    public decimal DiscountAmount { get; set; }
    public string? Notes { get; set; }
    public DateTime? SentDate { get; set; }
    public DateTime? AcceptedDate { get; set; }
    public string? RejectionReason { get; set; }
    public Guid? ConvertedToContractId { get; set; }
    public Guid? PreparedByUserId { get; set; }
    public Guid? ApprovedByUserId { get; set; }
    public DateTime? ApprovedDate { get; set; }
    public bool IsActive { get; set; } = true;
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<ServiceQuotationLine> Lines { get; set; } = new List<ServiceQuotationLine>();
}

public class ServiceQuotationLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid QuotationId { get; set; }
    public ServiceQuotation? Quotation { get; set; }
    public int LineNumber { get; set; }
    public string? Description { get; set; }
    public decimal Quantity { get; set; } = 1;
    public string? Unit { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal DiscountPercent { get; set; }
    public decimal TaxPercent { get; set; }
    public decimal LineTotal { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class ServiceContract
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string ContractNumber { get; set; } = string.Empty;
    public DateTime ContractDate { get; set; } = DateTime.UtcNow;
    public Guid? QuotationId { get; set; }
    public ServiceQuotation? Quotation { get; set; }
    public Guid CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public string? ProjectName { get; set; }
    public string? ScopeOfWork { get; set; }
    public Truebooks.Platform.Contracts.Enums.ContractType ContractType { get; set; }
    public Truebooks.Platform.Contracts.Enums.ContractStatus Status { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public DateTime? NextBillingDate { get; set; }
    public int BillingDayOfMonth { get; set; } = 1;
    public Truebooks.Platform.Contracts.Enums.BillingFrequency BillingFrequency { get; set; }
    public decimal ContractValue { get; set; }
    public decimal RecurringAmount { get; set; }
    public decimal TaxPercent { get; set; } = 0;
    public string? CurrencyCode { get; set; } = "AED";
    public string? TermsAndConditions { get; set; }
    public string? PaymentTerms { get; set; }
    public string? SLATerms { get; set; }
    public string? Notes { get; set; }
    public bool AutoRenew { get; set; }
    public int? RenewalNoticeDays { get; set; } = 30;
    public DateTime? LastRenewalDate { get; set; }
    public Guid? OriginalContractId { get; set; }
    public int RenewalCount { get; set; } = 0;
    public decimal TotalBilledAmount { get; set; } = 0;
    public decimal TotalReceivedAmount { get; set; } = 0;
    public decimal OutstandingBalance { get; set; } = 0;
    public bool EnableDeferredRevenue { get; set; }
    public Guid? DeferredRevenueAccountId { get; set; }
    public Guid? RevenueAccountId { get; set; }
    public Guid? ClientCalendarId { get; set; }
    public bool IsActive { get; set; } = true;
    public string? CancellationReason { get; set; }
    public DateTime? CancelledDate { get; set; }
    public Guid? AccountManagerUserId { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
    public ICollection<ServiceTaskLog> TaskLogs { get; set; } = new List<ServiceTaskLog>();
}

public class ServiceTaskLog
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid ServiceContractId { get; set; }
    public ServiceContract? ServiceContract { get; set; }
    public DateTime TaskDate { get; set; }
    public DateTime? TimeFrom { get; set; }
    public DateTime? TimeTo { get; set; }
    public string? TaskType { get; set; }
    public string? Description { get; set; }
    public decimal? HoursSpent { get; set; }
    public Guid? PerformedByUserId { get; set; }
    public string? PerformedByName { get; set; }
    public Guid? EmployeeId { get; set; }
    public Employee? Employee { get; set; }
    public int Status { get; set; }
    public string? Notes { get; set; }
    public bool IsBillable { get; set; } = true;
    public decimal? BillableAmount { get; set; }
    public Guid? InvoiceId { get; set; }
    public Truebooks.Platform.Contracts.Legacy.DTOs.TimesheetApprovalStatus ApprovalStatus { get; set; } = Truebooks.Platform.Contracts.Legacy.DTOs.TimesheetApprovalStatus.Pending;
    public Guid? ApprovedByUserId { get; set; }
    public DateTime? ApprovedDate { get; set; }
    public string? ApprovalNotes { get; set; }
    public bool ProcessedForPayroll { get; set; } = false;
    public Guid? PayrollJournalId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class CustomerModuleAssignment
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid CustomerId { get; set; }
    public Guid ModuleId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public string? CreatedBy { get; set; }
}

public class SupplierModuleAssignment
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid SupplierId { get; set; }
    public Guid ModuleId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public string? CreatedBy { get; set; }
}

public class Campaign
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int CampaignType { get; set; }
    public int Status { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public decimal Budget { get; set; }
    public decimal SpentAmount { get; set; }
    public string? TargetAudience { get; set; }
    public string? Goals { get; set; }
    public int LeadsGenerated { get; set; }
    public int ConversionsCount { get; set; }
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public class ClientReport
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid ServiceContractId { get; set; }
    public ServiceContract? ServiceContract { get; set; }
    public Guid CustomerId { get; set; }
    public string ReportTitle { get; set; } = string.Empty;
    public DateTime PeriodStart { get; set; }
    public DateTime PeriodEnd { get; set; }
    public int Status { get; set; }
    public string? Summary { get; set; }
    public string? Achievements { get; set; }
    public string? Issues { get; set; }
    public string? NextSteps { get; set; }
    public decimal HoursWorked { get; set; }
    public decimal BillableAmount { get; set; }
    public DateTime? SentDate { get; set; }
    public string? SentTo { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}

public enum PortType
{
    SeaPort = 0,
    Airport = 1,
    InlandPort = 2,
    DryPort = 3
}

[System.ComponentModel.DataAnnotations.Schema.Table("Ports")]
public class Port
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.Column("Code")]
    public string PortCode { get; set; } = string.Empty;
    [System.ComponentModel.DataAnnotations.Schema.Column("Name")]
    public string PortName { get; set; } = string.Empty;
    public string? City { get; set; }
    public string? Country { get; set; }
    public string? CountryCode { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public string? UNLocode { get; set; }
    public PortType PortType { get; set; } = PortType.SeaPort;
    public bool IsActive { get; set; } = true;
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

[System.ComponentModel.DataAnnotations.Schema.Table("ShippingLines")]
public class ShippingLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? SCACCode { get; set; }
    public string? ContactPerson { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.Column("ContactPhone")]
    public string? Phone { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.Column("ContactEmail")]
    public string? Email { get; set; }
    public string? Address { get; set; }
    public string? Country { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public string? Website { get; set; }
    public Guid? SupplierId { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

[System.ComponentModel.DataAnnotations.Schema.Table("Vessels")]
public class Vessel
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.Column("Code")]
    public string VesselCode { get; set; } = string.Empty;
    [System.ComponentModel.DataAnnotations.Schema.Column("Name")]
    public string VesselName { get; set; } = string.Empty;
    public string? IMONumber { get; set; }
    public string? CallSign { get; set; }
    public string? Flag { get; set; }
    public Guid? FlagCountryId { get; set; }
    public Guid? ShippingLineId { get; set; }
    public string? VesselType { get; set; }
    public decimal? GrossTonnage { get; set; }
    public decimal? NetTonnage { get; set; }
    public int? TEUCapacity { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

[System.ComponentModel.DataAnnotations.Schema.Table("Carriers")]
public class Carrier
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.Column("Code")]
    public string CarrierCode { get; set; } = string.Empty;
    [System.ComponentModel.DataAnnotations.Schema.Column("Name")]
    public string CarrierName { get; set; } = string.Empty;
    public CarrierType CarrierType { get; set; } = CarrierType.Airline;
    public string? IATACode { get; set; }
    public string? ICAOCode { get; set; }
    public string? ContactPerson { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.Column("ContactPhone")]
    public string? Phone { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.Column("ContactEmail")]
    public string? Email { get; set; }
    public string? Address { get; set; }
    public string? Country { get; set; }
    public Guid? CountryId { get; set; }
    public Guid? StateId { get; set; }
    public Guid? CityId { get; set; }
    public string? Website { get; set; }
    public Guid? SupplierId { get; set; }
    public bool IsActive { get; set; } = true;
    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public enum CarrierType
{
    Airline = 0,
    ShippingLine = 1,
    Trucker = 2,
    Railway = 3,
    CourierCompany = 4
}

[System.ComponentModel.DataAnnotations.Schema.Table("LogisticsJobModes")]
public class LogisticsJobMode
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    [System.ComponentModel.DataAnnotations.Schema.Column("TransportMode")]
    public TransportMode Mode { get; set; } = TransportMode.Sea;
    public bool IsActive { get; set; } = true;
    public string? Description { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public enum TransportMode
{
    Sea = 0,
    Air = 1,
    Land = 2,
    Rail = 3,
    Multimodal = 4
}

[System.ComponentModel.DataAnnotations.Schema.Table("LogisticsJobTypes")]
public class LogisticsJobType
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    [System.ComponentModel.DataAnnotations.Schema.Column("JobDirection")]
    public JobDirection Direction { get; set; } = JobDirection.Import;
    [System.ComponentModel.DataAnnotations.Schema.Column("TransportMode")]
    public TransportMode TransportMode { get; set; } = TransportMode.Sea;
    public bool IsActive { get; set; } = true;
    public string? Description { get; set; }
    public Guid? DefaultJobModeId { get; set; }
    public virtual LogisticsJobMode? DefaultJobMode { get; set; }
    public string? Prefix { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public enum JobDirection
{
    Import = 0,
    Export = 1,
    CrossTrade = 2,
    Local = 3
}

public enum LogisticsEnquirySource
{
    Staff = 0,
    Customer = 1,
    Website = 2,
    Email = 3
}

public class LogisticsEnquiry
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string EnquiryNumber { get; set; } = string.Empty;
    public DateTime EnquiryDate { get; set; } = DateTime.UtcNow;
    public bool IsWalkInCustomer { get; set; }
    public Guid? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    public string? CustomerAddress { get; set; }
    public Guid? JobModeId { get; set; }
    public string? JobModeName { get; set; }
    public Guid? JobTypeId { get; set; }
    public string? JobTypeName { get; set; }
    public int ShipmentType { get; set; }
    public int Status { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public string? ContactPerson { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? Origin { get; set; }
    public string? Destination { get; set; }
    public Guid? OriginCountryId { get; set; }
    public string? OriginCountryName { get; set; }
    public Guid? DestinationCountryId { get; set; }
    public string? DestinationCountryName { get; set; }
    public Guid? PortOfLoadingId { get; set; }
    public string? PortOfLoadingName { get; set; }
    public Guid? PortOfDischargeId { get; set; }
    public string? PortOfDischargeName { get; set; }
    public string? CargoDescription { get; set; }
    public decimal? GrossWeightKg { get; set; }
    public decimal? VolumeCBM { get; set; }
    public int? PackageCount { get; set; }
    public int? ContainerCount { get; set; }
    public Guid? ContainerTypeId { get; set; }
    public string? ContainerTypeName { get; set; }
    public DateTime? RequiredShipDate { get; set; }
    public DateTime? RequiredDeliveryDate { get; set; }
    public string? Requirements { get; set; }
    public string? InternalNotes { get; set; }
    public Guid? AssignedToUserId { get; set; }
    public string? AssignedToUserName { get; set; }
    public DateTime? FollowUpDate { get; set; }
    public Guid? ConvertedToQuotationId { get; set; }
    public string? ConvertedToQuotationNumber { get; set; }
    public Guid? CreatedByUserId { get; set; }
    public string? CreatedByUserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    public int Source { get; set; }
    
    public Customer? Customer { get; set; }
    public LogisticsJobMode? JobMode { get; set; }
    public LogisticsJobType? JobType { get; set; }
    public Port? PortOfLoading { get; set; }
    public Port? PortOfDischarge { get; set; }
    public Branch? Branch { get; set; }
    public List<EnquiryDocument> Documents { get; set; } = new();
}

public class ShippingDocumentType
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
}

public class EnquiryDocument
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid EnquiryId { get; set; }
    public Guid? DocumentTypeId { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string OriginalFileName { get; set; } = string.Empty;
    public string ContentType { get; set; } = string.Empty;
    public long FileSize { get; set; }
    public byte[]? FileData { get; set; }
    public string? Notes { get; set; }
    public Guid? UploadedByUserId { get; set; }
    public DateTime UploadedAt { get; set; } = DateTime.UtcNow;
    
    public LogisticsEnquiry? Enquiry { get; set; }
    public ShippingDocumentType? DocumentType { get; set; }
}

public class JobDocument
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid JobId { get; set; }
    public int DocumentType { get; set; }
    public string DocumentName { get; set; } = string.Empty;
    public string? DocumentNumber { get; set; }
    public DateTime? DocumentDate { get; set; }
    public string? FilePath { get; set; }
    public string? FileType { get; set; }
    public long? FileSizeBytes { get; set; }
    public byte[]? FileData { get; set; }
    public bool IsOriginal { get; set; }
    public int CopyCount { get; set; }
    public DateTime? ReceivedDate { get; set; }
    public DateTime? SentDate { get; set; }
    public string? ReceivedFrom { get; set; }
    public string? SentTo { get; set; }
    public string? Notes { get; set; }
    public Guid? UploadedByUserId { get; set; }
    public string? UploadedByUserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public LogisticsJob? Job { get; set; }
}

public enum LogisticsEstimationStatus
{
    Draft = 0,
    Submitted = 1,
    Approved = 2,
    ConvertedToQuotation = 3,
    Cancelled = 4
}

public class LogisticsEstimation
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string EstimationNumber { get; set; } = string.Empty;
    public DateTime EstimationDate { get; set; } = DateTime.UtcNow;
    public DateTime? ValidUntil { get; set; }
    public Guid? EnquiryId { get; set; }
    public string? EnquiryNumber { get; set; }
    public int Status { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public Guid? JobTypeId { get; set; }
    public string? JobTypeName { get; set; }
    public Guid? JobModeId { get; set; }
    public string? JobModeName { get; set; }
    public int ShipmentType { get; set; }
    public Guid? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    public string? ContactPerson { get; set; }
    public string? Email { get; set; }
    public string? Origin { get; set; }
    public string? Destination { get; set; }
    public Guid? PortOfLoadingId { get; set; }
    public string? PortOfLoadingName { get; set; }
    public Guid? PortOfDischargeId { get; set; }
    public string? PortOfDischargeName { get; set; }
    public string? CargoDescription { get; set; }
    public decimal? GrossWeightKg { get; set; }
    public decimal? VolumeCBM { get; set; }
    public int? PackageCount { get; set; }
    public int? ContainerCount { get; set; }
    public Guid? ContainerTypeId { get; set; }
    public string? ContainerTypeName { get; set; }
    public Guid? LocalCurrencyId { get; set; }
    public string? LocalCurrencyCode { get; set; }
    public Guid? ForeignCurrencyId { get; set; }
    public string? ForeignCurrencyCode { get; set; }
    public decimal ExchangeRate { get; set; } = 1;
    public decimal TotalCostLocal { get; set; }
    public decimal TotalCostForeign { get; set; }
    public decimal TotalSalesLocal { get; set; }
    public decimal TotalSalesForeign { get; set; }
    public decimal TotalMarginLocal { get; set; }
    public decimal TotalMarginForeign { get; set; }
    public decimal MarginPercent { get; set; }
    public string? InternalNotes { get; set; }
    public Guid? ConvertedToQuotationId { get; set; }
    public string? ConvertedToQuotationNumber { get; set; }
    public Guid? CurrentVersionId { get; set; }
    public Guid? AcceptedVersionId { get; set; }
    public int LatestVersionNumber { get; set; } = 1;
    public Guid? SubmittedByUserId { get; set; }
    public string? SubmittedByUserName { get; set; }
    public DateTime? SubmittedAt { get; set; }
    public Guid? ApprovedByUserId { get; set; }
    public string? ApprovedByUserName { get; set; }
    public DateTime? ApprovedAt { get; set; }
    public string? ApprovalNotes { get; set; }
    public Guid? CreatedByUserId { get; set; }
    public string? CreatedByUserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public Customer? Customer { get; set; }
    public LogisticsEnquiry? Enquiry { get; set; }
    public LogisticsJobMode? JobMode { get; set; }
    public LogisticsJobType? JobType { get; set; }
    public Port? PortOfLoading { get; set; }
    public Port? PortOfDischarge { get; set; }
    public Branch? Branch { get; set; }
    public List<LogisticsEstimationVersion> Versions { get; set; } = new();
}

public class LogisticsEstimationVersion
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid EstimationId { get; set; }
    public int VersionNumber { get; set; } = 1;
    public int Status { get; set; }
    public DateTime VersionDate { get; set; } = DateTime.UtcNow;
    public DateTime? ValidUntil { get; set; }
    public Guid? LocalCurrencyId { get; set; }
    public string? LocalCurrencyCode { get; set; }
    public Guid? ForeignCurrencyId { get; set; }
    public string? ForeignCurrencyCode { get; set; }
    public decimal ExchangeRate { get; set; } = 1;
    public decimal TotalCostLocal { get; set; }
    public decimal TotalCostForeign { get; set; }
    public decimal TotalSalesLocal { get; set; }
    public decimal TotalSalesForeign { get; set; }
    public decimal TotalMarginLocal { get; set; }
    public decimal TotalMarginForeign { get; set; }
    public decimal MarginPercent { get; set; }
    public string? InternalNotes { get; set; }
    public string? VersionNotes { get; set; }
    public Guid? ConvertedToQuotationVersionId { get; set; }
    public Guid? SubmittedByUserId { get; set; }
    public string? SubmittedByUserName { get; set; }
    public DateTime? SubmittedAt { get; set; }
    public Guid? ApprovedByUserId { get; set; }
    public string? ApprovedByUserName { get; set; }
    public DateTime? ApprovedAt { get; set; }
    public string? ApprovalNotes { get; set; }
    public Guid? CreatedByUserId { get; set; }
    public string? CreatedByUserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public LogisticsEstimation? Estimation { get; set; }
    public List<LogisticsEstimationVersionLine> Lines { get; set; } = new();
}

public class LogisticsEstimationVersionLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid EstimationVersionId { get; set; }
    public int SlNo { get; set; }
    public Guid? ChargeTypeId { get; set; }
    public string? ChargeTypeCode { get; set; }
    public string? ChargeTypeName { get; set; }
    public Guid? SupplierId { get; set; }
    public string? SupplierName { get; set; }
    public string? Unit { get; set; }
    public decimal Quantity { get; set; } = 1;
    public Guid? CostCurrencyId { get; set; }
    public string? CostCurrencyCode { get; set; }
    public decimal CostExchangeRate { get; set; } = 1;
    public decimal CostRate { get; set; }
    public decimal CostValueLocal { get; set; }
    public decimal CostValueForeign { get; set; }
    public Guid? SalesCurrencyId { get; set; }
    public string? SalesCurrencyCode { get; set; }
    public decimal SalesExchangeRate { get; set; } = 1;
    public decimal SalesRate { get; set; }
    public decimal SalesValueLocal { get; set; }
    public decimal SalesValueForeign { get; set; }
    public decimal MarginLocal { get; set; }
    public decimal MarginForeign { get; set; }
    public decimal MarginPercent { get; set; }
    public string? Remarks { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public LogisticsEstimationVersion? EstimationVersion { get; set; }
    public ChargeType? ChargeType { get; set; }
    public Supplier? Supplier { get; set; }
}

public class LogisticsQuotation
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string QuotationNumber { get; set; } = string.Empty;
    public DateTime QuotationDate { get; set; } = DateTime.UtcNow;
    public DateTime? ValidUntil { get; set; }
    public int VersionNumber { get; set; } = 1;
    public int Status { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? EnquiryId { get; set; }
    public string? EnquiryNumber { get; set; }
    public Guid? EstimationId { get; set; }
    public string? EstimationNumber { get; set; }
    
    public Guid? CustomerId { get; set; }
    public string? CustomerName { get; set; }
    public string? CustomerCompanyName { get; set; }
    public string? CustomerAddress { get; set; }
    public string? ContactPerson { get; set; }
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public int PaymentTermsDays { get; set; } = 30;
    public string? PaymentTermsDescription { get; set; }
    
    public Guid? JobModeId { get; set; }
    public string? JobModeName { get; set; }
    public int ShipmentType { get; set; }
    public string? Origin { get; set; }
    public string? Destination { get; set; }
    public int PackageCount { get; set; }
    public decimal ActualWeightKg { get; set; }
    public decimal ChargeableWeightKg { get; set; }
    public string? Dimensions { get; set; }
    public string? ExpectedTransitTime { get; set; }
    public string? CargoDescription { get; set; }
    
    public string CurrencyCode { get; set; } = "USD";
    public decimal Subtotal { get; set; }
    public decimal TaxPercent { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal TotalAmount { get; set; }
    
    public string? TermsAndConditions { get; set; }
    public string? BankName { get; set; }
    public string? BankAccountName { get; set; }
    public string? BankAccountNumber { get; set; }
    public string? BankSwiftCode { get; set; }
    public string? InternalNotes { get; set; }
    
    public Guid? ConvertedToJobId { get; set; }
    public string? ConvertedToJobNumber { get; set; }
    public DateTime? SentDate { get; set; }
    public DateTime? ConfirmedDate { get; set; }
    public Guid? ConfirmedByUserId { get; set; }
    public string? ConfirmedByUserName { get; set; }
    
    public Guid? CreatedByUserId { get; set; }
    public string? CreatedByUserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public Customer? Customer { get; set; }
    public LogisticsEnquiry? Enquiry { get; set; }
    public LogisticsEstimation? Estimation { get; set; }
    public List<QuotationLine> Lines { get; set; } = new();
}

public class QuotationLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid QuotationId { get; set; }
    public int LineNumber { get; set; }
    public string Description { get; set; } = string.Empty;
    public Guid? ChargeTypeId { get; set; }
    public string? ChargeTypeName { get; set; }
    public decimal Amount { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public LogisticsQuotation? Quotation { get; set; }
}

[System.ComponentModel.DataAnnotations.Schema.Table("LogisticsJobs")]
public class LogisticsJob
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string JobNumber { get; set; } = string.Empty;
    public DateTime JobDate { get; set; }
    public Guid JobTypeId { get; set; }
    public Guid JobModeId { get; set; }
    public int ShipmentType { get; set; }
    public int Status { get; set; }
    public Guid? BranchId { get; set; }
    public Guid? DepartmentId { get; set; }
    public Guid CustomerId { get; set; }
    public string? CustomerName { get; set; }
    public Guid? ShipperId { get; set; }
    public string? ShipperName { get; set; }
    public string? ShipperAddress { get; set; }
    public Guid? ConsigneeId { get; set; }
    public string? ConsigneeName { get; set; }
    public string? ConsigneeAddress { get; set; }
    public Guid? NotifyPartyId { get; set; }
    public string? NotifyPartyName { get; set; }
    public string? NotifyPartyAddress { get; set; }
    public Guid? CarrierId { get; set; }
    public string? CarrierName { get; set; }
    public Guid? ShippingLineId { get; set; }
    public string? ShippingLineName { get; set; }
    public Guid? ShippingAgentId { get; set; }
    public string? ShippingAgentName { get; set; }
    public string? MasterBLAWB { get; set; }
    public string? HouseBLAWB { get; set; }
    public string? CustomerReference { get; set; }
    public Guid? VesselId { get; set; }
    public string? VesselName { get; set; }
    public string? VoyageFlightNo { get; set; }
    public Guid? PortOfLoadingId { get; set; }
    public string? PortOfLoadingName { get; set; }
    public Guid? PortOfDischargeId { get; set; }
    public string? PortOfDischargeName { get; set; }
    public string? PlaceOfReceipt { get; set; }
    public string? PlaceOfDelivery { get; set; }
    public DateTime? ETD { get; set; }
    public DateTime? ETA { get; set; }
    public DateTime? ATD { get; set; }
    public DateTime? ATA { get; set; }
    public string? GoodsDescription { get; set; }
    public Guid? CargoTypeId { get; set; }
    public string? CargoTypeName { get; set; }
    public decimal? GrossWeightKg { get; set; }
    public decimal? ChargeableWeightKg { get; set; }
    public decimal? VolumeCBM { get; set; }
    public int? TotalPackages { get; set; }
    public string? PackageUnit { get; set; }
    public int? ContainerCount { get; set; }
    public Guid? ContainerTypeId { get; set; }
    public string? ContainerTypeName { get; set; }
    public string? CurrencyCode { get; set; }
    public decimal? ExchangeRate { get; set; }
    public decimal? TotalEstimatedCost { get; set; }
    public decimal? TotalEstimatedSales { get; set; }
    public decimal? TotalEstimatedMargin { get; set; }
    public decimal? TotalActualCost { get; set; }
    public decimal? TotalActualSales { get; set; }
    public decimal? TotalActualMargin { get; set; }
    public bool IsClosed { get; set; }
    public DateTime? ClosedDate { get; set; }
    public Guid? ClosedByUserId { get; set; }
    public string? ClosedByUserName { get; set; }
    
    // Job Closing / Accrual Accounting fields
    public int ClosingStatus { get; set; } // 0=Open, 1=ProvisionPosted, 2=PartiallyMatched, 3=FullyMatched, 4=Closed
    public bool IsProvisionPosted { get; set; }
    public DateTime? ProvisionPostedDate { get; set; }
    public Guid? ProvisionPostedByUserId { get; set; }
    public decimal? ProvisionalCostAmount { get; set; }
    public decimal? AccruedCostPayableAmount { get; set; }
    public decimal? DeferredRevenueAmount { get; set; }
    public bool IsRevenueRecognized { get; set; }
    public DateTime? RevenueRecognizedDate { get; set; }
    public decimal? RecognizedRevenueAmount { get; set; }
    public decimal? RecognizedCostOfSalesAmount { get; set; }
    public Guid? ClosingFinancialPeriodId { get; set; }
    public int UnmatchedCostLineCount { get; set; }
    public decimal? UnmatchedCostAmount { get; set; }
    public decimal? VarianceAmount { get; set; }
    public string? ClosingNotes { get; set; }
    
    // Linked Document fields (Job as Master Record pattern)
    public Guid? EnquiryId { get; set; }
    public string? EnquiryNumber { get; set; }
    public Guid? EstimationId { get; set; }
    public string? EstimationNumber { get; set; }
    public Guid? QuotationId { get; set; }
    public string? QuotationNumber { get; set; }
    
    // Operational Tracking fields
    public DateTime? ActualPickupDate { get; set; }
    public DateTime? ActualDeliveryDate { get; set; }
    public Guid? AssignedStaffId { get; set; }
    public string? AssignedStaffName { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.Column(TypeName = "jsonb")]
    public string? TrackingNumbers { get; set; }
    public string? CurrentLocation { get; set; }
    public string? CurrentMilestone { get; set; }
    public int MilestoneProgress { get; set; } // 0-100 percentage
    
    public bool IsVoided { get; set; }
    public DateTime? VoidedDate { get; set; }
    public Guid? VoidedByUserId { get; set; }
    public string? VoidReason { get; set; }
    public string? InternalNotes { get; set; }
    public string? SpecialInstructions { get; set; }
    public Guid? CreatedByUserId { get; set; }
    public string? CreatedByUserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public LogisticsJobMode? JobMode { get; set; }
    public LogisticsJobType? JobType { get; set; }
    public LogisticsEnquiry? Enquiry { get; set; }
    public LogisticsEstimation? Estimation { get; set; }
    public LogisticsQuotation? Quotation { get; set; }
    public ICollection<JobCostLine> CostLines { get; set; } = new List<JobCostLine>();
    public ICollection<JobClosingEntry> ClosingEntries { get; set; } = new List<JobClosingEntry>();
    public ICollection<JobActivityLog> ActivityLogs { get; set; } = new List<JobActivityLog>();
}

[System.ComponentModel.DataAnnotations.Schema.Table("JobCostLines")]
public class JobCostLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid JobId { get; set; }
    public int LineNumber { get; set; }
    public string Description { get; set; } = string.Empty;
    public Guid? ChargeTypeId { get; set; }
    public string? ChargeTypeName { get; set; }
    public int LineType { get; set; } // 0=Revenue, 1=Cost
    
    // Vendor/Supplier
    public Guid? VendorId { get; set; }
    public string? VendorName { get; set; }
    
    // Cost fields
    public string CostCurrencyCode { get; set; } = "USD";
    public decimal CostExchangeRate { get; set; } = 1m;
    public decimal EstimatedCostFC { get; set; }
    public decimal EstimatedCostLC { get; set; }
    public decimal ActualCostFC { get; set; }
    public decimal ActualCostLC { get; set; }
    
    // Sales fields
    public string SalesCurrencyCode { get; set; } = "USD";
    public decimal SalesExchangeRate { get; set; } = 1m;
    public decimal EstimatedSalesFC { get; set; }
    public decimal EstimatedSalesLC { get; set; }
    public decimal ActualSalesFC { get; set; }
    public decimal ActualSalesLC { get; set; }
    
    // Margin fields
    public decimal EstimatedMarginLC { get; set; }
    public decimal ActualMarginLC { get; set; }
    public decimal MarkupPercent { get; set; }
    
    // Billing status
    public bool IsCustomerInvoiced { get; set; }
    public bool IsVendorInvoiced { get; set; }
    public int Status { get; set; } // 0=Active, 1=Invoiced, 2=Cancelled
    
    // Accrual Accounting / Vendor Invoice Matching fields
    public bool IsProvisioned { get; set; }
    public decimal? ProvisionedAmount { get; set; }
    public DateTime? ProvisionedDate { get; set; }
    public Guid? ProvisionJournalEntryId { get; set; }
    public bool IsMatched { get; set; }
    public Guid? VendorInvoiceId { get; set; }
    public string? VendorInvoiceNumber { get; set; }
    public DateTime? MatchedDate { get; set; }
    public decimal? MatchedAmount { get; set; }
    public decimal? VarianceAmount { get; set; }
    public Guid? MatchingJournalEntryId { get; set; }
    public int MatchingStatus { get; set; } // 0=NotProvisioned, 1=Provisioned, 2=Matched, 3=MatchedWithVariance
    
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public LogisticsJob? Job { get; set; }
}

[System.ComponentModel.DataAnnotations.Schema.Table("JobClosingEntries")]
public class JobClosingEntry
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid JobId { get; set; }
    public string JobNumber { get; set; } = string.Empty;
    public int EntryType { get; set; } // 1=MonthEndProvision, 2=ProvisionReversal, 3=VendorInvoiceMatching, 4=RevenueRecognition, 5=VarianceAdjustment
    public DateTime EntryDate { get; set; }
    public Guid FinancialPeriodId { get; set; }
    public string? FinancialPeriodName { get; set; }
    public Guid? JournalEntryId { get; set; }
    public string? JournalEntryNumber { get; set; }
    
    // Debit entries
    public Guid? DebitAccountId { get; set; }
    public string? DebitAccountCode { get; set; }
    public string? DebitAccountName { get; set; }
    public decimal DebitAmount { get; set; }
    
    // Credit entries  
    public Guid? CreditAccountId { get; set; }
    public string? CreditAccountCode { get; set; }
    public string? CreditAccountName { get; set; }
    public decimal CreditAmount { get; set; }
    
    // Reference to cost line for matching entries
    public Guid? JobCostLineId { get; set; }
    public Guid? VendorInvoiceId { get; set; }
    public string? VendorInvoiceNumber { get; set; }
    
    public string? Description { get; set; }
    public string? Notes { get; set; }
    public bool IsReversed { get; set; }
    public Guid? ReversalEntryId { get; set; }
    public DateTime? ReversedDate { get; set; }
    
    public Guid? CreatedByUserId { get; set; }
    public string? CreatedByUserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    public LogisticsJob? Job { get; set; }
}

public enum JobActivityType
{
    Created = 1,
    StatusChanged = 2,
    DocumentAdded = 3,
    CostLineAdded = 4,
    InvoiceGenerated = 5,
    MilestoneReached = 6,
    NoteAdded = 7,
    AssignmentChanged = 8,
    DateUpdated = 9,
    Closed = 10,
    QuotationLinked = 11,
    CarrierAssigned = 12,
    TrackingUpdated = 13,
    CustomerNotified = 14,
    VendorInvoiceMatched = 15
}

[System.ComponentModel.DataAnnotations.Schema.Table("JobActivityLogs")]
public class JobActivityLog
{
    [System.ComponentModel.DataAnnotations.Key]
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid JobId { get; set; }
    [System.ComponentModel.DataAnnotations.MaxLength(50)]
    public string JobNumber { get; set; } = string.Empty;
    public JobActivityType ActivityType { get; set; }
    public DateTime ActivityDate { get; set; } = DateTime.UtcNow;
    [System.ComponentModel.DataAnnotations.Required]
    [System.ComponentModel.DataAnnotations.MaxLength(200)]
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
    [System.ComponentModel.DataAnnotations.MaxLength(100)]
    public string? RelatedEntityType { get; set; }
    public Guid? RelatedEntityId { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.Column(TypeName = "jsonb")]
    public string? Metadata { get; set; }
    public Guid? UserId { get; set; }
    [System.ComponentModel.DataAnnotations.MaxLength(200)]
    public string? UserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    public LogisticsJob? Job { get; set; }
}

[System.ComponentModel.DataAnnotations.Schema.Table("LogisticsVendorInvoices")]
public class LogisticsVendorInvoice
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public DateTime InvoiceDate { get; set; }
    public DateTime? DueDate { get; set; }
    public Guid VendorId { get; set; }
    public string VendorName { get; set; } = string.Empty;
    public string? VendorAddress { get; set; }
    public string? VendorTaxNumber { get; set; }
    public string CurrencyCode { get; set; } = "USD";
    public decimal ExchangeRate { get; set; } = 1;
    public decimal SubTotalFC { get; set; }
    public decimal SubTotalLC { get; set; }
    public decimal TaxPercent { get; set; }
    public decimal TaxAmountFC { get; set; }
    public decimal TaxAmountLC { get; set; }
    public decimal TotalAmountFC { get; set; }
    public decimal TotalAmountLC { get; set; }
    public decimal AllocatedAmount { get; set; }
    public decimal BalanceAmount { get; set; }
    public int Status { get; set; } // 0=Draft, 1=PendingApproval, 2=Approved, 3=Posted, 4=PartiallyPaid, 5=Paid, 6=Cancelled
    public bool IsPosted { get; set; }
    public DateTime? PostedDate { get; set; }
    public Guid? PostedByUserId { get; set; }
    public string? PostedByUserName { get; set; }
    public Guid? JournalEntryId { get; set; }
    public string? JournalEntryNumber { get; set; }
    public Guid? APAccountId { get; set; }
    public string? APAccountCode { get; set; }
    public string? APAccountName { get; set; }
    public string? Notes { get; set; }
    public string? CreatedByUserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public ICollection<LogisticsVendorInvoiceLine>? InvoiceLines { get; set; }
}

[System.ComponentModel.DataAnnotations.Schema.Table("LogisticsVendorInvoiceLines")]
public class LogisticsVendorInvoiceLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid InvoiceId { get; set; }
    public int LineNumber { get; set; }
    public Guid JobId { get; set; }
    public string JobNumber { get; set; } = string.Empty;
    public Guid? JobCostLineId { get; set; }
    public string? ChargeTypeName { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal ProvisionedAmount { get; set; }
    public decimal InvoicedAmountFC { get; set; }
    public decimal InvoicedAmountLC { get; set; }
    public decimal VarianceAmount { get; set; }
    public bool IsWithinProvision { get; set; } = true;
    public Guid? CostOfSalesAccountId { get; set; }
    public string? CostOfSalesAccountCode { get; set; }
    public string? CostOfSalesAccountName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    public LogisticsVendorInvoice? Invoice { get; set; }
    public JobCostLine? JobCostLine { get; set; }
}

[System.ComponentModel.DataAnnotations.Schema.Table("LogisticsCustomerInvoices")]
public class LogisticsCustomerInvoice
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public DateTime InvoiceDate { get; set; }
    public DateTime? DueDate { get; set; }
    public Guid JobId { get; set; }
    public string JobNumber { get; set; } = string.Empty;
    public Guid? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string? CustomerAddress { get; set; }
    public string? CustomerTaxNumber { get; set; }
    public string? CustomerEmail { get; set; }
    public string CurrencyCode { get; set; } = "USD";
    public decimal ExchangeRate { get; set; } = 1;
    public decimal SubTotalFC { get; set; }
    public decimal SubTotalLC { get; set; }
    public decimal TaxPercent { get; set; }
    public decimal TaxAmountFC { get; set; }
    public decimal TaxAmountLC { get; set; }
    public decimal TotalAmountFC { get; set; }
    public decimal TotalAmountLC { get; set; }
    public decimal PaidAmount { get; set; }
    public decimal BalanceAmount { get; set; }
    public int Status { get; set; }
    public bool IsPosted { get; set; }
    public DateTime? PostedDate { get; set; }
    public Guid? PostedByUserId { get; set; }
    public string? PostedByUserName { get; set; }
    public Guid? JournalEntryId { get; set; }
    public string? JournalEntryNumber { get; set; }
    public Guid? ARAccountId { get; set; }
    public string? ARAccountCode { get; set; }
    public string? ARAccountName { get; set; }
    public string? Notes { get; set; }
    public bool IsEmailSent { get; set; }
    public DateTime? EmailSentDate { get; set; }
    public string? CreatedByUserName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
    
    public LogisticsJob? Job { get; set; }
    public Customer? Customer { get; set; }
    public List<LogisticsCustomerInvoiceLine> Lines { get; set; } = new();
}

[System.ComponentModel.DataAnnotations.Schema.Table("LogisticsCustomerInvoiceLines")]
public class LogisticsCustomerInvoiceLine
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public Guid InvoiceId { get; set; }
    public int LineNumber { get; set; }
    public string Description { get; set; } = string.Empty;
    public string? ChargeTypeName { get; set; }
    public decimal Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal AmountFC { get; set; }
    public decimal AmountLC { get; set; }
    public Guid? RevenueAccountId { get; set; }
    public string? RevenueAccountCode { get; set; }
    public string? RevenueAccountName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    
    public LogisticsCustomerInvoice? Invoice { get; set; }
}

[System.ComponentModel.DataAnnotations.Schema.Table("DemoDataTrackings")]
public class DemoDataTracking
{
    public Guid Id { get; set; }
    public Guid TenantId { get; set; }
    public string EntityType { get; set; } = string.Empty;
    public Guid EntityId { get; set; }
    public string BatchId { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
