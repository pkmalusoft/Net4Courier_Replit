using Microsoft.AspNetCore.Builder;
using Truebooks.Platform.Core.MultiTenancy;

namespace Truebooks.Platform.Core.Extensions;

public static class ApplicationBuilderExtensions
{
    public static IApplicationBuilder UsePlatformMiddleware(this IApplicationBuilder app)
    {
        app.UseMiddleware<TenantMiddleware>();
        app.UseMiddleware<ModuleAccessMiddleware>();

        return app;
    }

    public static IApplicationBuilder UseTenantResolution(this IApplicationBuilder app)
    {
        app.UseMiddleware<TenantMiddleware>();
        return app;
    }

    public static IApplicationBuilder UseModuleAccess(this IApplicationBuilder app)
    {
        app.UseMiddleware<ModuleAccessMiddleware>();
        return app;
    }
}
