using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Truebooks.Platform.Contracts.Modules;
using Truebooks.Platform.Contracts.Services;
using Truebooks.Platform.Core.Infrastructure;
using Truebooks.Platform.Core.MultiTenancy;

namespace Truebooks.Platform.Core.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddPlatformCore(this IServiceCollection services, string connectionString)
    {
        services.AddDbContextFactory<PlatformDbContext>(options =>
        {
            options.UseNpgsql(connectionString, npgsql =>
            {
                npgsql.MigrationsHistoryTable("__EFMigrationsHistory_Platform");
                npgsql.EnableRetryOnFailure(
                    maxRetryCount: 5,
                    maxRetryDelay: TimeSpan.FromSeconds(30),
                    errorCodesToAdd: null);
                npgsql.CommandTimeout(60);
            });
        });

        services.AddScoped<ITenantContext, TenantContext>();
        services.AddScoped<ITenantModuleService, TenantModuleService>();
        services.AddSingleton<IModuleRegistry, ModuleRegistry>();
        services.AddMemoryCache();

        return services;
    }

    public static IServiceCollection AddModuleManifest<TManifest>(this IServiceCollection services)
        where TManifest : class, IModuleManifest, new()
    {
        var manifest = new TManifest();
        
        services.AddSingleton<IModuleManifest>(manifest);
        
        services.AddHostedService(sp => new ModuleRegistrationHostedService(manifest, sp.GetRequiredService<IModuleRegistry>()));

        manifest.ConfigureServices(services);

        return services;
    }
}

public class ModuleRegistrationHostedService : IHostedService
{
    private readonly IModuleManifest _manifest;
    private readonly IModuleRegistry _registry;

    public ModuleRegistrationHostedService(IModuleManifest manifest, IModuleRegistry registry)
    {
        _manifest = manifest;
        _registry = registry;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _registry.RegisterModule(_manifest);
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;
}
