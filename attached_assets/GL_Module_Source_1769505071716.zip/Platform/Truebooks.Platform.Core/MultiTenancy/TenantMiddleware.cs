using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Truebooks.Platform.Core.Infrastructure;

namespace Truebooks.Platform.Core.MultiTenancy;

public class TenantMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<TenantMiddleware> _logger;

    public TenantMiddleware(RequestDelegate next, ILogger<TenantMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context, ITenantContext tenantContext)
    {
        if (tenantContext is TenantContext mutableContext)
        {
            var tenantIdClaim = context.User.FindFirst("tenant_id")?.Value;
            if (Guid.TryParse(tenantIdClaim, out var tenantId))
            {
                mutableContext.TenantId = tenantId;
                mutableContext.TenantName = context.User.FindFirst("tenant_name")?.Value;
                _logger.LogDebug("Tenant context set from JWT: {TenantId}", tenantId);
            }
            else
            {
                await TryResolveTenantFromHeaderOrPath(context, mutableContext);
            }
        }

        await _next(context);
    }

    private async Task TryResolveTenantFromHeaderOrPath(HttpContext context, TenantContext mutableContext)
    {
        string? tenantSlug = null;

        if (context.Request.Headers.TryGetValue("X-Tenant-Id", out var headerValue))
        {
            tenantSlug = headerValue.FirstOrDefault();
        }

        if (string.IsNullOrEmpty(tenantSlug))
        {
            var path = context.Request.Path.Value ?? "";
            var storeMatch = System.Text.RegularExpressions.Regex.Match(path, @"^/store/([^/]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (storeMatch.Success)
            {
                tenantSlug = storeMatch.Groups[1].Value;
            }
        }

        if (!string.IsNullOrEmpty(tenantSlug))
        {
            try
            {
                var dbContext = context.RequestServices.GetService<PlatformDbContext>();
                if (dbContext != null)
                {
                    var tenant = await dbContext.Tenants
                        .AsNoTracking()
                        .FirstOrDefaultAsync(t => 
                            t.Subdomain == tenantSlug || 
                            t.Name.ToLower() == tenantSlug.ToLower());

                    if (tenant != null)
                    {
                        mutableContext.TenantId = tenant.Id;
                        mutableContext.TenantName = tenant.Name;
                        _logger.LogDebug("Tenant context set from header/path: {TenantId} ({TenantSlug})", tenant.Id, tenantSlug);
                    }
                    else
                    {
                        _logger.LogWarning("Tenant not found for slug: {TenantSlug}", tenantSlug);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error resolving tenant from slug: {TenantSlug}", tenantSlug);
            }
        }
    }
}
