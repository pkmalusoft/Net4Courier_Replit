using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Truebooks.Platform.Contracts.Enums;
using Truebooks.Platform.Contracts.Services;

namespace Truebooks.Platform.Core.MultiTenancy;

public class ModuleAccessMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ModuleAccessMiddleware> _logger;
    private readonly Dictionary<string, string> _routeToModuleMap;
    private readonly HashSet<string> _publicEcommerceEndpoints;

    public ModuleAccessMiddleware(RequestDelegate next, ILogger<ModuleAccessMiddleware> logger)
    {
        _next = next;
        _logger = logger;
        _routeToModuleMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "/api/courier", "Courier" },
            { "/api/shipments", "Courier" },
            { "/api/tracking", "Courier" },
            { "/api/pickupdashboard", "Courier" },
            { "/api/logistics", "ShippingFreight" },
            { "/api/ecommerce", "Ecommerce" },
            { "/api/products", "Ecommerce" },
            { "/api/cart", "Ecommerce" },
            { "/api/orders", "Ecommerce" },
            { "/api/hrpayroll", "HRPayroll" },
            { "/api/employees", "HRPayroll" },
            { "/api/payroll", "HRPayroll" },
            { "/api/landtransport", "LandTransport" },
            { "/api/relocation", "Relocation" },
            { "/api/servicebusiness", "ServiceBusiness" },
            { "/api/budget", "BudgetingForecast" },
            { "/api/doortodoor", "DoorToDoor" },
            { "/api/empost", "Courier" }
        };
        _publicEcommerceEndpoints = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "/api/ecommerce/products",
            "/api/ecommerce/categories",
            "/api/ecommerce/customer/login",
            "/api/ecommerce/customer/register"
        };
    }

    public async Task InvokeAsync(HttpContext context, ITenantContext tenantContext, ITenantModuleService moduleService)
    {
        if (!tenantContext.HasTenant)
        {
            await _next(context);
            return;
        }

        var path = context.Request.Path.Value?.ToLowerInvariant() ?? "";
        
        if (IsPublicEcommerceEndpoint(path))
        {
            await _next(context);
            return;
        }

        var moduleCode = GetModuleFromPath(path);

        if (moduleCode != null)
        {
            var accessLevel = await moduleService.GetModuleAccessLevelAsync(tenantContext.TenantId!.Value, moduleCode);
            var httpMethod = context.Request.Method;
            var isReadRequest = IsReadRequest(httpMethod);

            if (accessLevel == ModuleAccessLevel.None)
            {
                _logger.LogWarning("Module {ModuleCode} access suspended for tenant {TenantId}", moduleCode, tenantContext.TenantId);
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                await context.Response.WriteAsJsonAsync(new
                {
                    error = "Module access suspended for this tenant",
                    moduleCode
                });
                return;
            }

            if (accessLevel == ModuleAccessLevel.ReadOnly && !isReadRequest)
            {
                _logger.LogWarning("Module {ModuleCode} write access denied (read-only) for tenant {TenantId}", moduleCode, tenantContext.TenantId);
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                await context.Response.WriteAsJsonAsync(new
                {
                    error = "Module is in read-only mode. Create, update, and delete operations are not allowed.",
                    moduleCode,
                    accessLevel = "read-only"
                });
                return;
            }

            context.Items["ModuleAccessLevel"] = accessLevel;
            context.Items["IsModuleReadOnly"] = accessLevel == ModuleAccessLevel.ReadOnly;
        }

        await _next(context);
    }

    private string? GetModuleFromPath(string path)
    {
        foreach (var mapping in _routeToModuleMap)
        {
            if (path.StartsWith(mapping.Key, StringComparison.OrdinalIgnoreCase))
            {
                return mapping.Value;
            }
        }
        return null;
    }

    private bool IsPublicEcommerceEndpoint(string path)
    {
        foreach (var endpoint in _publicEcommerceEndpoints)
        {
            if (path.StartsWith(endpoint, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }
        return false;
    }

    private static bool IsReadRequest(string httpMethod)
    {
        return httpMethod.Equals("GET", StringComparison.OrdinalIgnoreCase) ||
               httpMethod.Equals("HEAD", StringComparison.OrdinalIgnoreCase) ||
               httpMethod.Equals("OPTIONS", StringComparison.OrdinalIgnoreCase);
    }
}
