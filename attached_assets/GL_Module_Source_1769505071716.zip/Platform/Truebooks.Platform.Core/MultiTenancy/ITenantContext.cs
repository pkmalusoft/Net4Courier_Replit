namespace Truebooks.Platform.Core.MultiTenancy;

public interface ITenantContext
{
    Guid? TenantId { get; }
    string? TenantName { get; }
    bool HasTenant { get; }
}

public class TenantContext : ITenantContext
{
    public Guid? TenantId { get; set; }
    public string? TenantName { get; set; }
    public bool HasTenant => TenantId.HasValue;
}
