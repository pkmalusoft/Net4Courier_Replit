using System.ComponentModel.DataAnnotations;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Models;

public class PeriodStatusChangeLog : BaseEntity
{
    [Required]
    public Guid FinancialPeriodId { get; set; }
    public FinancialPeriod FinancialPeriod { get; set; } = null!;

    [Required]
    public FinancialPeriodStatus PreviousStatus { get; set; }

    [Required]
    public FinancialPeriodStatus NewStatus { get; set; }

    [Required]
    public Guid ChangedByUserId { get; set; }

    [MaxLength(100)]
    public string? ChangedByUserName { get; set; }

    [MaxLength(50)]
    public string? ChangedByUserRole { get; set; }

    [Required]
    public DateTime ChangedAt { get; set; } = DateTime.UtcNow;

    [MaxLength(500)]
    public string? Reason { get; set; }

    [MaxLength(50)]
    public string? IpAddress { get; set; }
}
