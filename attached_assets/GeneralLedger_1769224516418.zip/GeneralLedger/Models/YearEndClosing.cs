using System.ComponentModel.DataAnnotations;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Models;

public class YearEndClosing : BaseEntity
{
    [Required]
    [MaxLength(50)]
    public string ClosingNumber { get; set; } = string.Empty;

    [Required]
    public Guid FinancialPeriodId { get; set; }
    public FinancialPeriod FinancialPeriod { get; set; } = null!;

    public YearEndClosingStatus Status { get; set; } = YearEndClosingStatus.Draft;

    public DateTime? ValidationDate { get; set; }
    public Guid? ValidatedByUserId { get; set; }

    public DateTime? ClosingDate { get; set; }
    public Guid? ClosedByUserId { get; set; }

    public DateTime? RollbackDate { get; set; }
    public Guid? RolledBackByUserId { get; set; }
    
    [MaxLength(500)]
    public string? RollbackReason { get; set; }

    public Guid? ClosingJournalEntryId { get; set; }
    public JournalEntry? ClosingJournalEntry { get; set; }

    public Guid? OpeningJournalEntryId { get; set; }
    public JournalEntry? OpeningJournalEntry { get; set; }

    public decimal TotalRevenue { get; set; }
    public decimal TotalExpense { get; set; }
    public decimal NetIncomeOrLoss { get; set; }

    public decimal ARControlBalance { get; set; }
    public decimal ARSubledgerBalance { get; set; }
    public decimal ARVariance { get; set; }

    public decimal APControlBalance { get; set; }
    public decimal APSubledgerBalance { get; set; }
    public decimal APVariance { get; set; }

    public decimal InventoryControlBalance { get; set; }
    public decimal InventorySubledgerBalance { get; set; }
    public decimal InventoryVariance { get; set; }

    [MaxLength(2000)]
    public string? ValidationErrors { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public ICollection<OpeningBalanceSnapshot> OpeningBalanceSnapshots { get; set; } = new List<OpeningBalanceSnapshot>();
}
