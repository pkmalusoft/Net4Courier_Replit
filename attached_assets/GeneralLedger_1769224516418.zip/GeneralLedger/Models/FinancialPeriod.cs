using System.ComponentModel.DataAnnotations;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Models;

public class FinancialPeriod : BaseEntity
{
    [Required]
    [MaxLength(50)]
    public string PeriodName { get; set; } = string.Empty;

    [Required]
    public int FiscalYear { get; set; }

    [Required]
    public int PeriodNumber { get; set; }

    [Required]
    public DateTime StartDate { get; set; }

    [Required]
    public DateTime EndDate { get; set; }

    public FinancialPeriodStatus Status { get; set; } = FinancialPeriodStatus.NotOpened;

    public bool IsYearEnd { get; set; }

    public DateTime? OpenedDate { get; set; }
    public Guid? OpenedByUserId { get; set; }

    public DateTime? ClosedDate { get; set; }
    public Guid? ClosedByUserId { get; set; }

    public DateTime? LockedDate { get; set; }
    public Guid? LockedByUserId { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }

    public Guid? PreviousPeriodId { get; set; }
    public FinancialPeriod? PreviousPeriod { get; set; }

    public Guid? NextPeriodId { get; set; }
    public FinancialPeriod? NextPeriod { get; set; }

    public Guid? FinancialCalendarId { get; set; }
    public FinancialCalendar? FinancialCalendar { get; set; }

    public ICollection<YearEndClosing> YearEndClosings { get; set; } = new List<YearEndClosing>();
}
