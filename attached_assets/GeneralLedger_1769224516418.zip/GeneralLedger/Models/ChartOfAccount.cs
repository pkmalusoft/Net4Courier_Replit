using System.ComponentModel.DataAnnotations;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Models;

public class ChartOfAccount : BaseEntity
{
    [MaxLength(20)]
    public string? AccountCode { get; set; }

    [Required]
    [MaxLength(200)]
    public string AccountName { get; set; } = string.Empty;

    public AccountType AccountType { get; set; }

    public Guid? ParentAccountId { get; set; }
    public ChartOfAccount? ParentAccount { get; set; }

    public ICollection<ChartOfAccount> SubAccounts { get; set; } = new List<ChartOfAccount>();

    public bool IsActive { get; set; } = true;

    // Deactivation / Void Metadata
    public DateTime? DeactivatedDate { get; set; }

    public Guid? DeactivatedByUserId { get; set; }

    [MaxLength(500)]
    public string? DeactivationReason { get; set; }

    public bool AllowPosting { get; set; } = true;

    public Guid? AccountClassificationId { get; set; }
    public AccountClassification? AccountClassification { get; set; }

    public ControlAccountType ControlAccountType { get; set; } = ControlAccountType.None;

    public bool IsSystemAccount { get; set; } = false;
}
