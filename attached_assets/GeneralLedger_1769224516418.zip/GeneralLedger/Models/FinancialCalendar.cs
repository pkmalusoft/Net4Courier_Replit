using System.ComponentModel.DataAnnotations;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Models;

public class FinancialCalendar : BaseEntity
{
    [Required]
    [MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [MaxLength(20)]
    public string Code { get; set; } = string.Empty;

    public CalendarType Type { get; set; } = CalendarType.Statutory;

    [Range(1, 12)]
    public int StartMonth { get; set; } = 1;

    public bool IsPrimary { get; set; }

    public bool IsActive { get; set; } = true;

    [MaxLength(500)]
    public string? Description { get; set; }

    [MaxLength(3)]
    public string? CountryCode { get; set; }

    public ICollection<FinancialPeriod> Periods { get; set; } = new List<FinancialPeriod>();

    public ICollection<RevenueRecognitionSchedule> RecognitionSchedules { get; set; } = new List<RevenueRecognitionSchedule>();
}
