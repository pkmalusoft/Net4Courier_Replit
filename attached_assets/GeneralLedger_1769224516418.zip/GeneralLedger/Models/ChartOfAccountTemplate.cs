using System.ComponentModel.DataAnnotations;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Models;

public class ChartOfAccountTemplate
{
    [Key]
    public Guid Id { get; set; }
    
    [Required]
    public IndustryType IndustryType { get; set; }
    
    [MaxLength(20)]
    public string? AccountCode { get; set; }
    
    [Required]
    [MaxLength(200)]
    public string AccountName { get; set; } = string.Empty;
    
    [Required]
    public AccountType AccountType { get; set; }
    
    [MaxLength(20)]
    public string? ParentCode { get; set; }
    
    public int SortOrder { get; set; }
    
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
