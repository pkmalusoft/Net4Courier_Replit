using System.ComponentModel.DataAnnotations;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Models;

public class RevenueRecognitionLine : BaseEntity
{
    [Required]
    public Guid ScheduleId { get; set; }
    public RevenueRecognitionSchedule? Schedule { get; set; }

    public int SequenceNo { get; set; }

    [Required]
    public DateTime RecognitionDate { get; set; }

    [Required]
    public decimal Amount { get; set; }

    public Guid? ClientPeriodId { get; set; }
    public FinancialPeriod? ClientPeriod { get; set; }

    public Guid? StatutoryPeriodId { get; set; }
    public FinancialPeriod? StatutoryPeriod { get; set; }

    public int StatutoryFiscalYear { get; set; }

    public RecognitionLineStatus Status { get; set; } = RecognitionLineStatus.Pending;

    public DateTime? PostedDate { get; set; }

    public Guid? JournalEntryId { get; set; }

    [MaxLength(50)]
    public string? JournalEntryNo { get; set; }

    [MaxLength(500)]
    public string? ErrorMessage { get; set; }

    public int RetryCount { get; set; }
}
