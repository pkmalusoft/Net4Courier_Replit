using System.ComponentModel.DataAnnotations;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Models;

public class RevenueRecognitionSchedule : BaseEntity
{
    [Required]
    public Guid SourceEntityId { get; set; }

    [Required]
    [MaxLength(50)]
    public string SourceEntityType { get; set; } = string.Empty;

    [Required]
    [MaxLength(50)]
    public string SourceDocumentNo { get; set; } = string.Empty;

    [Required]
    public Guid CustomerId { get; set; }

    [Required]
    [MaxLength(200)]
    public string CustomerName { get; set; } = string.Empty;

    [Required]
    public decimal TotalAmount { get; set; }

    [Required]
    [MaxLength(3)]
    public string Currency { get; set; } = "INR";

    public decimal RecognizedAmount { get; set; }

    public decimal DeferredAmount => TotalAmount - RecognizedAmount;

    [Required]
    public DateTime ServiceStartDate { get; set; }

    [Required]
    public DateTime ServiceEndDate { get; set; }

    public int TotalPeriods { get; set; }

    public Guid? ClientCalendarId { get; set; }
    public FinancialCalendar? ClientCalendar { get; set; }

    [Required]
    public Guid DeferredRevenueAccountId { get; set; }

    [Required]
    public Guid RevenueAccountId { get; set; }

    public RecognitionStatus Status { get; set; } = RecognitionStatus.Active;

    public DateTime? CompletedDate { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }

    public ICollection<RevenueRecognitionLine> Lines { get; set; } = new List<RevenueRecognitionLine>();
}
