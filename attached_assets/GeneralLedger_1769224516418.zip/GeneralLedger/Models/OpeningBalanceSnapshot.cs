using System.ComponentModel.DataAnnotations;
using Server.Modules.Inventory.Models;

namespace Server.Modules.GeneralLedger.Models;

public class OpeningBalanceSnapshot : BaseEntity
{
    [Required]
    public Guid YearEndClosingId { get; set; }
    public YearEndClosing YearEndClosing { get; set; } = null!;

    [Required]
    public OpeningBalanceType BalanceType { get; set; }

    public Guid? ChartOfAccountId { get; set; }
    public ChartOfAccount? ChartOfAccount { get; set; }

    public Guid? CustomerId { get; set; }
    public Customer? Customer { get; set; }

    public Guid? SupplierId { get; set; }
    public Supplier? Supplier { get; set; }

    public Guid? ItemId { get; set; }
    public Item? Item { get; set; }

    public Guid? LocationId { get; set; }
    public InventoryLocation? Location { get; set; }

    public decimal DebitBalance { get; set; }
    public decimal CreditBalance { get; set; }
    public decimal NetBalance { get; set; }

    public decimal Quantity { get; set; }
    public decimal UnitCost { get; set; }
    public decimal TotalValue { get; set; }

    public Guid? CurrencyId { get; set; }
    public Currency? Currency { get; set; }
    public decimal ExchangeRate { get; set; } = 1;
    public decimal BaseCurrencyBalance { get; set; }

    [MaxLength(500)]
    public string? Description { get; set; }

    public bool IsProcessed { get; set; }
    public DateTime? ProcessedDate { get; set; }
}

public enum OpeningBalanceType
{
    GLAccount,
    CustomerBalance,
    SupplierBalance,
    InventoryBalance
}
