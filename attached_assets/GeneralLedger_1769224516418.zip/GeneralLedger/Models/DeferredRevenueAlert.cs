using System.ComponentModel.DataAnnotations;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Models;

public class DeferredRevenueAlert : BaseEntity
{
    public Guid? ScheduleId { get; set; }
    public RevenueRecognitionSchedule? Schedule { get; set; }

    public DeferredRevenueAlertType AlertType { get; set; } = DeferredRevenueAlertType.Recognition;

    [Required]
    [MaxLength(200)]
    public string Title { get; set; } = string.Empty;

    [Required]
    [MaxLength(1000)]
    public string Message { get; set; } = string.Empty;

    public decimal Amount { get; set; }

    [MaxLength(3)]
    public string Currency { get; set; } = "INR";

    public DateTime AlertDate { get; set; } = DateTime.UtcNow;

    public bool IsRead { get; set; }

    public bool IsAcknowledged { get; set; }

    public DateTime? AcknowledgedAt { get; set; }

    public Guid? AcknowledgedByUserId { get; set; }

    public bool IsDismissed { get; set; }

    public DateTime? DismissedAt { get; set; }

    [MaxLength(500)]
    public string? ActionUrl { get; set; }
}
