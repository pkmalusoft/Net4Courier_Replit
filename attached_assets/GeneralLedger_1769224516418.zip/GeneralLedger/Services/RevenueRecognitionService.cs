using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.GeneralLedger.Models;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Services;

public interface IRevenueRecognitionService
{
    Task<List<RevenueRecognitionSchedule>> GetAllSchedulesAsync(Guid tenantId);
    Task<RevenueRecognitionSchedule?> GetScheduleByIdAsync(Guid scheduleId, Guid tenantId);
    Task<List<RevenueRecognitionSchedule>> GetSchedulesByCustomerAsync(Guid customerId, Guid tenantId);
    Task<List<RevenueRecognitionLine>> GetScheduleLinesAsync(Guid scheduleId, Guid tenantId);
    Task<RevenueRecognitionSchedule> CreateScheduleAsync(RevenueRecognitionSchedule schedule, Guid tenantId, Guid userId);
    Task<RevenueRecognitionSchedule> CancelScheduleAsync(Guid scheduleId, Guid tenantId, Guid userId, string? reason = null);
    Task<DeferredRevenueDashboard> GetDashboardAsync(Guid tenantId);
    Task<List<RevenueRecognitionLine>> GetPendingLinesAsync(Guid tenantId, DateTime? asOfDate = null);
    Task<List<DeferredRevenueAlert>> GetAlertsAsync(Guid tenantId, bool unreadOnly = false);
    Task AcknowledgeAlertAsync(Guid alertId, Guid tenantId, Guid userId);
    Task DismissAlertAsync(Guid alertId, Guid tenantId, Guid userId);
    Task<DeferredRevenueAlertSummary> GetAlertSummaryAsync(Guid tenantId);
}

public class DeferredRevenueDashboard
{
    public decimal TotalDeferred { get; set; }
    public decimal RecognizedThisMonth { get; set; }
    public decimal RecognizedThisFY { get; set; }
    public int ActiveSchedules { get; set; }
    public int PendingRecognitions { get; set; }
    public string Currency { get; set; } = "INR";
}

public class DeferredRevenueAlertSummary
{
    public int TotalCount { get; set; }
    public int UnreadCount { get; set; }
    public int RecognitionCount { get; set; }
    public int ErrorCount { get; set; }
}

public class RevenueRecognitionService : IRevenueRecognitionService
{
    private readonly AppDbContext _context;
    private readonly IFinancialCalendarService _calendarService;
    private readonly ILogger<RevenueRecognitionService> _logger;

    public RevenueRecognitionService(
        AppDbContext context, 
        IFinancialCalendarService calendarService,
        ILogger<RevenueRecognitionService> logger)
    {
        _context = context;
        _calendarService = calendarService;
        _logger = logger;
    }

    public async Task<List<RevenueRecognitionSchedule>> GetAllSchedulesAsync(Guid tenantId)
    {
        return await _context.RevenueRecognitionSchedules
            .Include(s => s.ClientCalendar)
            .Where(s => s.TenantId == tenantId)
            .OrderByDescending(s => s.CreatedAt)
            .ToListAsync();
    }

    public async Task<RevenueRecognitionSchedule?> GetScheduleByIdAsync(Guid scheduleId, Guid tenantId)
    {
        return await _context.RevenueRecognitionSchedules
            .Include(s => s.ClientCalendar)
            .Include(s => s.Lines)
            .FirstOrDefaultAsync(s => s.Id == scheduleId && s.TenantId == tenantId);
    }

    public async Task<List<RevenueRecognitionSchedule>> GetSchedulesByCustomerAsync(Guid customerId, Guid tenantId)
    {
        return await _context.RevenueRecognitionSchedules
            .Include(s => s.ClientCalendar)
            .Where(s => s.TenantId == tenantId && s.CustomerId == customerId)
            .OrderByDescending(s => s.CreatedAt)
            .ToListAsync();
    }

    public async Task<List<RevenueRecognitionLine>> GetScheduleLinesAsync(Guid scheduleId, Guid tenantId)
    {
        return await _context.RevenueRecognitionLines
            .Where(l => l.ScheduleId == scheduleId && l.TenantId == tenantId)
            .OrderBy(l => l.SequenceNo)
            .ToListAsync();
    }

    public async Task<RevenueRecognitionSchedule> CreateScheduleAsync(RevenueRecognitionSchedule schedule, Guid tenantId, Guid userId)
    {
        if (schedule.ClientCalendarId.HasValue)
        {
            var calendar = await _calendarService.GetCalendarByIdAsync(schedule.ClientCalendarId.Value, tenantId);
            if (calendar == null)
            {
                throw new InvalidOperationException("Invalid calendar reference or calendar does not belong to this tenant.");
            }
            if (!calendar.IsActive)
            {
                throw new InvalidOperationException("The specified calendar is not active.");
            }
        }

        var deferredAccount = await _context.ChartOfAccounts
            .FirstOrDefaultAsync(a => a.Id == schedule.DeferredRevenueAccountId && a.TenantId == tenantId);
        if (deferredAccount == null)
        {
            throw new InvalidOperationException("Invalid deferred revenue account or account does not belong to this tenant.");
        }

        var revenueAccount = await _context.ChartOfAccounts
            .FirstOrDefaultAsync(a => a.Id == schedule.RevenueAccountId && a.TenantId == tenantId);
        if (revenueAccount == null)
        {
            throw new InvalidOperationException("Invalid revenue account or account does not belong to this tenant.");
        }

        schedule.TenantId = tenantId;
        schedule.CreatedBy = userId.ToString();
        schedule.CreatedAt = DateTime.UtcNow;
        schedule.Status = RecognitionStatus.Active;
        schedule.RecognizedAmount = 0;

        var totalMonths = ((schedule.ServiceEndDate.Year - schedule.ServiceStartDate.Year) * 12) 
                          + schedule.ServiceEndDate.Month - schedule.ServiceStartDate.Month + 1;
        schedule.TotalPeriods = totalMonths;

        var monthlyAmount = Math.Round(schedule.TotalAmount / totalMonths, 2);
        var remainder = schedule.TotalAmount - (monthlyAmount * totalMonths);

        var lines = new List<RevenueRecognitionLine>();
        var currentDate = new DateTime(schedule.ServiceStartDate.Year, schedule.ServiceStartDate.Month, 1);

        for (int i = 0; i < totalMonths; i++)
        {
            var endOfMonth = currentDate.AddMonths(1).AddDays(-1);
            var amount = monthlyAmount;
            
            if (i == totalMonths - 1)
                amount += remainder;

            var statutoryPeriod = await _calendarService.MapDateToStatutoryPeriodAsync(endOfMonth, tenantId);

            var line = new RevenueRecognitionLine
            {
                TenantId = tenantId,
                ScheduleId = schedule.Id,
                SequenceNo = i + 1,
                RecognitionDate = endOfMonth,
                Amount = amount,
                StatutoryPeriodId = statutoryPeriod?.Id,
                StatutoryFiscalYear = statutoryPeriod?.FiscalYear ?? 0,
                Status = RecognitionLineStatus.Pending,
                CreatedBy = userId.ToString(),
                CreatedAt = DateTime.UtcNow
            };

            lines.Add(line);
            currentDate = currentDate.AddMonths(1);
        }

        schedule.Lines = lines;

        _context.RevenueRecognitionSchedules.Add(schedule);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Created revenue recognition schedule {ScheduleId} for {DocumentNo} with {LineCount} periods", 
            schedule.Id, schedule.SourceDocumentNo, lines.Count);

        return schedule;
    }

    public async Task<RevenueRecognitionSchedule> CancelScheduleAsync(Guid scheduleId, Guid tenantId, Guid userId, string? reason = null)
    {
        var schedule = await GetScheduleByIdAsync(scheduleId, tenantId);
        if (schedule == null)
            throw new InvalidOperationException("Schedule not found");

        if (schedule.Status == RecognitionStatus.Cancelled)
            throw new InvalidOperationException("Schedule is already cancelled");

        foreach (var line in schedule.Lines.Where(l => l.Status == RecognitionLineStatus.Pending))
        {
            line.Status = RecognitionLineStatus.Skipped;
            line.UpdatedAt = DateTime.UtcNow;
            line.UpdatedBy = userId.ToString();
        }

        schedule.Status = RecognitionStatus.Cancelled;
        schedule.Notes = reason ?? schedule.Notes;
        schedule.UpdatedAt = DateTime.UtcNow;
        schedule.UpdatedBy = userId.ToString();

        await _context.SaveChangesAsync();

        _logger.LogInformation("Cancelled revenue recognition schedule {ScheduleId}", scheduleId);

        return schedule;
    }

    public async Task<DeferredRevenueDashboard> GetDashboardAsync(Guid tenantId)
    {
        var today = DateTime.UtcNow.Date;
        var startOfMonth = new DateTime(today.Year, today.Month, 1);
        var endOfMonth = startOfMonth.AddMonths(1).AddDays(-1);

        var currentPeriod = await _calendarService.MapDateToStatutoryPeriodAsync(today, tenantId);
        var currentFY = currentPeriod?.FiscalYear ?? today.Year;

        var activeSchedules = await _context.RevenueRecognitionSchedules
            .Where(s => s.TenantId == tenantId && s.Status == RecognitionStatus.Active)
            .ToListAsync();

        var totalDeferred = activeSchedules.Sum(s => s.DeferredAmount);

        var recognizedThisMonth = await _context.RevenueRecognitionLines
            .Where(l => l.TenantId == tenantId && 
                       l.Status == RecognitionLineStatus.Posted &&
                       l.PostedDate >= startOfMonth && 
                       l.PostedDate <= endOfMonth)
            .SumAsync(l => l.Amount);

        var recognizedThisFY = await _context.RevenueRecognitionLines
            .Where(l => l.TenantId == tenantId && 
                       l.Status == RecognitionLineStatus.Posted &&
                       l.StatutoryFiscalYear == currentFY)
            .SumAsync(l => l.Amount);

        var pendingRecognitions = await _context.RevenueRecognitionLines
            .Where(l => l.TenantId == tenantId && 
                       l.Status == RecognitionLineStatus.Pending &&
                       l.RecognitionDate <= today)
            .CountAsync();

        return new DeferredRevenueDashboard
        {
            TotalDeferred = totalDeferred,
            RecognizedThisMonth = recognizedThisMonth,
            RecognizedThisFY = recognizedThisFY,
            ActiveSchedules = activeSchedules.Count,
            PendingRecognitions = pendingRecognitions,
            Currency = activeSchedules.FirstOrDefault()?.Currency ?? "INR"
        };
    }

    public async Task<List<RevenueRecognitionLine>> GetPendingLinesAsync(Guid tenantId, DateTime? asOfDate = null)
    {
        var cutoffDate = asOfDate ?? DateTime.UtcNow.Date;

        return await _context.RevenueRecognitionLines
            .Include(l => l.Schedule)
            .Where(l => l.TenantId == tenantId && 
                       l.Status == RecognitionLineStatus.Pending &&
                       l.RecognitionDate <= cutoffDate)
            .OrderBy(l => l.RecognitionDate)
            .ToListAsync();
    }

    public async Task<List<DeferredRevenueAlert>> GetAlertsAsync(Guid tenantId, bool unreadOnly = false)
    {
        var query = _context.DeferredRevenueAlerts
            .Where(a => a.TenantId == tenantId && !a.IsDismissed);

        if (unreadOnly)
            query = query.Where(a => !a.IsRead);

        return await query
            .OrderByDescending(a => a.AlertDate)
            .Take(50)
            .ToListAsync();
    }

    public async Task AcknowledgeAlertAsync(Guid alertId, Guid tenantId, Guid userId)
    {
        var alert = await _context.DeferredRevenueAlerts
            .FirstOrDefaultAsync(a => a.Id == alertId && a.TenantId == tenantId);

        if (alert != null)
        {
            alert.IsAcknowledged = true;
            alert.AcknowledgedAt = DateTime.UtcNow;
            alert.AcknowledgedByUserId = userId;
            alert.IsRead = true;
            await _context.SaveChangesAsync();
        }
    }

    public async Task DismissAlertAsync(Guid alertId, Guid tenantId, Guid userId)
    {
        var alert = await _context.DeferredRevenueAlerts
            .FirstOrDefaultAsync(a => a.Id == alertId && a.TenantId == tenantId);

        if (alert != null)
        {
            alert.IsDismissed = true;
            alert.DismissedAt = DateTime.UtcNow;
            alert.IsRead = true;
            await _context.SaveChangesAsync();
        }
    }

    public async Task<DeferredRevenueAlertSummary> GetAlertSummaryAsync(Guid tenantId)
    {
        var alerts = await _context.DeferredRevenueAlerts
            .Where(a => a.TenantId == tenantId && !a.IsDismissed)
            .ToListAsync();

        return new DeferredRevenueAlertSummary
        {
            TotalCount = alerts.Count,
            UnreadCount = alerts.Count(a => !a.IsRead),
            RecognitionCount = alerts.Count(a => a.AlertType == DeferredRevenueAlertType.Recognition || 
                                                  a.AlertType == DeferredRevenueAlertType.Summary),
            ErrorCount = alerts.Count(a => a.AlertType == DeferredRevenueAlertType.Error)
        };
    }
}
