using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.GeneralLedger.Models;
using Server.Modules.AP.Models;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Services;

public interface IControlAccountReconciliationService
{
    Task<ControlAccountReconciliationResult> ReconcileAllControlAccountsAsync(Guid tenantId, DateTime asOfDate);
    Task<SubledgerReconciliationResult> ReconcileARAsync(Guid tenantId, DateTime asOfDate);
    Task<SubledgerReconciliationResult> ReconcileAPAsync(Guid tenantId, DateTime asOfDate);
    Task<SubledgerReconciliationResult> ReconcileInventoryAsync(Guid tenantId, DateTime asOfDate);
}

public class ControlAccountReconciliationResult
{
    public DateTime AsOfDate { get; set; }
    public SubledgerReconciliationResult ARReconciliation { get; set; } = new();
    public SubledgerReconciliationResult APReconciliation { get; set; } = new();
    public SubledgerReconciliationResult InventoryReconciliation { get; set; } = new();
    public bool AllReconciled => ARReconciliation.IsReconciled && APReconciliation.IsReconciled && InventoryReconciliation.IsReconciled;
    public List<string> Errors { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
}

public class SubledgerReconciliationResult
{
    public string AccountName { get; set; } = string.Empty;
    public Guid? ControlAccountId { get; set; }
    public decimal ControlBalance { get; set; }
    public decimal SubledgerBalance { get; set; }
    public decimal Variance => Math.Abs(ControlBalance - SubledgerBalance);
    public bool IsReconciled => Variance < 0.01m;
    public bool IsConfigured { get; set; }
    public List<SubledgerDetail> Details { get; set; } = new();
}

public class SubledgerDetail
{
    public Guid EntityId { get; set; }
    public string EntityName { get; set; } = string.Empty;
    public decimal Balance { get; set; }
}

public class ControlAccountReconciliationService : IControlAccountReconciliationService
{
    private readonly AppDbContext _context;
    private readonly ILogger<ControlAccountReconciliationService> _logger;

    public ControlAccountReconciliationService(AppDbContext context, ILogger<ControlAccountReconciliationService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<ControlAccountReconciliationResult> ReconcileAllControlAccountsAsync(Guid tenantId, DateTime asOfDate)
    {
        var result = new ControlAccountReconciliationResult
        {
            AsOfDate = asOfDate
        };

        try
        {
            result.ARReconciliation = await ReconcileARAsync(tenantId, asOfDate);
            result.APReconciliation = await ReconcileAPAsync(tenantId, asOfDate);
            result.InventoryReconciliation = await ReconcileInventoryAsync(tenantId, asOfDate);

            if (!result.ARReconciliation.IsReconciled && result.ARReconciliation.IsConfigured)
            {
                result.Warnings.Add($"AR Control variance: {result.ARReconciliation.Variance:C2}");
            }

            if (!result.APReconciliation.IsReconciled && result.APReconciliation.IsConfigured)
            {
                result.Warnings.Add($"AP Control variance: {result.APReconciliation.Variance:C2}");
            }

            if (!result.InventoryReconciliation.IsReconciled && result.InventoryReconciliation.IsConfigured)
            {
                result.Warnings.Add($"Inventory Control variance: {result.InventoryReconciliation.Variance:C2}");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error reconciling control accounts for tenant {TenantId}", tenantId);
            result.Errors.Add($"Reconciliation error: {ex.Message}");
        }

        return result;
    }

    public async Task<SubledgerReconciliationResult> ReconcileARAsync(Guid tenantId, DateTime asOfDate)
    {
        var result = new SubledgerReconciliationResult
        {
            AccountName = "Accounts Receivable"
        };

        var arControlAccount = await _context.ChartOfAccounts
            .FirstOrDefaultAsync(a => a.TenantId == tenantId && 
                                     a.ControlAccountType == ControlAccountType.AccountsReceivable && 
                                     a.IsActive);

        if (arControlAccount == null)
        {
            result.IsConfigured = false;
            return result;
        }

        result.IsConfigured = true;
        result.ControlAccountId = arControlAccount.Id;
        result.AccountName = arControlAccount.AccountName;

        result.ControlBalance = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId && 
                       l.AccountId == arControlAccount.Id &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate <= asOfDate)
            .SumAsync(l => l.Debit - l.Credit);

        var customers = await _context.Customers
            .Where(c => c.TenantId == tenantId && c.IsActive)
            .ToListAsync();

        foreach (var customer in customers)
        {
            var invoiceBalance = await _context.SalesInvoices
                .Where(i => i.TenantId == tenantId && 
                           i.CustomerId == customer.Id && 
                           i.Status != InvoiceStatus.Cancelled &&
                           !i.IsVoided &&
                           i.InvoiceDate <= asOfDate)
                .SumAsync(i => i.BalanceAmount);

            if (Math.Abs(invoiceBalance) > 0.001m)
            {
                result.Details.Add(new SubledgerDetail
                {
                    EntityId = customer.Id,
                    EntityName = customer.Name,
                    Balance = invoiceBalance
                });
            }

            result.SubledgerBalance += invoiceBalance;
        }

        _logger.LogDebug("AR Reconciliation: Control={Control}, Subledger={Subledger}, Variance={Variance}",
            result.ControlBalance, result.SubledgerBalance, result.Variance);

        return result;
    }

    public async Task<SubledgerReconciliationResult> ReconcileAPAsync(Guid tenantId, DateTime asOfDate)
    {
        var result = new SubledgerReconciliationResult
        {
            AccountName = "Accounts Payable"
        };

        var apControlAccount = await _context.ChartOfAccounts
            .FirstOrDefaultAsync(a => a.TenantId == tenantId && 
                                     a.ControlAccountType == ControlAccountType.AccountsPayable && 
                                     a.IsActive);

        if (apControlAccount == null)
        {
            result.IsConfigured = false;
            return result;
        }

        result.IsConfigured = true;
        result.ControlAccountId = apControlAccount.Id;
        result.AccountName = apControlAccount.AccountName;

        result.ControlBalance = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId && 
                       l.AccountId == apControlAccount.Id &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate <= asOfDate)
            .SumAsync(l => l.Credit - l.Debit);

        var vendors = await _context.Vendors
            .Where(v => v.TenantId == tenantId && v.IsActive)
            .ToListAsync();

        foreach (var vendor in vendors)
        {
            var billBalance = await _context.PurchaseBills
                .Where(b => b.TenantId == tenantId && 
                           b.VendorId == vendor.Id && 
                           b.Status != BillStatus.Cancelled &&
                           !b.IsVoided &&
                           b.BillDate <= asOfDate)
                .SumAsync(b => b.BalanceAmount);

            if (Math.Abs(billBalance) > 0.001m)
            {
                result.Details.Add(new SubledgerDetail
                {
                    EntityId = vendor.Id,
                    EntityName = vendor.Name,
                    Balance = billBalance
                });
            }

            result.SubledgerBalance += billBalance;
        }

        _logger.LogDebug("AP Reconciliation: Control={Control}, Subledger={Subledger}, Variance={Variance}",
            result.ControlBalance, result.SubledgerBalance, result.Variance);

        return result;
    }

    public async Task<SubledgerReconciliationResult> ReconcileInventoryAsync(Guid tenantId, DateTime asOfDate)
    {
        var result = new SubledgerReconciliationResult
        {
            AccountName = "Inventory"
        };

        var inventoryControlAccount = await _context.ChartOfAccounts
            .FirstOrDefaultAsync(a => a.TenantId == tenantId && 
                                     a.ControlAccountType == ControlAccountType.Inventory && 
                                     a.IsActive);

        if (inventoryControlAccount == null)
        {
            result.IsConfigured = false;
            return result;
        }

        result.IsConfigured = true;
        result.ControlAccountId = inventoryControlAccount.Id;
        result.AccountName = inventoryControlAccount.AccountName;

        result.ControlBalance = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId && 
                       l.AccountId == inventoryControlAccount.Id &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate <= asOfDate)
            .SumAsync(l => l.Debit - l.Credit);

        var inventoryDetails = await _context.ItemInventoryDetails
            .Include(d => d.Item)
            .Where(d => d.TenantId == tenantId)
            .ToListAsync();

        foreach (var detail in inventoryDetails)
        {
            var itemValue = detail.QuantityOnHand * (detail.Item?.StandardCost ?? 0);
            
            if (Math.Abs(itemValue) > 0.001m)
            {
                result.Details.Add(new SubledgerDetail
                {
                    EntityId = detail.ItemId,
                    EntityName = detail.Item?.Name ?? "Unknown Item",
                    Balance = itemValue
                });
            }

            result.SubledgerBalance += itemValue;
        }

        _logger.LogDebug("Inventory Reconciliation: Control={Control}, Subledger={Subledger}, Variance={Variance}",
            result.ControlBalance, result.SubledgerBalance, result.Variance);

        return result;
    }
}
