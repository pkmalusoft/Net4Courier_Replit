using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.GeneralLedger.Models;
using Server.Modules.AP.Models;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Services;

public interface IYearEndClosingService
{
    Task<YearEndClosing> CreateClosingAsync(Guid periodId, Guid tenantId, Guid userId);
    Task<YearEndClosing?> GetClosingByIdAsync(Guid closingId, Guid tenantId);
    Task<YearEndClosing?> GetClosingForPeriodAsync(Guid periodId, Guid tenantId);
    Task<List<YearEndClosing>> GetAllClosingsAsync(Guid tenantId);
    
    Task<YearEndClosingValidationResult> Stage1_ValidateAsync(Guid closingId, Guid tenantId, Guid userId);
    Task<YearEndClosing> Stage2_CloseIncomeExpenseAsync(Guid closingId, Guid tenantId, Guid userId);
    Task<YearEndClosing> Stage3_SnapshotSubledgersAsync(Guid closingId, Guid tenantId, Guid userId);
    Task<YearEndClosing> Stage4_SnapshotInventoryAsync(Guid closingId, Guid tenantId, Guid userId);
    Task<YearEndClosing> Stage5_GenerateOpeningJEAsync(Guid closingId, Guid tenantId, Guid userId);
    
    Task<YearEndClosing> CompleteClosingAsync(Guid closingId, Guid tenantId, Guid userId);
    Task<YearEndClosing> RollbackClosingAsync(Guid closingId, Guid tenantId, Guid userId, string reason);
}

public class YearEndClosingValidationResult
{
    public bool IsValid { get; set; }
    public List<string> Errors { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
    
    public bool ARControlConfigured { get; set; }
    public bool APControlConfigured { get; set; }
    public bool InventoryControlConfigured { get; set; }
    public bool RetainedEarningsConfigured { get; set; }
    
    public decimal TotalRevenue { get; set; }
    public decimal TotalExpense { get; set; }
    public decimal NetIncomeOrLoss { get; set; }
    
    public decimal ARControlBalance { get; set; }
    public decimal ARSubledgerBalance { get; set; }
    public decimal ARVariance { get; set; }
    
    public decimal APControlBalance { get; set; }
    public decimal APSubledgerBalance { get; set; }
    public decimal APVariance { get; set; }
    
    public decimal InventoryControlBalance { get; set; }
    public decimal InventorySubledgerBalance { get; set; }
    public decimal InventoryVariance { get; set; }
    
    public int UnpostedJournals { get; set; }
    public int DraftDocuments { get; set; }
}

public class YearEndClosingService : IYearEndClosingService
{
    private readonly AppDbContext _context;
    private readonly IFinancialPeriodService _periodService;
    private readonly IControlAccountReconciliationService _reconciliationService;
    private readonly IVoucherNumberingService _voucherService;
    private readonly ILogger<YearEndClosingService> _logger;

    public YearEndClosingService(
        AppDbContext context,
        IFinancialPeriodService periodService,
        IControlAccountReconciliationService reconciliationService,
        IVoucherNumberingService voucherService,
        ILogger<YearEndClosingService> logger)
    {
        _context = context;
        _periodService = periodService;
        _reconciliationService = reconciliationService;
        _voucherService = voucherService;
        _logger = logger;
    }

    public async Task<YearEndClosing> CreateClosingAsync(Guid periodId, Guid tenantId, Guid userId)
    {
        var period = await _periodService.GetPeriodByIdAsync(periodId, tenantId);
        if (period == null)
            throw new InvalidOperationException("Financial period not found.");

        if (!period.IsYearEnd)
            throw new InvalidOperationException("This period is not a year-end period.");

        var existingClosing = await GetClosingForPeriodAsync(periodId, tenantId);
        if (existingClosing != null && existingClosing.Status != YearEndClosingStatus.RolledBack)
            throw new InvalidOperationException("A year-end closing already exists for this period.");

        var closingNumber = await _voucherService.GenerateNumberAsync(VoucherTransactionType.YearEndClosing, tenantId);

        var closing = new YearEndClosing
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId,
            ClosingNumber = closingNumber,
            FinancialPeriodId = periodId,
            Status = YearEndClosingStatus.Draft,
            CreatedAt = DateTime.UtcNow
        };

        _context.YearEndClosings.Add(closing);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Created year-end closing {ClosingNumber} for period {PeriodId}, tenant {TenantId}",
            closingNumber, periodId, tenantId);

        return closing;
    }

    public async Task<YearEndClosing?> GetClosingByIdAsync(Guid closingId, Guid tenantId)
    {
        return await _context.YearEndClosings
            .Include(c => c.FinancialPeriod)
            .Include(c => c.ClosingJournalEntry)
            .Include(c => c.OpeningJournalEntry)
            .FirstOrDefaultAsync(c => c.Id == closingId && c.TenantId == tenantId);
    }

    public async Task<YearEndClosing?> GetClosingForPeriodAsync(Guid periodId, Guid tenantId)
    {
        return await _context.YearEndClosings
            .Include(c => c.FinancialPeriod)
            .FirstOrDefaultAsync(c => c.FinancialPeriodId == periodId && c.TenantId == tenantId);
    }

    public async Task<List<YearEndClosing>> GetAllClosingsAsync(Guid tenantId)
    {
        return await _context.YearEndClosings
            .Include(c => c.FinancialPeriod)
            .Where(c => c.TenantId == tenantId)
            .OrderByDescending(c => c.CreatedAt)
            .ToListAsync();
    }

    public async Task<YearEndClosingValidationResult> Stage1_ValidateAsync(Guid closingId, Guid tenantId, Guid userId)
    {
        var closing = await GetClosingByIdAsync(closingId, tenantId);
        if (closing == null)
            throw new InvalidOperationException("Year-end closing not found.");

        if (closing.Status != YearEndClosingStatus.Draft)
            throw new InvalidOperationException("Closing must be in Draft status to validate.");

        var period = closing.FinancialPeriod!;
        var result = new YearEndClosingValidationResult();

        result.RetainedEarningsConfigured = await _context.ChartOfAccounts
            .AnyAsync(a => a.TenantId == tenantId && a.ControlAccountType == ControlAccountType.RetainedEarnings && a.IsActive);
        result.ARControlConfigured = await _context.ChartOfAccounts
            .AnyAsync(a => a.TenantId == tenantId && a.ControlAccountType == ControlAccountType.AccountsReceivable && a.IsActive);
        result.APControlConfigured = await _context.ChartOfAccounts
            .AnyAsync(a => a.TenantId == tenantId && a.ControlAccountType == ControlAccountType.AccountsPayable && a.IsActive);
        result.InventoryControlConfigured = await _context.ChartOfAccounts
            .AnyAsync(a => a.TenantId == tenantId && a.ControlAccountType == ControlAccountType.Inventory && a.IsActive);

        if (!result.RetainedEarningsConfigured)
        {
            result.Errors.Add("Retained Earnings account must be configured before year-end closing.");
        }

        if (!result.ARControlConfigured)
        {
            result.Warnings.Add("AR Control account is not configured. AR subledger reconciliation will be skipped.");
        }

        if (!result.APControlConfigured)
        {
            result.Warnings.Add("AP Control account is not configured. AP subledger reconciliation will be skipped.");
        }

        result.UnpostedJournals = await _context.JournalEntries
            .Where(j => j.TenantId == tenantId && j.Status == JournalEntryStatus.Draft && !j.IsVoided)
            .CountAsync();

        if (result.UnpostedJournals > 0)
        {
            result.Errors.Add($"There are {result.UnpostedJournals} unposted journal entries. Please post or cancel them before closing.");
        }

        var revenueAccounts = await _context.ChartOfAccounts
            .Where(a => a.TenantId == tenantId && a.AccountType == AccountType.Revenue && a.IsActive)
            .Select(a => a.Id)
            .ToListAsync();

        var expenseAccounts = await _context.ChartOfAccounts
            .Where(a => a.TenantId == tenantId && a.AccountType == AccountType.Expense && a.IsActive)
            .Select(a => a.Id)
            .ToListAsync();

        result.TotalRevenue = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId && 
                       revenueAccounts.Contains(l.AccountId) &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate >= period.StartDate &&
                       l.JournalEntry.EntryDate <= period.EndDate)
            .SumAsync(l => l.Credit - l.Debit);

        result.TotalExpense = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId && 
                       expenseAccounts.Contains(l.AccountId) &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate >= period.StartDate &&
                       l.JournalEntry.EntryDate <= period.EndDate)
            .SumAsync(l => l.Debit - l.Credit);

        result.NetIncomeOrLoss = result.TotalRevenue - result.TotalExpense;

        if (result.ARControlConfigured)
        {
            var arReconciliation = await _reconciliationService.ReconcileARAsync(tenantId, period.EndDate);
            result.ARControlBalance = arReconciliation.ControlBalance;
            result.ARSubledgerBalance = arReconciliation.SubledgerBalance;
            result.ARVariance = arReconciliation.Variance;
            
            if (Math.Abs(result.ARVariance) > 0.01m)
            {
                result.Warnings.Add($"AR Control variance of {result.ARVariance:C2} detected.");
            }
        }

        if (result.APControlConfigured)
        {
            var apReconciliation = await _reconciliationService.ReconcileAPAsync(tenantId, period.EndDate);
            result.APControlBalance = apReconciliation.ControlBalance;
            result.APSubledgerBalance = apReconciliation.SubledgerBalance;
            result.APVariance = apReconciliation.Variance;
            
            if (Math.Abs(result.APVariance) > 0.01m)
            {
                result.Warnings.Add($"AP Control variance of {result.APVariance:C2} detected.");
            }
        }

        if (result.InventoryControlConfigured)
        {
            var invReconciliation = await _reconciliationService.ReconcileInventoryAsync(tenantId, period.EndDate);
            result.InventoryControlBalance = invReconciliation.ControlBalance;
            result.InventorySubledgerBalance = invReconciliation.SubledgerBalance;
            result.InventoryVariance = invReconciliation.Variance;
            
            if (Math.Abs(result.InventoryVariance) > 0.01m)
            {
                result.Warnings.Add($"Inventory Control variance of {result.InventoryVariance:C2} detected.");
            }
        }

        result.IsValid = !result.Errors.Any();

        closing.ValidationDate = DateTime.UtcNow;
        closing.TotalRevenue = result.TotalRevenue;
        closing.TotalExpense = result.TotalExpense;
        closing.NetIncomeOrLoss = result.NetIncomeOrLoss;
        closing.ARControlBalance = result.ARControlBalance;
        closing.ARSubledgerBalance = result.ARSubledgerBalance;
        closing.ARVariance = result.ARVariance;
        closing.APControlBalance = result.APControlBalance;
        closing.APSubledgerBalance = result.APSubledgerBalance;
        closing.APVariance = result.APVariance;
        closing.InventoryControlBalance = result.InventoryControlBalance;
        closing.InventorySubledgerBalance = result.InventorySubledgerBalance;
        closing.InventoryVariance = result.InventoryVariance;
        closing.ValidationErrors = result.Errors.Any() ? string.Join("; ", result.Errors) : null;

        if (result.IsValid)
        {
            closing.Status = YearEndClosingStatus.Validated;
        }

        await _context.SaveChangesAsync();

        _logger.LogInformation("Validated year-end closing {ClosingId}. Valid: {IsValid}", closingId, result.IsValid);

        return result;
    }

    public async Task<YearEndClosing> Stage2_CloseIncomeExpenseAsync(Guid closingId, Guid tenantId, Guid userId)
    {
        var closing = await GetClosingByIdAsync(closingId, tenantId);
        if (closing == null)
            throw new InvalidOperationException("Year-end closing not found.");

        if (closing.Status != YearEndClosingStatus.Validated)
            throw new InvalidOperationException("Closing must be validated before closing income/expense accounts.");

        var period = closing.FinancialPeriod!;

        var retainedEarningsAccount = await _context.ChartOfAccounts
            .FirstOrDefaultAsync(a => a.TenantId == tenantId && a.ControlAccountType == ControlAccountType.RetainedEarnings && a.IsActive);

        if (retainedEarningsAccount == null)
            throw new InvalidOperationException("Retained Earnings account not configured.");

        var revenueAccounts = await _context.ChartOfAccounts
            .Where(a => a.TenantId == tenantId && a.AccountType == AccountType.Revenue && a.IsActive)
            .Select(a => a.Id)
            .ToListAsync();

        var expenseAccounts = await _context.ChartOfAccounts
            .Where(a => a.TenantId == tenantId && a.AccountType == AccountType.Expense && a.IsActive)
            .Select(a => a.Id)
            .ToListAsync();

        var revenueBalances = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId && 
                       revenueAccounts.Contains(l.AccountId) &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate <= period.EndDate)
            .GroupBy(l => l.AccountId)
            .Select(g => new { AccountId = g.Key, Balance = g.Sum(l => l.Credit - l.Debit) })
            .ToListAsync();

        var expenseBalances = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId && 
                       expenseAccounts.Contains(l.AccountId) &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate <= period.EndDate)
            .GroupBy(l => l.AccountId)
            .Select(g => new { AccountId = g.Key, Balance = g.Sum(l => l.Debit - l.Credit) })
            .ToListAsync();

        var jeNumber = await _voucherService.GenerateNumberAsync(VoucherTransactionType.YearEndClosing, tenantId);

        var closingJE = new JournalEntry
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId,
            EntryNumber = jeNumber,
            EntryDate = period.EndDate,
            Description = $"Year-End Closing Entry - FY{period.FiscalYear}",
            Status = JournalEntryStatus.Posted,
            PostedDate = DateTime.UtcNow,
            PostedByUserId = userId
        };

        var lines = new List<JournalEntryLine>();

        foreach (var revenue in revenueBalances.Where(r => Math.Abs(r.Balance) > 0.001m))
        {
            lines.Add(new JournalEntryLine
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                JournalEntryId = closingJE.Id,
                AccountId = revenue.AccountId,
                Debit = revenue.Balance > 0 ? revenue.Balance : 0,
                Credit = revenue.Balance < 0 ? Math.Abs(revenue.Balance) : 0,
                Description = "Close revenue to Retained Earnings"
            });
        }

        foreach (var expense in expenseBalances.Where(e => Math.Abs(e.Balance) > 0.001m))
        {
            lines.Add(new JournalEntryLine
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                JournalEntryId = closingJE.Id,
                AccountId = expense.AccountId,
                Debit = expense.Balance < 0 ? Math.Abs(expense.Balance) : 0,
                Credit = expense.Balance > 0 ? expense.Balance : 0,
                Description = "Close expense to Retained Earnings"
            });
        }

        var netIncome = closing.NetIncomeOrLoss;
        lines.Add(new JournalEntryLine
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId,
            JournalEntryId = closingJE.Id,
            AccountId = retainedEarningsAccount.Id,
            Debit = netIncome < 0 ? Math.Abs(netIncome) : 0,
            Credit = netIncome > 0 ? netIncome : 0,
            Description = "Net Income/Loss to Retained Earnings"
        });

        closingJE.Lines = lines;

        _context.JournalEntries.Add(closingJE);
        _context.JournalEntryLines.AddRange(lines);

        closing.ClosingJournalEntryId = closingJE.Id;
        closing.Status = YearEndClosingStatus.IncomeExpenseClosed;

        await _context.SaveChangesAsync();

        _logger.LogInformation("Closed income/expense accounts for year-end closing {ClosingId}", closingId);

        return closing;
    }

    public async Task<YearEndClosing> Stage3_SnapshotSubledgersAsync(Guid closingId, Guid tenantId, Guid userId)
    {
        var closing = await GetClosingByIdAsync(closingId, tenantId);
        if (closing == null)
            throw new InvalidOperationException("Year-end closing not found.");

        if (closing.Status != YearEndClosingStatus.IncomeExpenseClosed)
            throw new InvalidOperationException("Income/expense accounts must be closed before snapshotting subledgers.");

        var period = closing.FinancialPeriod!;

        // Clear existing subledger snapshots for this closing before creating new ones
        var existingSubledgerSnapshots = await _context.OpeningBalanceSnapshots
            .Where(s => s.YearEndClosingId == closingId && 
                       (s.BalanceType == OpeningBalanceType.CustomerBalance || 
                        s.BalanceType == OpeningBalanceType.SupplierBalance))
            .ToListAsync();
        
        if (existingSubledgerSnapshots.Any())
        {
            _context.OpeningBalanceSnapshots.RemoveRange(existingSubledgerSnapshots);
            await _context.SaveChangesAsync();
        }

        var customers = await _context.Customers
            .Where(c => c.TenantId == tenantId && c.IsActive)
            .ToListAsync();

        foreach (var customer in customers)
        {
            var invoiceBalance = await _context.SalesInvoices
                .Where(i => i.TenantId == tenantId && 
                           i.CustomerId == customer.Id && 
                           i.Status != InvoiceStatus.Cancelled &&
                           !i.IsVoided &&
                           i.InvoiceDate <= period.EndDate)
                .SumAsync(i => i.BalanceAmount);

            if (Math.Abs(invoiceBalance) > 0.001m)
            {
                var snapshot = new OpeningBalanceSnapshot
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    YearEndClosingId = closingId,
                    BalanceType = OpeningBalanceType.CustomerBalance,
                    CustomerId = customer.Id,
                    DebitBalance = invoiceBalance > 0 ? invoiceBalance : 0,
                    CreditBalance = invoiceBalance < 0 ? Math.Abs(invoiceBalance) : 0,
                    NetBalance = invoiceBalance,
                    Description = $"Opening balance for {customer.Name}"
                };

                _context.OpeningBalanceSnapshots.Add(snapshot);
            }
        }

        var suppliers = await _context.Suppliers
            .Where(s => s.TenantId == tenantId && s.IsActive)
            .ToListAsync();

        foreach (var supplier in suppliers)
        {
            var billBalance = await _context.PurchaseBills
                .Where(b => b.TenantId == tenantId && 
                           b.VendorId == supplier.Id && 
                           b.Status != BillStatus.Cancelled &&
                           !b.IsVoided &&
                           b.BillDate <= period.EndDate)
                .SumAsync(b => b.BalanceAmount);

            if (Math.Abs(billBalance) > 0.001m)
            {
                var snapshot = new OpeningBalanceSnapshot
                {
                    Id = Guid.NewGuid(),
                    TenantId = tenantId,
                    YearEndClosingId = closingId,
                    BalanceType = OpeningBalanceType.SupplierBalance,
                    SupplierId = supplier.Id,
                    DebitBalance = billBalance < 0 ? Math.Abs(billBalance) : 0,
                    CreditBalance = billBalance > 0 ? billBalance : 0,
                    NetBalance = billBalance,
                    Description = $"Opening balance for {supplier.Name}"
                };

                _context.OpeningBalanceSnapshots.Add(snapshot);
            }
        }

        closing.Status = YearEndClosingStatus.SubledgersSnapshotted;
        await _context.SaveChangesAsync();

        _logger.LogInformation("Snapshotted subledgers for year-end closing {ClosingId}", closingId);

        return closing;
    }

    public async Task<YearEndClosing> Stage4_SnapshotInventoryAsync(Guid closingId, Guid tenantId, Guid userId)
    {
        var closing = await GetClosingByIdAsync(closingId, tenantId);
        if (closing == null)
            throw new InvalidOperationException("Year-end closing not found.");

        if (closing.Status != YearEndClosingStatus.SubledgersSnapshotted)
            throw new InvalidOperationException("Subledgers must be snapshotted before snapshotting inventory.");

        var period = closing.FinancialPeriod!;

        // Clear existing inventory snapshots for this closing before creating new ones
        var existingInventorySnapshots = await _context.OpeningBalanceSnapshots
            .Where(s => s.YearEndClosingId == closingId && s.BalanceType == OpeningBalanceType.InventoryBalance)
            .ToListAsync();
        
        if (existingInventorySnapshots.Any())
        {
            _context.OpeningBalanceSnapshots.RemoveRange(existingInventorySnapshots);
            await _context.SaveChangesAsync();
        }

        var inventoryDetails = await _context.ItemInventoryDetails
            .Include(d => d.Item)
            .Include(d => d.Warehouse)
            .Where(d => d.TenantId == tenantId && d.QuantityOnHand > 0)
            .ToListAsync();

        foreach (var detail in inventoryDetails)
        {
            var unitCost = detail.Item?.StandardCost ?? 0;
            var totalValue = detail.QuantityOnHand * unitCost;

            var snapshot = new OpeningBalanceSnapshot
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                YearEndClosingId = closingId,
                BalanceType = OpeningBalanceType.InventoryBalance,
                ItemId = detail.ItemId,
                Quantity = detail.QuantityOnHand,
                UnitCost = unitCost,
                TotalValue = totalValue,
                DebitBalance = totalValue,
                CreditBalance = 0,
                NetBalance = totalValue,
                Description = $"Opening inventory for {detail.Item?.Name ?? "Unknown"} at {detail.Warehouse?.Name ?? "Default"}"
            };

            _context.OpeningBalanceSnapshots.Add(snapshot);
        }

        closing.Status = YearEndClosingStatus.InventorySnapshotted;
        await _context.SaveChangesAsync();

        _logger.LogInformation("Snapshotted inventory for year-end closing {ClosingId}", closingId);

        return closing;
    }

    public async Task<YearEndClosing> Stage5_GenerateOpeningJEAsync(Guid closingId, Guid tenantId, Guid userId)
    {
        var closing = await GetClosingByIdAsync(closingId, tenantId);
        if (closing == null)
            throw new InvalidOperationException("Year-end closing not found.");

        if (closing.Status != YearEndClosingStatus.InventorySnapshotted)
            throw new InvalidOperationException("Inventory must be snapshotted before finalizing closing.");

        var period = closing.FinancialPeriod!;

        closing.Status = YearEndClosingStatus.OpeningJEGenerated;
        closing.Notes = (closing.Notes ?? "") + " | Opening balances are calculated dynamically from all prior transactions.";

        await _context.SaveChangesAsync();

        _logger.LogInformation("Finalized year-end closing {ClosingId} - Opening balances will be calculated dynamically", closingId);

        return closing;
    }

    public async Task<YearEndClosing> CompleteClosingAsync(Guid closingId, Guid tenantId, Guid userId)
    {
        var closing = await GetClosingByIdAsync(closingId, tenantId);
        if (closing == null)
            throw new InvalidOperationException("Year-end closing not found.");

        if (closing.Status != YearEndClosingStatus.OpeningJEGenerated)
            throw new InvalidOperationException("Opening JE must be generated before completing the closing.");

        var period = closing.FinancialPeriod!;

        period.Status = FinancialPeriodStatus.HardClosed;

        closing.Status = YearEndClosingStatus.Completed;
        closing.ClosingDate = DateTime.UtcNow;
        closing.ClosedByUserId = userId;

        await _context.SaveChangesAsync();

        _logger.LogInformation("Completed year-end closing {ClosingId}", closingId);

        return closing;
    }

    public async Task<YearEndClosing> RollbackClosingAsync(Guid closingId, Guid tenantId, Guid userId, string reason)
    {
        var closing = await GetClosingByIdAsync(closingId, tenantId);
        if (closing == null)
            throw new InvalidOperationException("Year-end closing not found.");

        if (closing.Status == YearEndClosingStatus.Completed)
            throw new InvalidOperationException("Completed closings cannot be rolled back.");

        if (closing.ClosingJournalEntryId.HasValue)
        {
            var closingJE = await _context.JournalEntries.FindAsync(closing.ClosingJournalEntryId.Value);
            if (closingJE != null)
            {
                closingJE.IsVoided = true;
                closingJE.VoidedDate = DateTime.UtcNow;
                closingJE.VoidedByUserId = userId;
                closingJE.VoidReason = $"Year-end closing rollback: {reason}";
            }
        }

        if (closing.OpeningJournalEntryId.HasValue)
        {
            var openingJE = await _context.JournalEntries.FindAsync(closing.OpeningJournalEntryId.Value);
            if (openingJE != null)
            {
                openingJE.IsVoided = true;
                openingJE.VoidedDate = DateTime.UtcNow;
                openingJE.VoidedByUserId = userId;
                openingJE.VoidReason = $"Year-end closing rollback: {reason}";
            }
        }

        var snapshots = await _context.OpeningBalanceSnapshots
            .Where(s => s.YearEndClosingId == closingId)
            .ToListAsync();

        _context.OpeningBalanceSnapshots.RemoveRange(snapshots);

        closing.Status = YearEndClosingStatus.RolledBack;
        closing.Notes = $"Rolled back by user on {DateTime.UtcNow:yyyy-MM-dd HH:mm}: {reason}";

        await _context.SaveChangesAsync();

        _logger.LogInformation("Rolled back year-end closing {ClosingId}: {Reason}", closingId, reason);

        return closing;
    }
}
