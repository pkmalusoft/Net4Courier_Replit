using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.GeneralLedger.Models;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Services;

public interface IOpeningBalanceService
{
    Task<decimal> GetOpeningBalanceForAccountAsync(Guid accountId, DateTime asOfDate, Guid tenantId);
    Task<Dictionary<Guid, decimal>> GetAllOpeningBalancesAsync(DateTime asOfDate, Guid tenantId);
    Task<Dictionary<Guid, decimal>> GetBalanceSheetOpeningBalancesAsync(int fiscalYear, Guid tenantId);
    Task<List<OpeningBalanceDto>> GetOpeningBalancesForFiscalYearAsync(int fiscalYear, Guid tenantId);
    Task<decimal> GetRetainedEarningsCarryForwardAsync(int fiscalYear, Guid tenantId);
}

public class OpeningBalanceService : IOpeningBalanceService
{
    private readonly AppDbContext _context;
    private readonly ILogger<OpeningBalanceService> _logger;

    public OpeningBalanceService(AppDbContext context, ILogger<OpeningBalanceService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<decimal> GetOpeningBalanceForAccountAsync(Guid accountId, DateTime asOfDate, Guid tenantId)
    {
        var account = await _context.ChartOfAccounts
            .FirstOrDefaultAsync(a => a.Id == accountId && a.TenantId == tenantId);

        if (account == null)
            return 0m;

        if (IsBalanceSheetAccount(account.AccountType))
        {
            return await _context.JournalEntryLines
                .Include(l => l.JournalEntry)
                .Where(l => l.TenantId == tenantId &&
                           l.AccountId == accountId &&
                           l.JournalEntry.Status == JournalEntryStatus.Posted &&
                           !l.JournalEntry.IsVoided &&
                           l.JournalEntry.EntryDate < asOfDate)
                .SumAsync(l => l.Debit - l.Credit);
        }
        else
        {
            var fiscalYearStart = await GetFiscalYearStartDateAsync(asOfDate, tenantId);
            
            if (asOfDate <= fiscalYearStart)
                return 0m;

            return await _context.JournalEntryLines
                .Include(l => l.JournalEntry)
                .Where(l => l.TenantId == tenantId &&
                           l.AccountId == accountId &&
                           l.JournalEntry.Status == JournalEntryStatus.Posted &&
                           !l.JournalEntry.IsVoided &&
                           l.JournalEntry.EntryDate >= fiscalYearStart &&
                           l.JournalEntry.EntryDate < asOfDate)
                .SumAsync(l => l.Debit - l.Credit);
        }
    }

    public async Task<Dictionary<Guid, decimal>> GetAllOpeningBalancesAsync(DateTime asOfDate, Guid tenantId)
    {
        var accounts = await _context.ChartOfAccounts
            .Where(a => a.TenantId == tenantId && a.IsActive)
            .Select(a => new { a.Id, a.AccountType })
            .ToListAsync();

        var fiscalYearStart = await GetFiscalYearStartDateAsync(asOfDate, tenantId);

        var balanceSheetAccountIds = accounts
            .Where(a => IsBalanceSheetAccount(a.AccountType))
            .Select(a => a.Id)
            .ToHashSet();

        var incomeExpenseAccountIds = accounts
            .Where(a => IsIncomeExpenseAccount(a.AccountType))
            .Select(a => a.Id)
            .ToHashSet();

        var balanceSheetBalances = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId &&
                       balanceSheetAccountIds.Contains(l.AccountId) &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate < asOfDate)
            .GroupBy(l => l.AccountId)
            .Select(g => new { AccountId = g.Key, Balance = g.Sum(l => l.Debit - l.Credit) })
            .ToDictionaryAsync(x => x.AccountId, x => x.Balance);

        var incomeExpenseBalances = new Dictionary<Guid, decimal>();
        if (asOfDate > fiscalYearStart)
        {
            incomeExpenseBalances = await _context.JournalEntryLines
                .Include(l => l.JournalEntry)
                .Where(l => l.TenantId == tenantId &&
                           incomeExpenseAccountIds.Contains(l.AccountId) &&
                           l.JournalEntry.Status == JournalEntryStatus.Posted &&
                           !l.JournalEntry.IsVoided &&
                           l.JournalEntry.EntryDate >= fiscalYearStart &&
                           l.JournalEntry.EntryDate < asOfDate)
                .GroupBy(l => l.AccountId)
                .Select(g => new { AccountId = g.Key, Balance = g.Sum(l => l.Debit - l.Credit) })
                .ToDictionaryAsync(x => x.AccountId, x => x.Balance);
        }

        var result = new Dictionary<Guid, decimal>();
        foreach (var account in accounts)
        {
            if (balanceSheetBalances.TryGetValue(account.Id, out var bsBalance))
                result[account.Id] = bsBalance;
            else if (incomeExpenseBalances.TryGetValue(account.Id, out var ieBalance))
                result[account.Id] = ieBalance;
        }

        return result;
    }

    public async Task<Dictionary<Guid, decimal>> GetBalanceSheetOpeningBalancesAsync(int fiscalYear, Guid tenantId)
    {
        var fiscalYearStart = await GetFiscalYearStartDateForYearAsync(fiscalYear, tenantId);

        var balanceSheetAccountTypes = new[] { AccountType.Asset, AccountType.Liability, AccountType.Equity };
        var balanceSheetAccountIds = await _context.ChartOfAccounts
            .Where(a => a.TenantId == tenantId && 
                       balanceSheetAccountTypes.Contains(a.AccountType) && 
                       a.IsActive)
            .Select(a => a.Id)
            .ToListAsync();

        return await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId &&
                       balanceSheetAccountIds.Contains(l.AccountId) &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate < fiscalYearStart)
            .GroupBy(l => l.AccountId)
            .Select(g => new { AccountId = g.Key, Balance = g.Sum(l => l.Debit - l.Credit) })
            .Where(x => Math.Abs(x.Balance) > 0.001m)
            .ToDictionaryAsync(x => x.AccountId, x => x.Balance);
    }

    public async Task<List<OpeningBalanceDto>> GetOpeningBalancesForFiscalYearAsync(int fiscalYear, Guid tenantId)
    {
        var fiscalYearStart = await GetFiscalYearStartDateForYearAsync(fiscalYear, tenantId);

        var accounts = await _context.ChartOfAccounts
            .Where(a => a.TenantId == tenantId && a.IsActive)
            .Select(a => new { a.Id, a.AccountCode, a.AccountName, a.AccountType })
            .ToListAsync();

        var balanceSheetAccountTypes = new[] { AccountType.Asset, AccountType.Liability, AccountType.Equity };
        var balanceSheetAccountIds = accounts
            .Where(a => balanceSheetAccountTypes.Contains(a.AccountType))
            .Select(a => a.Id)
            .ToHashSet();

        var balances = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId &&
                       balanceSheetAccountIds.Contains(l.AccountId) &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate < fiscalYearStart)
            .GroupBy(l => l.AccountId)
            .Select(g => new { AccountId = g.Key, Balance = g.Sum(l => l.Debit - l.Credit) })
            .Where(x => Math.Abs(x.Balance) > 0.001m)
            .ToDictionaryAsync(x => x.AccountId, x => x.Balance);

        var result = new List<OpeningBalanceDto>();
        foreach (var account in accounts.Where(a => balanceSheetAccountIds.Contains(a.Id)))
        {
            if (balances.TryGetValue(account.Id, out var balance) && Math.Abs(balance) > 0.001m)
            {
                result.Add(new OpeningBalanceDto
                {
                    AccountId = account.Id,
                    AccountCode = account.AccountCode ?? "",
                    AccountName = account.AccountName,
                    AccountType = account.AccountType.ToString(),
                    DebitBalance = balance > 0 ? balance : 0,
                    CreditBalance = balance < 0 ? Math.Abs(balance) : 0,
                    NetBalance = balance
                });
            }
        }

        return result.OrderBy(x => x.AccountCode).ToList();
    }

    public async Task<decimal> GetRetainedEarningsCarryForwardAsync(int fiscalYear, Guid tenantId)
    {
        var fiscalYearStart = await GetFiscalYearStartDateForYearAsync(fiscalYear, tenantId);

        var revenueAccounts = await _context.ChartOfAccounts
            .Where(a => a.TenantId == tenantId && a.AccountType == AccountType.Revenue && a.IsActive)
            .Select(a => a.Id)
            .ToListAsync();

        var expenseAccounts = await _context.ChartOfAccounts
            .Where(a => a.TenantId == tenantId && a.AccountType == AccountType.Expense && a.IsActive)
            .Select(a => a.Id)
            .ToListAsync();

        var totalRevenue = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId &&
                       revenueAccounts.Contains(l.AccountId) &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate < fiscalYearStart)
            .SumAsync(l => l.Credit - l.Debit);

        var totalExpense = await _context.JournalEntryLines
            .Include(l => l.JournalEntry)
            .Where(l => l.TenantId == tenantId &&
                       expenseAccounts.Contains(l.AccountId) &&
                       l.JournalEntry.Status == JournalEntryStatus.Posted &&
                       !l.JournalEntry.IsVoided &&
                       l.JournalEntry.EntryDate < fiscalYearStart)
            .SumAsync(l => l.Debit - l.Credit);

        return totalRevenue - totalExpense;
    }

    private async Task<DateTime> GetFiscalYearStartDateAsync(DateTime referenceDate, Guid tenantId)
    {
        var period = await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId &&
                       p.StartDate <= referenceDate &&
                       p.EndDate >= referenceDate)
            .FirstOrDefaultAsync();

        if (period != null)
        {
            var firstPeriodOfYear = await _context.FinancialPeriods
                .Where(p => p.TenantId == tenantId && p.FiscalYear == period.FiscalYear && p.PeriodNumber == 1)
                .FirstOrDefaultAsync();

            return firstPeriodOfYear?.StartDate ?? new DateTime(period.FiscalYear, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        }

        return new DateTime(referenceDate.Year, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    }

    private async Task<DateTime> GetFiscalYearStartDateForYearAsync(int fiscalYear, Guid tenantId)
    {
        var firstPeriod = await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId && p.FiscalYear == fiscalYear && p.PeriodNumber == 1)
            .FirstOrDefaultAsync();

        return firstPeriod?.StartDate ?? new DateTime(fiscalYear, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    }

    private static bool IsBalanceSheetAccount(AccountType accountType)
    {
        return accountType == AccountType.Asset ||
               accountType == AccountType.Liability ||
               accountType == AccountType.Equity;
    }

    private static bool IsIncomeExpenseAccount(AccountType accountType)
    {
        return accountType == AccountType.Revenue ||
               accountType == AccountType.Expense;
    }
}

public class OpeningBalanceDto
{
    public Guid AccountId { get; set; }
    public string AccountCode { get; set; } = "";
    public string AccountName { get; set; } = "";
    public string AccountType { get; set; } = "";
    public decimal DebitBalance { get; set; }
    public decimal CreditBalance { get; set; }
    public decimal NetBalance { get; set; }
}
