using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.GeneralLedger.Models;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Services;

public interface IRevenueRecognitionEngine
{
    Task<RecognitionProcessingResult> ProcessPendingRecognitionsAsync(Guid tenantId, Guid userId);
    Task<RecognitionProcessingResult> ProcessSingleLineAsync(Guid lineId, Guid tenantId, Guid userId);
    Task CreateRecognitionAlertAsync(Guid tenantId, DeferredRevenueAlertType alertType, string title, string message, decimal amount, string currency, Guid? scheduleId = null);
}

public class RecognitionProcessingResult
{
    public int TotalProcessed { get; set; }
    public int SuccessCount { get; set; }
    public int FailedCount { get; set; }
    public decimal TotalAmountRecognized { get; set; }
    public List<string> Errors { get; set; } = new();
}

public class RevenueRecognitionEngine : IRevenueRecognitionEngine
{
    private readonly AppDbContext _context;
    private readonly IFinancialPeriodService _periodService;
    private readonly IFinancialCalendarService _calendarService;
    private readonly ILogger<RevenueRecognitionEngine> _logger;

    public RevenueRecognitionEngine(
        AppDbContext context,
        IFinancialPeriodService periodService,
        IFinancialCalendarService calendarService,
        ILogger<RevenueRecognitionEngine> logger)
    {
        _context = context;
        _periodService = periodService;
        _calendarService = calendarService;
        _logger = logger;
    }

    public async Task<RecognitionProcessingResult> ProcessPendingRecognitionsAsync(Guid tenantId, Guid userId)
    {
        var result = new RecognitionProcessingResult();
        var today = DateTime.UtcNow.Date;

        var pendingLines = await _context.RevenueRecognitionLines
            .Include(l => l.Schedule)
            .Where(l => l.TenantId == tenantId && 
                       l.Status == RecognitionLineStatus.Pending &&
                       l.RecognitionDate <= today &&
                       l.Schedule != null &&
                       l.Schedule.Status == RecognitionStatus.Active)
            .OrderBy(l => l.RecognitionDate)
            .ThenBy(l => l.SequenceNo)
            .ToListAsync();

        _logger.LogInformation("Processing {Count} pending recognition lines for tenant {TenantId}", 
            pendingLines.Count, tenantId);

        foreach (var line in pendingLines)
        {
            try
            {
                await ProcessLineAsync(line, tenantId, userId);
                result.SuccessCount++;
                result.TotalAmountRecognized += line.Amount;
            }
            catch (Exception ex)
            {
                result.FailedCount++;
                result.Errors.Add($"{line.Schedule?.SourceDocumentNo}: {ex.Message}");
                
                line.Status = RecognitionLineStatus.Failed;
                line.ErrorMessage = ex.Message;
                line.RetryCount++;
                line.UpdatedAt = DateTime.UtcNow;
                line.UpdatedBy = userId.ToString();

                _logger.LogError(ex, "Failed to process recognition line {LineId}", line.Id);
            }

            result.TotalProcessed++;
        }

        await _context.SaveChangesAsync();

        if (result.SuccessCount > 0)
        {
            var currency = pendingLines.FirstOrDefault()?.Schedule?.Currency ?? "INR";
            await CreateRecognitionAlertAsync(
                tenantId,
                DeferredRevenueAlertType.Summary,
                "Monthly Revenue Recognition Complete",
                $"{result.SuccessCount} recognition entries posted totaling {currency} {result.TotalAmountRecognized:N2}",
                result.TotalAmountRecognized,
                currency
            );
        }

        if (result.FailedCount > 0)
        {
            await CreateRecognitionAlertAsync(
                tenantId,
                DeferredRevenueAlertType.Error,
                "Revenue Recognition Errors",
                $"{result.FailedCount} recognition entries failed. Please review and retry.",
                0,
                "INR"
            );
        }

        _logger.LogInformation("Completed recognition processing: {Success} succeeded, {Failed} failed, total {Amount}", 
            result.SuccessCount, result.FailedCount, result.TotalAmountRecognized);

        return result;
    }

    public async Task<RecognitionProcessingResult> ProcessSingleLineAsync(Guid lineId, Guid tenantId, Guid userId)
    {
        var result = new RecognitionProcessingResult();

        var line = await _context.RevenueRecognitionLines
            .Include(l => l.Schedule)
            .FirstOrDefaultAsync(l => l.Id == lineId && l.TenantId == tenantId);

        if (line == null)
            throw new InvalidOperationException("Recognition line not found");

        if (line.Status != RecognitionLineStatus.Pending && line.Status != RecognitionLineStatus.Failed)
            throw new InvalidOperationException($"Line is not in a processable state: {line.Status}");

        try
        {
            await ProcessLineAsync(line, tenantId, userId);
            await _context.SaveChangesAsync();

            result.SuccessCount = 1;
            result.TotalProcessed = 1;
            result.TotalAmountRecognized = line.Amount;
        }
        catch (Exception ex)
        {
            result.FailedCount = 1;
            result.TotalProcessed = 1;
            result.Errors.Add(ex.Message);

            line.Status = RecognitionLineStatus.Failed;
            line.ErrorMessage = ex.Message;
            line.RetryCount++;
            line.UpdatedAt = DateTime.UtcNow;
            line.UpdatedBy = userId.ToString();
            await _context.SaveChangesAsync();
        }

        return result;
    }

    private async Task ProcessLineAsync(RevenueRecognitionLine line, Guid tenantId, Guid userId)
    {
        if (line.Schedule == null)
            throw new InvalidOperationException("Schedule not loaded");

        var statutoryPeriod = await _calendarService.MapDateToStatutoryPeriodAsync(line.RecognitionDate, tenantId);
        if (statutoryPeriod == null)
            throw new InvalidOperationException($"No statutory period found for date {line.RecognitionDate:d}");

        if (statutoryPeriod.Status != FinancialPeriodStatus.Open && 
            statutoryPeriod.Status != FinancialPeriodStatus.SoftClosed)
        {
            throw new InvalidOperationException($"Period {statutoryPeriod.PeriodName} is not open for posting (status: {statutoryPeriod.Status})");
        }

        var journalEntry = new JournalEntry
        {
            TenantId = tenantId,
            EntryNumber = await GenerateJournalNumberAsync(tenantId),
            EntryDate = line.RecognitionDate,
            Description = $"Revenue recognition for {line.Schedule.SourceDocumentNo} - {line.Schedule.CustomerName} ({line.RecognitionDate:MMM yyyy}) [Ref: RR-{line.Schedule.SourceDocumentNo}/{line.SequenceNo:D2}]",
            Status = JournalEntryStatus.Posted,
            PostedDate = DateTime.UtcNow,
            PostedByUserId = userId,
            CreatedBy = userId.ToString(),
            CreatedAt = DateTime.UtcNow,
            Lines = new List<JournalEntryLine>
            {
                new JournalEntryLine
                {
                    TenantId = tenantId,
                    AccountId = line.Schedule.DeferredRevenueAccountId,
                    Debit = line.Amount,
                    Credit = 0,
                    Description = $"Deferred revenue release - {line.Schedule.CustomerName}",
                    CreatedBy = userId.ToString(),
                    CreatedAt = DateTime.UtcNow
                },
                new JournalEntryLine
                {
                    TenantId = tenantId,
                    AccountId = line.Schedule.RevenueAccountId,
                    Debit = 0,
                    Credit = line.Amount,
                    Description = $"Revenue recognized - {line.Schedule.CustomerName}",
                    CreatedBy = userId.ToString(),
                    CreatedAt = DateTime.UtcNow
                }
            }
        };

        _context.JournalEntries.Add(journalEntry);

        line.Status = RecognitionLineStatus.Posted;
        line.PostedDate = DateTime.UtcNow;
        line.JournalEntryId = journalEntry.Id;
        line.JournalEntryNo = journalEntry.EntryNumber;
        line.StatutoryPeriodId = statutoryPeriod.Id;
        line.StatutoryFiscalYear = statutoryPeriod.FiscalYear;
        line.ErrorMessage = null;
        line.UpdatedAt = DateTime.UtcNow;
        line.UpdatedBy = userId.ToString();

        line.Schedule.RecognizedAmount += line.Amount;
        line.Schedule.UpdatedAt = DateTime.UtcNow;
        line.Schedule.UpdatedBy = userId.ToString();

        var allLinesPosted = await _context.RevenueRecognitionLines
            .Where(l => l.ScheduleId == line.ScheduleId && l.Status != RecognitionLineStatus.Posted)
            .CountAsync() == 1;

        if (allLinesPosted)
        {
            line.Schedule.Status = RecognitionStatus.Completed;
            line.Schedule.CompletedDate = DateTime.UtcNow;
        }

        await CreateRecognitionAlertAsync(
            tenantId,
            DeferredRevenueAlertType.Recognition,
            "Revenue Recognized",
            $"{line.Schedule.Currency} {line.Amount:N2} recognized for {line.Schedule.CustomerName} ({line.RecognitionDate:MMM yyyy})",
            line.Amount,
            line.Schedule.Currency,
            line.ScheduleId
        );

        _logger.LogInformation("Posted recognition journal {JournalNo} for {Amount} - {Customer}", 
            journalEntry.EntryNumber, line.Amount, line.Schedule.CustomerName);
    }

    private async Task<string> GenerateJournalNumberAsync(Guid tenantId)
    {
        var prefix = $"RR-{DateTime.UtcNow:yyyyMM}-";
        var lastEntry = await _context.JournalEntries
            .Where(j => j.TenantId == tenantId && j.EntryNumber.StartsWith(prefix))
            .OrderByDescending(j => j.EntryNumber)
            .FirstOrDefaultAsync();

        var nextNumber = 1;
        if (lastEntry != null && lastEntry.EntryNumber.Length > prefix.Length)
        {
            var numberPart = lastEntry.EntryNumber.Substring(prefix.Length);
            if (int.TryParse(numberPart, out var num))
                nextNumber = num + 1;
        }

        return $"{prefix}{nextNumber:D4}";
    }

    public async Task CreateRecognitionAlertAsync(Guid tenantId, DeferredRevenueAlertType alertType, string title, string message, decimal amount, string currency, Guid? scheduleId = null)
    {
        var alert = new DeferredRevenueAlert
        {
            TenantId = tenantId,
            ScheduleId = scheduleId,
            AlertType = alertType,
            Title = title,
            Message = message,
            Amount = amount,
            Currency = currency,
            AlertDate = DateTime.UtcNow,
            IsRead = false,
            IsAcknowledged = false,
            ActionUrl = scheduleId.HasValue ? $"/finance/deferred-revenue/{scheduleId}" : "/finance/deferred-revenue",
            CreatedAt = DateTime.UtcNow
        };

        _context.DeferredRevenueAlerts.Add(alert);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Created deferred revenue alert: {Title}", title);
    }
}
