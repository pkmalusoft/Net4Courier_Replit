using Microsoft.EntityFrameworkCore;
using Server.Data;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Services;

public class RevenueRecognitionBackgroundService : BackgroundService
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<RevenueRecognitionBackgroundService> _logger;
    private readonly IConfiguration _configuration;

    public RevenueRecognitionBackgroundService(
        IServiceProvider serviceProvider,
        ILogger<RevenueRecognitionBackgroundService> logger,
        IConfiguration configuration)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
        _configuration = configuration;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Revenue Recognition Background Service starting");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var processingTime = _configuration.GetValue("RevenueRecognition:ProcessingTime", TimeSpan.FromHours(0.5));
                var now = DateTime.UtcNow;
                var nextRun = now.Date.Add(processingTime);
                
                if (nextRun <= now)
                {
                    nextRun = nextRun.AddDays(1);
                }

                var delay = nextRun - now;
                _logger.LogInformation("Next revenue recognition processing scheduled at {NextRun} (in {Delay})", nextRun, delay);

                await Task.Delay(delay, stoppingToken);

                await ProcessPendingRecognitionsAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Revenue Recognition Background Service");
                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
            }
        }

        _logger.LogInformation("Revenue Recognition Background Service stopping");
    }

    private async Task ProcessPendingRecognitionsAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Starting daily revenue recognition processing");

        using var scope = _serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var recognitionEngine = scope.ServiceProvider.GetRequiredService<IRevenueRecognitionEngine>();
        var calendarService = scope.ServiceProvider.GetRequiredService<IFinancialCalendarService>();

        try
        {
            var enabledTenants = await context.Tenants
                .Where(t => t.EnableMultipleCalendars)
                .Select(t => t.Id)
                .ToListAsync(stoppingToken);

            _logger.LogInformation("Found {Count} tenants with multi-calendar enabled", enabledTenants.Count);

            var totalProcessed = 0;
            var totalErrors = 0;

            foreach (var tenantId in enabledTenants)
            {
                if (stoppingToken.IsCancellationRequested)
                    break;

                try
                {
                    var result = await recognitionEngine.ProcessPendingRecognitionsAsync(tenantId, Guid.Empty);
                    totalProcessed += result.TotalProcessed;
                    totalErrors += result.FailedCount;

                    if (result.TotalProcessed > 0)
                    {
                        _logger.LogInformation(
                            "Tenant {TenantId}: Processed {Processed} recognitions, {Errors} errors, Total amount: {Amount:C}",
                            tenantId, result.TotalProcessed, result.FailedCount, result.TotalAmountRecognized);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error processing tenant {TenantId}", tenantId);
                    totalErrors++;
                }
            }

            _logger.LogInformation(
                "Daily revenue recognition completed. Total processed: {Processed}, Total errors: {Errors}",
                totalProcessed, totalErrors);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in daily revenue recognition processing");
        }
    }
}
