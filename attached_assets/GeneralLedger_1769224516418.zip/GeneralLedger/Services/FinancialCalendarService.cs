using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.GeneralLedger.Models;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Services;

public interface IFinancialCalendarService
{
    Task<List<FinancialCalendar>> GetAllCalendarsAsync(Guid tenantId);
    Task<FinancialCalendar?> GetCalendarByIdAsync(Guid calendarId, Guid tenantId);
    Task<FinancialCalendar?> GetPrimaryCalendarAsync(Guid tenantId);
    Task<FinancialCalendar> CreateCalendarAsync(FinancialCalendar calendar, Guid tenantId, Guid userId);
    Task<FinancialCalendar> UpdateCalendarAsync(FinancialCalendar calendar, Guid tenantId, Guid userId);
    Task DeleteCalendarAsync(Guid calendarId, Guid tenantId);
    Task<List<FinancialPeriod>> GeneratePeriodsAsync(Guid calendarId, int fiscalYear, Guid tenantId, Guid userId);
    Task<bool> IsMultiCalendarEnabledAsync(Guid tenantId);
    Task SetMultiCalendarEnabledAsync(Guid tenantId, bool enabled);
    Task<FinancialPeriod?> MapDateToStatutoryPeriodAsync(DateTime date, Guid tenantId);
}

public class FinancialCalendarService : IFinancialCalendarService
{
    private readonly AppDbContext _context;
    private readonly ILogger<FinancialCalendarService> _logger;

    public FinancialCalendarService(AppDbContext context, ILogger<FinancialCalendarService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<List<FinancialCalendar>> GetAllCalendarsAsync(Guid tenantId)
    {
        return await _context.FinancialCalendars
            .Where(c => c.TenantId == tenantId)
            .OrderByDescending(c => c.IsPrimary)
            .ThenBy(c => c.Name)
            .ToListAsync();
    }

    public async Task<FinancialCalendar?> GetCalendarByIdAsync(Guid calendarId, Guid tenantId)
    {
        return await _context.FinancialCalendars
            .Include(c => c.Periods)
            .FirstOrDefaultAsync(c => c.Id == calendarId && c.TenantId == tenantId);
    }

    public async Task<FinancialCalendar?> GetPrimaryCalendarAsync(Guid tenantId)
    {
        return await _context.FinancialCalendars
            .FirstOrDefaultAsync(c => c.TenantId == tenantId && c.IsPrimary);
    }

    public async Task<FinancialCalendar> CreateCalendarAsync(FinancialCalendar calendar, Guid tenantId, Guid userId)
    {
        calendar.TenantId = tenantId;
        calendar.CreatedBy = userId.ToString();
        calendar.CreatedAt = DateTime.UtcNow;

        if (calendar.IsPrimary)
        {
            var existingPrimary = await _context.FinancialCalendars
                .Where(c => c.TenantId == tenantId && c.IsPrimary)
                .ToListAsync();
            
            foreach (var ep in existingPrimary)
            {
                ep.IsPrimary = false;
                ep.UpdatedAt = DateTime.UtcNow;
                ep.UpdatedBy = userId.ToString();
            }
        }

        _context.FinancialCalendars.Add(calendar);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Created financial calendar {CalendarName} for tenant {TenantId}", calendar.Name, tenantId);
        return calendar;
    }

    public async Task<FinancialCalendar> UpdateCalendarAsync(FinancialCalendar calendar, Guid tenantId, Guid userId)
    {
        var existing = await _context.FinancialCalendars
            .FirstOrDefaultAsync(c => c.Id == calendar.Id && c.TenantId == tenantId);

        if (existing == null)
            throw new InvalidOperationException("Calendar not found");

        if (calendar.IsPrimary && !existing.IsPrimary)
        {
            var otherPrimary = await _context.FinancialCalendars
                .Where(c => c.TenantId == tenantId && c.IsPrimary && c.Id != calendar.Id)
                .ToListAsync();
            
            foreach (var op in otherPrimary)
            {
                op.IsPrimary = false;
                op.UpdatedAt = DateTime.UtcNow;
                op.UpdatedBy = userId.ToString();
            }
        }

        existing.Name = calendar.Name;
        existing.Code = calendar.Code;
        existing.Type = calendar.Type;
        existing.StartMonth = calendar.StartMonth;
        existing.IsPrimary = calendar.IsPrimary;
        existing.IsActive = calendar.IsActive;
        existing.Description = calendar.Description;
        existing.CountryCode = calendar.CountryCode;
        existing.UpdatedAt = DateTime.UtcNow;
        existing.UpdatedBy = userId.ToString();

        await _context.SaveChangesAsync();

        _logger.LogInformation("Updated financial calendar {CalendarId} for tenant {TenantId}", calendar.Id, tenantId);
        return existing;
    }

    public async Task DeleteCalendarAsync(Guid calendarId, Guid tenantId)
    {
        var calendar = await _context.FinancialCalendars
            .Include(c => c.Periods)
            .Include(c => c.RecognitionSchedules)
            .FirstOrDefaultAsync(c => c.Id == calendarId && c.TenantId == tenantId);

        if (calendar == null)
            throw new InvalidOperationException("Calendar not found");

        if (calendar.IsPrimary)
            throw new InvalidOperationException("Cannot delete the primary (statutory) calendar");

        if (calendar.RecognitionSchedules.Any())
            throw new InvalidOperationException("Cannot delete calendar with active recognition schedules");

        _context.FinancialPeriods.RemoveRange(calendar.Periods);
        _context.FinancialCalendars.Remove(calendar);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Deleted financial calendar {CalendarId} for tenant {TenantId}", calendarId, tenantId);
    }

    public async Task<List<FinancialPeriod>> GeneratePeriodsAsync(Guid calendarId, int fiscalYear, Guid tenantId, Guid userId)
    {
        var calendar = await GetCalendarByIdAsync(calendarId, tenantId);
        if (calendar == null)
            throw new InvalidOperationException("Calendar not found");

        var existingPeriods = await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId && 
                       p.FinancialCalendarId == calendarId && 
                       p.FiscalYear == fiscalYear)
            .ToListAsync();

        if (existingPeriods.Any())
            throw new InvalidOperationException($"Periods for fiscal year {fiscalYear} already exist for this calendar");

        var periods = new List<FinancialPeriod>();
        var startMonth = calendar.StartMonth;

        for (int i = 0; i < 12; i++)
        {
            var monthNumber = ((startMonth - 1 + i) % 12) + 1;
            var year = monthNumber >= startMonth ? fiscalYear : fiscalYear + 1;
            if (startMonth > 6 && monthNumber < startMonth)
                year = fiscalYear + 1;

            var startDate = new DateTime(year, monthNumber, 1);
            var endDate = startDate.AddMonths(1).AddDays(-1);

            var period = new FinancialPeriod
            {
                TenantId = tenantId,
                FinancialCalendarId = calendarId,
                FiscalYear = fiscalYear,
                PeriodNumber = i + 1,
                PeriodName = $"{startDate:MMM yyyy}",
                StartDate = startDate,
                EndDate = endDate,
                Status = FinancialPeriodStatus.NotOpened,
                IsYearEnd = i == 11,
                CreatedBy = userId.ToString(),
                CreatedAt = DateTime.UtcNow
            };

            periods.Add(period);
        }

        if (periods.Count >= 2)
        {
            for (int i = 1; i < periods.Count; i++)
            {
                periods[i].PreviousPeriodId = periods[i - 1].Id;
                periods[i - 1].NextPeriodId = periods[i].Id;
            }
        }

        _context.FinancialPeriods.AddRange(periods);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Generated {Count} periods for calendar {CalendarId}, fiscal year {FiscalYear}", 
            periods.Count, calendarId, fiscalYear);

        return periods;
    }

    public async Task<bool> IsMultiCalendarEnabledAsync(Guid tenantId)
    {
        var tenant = await _context.Tenants.FirstOrDefaultAsync(t => t.Id == tenantId);
        return tenant?.EnableMultipleCalendars ?? false;
    }

    public async Task SetMultiCalendarEnabledAsync(Guid tenantId, bool enabled)
    {
        var tenant = await _context.Tenants.FirstOrDefaultAsync(t => t.Id == tenantId);
        if (tenant != null)
        {
            tenant.EnableMultipleCalendars = enabled;
            await _context.SaveChangesAsync();
            _logger.LogInformation("Set EnableMultipleCalendars to {Enabled} for tenant {TenantId}", enabled, tenantId);
        }
    }

    public async Task<FinancialPeriod?> MapDateToStatutoryPeriodAsync(DateTime date, Guid tenantId)
    {
        var primaryCalendar = await GetPrimaryCalendarAsync(tenantId);
        if (primaryCalendar == null)
            return null;

        return await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId && 
                       p.FinancialCalendarId == primaryCalendar.Id &&
                       p.StartDate <= date.Date && 
                       p.EndDate >= date.Date)
            .FirstOrDefaultAsync();
    }
}
