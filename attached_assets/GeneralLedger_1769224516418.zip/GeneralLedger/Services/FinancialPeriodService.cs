using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.AP.Models;
using Server.Modules.AR.Models;
using Server.Modules.CashBank.Models;
using Server.Modules.GeneralLedger.Models;
using Shared.Enums;

namespace Server.Modules.GeneralLedger.Services;

public interface IFinancialPeriodService
{
    Task<List<FinancialPeriod>> GetAllPeriodsAsync(Guid tenantId);
    Task<FinancialPeriod?> GetPeriodByIdAsync(Guid periodId, Guid tenantId);
    Task<FinancialPeriod?> GetCurrentPeriodAsync(Guid tenantId);
    Task<FinancialPeriod?> GetPeriodForDateAsync(DateTime date, Guid tenantId);
    Task<List<FinancialPeriod>> GetSelectablePeriodsAsync(Guid tenantId);
    Task<List<FinancialPeriod>> CreateFiscalYearAsync(int fiscalYear, int startMonth, Guid tenantId, Guid userId);
    Task<FinancialPeriod> OpenPeriodAsync(Guid periodId, Guid tenantId, Guid userId, string? userRole = null);
    Task<FinancialPeriod> SoftClosePeriodAsync(Guid periodId, Guid tenantId, Guid userId, string? userRole = null);
    Task<FinancialPeriod> HardClosePeriodAsync(Guid periodId, Guid tenantId, Guid userId, string? userRole = null);
    Task<FinancialPeriod> ReopenPeriodAsync(Guid periodId, Guid tenantId, Guid userId, string userRole);
    Task<FinancialPeriod> LockPeriodAsync(Guid periodId, Guid tenantId, Guid userId, string? userRole = null);
    Task<bool> CanPostToDateAsync(DateTime transactionDate, Guid tenantId);
    Task<PeriodValidationResult> ValidatePeriodForClosingAsync(Guid periodId, Guid tenantId);
    bool CanUserPostToPeriodStatus(FinancialPeriodStatus status, string userRole);
    bool CanUserReopenFromStatus(FinancialPeriodStatus status, string userRole);
    Task<PeriodPostingPermission> GetPostingPermissionForDateAsync(DateTime transactionDate, Guid tenantId, string userRole);
    Task<List<PeriodStatusChangeLog>> GetPeriodAuditLogAsync(Guid periodId, Guid tenantId);
}

public class PeriodPostingPermission
{
    public bool CanPost { get; set; }
    public string? Reason { get; set; }
    public FinancialPeriodStatus? PeriodStatus { get; set; }
    public bool RequiresElevatedPermission { get; set; }
    public string? RequiredRole { get; set; }
}

public class PeriodValidationResult
{
    public bool IsValid { get; set; }
    public List<string> Errors { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
    public int UnpostedJournalEntries { get; set; }
    public int DraftDocuments { get; set; }
    public bool HasPreviousOpenPeriods { get; set; }
    public bool HasUnreconciledBankAccounts { get; set; }
}

public class FinancialPeriodService : IFinancialPeriodService
{
    private readonly AppDbContext _context;
    private readonly ILogger<FinancialPeriodService> _logger;

    public FinancialPeriodService(AppDbContext context, ILogger<FinancialPeriodService> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<List<FinancialPeriod>> GetAllPeriodsAsync(Guid tenantId)
    {
        return await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId)
            .OrderByDescending(p => p.FiscalYear)
            .ThenByDescending(p => p.PeriodNumber)
            .ToListAsync();
    }

    public async Task<FinancialPeriod?> GetPeriodByIdAsync(Guid periodId, Guid tenantId)
    {
        return await _context.FinancialPeriods
            .FirstOrDefaultAsync(p => p.Id == periodId && p.TenantId == tenantId);
    }

    public async Task<FinancialPeriod?> GetCurrentPeriodAsync(Guid tenantId)
    {
        var today = DateTime.UtcNow.Date;
        return await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId && p.StartDate <= today && p.EndDate >= today)
            .FirstOrDefaultAsync();
    }

    public async Task<FinancialPeriod?> GetPeriodForDateAsync(DateTime date, Guid tenantId)
    {
        return await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId && p.StartDate <= date.Date && p.EndDate >= date.Date)
            .FirstOrDefaultAsync();
    }

    public async Task<List<FinancialPeriod>> GetSelectablePeriodsAsync(Guid tenantId)
    {
        return await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId && 
                       (p.Status == FinancialPeriodStatus.Open || 
                        p.Status == FinancialPeriodStatus.SoftClosed))
            .OrderByDescending(p => p.FiscalYear)
            .ThenByDescending(p => p.PeriodNumber)
            .ToListAsync();
    }

    public async Task<List<FinancialPeriod>> CreateFiscalYearAsync(int fiscalYear, int startMonth, Guid tenantId, Guid userId)
    {
        var existingPeriods = await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId && p.FiscalYear == fiscalYear)
            .AnyAsync();

        if (existingPeriods)
        {
            throw new InvalidOperationException($"Financial periods for fiscal year {fiscalYear} already exist.");
        }

        var previousYearLastPeriod = await _context.FinancialPeriods
            .Where(p => p.TenantId == tenantId && p.FiscalYear == fiscalYear - 1)
            .OrderByDescending(p => p.PeriodNumber)
            .FirstOrDefaultAsync();

        var periods = new List<FinancialPeriod>();

        for (int periodNumber = 1; periodNumber <= 12; periodNumber++)
        {
            int month = ((startMonth - 1 + periodNumber - 1) % 12) + 1;
            int year = fiscalYear;
            if (month < startMonth)
            {
                year = fiscalYear + 1;
            }

            var startDate = DateTime.SpecifyKind(new DateTime(year, month, 1), DateTimeKind.Utc);
            var endDate = DateTime.SpecifyKind(startDate.AddMonths(1).AddDays(-1), DateTimeKind.Utc);
            var isYearEnd = periodNumber == 12;

            var period = new FinancialPeriod
            {
                Id = Guid.NewGuid(),
                TenantId = tenantId,
                PeriodName = $"Period {periodNumber} - {startDate:MMM yyyy}",
                FiscalYear = fiscalYear,
                PeriodNumber = periodNumber,
                StartDate = startDate,
                EndDate = endDate,
                Status = FinancialPeriodStatus.NotOpened,
                IsYearEnd = isYearEnd,
                CreatedAt = DateTime.UtcNow
            };

            periods.Add(period);
        }

        _context.FinancialPeriods.AddRange(periods);
        await _context.SaveChangesAsync();

        for (int i = 0; i < periods.Count; i++)
        {
            if (i > 0)
            {
                periods[i].PreviousPeriodId = periods[i - 1].Id;
            }
            else if (previousYearLastPeriod != null)
            {
                periods[i].PreviousPeriodId = previousYearLastPeriod.Id;
            }

            if (i < periods.Count - 1)
            {
                periods[i].NextPeriodId = periods[i + 1].Id;
            }
        }

        if (previousYearLastPeriod != null)
        {
            previousYearLastPeriod.NextPeriodId = periods[0].Id;
            _context.FinancialPeriods.Update(previousYearLastPeriod);
        }

        await _context.SaveChangesAsync();

        _logger.LogInformation("Created fiscal year {FiscalYear} with 12 periods for tenant {TenantId}", fiscalYear, tenantId);

        return periods;
    }

    public async Task<FinancialPeriod> OpenPeriodAsync(Guid periodId, Guid tenantId, Guid userId, string? userRole = null)
    {
        var period = await GetPeriodByIdAsync(periodId, tenantId);
        if (period == null)
        {
            throw new InvalidOperationException("Period not found.");
        }

        if (period.Status != FinancialPeriodStatus.NotOpened)
        {
            throw new InvalidOperationException($"Cannot open period. Current status is {period.Status}.");
        }

        if (period.PreviousPeriodId.HasValue)
        {
            var previousPeriod = await GetPeriodByIdAsync(period.PreviousPeriodId.Value, tenantId);
            if (previousPeriod != null && previousPeriod.Status == FinancialPeriodStatus.NotOpened)
            {
                throw new InvalidOperationException("Cannot open this period. Previous period has not been opened yet.");
            }
        }

        var previousStatus = period.Status;
        period.Status = FinancialPeriodStatus.Open;
        period.OpenedDate = DateTime.UtcNow;
        period.OpenedByUserId = userId;
        period.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        await LogStatusChangeAsync(period, previousStatus, FinancialPeriodStatus.Open, userId, userRole: userRole, reason: "Period opened");
        _logger.LogInformation("Opened period {PeriodId} for tenant {TenantId} by user {UserId}", periodId, tenantId, userId);

        return period;
    }

    public async Task<FinancialPeriod> SoftClosePeriodAsync(Guid periodId, Guid tenantId, Guid userId, string? userRole = null)
    {
        var period = await GetPeriodByIdAsync(periodId, tenantId);
        if (period == null)
        {
            throw new InvalidOperationException("Period not found.");
        }

        if (period.Status != FinancialPeriodStatus.Open)
        {
            throw new InvalidOperationException($"Cannot soft close period. Current status is {period.Status}. Period must be Open.");
        }

        if (period.PreviousPeriodId.HasValue)
        {
            var previousPeriod = await GetPeriodByIdAsync(period.PreviousPeriodId.Value, tenantId);
            if (previousPeriod != null && previousPeriod.Status == FinancialPeriodStatus.Open)
            {
                throw new InvalidOperationException("Cannot close this period. Previous period is still open.");
            }
        }

        var previousStatus = period.Status;
        period.Status = FinancialPeriodStatus.SoftClosed;
        period.ClosedDate = DateTime.UtcNow;
        period.ClosedByUserId = userId;
        period.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        await LogStatusChangeAsync(period, previousStatus, FinancialPeriodStatus.SoftClosed, userId, userRole: userRole, reason: "Period soft closed");
        _logger.LogInformation("Soft closed period {PeriodId} for tenant {TenantId} by user {UserId}", periodId, tenantId, userId);

        return period;
    }

    public async Task<FinancialPeriod> HardClosePeriodAsync(Guid periodId, Guid tenantId, Guid userId, string? userRole = null)
    {
        var period = await GetPeriodByIdAsync(periodId, tenantId);
        if (period == null)
        {
            throw new InvalidOperationException("Period not found.");
        }

        if (period.Status != FinancialPeriodStatus.SoftClosed)
        {
            throw new InvalidOperationException($"Cannot hard close period. Current status is {period.Status}. Period must be Soft Closed first.");
        }

        var validation = await ValidatePeriodForClosingAsync(periodId, tenantId);
        if (!validation.IsValid)
        {
            throw new InvalidOperationException($"Period cannot be hard closed: {string.Join(", ", validation.Errors)}");
        }

        var previousStatus = period.Status;
        period.Status = FinancialPeriodStatus.HardClosed;
        period.LockedDate = DateTime.UtcNow;
        period.LockedByUserId = userId;
        period.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        await LogStatusChangeAsync(period, previousStatus, FinancialPeriodStatus.HardClosed, userId, userRole: userRole, reason: "Period hard closed after validation");
        _logger.LogInformation("Hard closed period {PeriodId} for tenant {TenantId} by user {UserId}", periodId, tenantId, userId);

        return period;
    }

    public async Task<FinancialPeriod> ReopenPeriodAsync(Guid periodId, Guid tenantId, Guid userId, string userRole)
    {
        var period = await GetPeriodByIdAsync(periodId, tenantId);
        if (period == null)
        {
            throw new InvalidOperationException("Period not found.");
        }

        if (period.Status == FinancialPeriodStatus.NotOpened)
        {
            throw new InvalidOperationException("Period has not been opened yet.");
        }

        if (!CanUserReopenFromStatus(period.Status, userRole))
        {
            var requiredRole = GetRequiredRoleForReopening(period.Status);
            throw new UnauthorizedAccessException($"You do not have permission to reopen a period with status '{period.Status}'. Required role: {requiredRole}");
        }

        if (period.NextPeriodId.HasValue)
        {
            var nextPeriod = await GetPeriodByIdAsync(period.NextPeriodId.Value, tenantId);
            if (nextPeriod != null && 
                (nextPeriod.Status == FinancialPeriodStatus.HardClosed || 
                 nextPeriod.Status == FinancialPeriodStatus.Archived))
            {
                throw new InvalidOperationException("Cannot reopen this period. Next period is already hard closed or archived.");
            }
        }

        var previousStatus = period.Status;
        period.Status = FinancialPeriodStatus.Open;
        period.ClosedDate = null;
        period.ClosedByUserId = null;
        period.LockedDate = null;
        period.LockedByUserId = null;
        period.Notes = $"{period.Notes}\n[{DateTime.UtcNow:yyyy-MM-dd HH:mm}] Reopened by {userRole} (user {userId})".Trim();
        period.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        await LogStatusChangeAsync(period, previousStatus, FinancialPeriodStatus.Open, userId, userRole: userRole, reason: $"Period reopened by {userRole}");
        _logger.LogInformation("Reopened period {PeriodId} for tenant {TenantId} by user {UserId} with role {Role}", periodId, tenantId, userId, userRole);

        return period;
    }
    
    public bool CanUserPostToPeriodStatus(FinancialPeriodStatus status, string userRole)
    {
        var role = userRole.ToLowerInvariant();
        
        return status switch
        {
            FinancialPeriodStatus.Open => true,
            FinancialPeriodStatus.SoftClosed => role is "owner" or "admin",
            FinancialPeriodStatus.HardClosed => role is "auditor",
            _ => false
        };
    }
    
    public bool CanUserReopenFromStatus(FinancialPeriodStatus status, string userRole)
    {
        var role = userRole.ToLowerInvariant();
        
        return status switch
        {
            FinancialPeriodStatus.SoftClosed => role is "owner" or "admin",
            FinancialPeriodStatus.HardClosed => role is "owner",
            FinancialPeriodStatus.Archived => role is "auditor",
            _ => false
        };
    }
    
    private string GetRequiredRoleForReopening(FinancialPeriodStatus status)
    {
        return status switch
        {
            FinancialPeriodStatus.SoftClosed => "Admin or Owner",
            FinancialPeriodStatus.HardClosed => "Owner",
            FinancialPeriodStatus.Archived => "Auditor",
            _ => "Unknown"
        };
    }
    
    public async Task<PeriodPostingPermission> GetPostingPermissionForDateAsync(DateTime transactionDate, Guid tenantId, string userRole)
    {
        var period = await GetPeriodForDateAsync(transactionDate, tenantId);
        
        if (period == null)
        {
            return new PeriodPostingPermission
            {
                CanPost = false,
                Reason = "No financial period exists for this date. Please create periods first.",
                PeriodStatus = null,
                RequiresElevatedPermission = false
            };
        }
        
        var canPost = CanUserPostToPeriodStatus(period.Status, userRole);
        
        if (canPost)
        {
            return new PeriodPostingPermission
            {
                CanPost = true,
                PeriodStatus = period.Status,
                RequiresElevatedPermission = period.Status != FinancialPeriodStatus.Open,
                RequiredRole = period.Status == FinancialPeriodStatus.Open ? null : GetRequiredRoleForPosting(period.Status)
            };
        }
        
        return new PeriodPostingPermission
        {
            CanPost = false,
            Reason = $"Cannot post to a period with status '{period.Status}'.",
            PeriodStatus = period.Status,
            RequiresElevatedPermission = true,
            RequiredRole = GetRequiredRoleForPosting(period.Status)
        };
    }
    
    private string GetRequiredRoleForPosting(FinancialPeriodStatus status)
    {
        return status switch
        {
            FinancialPeriodStatus.SoftClosed => "Admin or Owner",
            FinancialPeriodStatus.HardClosed => "Auditor",
            _ => "None (period is closed)"
        };
    }

    public async Task<FinancialPeriod> LockPeriodAsync(Guid periodId, Guid tenantId, Guid userId, string? userRole = null)
    {
        var period = await GetPeriodByIdAsync(periodId, tenantId);
        if (period == null)
        {
            throw new InvalidOperationException("Period not found.");
        }

        if (period.Status != FinancialPeriodStatus.HardClosed)
        {
            throw new InvalidOperationException($"Cannot archive period. Current status is {period.Status}. Period must be Hard Closed first.");
        }

        var previousStatus = period.Status;
        period.Status = FinancialPeriodStatus.Archived;
        period.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        await LogStatusChangeAsync(period, previousStatus, FinancialPeriodStatus.Archived, userId, userRole: userRole, reason: "Period archived");
        _logger.LogInformation("Archived period {PeriodId} for tenant {TenantId} by user {UserId}", periodId, tenantId, userId);

        return period;
    }

    public async Task<bool> CanPostToDateAsync(DateTime transactionDate, Guid tenantId)
    {
        var period = await GetPeriodForDateAsync(transactionDate, tenantId);
        
        if (period == null)
        {
            return false;
        }

        return period.Status == FinancialPeriodStatus.Open || 
               period.Status == FinancialPeriodStatus.SoftClosed;
    }

    public async Task<PeriodValidationResult> ValidatePeriodForClosingAsync(Guid periodId, Guid tenantId)
    {
        var result = new PeriodValidationResult { IsValid = true };
        
        var period = await GetPeriodByIdAsync(periodId, tenantId);
        if (period == null)
        {
            result.IsValid = false;
            result.Errors.Add("Period not found.");
            return result;
        }

        var unpostedJournals = await _context.JournalEntries
            .CountAsync(j => j.TenantId == tenantId && 
                           j.EntryDate >= period.StartDate && 
                           j.EntryDate <= period.EndDate &&
                           j.Status == JournalEntryStatus.Draft);
        
        if (unpostedJournals > 0)
        {
            result.UnpostedJournalEntries = unpostedJournals;
            result.Errors.Add($"There are {unpostedJournals} unposted journal entries in this period.");
            result.IsValid = false;
        }

        var draftInvoices = await _context.SalesInvoices
            .CountAsync(i => i.TenantId == tenantId && 
                           i.InvoiceDate >= period.StartDate && 
                           i.InvoiceDate <= period.EndDate &&
                           i.Status == InvoiceStatus.Draft);

        var draftBills = await _context.PurchaseBills
            .CountAsync(b => b.TenantId == tenantId && 
                           b.BillDate >= period.StartDate && 
                           b.BillDate <= period.EndDate &&
                           b.Status == BillStatus.Draft);

        var draftCashBank = await _context.CashBankTransactions
            .CountAsync(t => t.TenantId == tenantId && 
                           t.VoucherDate >= period.StartDate && 
                           t.VoucherDate <= period.EndDate &&
                           t.Status == CashBankStatus.Draft);

        result.DraftDocuments = draftInvoices + draftBills + draftCashBank;
        if (result.DraftDocuments > 0)
        {
            result.Warnings.Add($"There are {result.DraftDocuments} draft documents in this period ({draftInvoices} invoices, {draftBills} bills, {draftCashBank} cash/bank transactions).");
        }

        if (period.PreviousPeriodId.HasValue)
        {
            var previousPeriod = await GetPeriodByIdAsync(period.PreviousPeriodId.Value, tenantId);
            if (previousPeriod != null && 
                (previousPeriod.Status == FinancialPeriodStatus.Open || 
                 previousPeriod.Status == FinancialPeriodStatus.SoftClosed))
            {
                result.HasPreviousOpenPeriods = true;
                result.Errors.Add("Previous period is still open or soft closed. Close it first.");
                result.IsValid = false;
            }
        }

        return result;
    }
    
    public async Task<List<PeriodStatusChangeLog>> GetPeriodAuditLogAsync(Guid periodId, Guid tenantId)
    {
        return await _context.PeriodStatusChangeLogs
            .Where(log => log.FinancialPeriodId == periodId && log.TenantId == tenantId)
            .OrderByDescending(log => log.ChangedAt)
            .ToListAsync();
    }
    
    private async Task LogStatusChangeAsync(
        FinancialPeriod period, 
        FinancialPeriodStatus previousStatus, 
        FinancialPeriodStatus newStatus, 
        Guid userId, 
        string? userName = null, 
        string? userRole = null, 
        string? reason = null,
        string? ipAddress = null)
    {
        var log = new PeriodStatusChangeLog
        {
            Id = Guid.NewGuid(),
            TenantId = period.TenantId,
            FinancialPeriodId = period.Id,
            PreviousStatus = previousStatus,
            NewStatus = newStatus,
            ChangedByUserId = userId,
            ChangedByUserName = userName,
            ChangedByUserRole = userRole,
            ChangedAt = DateTime.UtcNow,
            Reason = reason,
            IpAddress = ipAddress,
            CreatedAt = DateTime.UtcNow
        };
        
        _context.PeriodStatusChangeLogs.Add(log);
        await _context.SaveChangesAsync();
        
        _logger.LogInformation(
            "Period status change logged: Period {PeriodId}, {PreviousStatus} -> {NewStatus}, User {UserId}",
            period.Id, previousStatus, newStatus, userId);
    }
}
