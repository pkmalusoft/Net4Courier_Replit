using Microsoft.EntityFrameworkCore;
using Truebooks.HRPayroll.Core.Data;
using Truebooks.HRPayroll.Core.Models;
using Truebooks.Platform.Core.MultiTenancy;

namespace Truebooks.HRPayroll.Core.Services;

public interface IEmployeeService
{
    Task<Employee?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task<Employee?> GetByCodeAsync(string employeeCode, CancellationToken cancellationToken = default);
    Task<IEnumerable<Employee>> GetAllActiveAsync(CancellationToken cancellationToken = default);
    Task<IEnumerable<Employee>> GetByDepartmentAsync(Guid departmentId, CancellationToken cancellationToken = default);
    Task<Employee> CreateAsync(Employee employee, CancellationToken cancellationToken = default);
    Task UpdateAsync(Employee employee, CancellationToken cancellationToken = default);
    Task DeactivateAsync(Guid id, CancellationToken cancellationToken = default);
}

public class EmployeeService : IEmployeeService
{
    private readonly HRPayrollDbContext _context;
    private readonly ITenantContext _tenantContext;

    public EmployeeService(HRPayrollDbContext context, ITenantContext tenantContext)
    {
        _context = context;
        _tenantContext = tenantContext;
    }

    public async Task<Employee?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return await _context.Employees
            .Include(e => e.PayrollRecords.OrderByDescending(p => p.Year).ThenByDescending(p => p.Month).Take(3))
            .FirstOrDefaultAsync(e => e.Id == id, cancellationToken);
    }

    public async Task<Employee?> GetByCodeAsync(string employeeCode, CancellationToken cancellationToken = default)
    {
        return await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeCode == employeeCode, cancellationToken);
    }

    public async Task<IEnumerable<Employee>> GetAllActiveAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Employees
            .Where(e => e.Status == "Active")
            .OrderBy(e => e.FirstName)
            .ThenBy(e => e.LastName)
            .ToListAsync(cancellationToken);
    }

    public async Task<IEnumerable<Employee>> GetByDepartmentAsync(Guid departmentId, CancellationToken cancellationToken = default)
    {
        return await _context.Employees
            .Where(e => e.DepartmentId == departmentId && e.Status == "Active")
            .OrderBy(e => e.FirstName)
            .ToListAsync(cancellationToken);
    }

    public async Task<Employee> CreateAsync(Employee employee, CancellationToken cancellationToken = default)
    {
        employee.Id = Guid.NewGuid();
        employee.TenantId = _tenantContext.TenantId ?? throw new InvalidOperationException("Tenant context not available");
        employee.CreatedAt = DateTime.UtcNow;

        if (string.IsNullOrEmpty(employee.EmployeeCode))
        {
            var count = await _context.Employees.CountAsync(cancellationToken);
            employee.EmployeeCode = $"EMP{(count + 1):D5}";
        }

        _context.Employees.Add(employee);
        await _context.SaveChangesAsync(cancellationToken);
        return employee;
    }

    public async Task UpdateAsync(Employee employee, CancellationToken cancellationToken = default)
    {
        employee.UpdatedAt = DateTime.UtcNow;
        _context.Employees.Update(employee);
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task DeactivateAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var employee = await _context.Employees.FindAsync(new object[] { id }, cancellationToken);
        if (employee == null) throw new InvalidOperationException($"Employee {id} not found");
        
        employee.Status = "Inactive";
        employee.TerminationDate = DateTime.UtcNow;
        employee.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
    }
}
