using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Truebooks.HRPayroll.Core.Models;
using Truebooks.HRPayroll.Core.Services;
using Truebooks.Platform.Core.MultiTenancy;

namespace Truebooks.HRPayroll.Api.Controllers;

[ApiController]
[Route("api/hrpayroll/[controller]")]
[Authorize]
public class EmployeeController : ControllerBase
{
    private readonly IEmployeeService _employeeService;
    private readonly ITenantContext _tenantContext;
    private readonly ILogger<EmployeeController> _logger;

    public EmployeeController(IEmployeeService employeeService, ITenantContext tenantContext, ILogger<EmployeeController> logger)
    {
        _employeeService = employeeService;
        _tenantContext = tenantContext;
        _logger = logger;
    }

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
    {
        if (!_tenantContext.HasTenant) return BadRequest(new { error = "Tenant context not available" });
        
        var employee = await _employeeService.GetByIdAsync(id, cancellationToken);
        if (employee == null) return NotFound(new { error = $"Employee {id} not found" });
        return Ok(employee);
    }

    [HttpGet("code/{employeeCode}")]
    public async Task<IActionResult> GetByCode(string employeeCode, CancellationToken cancellationToken)
    {
        if (!_tenantContext.HasTenant) return BadRequest(new { error = "Tenant context not available" });
        
        var employee = await _employeeService.GetByCodeAsync(employeeCode, cancellationToken);
        if (employee == null) return NotFound(new { error = $"Employee {employeeCode} not found" });
        return Ok(employee);
    }

    [HttpGet]
    public async Task<IActionResult> GetAllActive(CancellationToken cancellationToken)
    {
        if (!_tenantContext.HasTenant) return BadRequest(new { error = "Tenant context not available" });
        
        var employees = await _employeeService.GetAllActiveAsync(cancellationToken);
        return Ok(employees);
    }

    [HttpGet("department/{departmentId:guid}")]
    public async Task<IActionResult> GetByDepartment(Guid departmentId, CancellationToken cancellationToken)
    {
        if (!_tenantContext.HasTenant) return BadRequest(new { error = "Tenant context not available" });
        
        var employees = await _employeeService.GetByDepartmentAsync(departmentId, cancellationToken);
        return Ok(employees);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateEmployeeRequest request, CancellationToken cancellationToken)
    {
        if (!_tenantContext.HasTenant) return BadRequest(new { error = "Tenant context not available" });
        
        if (string.IsNullOrWhiteSpace(request.FirstName)) return BadRequest(new { error = "First name is required" });
        if (string.IsNullOrWhiteSpace(request.LastName)) return BadRequest(new { error = "Last name is required" });
        if (string.IsNullOrWhiteSpace(request.Email)) return BadRequest(new { error = "Email is required" });

        try
        {
            var employee = new Employee
            {
                EmployeeCode = request.EmployeeCode ?? "",
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Phone = request.Phone ?? "",
                DateOfBirth = request.DateOfBirth,
                Gender = request.Gender ?? "",
                Nationality = request.Nationality ?? "",
                DepartmentId = request.DepartmentId,
                DesignationId = request.DesignationId,
                JoiningDate = request.JoiningDate,
                EmploymentType = request.EmploymentType ?? "FullTime",
                Address = request.Address ?? "",
                City = request.City ?? "",
                Country = request.Country ?? "",
                BankName = request.BankName ?? "",
                IBAN = request.IBAN ?? ""
            };

            var created = await _employeeService.CreateAsync(employee, cancellationToken);
            _logger.LogInformation("Created employee {Code} for tenant {TenantId}", created.EmployeeCode, _tenantContext.TenantId);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Deactivate(Guid id, CancellationToken cancellationToken)
    {
        if (!_tenantContext.HasTenant) return BadRequest(new { error = "Tenant context not available" });

        try
        {
            await _employeeService.DeactivateAsync(id, cancellationToken);
            _logger.LogInformation("Deactivated employee {Id} for tenant {TenantId}", id, _tenantContext.TenantId);
            return Ok(new { message = "Employee deactivated successfully" });
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { error = ex.Message });
        }
    }
}

public record CreateEmployeeRequest(
    string? EmployeeCode,
    [Required] string FirstName,
    [Required] string LastName,
    [Required] string Email,
    string? Phone,
    DateTime DateOfBirth,
    string? Gender,
    string? Nationality,
    Guid? DepartmentId,
    Guid? DesignationId,
    DateTime JoiningDate,
    string? EmploymentType,
    string? Address,
    string? City,
    string? Country,
    string? BankName,
    string? IBAN);
