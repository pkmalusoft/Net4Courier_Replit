using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Server.Data;
using System.Security.Claims;

namespace Server.Modules.HRPayroll.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]s")]
public class EmployeeController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly ITenantProvider _tenantProvider;

    public EmployeeController(AppDbContext context, ITenantProvider tenantProvider)
    {
        _context = context;
        _tenantProvider = tenantProvider;
    }

    private Guid GetCurrentTenantId()
    {
        return _tenantProvider.CurrentTenantId ?? throw new UnauthorizedAccessException("Tenant context not available");
    }

    private Guid GetCurrentUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userIdClaim) || !Guid.TryParse(userIdClaim, out var userId))
        {
            throw new UnauthorizedAccessException("User context not available");
        }
        return userId;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Employee>>> GetAll([FromQuery] bool includeInactive = false)
    {
        var tenantId = GetCurrentTenantId();
        var query = _context.Employees.Where(e => e.TenantId == tenantId);
        
        if (!includeInactive)
        {
            query = query.Where(e => e.IsActive);
        }
        
        return await query.OrderBy(e => e.EmployeeCode).ToListAsync();
    }

    [HttpGet("active")]
    public async Task<ActionResult<IEnumerable<Employee>>> GetActive()
    {
        var tenantId = GetCurrentTenantId();
        return await _context.Employees
            .Where(e => e.TenantId == tenantId && e.IsActive)
            .OrderBy(e => e.EmployeeCode)
            .ToListAsync();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Employee>> GetById(Guid id)
    {
        var tenantId = GetCurrentTenantId();
        var employee = await _context.Employees
            .FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId);
        
        if (employee == null)
        {
            return NotFound();
        }

        return employee;
    }

    [HttpGet("by-code/{code}")]
    public async Task<ActionResult<Employee>> GetByCode(string code)
    {
        var tenantId = GetCurrentTenantId();
        var employee = await _context.Employees
            .FirstOrDefaultAsync(e => e.EmployeeCode == code && e.TenantId == tenantId);
        
        if (employee == null)
        {
            return NotFound();
        }

        return employee;
    }

    [HttpPost]
    [Authorize(Roles = "owner,admin")]
    public async Task<ActionResult<Employee>> Create([FromBody] Employee employee)
    {
        var tenantId = GetCurrentTenantId();
        
        employee.TenantId = tenantId;
        employee.Id = Guid.NewGuid();
        employee.CreatedAt = DateTime.UtcNow;
        
        var exists = await _context.Employees
            .AnyAsync(e => e.TenantId == tenantId && e.EmployeeCode == employee.EmployeeCode);
        
        if (exists)
        {
            return BadRequest("Employee code already exists");
        }

        _context.Employees.Add(employee);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetById), new { id = employee.Id }, employee);
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "owner,admin")]
    public async Task<IActionResult> Update(Guid id, [FromBody] Employee employee)
    {
        var tenantId = GetCurrentTenantId();
        
        if (id != employee.Id)
        {
            return BadRequest("ID mismatch");
        }

        var existing = await _context.Employees
            .FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId);

        if (existing == null)
        {
            return NotFound();
        }

        var codeExists = await _context.Employees
            .AnyAsync(e => e.TenantId == tenantId && e.EmployeeCode == employee.EmployeeCode && e.Id != id);
        
        if (codeExists)
        {
            return BadRequest("Employee code already exists");
        }

        existing.EmployeeCode = employee.EmployeeCode;
        existing.FirstName = employee.FirstName;
        existing.LastName = employee.LastName;
        existing.Email = employee.Email;
        existing.Phone = employee.Phone;
        existing.Address = employee.Address;
        existing.Country = employee.Country;
        existing.State = employee.State;
        existing.TaxIdNumber = employee.TaxIdNumber;
        existing.DateOfBirth = employee.DateOfBirth;
        existing.JoiningDate = employee.JoiningDate;
        existing.Designation = employee.Designation;
        existing.Department = employee.Department;
        existing.Status = employee.Status;
        existing.BankAccountNumber = employee.BankAccountNumber;
        existing.BankName = employee.BankName;
        existing.BankIFSC = employee.BankIFSC;
        existing.BaseSalary = employee.BaseSalary;
        existing.HRA = employee.HRA;
        existing.DA = employee.DA;
        existing.PaymentTermsDays = employee.PaymentTermsDays;
        existing.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "owner,admin")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var tenantId = GetCurrentTenantId();
        var employee = await _context.Employees
            .FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId);

        if (employee == null)
        {
            return NotFound();
        }

        employee.IsActive = false;
        employee.DeactivatedDate = DateTime.UtcNow;
        employee.DeactivatedByUserId = GetCurrentUserId();
        employee.DeactivationReason = "Soft deleted via API";
        employee.UpdatedAt = DateTime.UtcNow;
        
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpPost("{id}/activate")]
    [Authorize(Roles = "owner,admin")]
    public async Task<IActionResult> Activate(Guid id)
    {
        var tenantId = GetCurrentTenantId();
        var employee = await _context.Employees
            .FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId);

        if (employee == null)
        {
            return NotFound();
        }

        employee.IsActive = true;
        employee.DeactivatedDate = null;
        employee.DeactivatedByUserId = null;
        employee.DeactivationReason = null;
        employee.UpdatedAt = DateTime.UtcNow;
        
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpPost("{id}/deactivate")]
    [Authorize(Roles = "owner,admin")]
    public async Task<IActionResult> Deactivate(Guid id, [FromBody] EmployeeDeactivateRequest? request = null)
    {
        var tenantId = GetCurrentTenantId();
        var employee = await _context.Employees
            .FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId);

        if (employee == null)
        {
            return NotFound();
        }

        employee.IsActive = false;
        employee.DeactivatedDate = DateTime.UtcNow;
        employee.DeactivatedByUserId = GetCurrentUserId();
        employee.DeactivationReason = request?.Reason ?? "Deactivated";
        employee.UpdatedAt = DateTime.UtcNow;
        
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpGet("count")]
    public async Task<ActionResult<EmployeeCountDto>> GetCount()
    {
        var tenantId = GetCurrentTenantId();
        var total = await _context.Employees.CountAsync(e => e.TenantId == tenantId);
        var active = await _context.Employees.CountAsync(e => e.TenantId == tenantId && e.IsActive);
        
        return new EmployeeCountDto
        {
            Total = total,
            Active = active,
            Inactive = total - active
        };
    }

    [HttpGet("by-department/{department}")]
    public async Task<ActionResult<IEnumerable<Employee>>> GetByDepartment(string department)
    {
        var tenantId = GetCurrentTenantId();
        return await _context.Employees
            .Where(e => e.TenantId == tenantId && e.IsActive && e.Department == department)
            .OrderBy(e => e.EmployeeCode)
            .ToListAsync();
    }

    [HttpGet("departments")]
    public async Task<ActionResult<IEnumerable<string>>> GetDepartments()
    {
        var tenantId = GetCurrentTenantId();
        return await _context.Employees
            .Where(e => e.TenantId == tenantId && e.IsActive && e.Department != null)
            .Select(e => e.Department!)
            .Distinct()
            .OrderBy(d => d)
            .ToListAsync();
    }
}

public class EmployeeDeactivateRequest
{
    public string? Reason { get; set; }
}

public class EmployeeCountDto
{
    public int Total { get; set; }
    public int Active { get; set; }
    public int Inactive { get; set; }
}
