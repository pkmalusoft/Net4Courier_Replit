using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.HRPayroll.Models;

namespace Server.Modules.HRPayroll.Services;

public class EmployeePayrollProfileService : IEmployeePayrollProfileService
{
    private readonly AppDbContext _context;
    private readonly ITenantProvider _tenantProvider;

    public EmployeePayrollProfileService(AppDbContext context, ITenantProvider tenantProvider)
    {
        _context = context;
        _tenantProvider = tenantProvider;
    }

    public async Task<List<EmployeePayrollProfile>> GetAllProfilesAsync(bool activeOnly = true)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<EmployeePayrollProfile>();

        var query = _context.Set<EmployeePayrollProfile>()
            .Include(p => p.Employee)
            .Where(p => p.TenantId == tenantId.Value);

        if (activeOnly)
            query = query.Where(p => p.Employee != null && p.Employee.IsActive);

        return await query.OrderBy(p => p.EmployeeId).ToListAsync();
    }

    public async Task<EmployeePayrollProfile?> GetProfileByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<EmployeePayrollProfile>()
            .Include(p => p.Employee)
            .FirstOrDefaultAsync(p => p.Id == id && p.TenantId == tenantId.Value);
    }

    public async Task<EmployeePayrollProfile?> GetProfileByEmployeeIdAsync(Guid employeeId)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<EmployeePayrollProfile>()
            .Include(p => p.Employee)
            .FirstOrDefaultAsync(p => p.EmployeeId == employeeId && p.TenantId == tenantId.Value);
    }

    public async Task<EmployeePayrollProfile> CreateProfileAsync(EmployeePayrollProfile profile)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        profile.Id = Guid.NewGuid();
        profile.TenantId = tenantId.Value;
        profile.CreatedAt = DateTime.UtcNow;

        _context.Set<EmployeePayrollProfile>().Add(profile);
        await _context.SaveChangesAsync();

        return profile;
    }

    public async Task<EmployeePayrollProfile> UpdateProfileAsync(EmployeePayrollProfile profile)
    {
        profile.UpdatedAt = DateTime.UtcNow;
        _context.Set<EmployeePayrollProfile>().Update(profile);
        await _context.SaveChangesAsync();
        return profile;
    }

    public async Task<bool> DeleteProfileAsync(Guid id)
    {
        var profile = await GetProfileByIdAsync(id);
        if (profile == null)
            return false;

        _context.Set<EmployeePayrollProfile>().Remove(profile);
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<bool> ActivateProfileAsync(Guid id)
    {
        return await Task.FromResult(true);
    }

    public async Task<bool> DeactivateProfileAsync(Guid id)
    {
        return await Task.FromResult(true);
    }

    public async Task<List<PayHead>> GetPayHeadsAsync(bool activeOnly = true)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<PayHead>();

        var query = _context.Set<PayHead>().Where(p => p.TenantId == tenantId.Value);
        if (activeOnly)
            query = query.Where(p => p.IsActive);

        return await query.OrderBy(p => p.DisplayOrder).ThenBy(p => p.Name).ToListAsync();
    }

    public async Task<PayHead?> GetPayHeadByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<PayHead>()
            .FirstOrDefaultAsync(p => p.Id == id && p.TenantId == tenantId.Value);
    }

    public async Task<PayHead> CreatePayHeadAsync(PayHead payHead)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        payHead.Id = Guid.NewGuid();
        payHead.TenantId = tenantId.Value;
        payHead.CreatedAt = DateTime.UtcNow;

        _context.Set<PayHead>().Add(payHead);
        await _context.SaveChangesAsync();

        return payHead;
    }

    public async Task<PayHead> UpdatePayHeadAsync(PayHead payHead)
    {
        payHead.UpdatedAt = DateTime.UtcNow;
        _context.Set<PayHead>().Update(payHead);
        await _context.SaveChangesAsync();
        return payHead;
    }

    public async Task<bool> DeletePayHeadAsync(Guid id)
    {
        var payHead = await GetPayHeadByIdAsync(id);
        if (payHead == null)
            return false;

        payHead.IsActive = false;
        payHead.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<List<EmployeePayHead>> GetEmployeePayHeadsAsync(Guid employeeId)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<EmployeePayHead>();

        return await _context.Set<EmployeePayHead>()
            .Where(e => e.EmployeeId == employeeId && e.TenantId == tenantId.Value && e.IsActive)
            .Include(e => e.PayHead)
            .ToListAsync();
    }

    public async Task<EmployeePayHead?> GetEmployeePayHeadByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<EmployeePayHead>()
            .Include(e => e.PayHead)
            .FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId.Value);
    }

    public async Task<EmployeePayHead> AssignPayHeadAsync(Guid employeeId, Guid payHeadId, decimal amount, decimal? percentage = null, DateTime? effectiveFrom = null, DateTime? effectiveTo = null)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        var employeePayHead = new EmployeePayHead
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId.Value,
            EmployeeId = employeeId,
            PayHeadId = payHeadId,
            Amount = amount,
            EffectiveFrom = effectiveFrom ?? DateTime.UtcNow,
            EffectiveTo = effectiveTo,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        _context.Set<EmployeePayHead>().Add(employeePayHead);
        await _context.SaveChangesAsync();

        return employeePayHead;
    }

    public async Task<EmployeePayHead> UpdateEmployeePayHeadAsync(EmployeePayHead employeePayHead)
    {
        employeePayHead.UpdatedAt = DateTime.UtcNow;
        _context.Set<EmployeePayHead>().Update(employeePayHead);
        await _context.SaveChangesAsync();
        return employeePayHead;
    }

    public async Task<bool> RemoveEmployeePayHeadAsync(Guid id)
    {
        var employeePayHead = await GetEmployeePayHeadByIdAsync(id);
        if (employeePayHead == null)
            return false;

        employeePayHead.IsActive = false;
        employeePayHead.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<List<PayrollCycle>> GetPayrollCyclesAsync(bool activeOnly = true)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<PayrollCycle>();

        var query = _context.Set<PayrollCycle>().Where(p => p.TenantId == tenantId.Value);
        if (activeOnly)
            query = query.Where(p => p.IsActive);

        return await query.OrderBy(p => p.Name).ToListAsync();
    }

    public async Task<PayrollCycle?> GetPayrollCycleByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<PayrollCycle>()
            .FirstOrDefaultAsync(p => p.Id == id && p.TenantId == tenantId.Value);
    }

    public async Task<PayrollCycle> CreatePayrollCycleAsync(PayrollCycle cycle)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        cycle.Id = Guid.NewGuid();
        cycle.TenantId = tenantId.Value;
        cycle.CreatedAt = DateTime.UtcNow;

        _context.Set<PayrollCycle>().Add(cycle);
        await _context.SaveChangesAsync();

        return cycle;
    }

    public async Task<PayrollCycle> UpdatePayrollCycleAsync(PayrollCycle cycle)
    {
        cycle.UpdatedAt = DateTime.UtcNow;
        _context.Set<PayrollCycle>().Update(cycle);
        await _context.SaveChangesAsync();
        return cycle;
    }

    public async Task<bool> DeletePayrollCycleAsync(Guid id)
    {
        var cycle = await GetPayrollCycleByIdAsync(id);
        if (cycle == null)
            return false;

        cycle.IsActive = false;
        cycle.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<decimal> CalculateGrossSalaryAsync(Guid employeePayrollProfileId)
    {
        var profile = await GetProfileByIdAsync(employeePayrollProfileId);
        if (profile == null)
            return 0;

        var baseSalary = profile.FixedGrossSalary ?? 0;
        
        var employeePayHeads = await GetEmployeePayHeadsAsync(employeePayrollProfileId);
        
        foreach (var eph in employeePayHeads.Where(e => e.IsActive))
        {
            if (eph.PayHead?.Type == PayHeadType.Earning)
                baseSalary += eph.Amount;
        }

        return baseSalary;
    }

    public async Task<EmployeePayrollSummary> GetEmployeeSummaryAsync(Guid employeeId)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        var employee = await _context.Employees
            .FirstOrDefaultAsync(e => e.Id == employeeId && e.TenantId == tenantId.Value);

        if (employee == null)
            throw new InvalidOperationException("Employee not found");

        var profile = await GetProfileByEmployeeIdAsync(employeeId);
        var summary = new EmployeePayrollSummary
        {
            EmployeeId = employeeId,
            EmployeeName = $"{employee.FirstName} {employee.LastName}",
            EmployeeCode = employee.EmployeeCode,
            PayrollProfileId = profile?.Id,
            HasPayrollProfile = profile != null
        };

        if (profile != null)
        {
            summary.GrossSalary = profile.FixedGrossSalary ?? 0;
            summary.IsWPSEligible = profile.IsWPSEnabled;
            summary.IsGOSIEligible = profile.IsGOSIApplicable;
        }

        summary.OutstandingLoans = await _context.Set<LoanRequest>()
            .Where(l => l.TenantId == tenantId.Value && l.EmployeeId == employeeId && l.Status != LoanStatus.Completed && l.Status == LoanStatus.Active)
            .SumAsync(l => l.OutstandingBalance);

        var currentYear = DateTime.UtcNow.Year;
        var leaveBalances = await _context.Set<LeaveBalance>()
            .Where(l => l.TenantId == tenantId.Value && l.EmployeeId == employeeId && l.Year == currentYear)
            .ToListAsync();
        summary.LeaveBalance = leaveBalances.Sum(l => l.ClosingBalance);

        var today = DateTime.UtcNow;
        var in30Days = today.AddDays(30);
        summary.PendingDocuments = await _context.Set<EmployeeDocument>()
            .CountAsync(d => d.TenantId == tenantId.Value && d.EmployeeId == employeeId && d.ExpiryDate <= in30Days);

        summary.IssuedAssets = await _context.Set<EmployeeAsset>()
            .CountAsync(a => a.TenantId == tenantId.Value && a.EmployeeId == employeeId && a.Status == AssetAssignmentStatus.Issued);

        var latestAccrual = await _context.Set<GratuityAccrual>()
            .Where(g => g.TenantId == tenantId.Value && g.EmployeeId == employeeId)
            .OrderByDescending(g => g.Year)
            .ThenByDescending(g => g.Month)
            .FirstOrDefaultAsync();
        summary.AccruedGratuity = latestAccrual?.CumulativeAccrual ?? 0;

        return summary;
    }
}
