using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.HRPayroll.Models;

namespace Server.Modules.HRPayroll.Services;

public class EmployeeDocumentService : IEmployeeDocumentService
{
    private readonly AppDbContext _context;
    private readonly ITenantProvider _tenantProvider;

    public EmployeeDocumentService(AppDbContext context, ITenantProvider tenantProvider)
    {
        _context = context;
        _tenantProvider = tenantProvider;
    }

    public async Task<List<PayrollDocumentType>> GetDocumentTypesAsync(bool activeOnly = true)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<PayrollDocumentType>();

        var query = _context.Set<PayrollDocumentType>().Where(d => d.TenantId == tenantId.Value);
        if (activeOnly)
            query = query.Where(d => d.IsActive);

        return await query.OrderBy(d => d.Name).ToListAsync();
    }

    public async Task<PayrollDocumentType?> GetDocumentTypeByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<PayrollDocumentType>()
            .FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
    }

    public async Task<PayrollDocumentType> CreateDocumentTypeAsync(PayrollDocumentType documentType)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        documentType.Id = Guid.NewGuid();
        documentType.TenantId = tenantId.Value;
        documentType.CreatedAt = DateTime.UtcNow;

        _context.Set<PayrollDocumentType>().Add(documentType);
        await _context.SaveChangesAsync();

        return documentType;
    }

    public async Task<PayrollDocumentType> UpdateDocumentTypeAsync(PayrollDocumentType documentType)
    {
        documentType.UpdatedAt = DateTime.UtcNow;
        _context.Set<PayrollDocumentType>().Update(documentType);
        await _context.SaveChangesAsync();
        return documentType;
    }

    public async Task<bool> DeleteDocumentTypeAsync(Guid id)
    {
        var documentType = await GetDocumentTypeByIdAsync(id);
        if (documentType == null)
            return false;

        documentType.IsActive = false;
        documentType.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<List<EmployeeDocument>> GetEmployeeDocumentsAsync(Guid? employeeId = null, Guid? documentTypeId = null, string? status = null)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<EmployeeDocument>();

        var query = _context.Set<EmployeeDocument>()
            .Where(d => d.TenantId == tenantId.Value && d.IsActive);

        if (employeeId.HasValue)
            query = query.Where(d => d.EmployeeId == employeeId.Value);

        if (documentTypeId.HasValue)
            query = query.Where(d => d.DocumentTypeId == documentTypeId.Value);

        if (!string.IsNullOrEmpty(status) && Enum.TryParse<DocumentStatus>(status, out var statusEnum))
            query = query.Where(d => d.Status == statusEnum);

        return await query
            .Include(d => d.DocumentType)
            .Include(d => d.Employee)
            .OrderBy(d => d.ExpiryDate)
            .ToListAsync();
    }

    public async Task<List<EmployeeDocument>> GetExpiringDocumentsAsync(int daysAhead = 30)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<EmployeeDocument>();

        var today = DateTime.UtcNow;
        var futureDate = today.AddDays(daysAhead);

        return await _context.Set<EmployeeDocument>()
            .Where(d => d.TenantId == tenantId.Value && d.IsActive && d.ExpiryDate > today && d.ExpiryDate <= futureDate)
            .Include(d => d.DocumentType)
            .Include(d => d.Employee)
            .OrderBy(d => d.ExpiryDate)
            .ToListAsync();
    }

    public async Task<List<EmployeeDocument>> GetExpiredDocumentsAsync()
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<EmployeeDocument>();

        var today = DateTime.UtcNow;

        return await _context.Set<EmployeeDocument>()
            .Where(d => d.TenantId == tenantId.Value && d.IsActive && d.ExpiryDate <= today)
            .Include(d => d.DocumentType)
            .Include(d => d.Employee)
            .OrderBy(d => d.ExpiryDate)
            .ToListAsync();
    }

    public async Task<EmployeeDocument?> GetEmployeeDocumentByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<EmployeeDocument>()
            .Include(d => d.DocumentType)
            .Include(d => d.Employee)
            .FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
    }

    public async Task<EmployeeDocument> CreateEmployeeDocumentAsync(EmployeeDocument document)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        document.Id = Guid.NewGuid();
        document.TenantId = tenantId.Value;
        document.Status = DocumentStatus.Valid;
        document.IssueDate = DateTime.SpecifyKind(document.IssueDate, DateTimeKind.Utc);
        document.ExpiryDate = DateTime.SpecifyKind(document.ExpiryDate, DateTimeKind.Utc);
        document.IsActive = true;
        document.CreatedAt = DateTime.UtcNow;

        _context.Set<EmployeeDocument>().Add(document);
        await _context.SaveChangesAsync();

        return document;
    }

    public async Task<EmployeeDocument> UpdateEmployeeDocumentAsync(EmployeeDocument document)
    {
        document.UpdatedAt = DateTime.UtcNow;
        _context.Set<EmployeeDocument>().Update(document);
        await _context.SaveChangesAsync();
        return document;
    }

    public async Task<EmployeeDocument> RenewDocumentAsync(Guid documentId, string newDocumentNumber, DateTime newIssueDate, DateTime newExpiryDate, Guid? processedByUserId = null)
    {
        var document = await GetEmployeeDocumentByIdAsync(documentId);
        if (document == null)
            throw new InvalidOperationException("Document not found");

        document.DocumentNumber = newDocumentNumber;
        document.IssueDate = DateTime.SpecifyKind(newIssueDate, DateTimeKind.Utc);
        document.ExpiryDate = DateTime.SpecifyKind(newExpiryDate, DateTimeKind.Utc);
        document.Status = DocumentStatus.Valid;
        document.RenewalStatus = RenewalStatus.Completed;
        document.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return document;
    }

    public async Task<bool> DeleteEmployeeDocumentAsync(Guid id)
    {
        var document = await GetEmployeeDocumentByIdAsync(id);
        if (document == null)
            return false;

        document.IsActive = false;
        document.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<List<DocumentAlert>> GetDocumentAlertsAsync(bool unreadOnly = false)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<DocumentAlert>();

        var query = _context.Set<DocumentAlert>()
            .Where(a => a.TenantId == tenantId.Value);

        if (unreadOnly)
            query = query.Where(a => !a.IsRead);

        return await query
            .Include(a => a.Document)
            .ThenInclude(d => d!.DocumentType)
            .OrderByDescending(a => a.AlertDate)
            .ToListAsync();
    }

    public async Task<List<DocumentAlert>> GetDocumentAlertsForEmployeeAsync(Guid employeeId)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<DocumentAlert>();

        return await _context.Set<DocumentAlert>()
            .Where(a => a.TenantId == tenantId.Value && a.Document != null && a.Document.EmployeeId == employeeId)
            .Include(a => a.Document)
            .ThenInclude(d => d!.DocumentType)
            .OrderByDescending(a => a.AlertDate)
            .ToListAsync();
    }

    public async Task<DocumentAlert?> GetDocumentAlertByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<DocumentAlert>()
            .Include(a => a.Document)
            .FirstOrDefaultAsync(a => a.Id == id && a.TenantId == tenantId.Value);
    }

    public async Task<DocumentAlert> MarkAlertAsReadAsync(Guid alertId, Guid userId)
    {
        var alert = await GetDocumentAlertByIdAsync(alertId);
        if (alert == null)
            throw new InvalidOperationException("Alert not found");

        alert.IsRead = true;
        alert.ReadByUserId = userId;
        alert.ReadAt = DateTime.UtcNow;
        alert.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return alert;
    }

    public async Task<DocumentAlert> MarkAlertAsActionedAsync(Guid alertId, Guid userId, string notes)
    {
        var alert = await GetDocumentAlertByIdAsync(alertId);
        if (alert == null)
            throw new InvalidOperationException("Alert not found");

        alert.IsActioned = true;
        alert.ActionedByUserId = userId;
        alert.ActionedAt = DateTime.UtcNow;
        alert.ActionNotes = notes;
        alert.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return alert;
    }

    public async Task GenerateExpiryAlertsAsync()
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return;

        var today = DateTime.UtcNow;
        var alertThresholds = new[] { 90, 60, 30, 14, 7, 1 };

        foreach (var daysAhead in alertThresholds)
        {
            var targetDate = today.AddDays(daysAhead);
            var documents = await _context.Set<EmployeeDocument>()
                .Where(d => d.TenantId == tenantId.Value && d.IsActive && d.ExpiryDate.Date == targetDate.Date)
                .ToListAsync();

            foreach (var doc in documents)
            {
                var existingAlert = await _context.Set<DocumentAlert>()
                    .AnyAsync(a => a.EmployeeDocumentId == doc.Id && a.DaysUntilExpiry == daysAhead);

                if (!existingAlert)
                {
                    var severity = daysAhead switch
                    {
                        <= 7 => "Critical",
                        <= 14 => "Critical",
                        <= 30 => "Warning",
                        _ => "Info"
                    };

                    var alert = new DocumentAlert
                    {
                        Id = Guid.NewGuid(),
                        TenantId = tenantId.Value,
                        EmployeeDocumentId = doc.Id,
                        AlertDate = today,
                        DaysUntilExpiry = daysAhead,
                        Severity = severity,
                        CreatedAt = DateTime.UtcNow
                    };

                    _context.Set<DocumentAlert>().Add(alert);
                }
            }
        }

        await _context.SaveChangesAsync();
    }

    public async Task<List<DocumentRenewal>> GetDocumentRenewalsAsync(Guid? employeeDocumentId = null, string? status = null)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<DocumentRenewal>();

        var query = _context.Set<DocumentRenewal>()
            .Where(r => r.TenantId == tenantId.Value);

        if (employeeDocumentId.HasValue)
            query = query.Where(r => r.DocumentId == employeeDocumentId.Value);

        if (!string.IsNullOrEmpty(status) && Enum.TryParse<DocumentRenewalStatus>(status, out var statusEnum))
            query = query.Where(r => r.Status == statusEnum);

        return await query
            .Include(r => r.Document)
            .OrderByDescending(r => r.InitiatedDate)
            .ToListAsync();
    }

    public async Task<DocumentRenewal?> GetDocumentRenewalByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<DocumentRenewal>()
            .Include(r => r.Document)
            .FirstOrDefaultAsync(r => r.Id == id && r.TenantId == tenantId.Value);
    }

    public async Task<DocumentRenewal> CreateDocumentRenewalRequestAsync(Guid employeeDocumentId, Guid requestedByUserId, string? notes = null)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        var document = await GetEmployeeDocumentByIdAsync(employeeDocumentId);
        if (document == null)
            throw new InvalidOperationException("Document not found");

        var renewal = new DocumentRenewal
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId.Value,
            DocumentId = employeeDocumentId,
            InitiatedDate = DateTime.UtcNow,
            AssignedToUserId = requestedByUserId,
            Status = DocumentRenewalStatus.Initiated,
            Notes = notes,
            CreatedAt = DateTime.UtcNow
        };

        document.RenewalStatus = RenewalStatus.InProgress;
        document.UpdatedAt = DateTime.UtcNow;

        _context.Set<DocumentRenewal>().Add(renewal);
        await _context.SaveChangesAsync();

        return renewal;
    }

    public async Task<DocumentRenewal> ProcessDocumentRenewalAsync(Guid renewalId, string newDocumentNumber, DateTime newIssueDate, DateTime newExpiryDate, Guid processedByUserId)
    {
        var renewal = await GetDocumentRenewalByIdAsync(renewalId);
        if (renewal == null)
            throw new InvalidOperationException("Renewal request not found");

        renewal.NewDocumentNumber = newDocumentNumber;
        renewal.NewExpiryDate = DateTime.SpecifyKind(newExpiryDate, DateTimeKind.Utc);
        renewal.Status = DocumentRenewalStatus.Completed;
        renewal.CompletedByUserId = processedByUserId;
        renewal.CompletedDate = DateTime.UtcNow;
        renewal.UpdatedAt = DateTime.UtcNow;

        await RenewDocumentAsync(renewal.DocumentId, newDocumentNumber, newIssueDate, newExpiryDate, processedByUserId);

        await _context.SaveChangesAsync();

        return renewal;
    }

    public async Task<DocumentExpiryStats> GetDocumentExpiryStatsAsync()
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new DocumentExpiryStats();

        var today = DateTime.UtcNow;
        var in30Days = today.AddDays(30);
        var in60Days = today.AddDays(60);
        var in90Days = today.AddDays(90);

        var documents = await _context.Set<EmployeeDocument>()
            .Where(d => d.TenantId == tenantId.Value && d.IsActive)
            .Include(d => d.DocumentType)
            .ToListAsync();

        var stats = new DocumentExpiryStats
        {
            TotalDocuments = documents.Count,
            ActiveDocuments = documents.Count(d => d.ExpiryDate > today),
            AlreadyExpired = documents.Count(d => d.ExpiryDate <= today),
            ExpiringIn30Days = documents.Count(d => d.ExpiryDate > today && d.ExpiryDate <= in30Days),
            ExpiringIn60Days = documents.Count(d => d.ExpiryDate > in30Days && d.ExpiryDate <= in60Days),
            ExpiringIn90Days = documents.Count(d => d.ExpiryDate > in60Days && d.ExpiryDate <= in90Days)
        };

        stats.PendingRenewals = await _context.Set<DocumentRenewal>()
            .CountAsync(r => r.TenantId == tenantId.Value && r.Status == DocumentRenewalStatus.Initiated);

        stats.ByType = documents
            .GroupBy(d => new { d.DocumentTypeId, TypeName = d.DocumentType?.Name ?? "Unknown" })
            .Select(g => new DocumentExpiryByType
            {
                DocumentTypeId = g.Key.DocumentTypeId,
                DocumentTypeName = g.Key.TypeName,
                Total = g.Count(),
                Expiring = g.Count(d => d.ExpiryDate > today && d.ExpiryDate <= in30Days),
                Expired = g.Count(d => d.ExpiryDate <= today)
            })
            .ToList();

        return stats;
    }
}
