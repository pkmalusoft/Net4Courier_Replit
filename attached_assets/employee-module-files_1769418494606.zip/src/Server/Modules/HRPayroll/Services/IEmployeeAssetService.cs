using Server.Modules.HRPayroll.Models;

namespace Server.Modules.HRPayroll.Services;

public interface IEmployeeAssetService
{
    Task<List<AssetCategory>> GetAssetCategoriesAsync(bool activeOnly = true);
    Task<AssetCategory?> GetAssetCategoryByIdAsync(Guid id);
    Task<AssetCategory> CreateAssetCategoryAsync(AssetCategory category);
    Task<AssetCategory> UpdateAssetCategoryAsync(AssetCategory category);
    Task<bool> DeleteAssetCategoryAsync(Guid id);
    
    Task<List<CompanyAsset>> GetCompanyAssetsAsync(Guid? categoryId = null, string? status = null);
    Task<List<CompanyAsset>> GetAvailableAssetsAsync();
    Task<CompanyAsset?> GetCompanyAssetByIdAsync(Guid id);
    Task<CompanyAsset?> GetCompanyAssetByCodeAsync(string assetCode);
    Task<CompanyAsset> CreateCompanyAssetAsync(CompanyAsset asset);
    Task<CompanyAsset> UpdateCompanyAssetAsync(CompanyAsset asset);
    Task<bool> DeleteCompanyAssetAsync(Guid id);
    Task<string> GenerateAssetCodeAsync(Guid? categoryId = null);
    
    Task<List<EmployeeAsset>> GetEmployeeAssetsAsync(Guid? employeeId = null, string? status = null);
    Task<List<EmployeeAsset>> GetIssuedAssetsAsync();
    Task<List<EmployeeAsset>> GetOverdueAssetsAsync();
    Task<EmployeeAsset?> GetEmployeeAssetByIdAsync(Guid id);
    Task<EmployeeAsset> IssueAssetToEmployeeAsync(Guid companyAssetId, Guid employeeId, Guid issuedByUserId, DateTime issuedDate, DateTime? expectedReturnDate = null, string? conditionOnIssue = null, string? notes = null);
    Task<EmployeeAsset> ReturnAssetFromEmployeeAsync(Guid employeeAssetId, Guid returnedByUserId, DateTime returnDate, string? conditionOnReturn = null, string? notes = null);
    Task<EmployeeAsset> UpdateEmployeeAssetAsync(EmployeeAsset employeeAsset);
    Task<bool> AcknowledgeAssetAsync(Guid employeeAssetId);
    
    Task<bool> HasOutstandingAssetsAsync(Guid employeeId);
    Task<List<EmployeeAsset>> GetOutstandingAssetsForEmployeeAsync(Guid employeeId);
    Task<AssetStats> GetAssetStatsAsync();
}

public class AssetStats
{
    public int TotalAssets { get; set; }
    public int AvailableAssets { get; set; }
    public int IssuedAssets { get; set; }
    public int UnderMaintenanceAssets { get; set; }
    public int RetiredAssets { get; set; }
    public decimal TotalAssetValue { get; set; }
    public decimal IssuedAssetValue { get; set; }
    public int OverdueReturns { get; set; }
    public List<AssetStatsByCategory> ByCategory { get; set; } = new();
}

public class AssetStatsByCategory
{
    public Guid CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int Total { get; set; }
    public int Available { get; set; }
    public int Issued { get; set; }
    public decimal TotalValue { get; set; }
}
