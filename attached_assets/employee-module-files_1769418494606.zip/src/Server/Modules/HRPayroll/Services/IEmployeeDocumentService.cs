using Server.Modules.HRPayroll.Models;

namespace Server.Modules.HRPayroll.Services;

public interface IEmployeeDocumentService
{
    Task<List<PayrollDocumentType>> GetDocumentTypesAsync(bool activeOnly = true);
    Task<PayrollDocumentType?> GetDocumentTypeByIdAsync(Guid id);
    Task<PayrollDocumentType> CreateDocumentTypeAsync(PayrollDocumentType documentType);
    Task<PayrollDocumentType> UpdateDocumentTypeAsync(PayrollDocumentType documentType);
    Task<bool> DeleteDocumentTypeAsync(Guid id);
    
    Task<List<EmployeeDocument>> GetEmployeeDocumentsAsync(Guid? employeeId = null, Guid? documentTypeId = null, string? status = null);
    Task<List<EmployeeDocument>> GetExpiringDocumentsAsync(int daysAhead = 30);
    Task<List<EmployeeDocument>> GetExpiredDocumentsAsync();
    Task<EmployeeDocument?> GetEmployeeDocumentByIdAsync(Guid id);
    Task<EmployeeDocument> CreateEmployeeDocumentAsync(EmployeeDocument document);
    Task<EmployeeDocument> UpdateEmployeeDocumentAsync(EmployeeDocument document);
    Task<EmployeeDocument> RenewDocumentAsync(Guid documentId, string newDocumentNumber, DateTime newIssueDate, DateTime newExpiryDate, Guid? processedByUserId = null);
    Task<bool> DeleteEmployeeDocumentAsync(Guid id);
    
    Task<List<DocumentAlert>> GetDocumentAlertsAsync(bool unreadOnly = false);
    Task<List<DocumentAlert>> GetDocumentAlertsForEmployeeAsync(Guid employeeId);
    Task<DocumentAlert?> GetDocumentAlertByIdAsync(Guid id);
    Task<DocumentAlert> MarkAlertAsReadAsync(Guid alertId, Guid userId);
    Task<DocumentAlert> MarkAlertAsActionedAsync(Guid alertId, Guid userId, string notes);
    Task GenerateExpiryAlertsAsync();
    
    Task<List<DocumentRenewal>> GetDocumentRenewalsAsync(Guid? employeeDocumentId = null, string? status = null);
    Task<DocumentRenewal?> GetDocumentRenewalByIdAsync(Guid id);
    Task<DocumentRenewal> CreateDocumentRenewalRequestAsync(Guid employeeDocumentId, Guid requestedByUserId, string? notes = null);
    Task<DocumentRenewal> ProcessDocumentRenewalAsync(Guid renewalId, string newDocumentNumber, DateTime newIssueDate, DateTime newExpiryDate, Guid processedByUserId);
    
    Task<DocumentExpiryStats> GetDocumentExpiryStatsAsync();
}

public class DocumentExpiryStats
{
    public int TotalDocuments { get; set; }
    public int ActiveDocuments { get; set; }
    public int ExpiringIn30Days { get; set; }
    public int ExpiringIn60Days { get; set; }
    public int ExpiringIn90Days { get; set; }
    public int AlreadyExpired { get; set; }
    public int PendingRenewals { get; set; }
    public List<DocumentExpiryByType> ByType { get; set; } = new();
}

public class DocumentExpiryByType
{
    public Guid DocumentTypeId { get; set; }
    public string DocumentTypeName { get; set; } = string.Empty;
    public int Total { get; set; }
    public int Expiring { get; set; }
    public int Expired { get; set; }
}
