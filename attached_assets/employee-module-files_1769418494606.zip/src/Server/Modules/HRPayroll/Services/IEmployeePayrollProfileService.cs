using Server.Modules.HRPayroll.Models;

namespace Server.Modules.HRPayroll.Services;

public interface IEmployeePayrollProfileService
{
    Task<List<EmployeePayrollProfile>> GetAllProfilesAsync(bool activeOnly = true);
    Task<EmployeePayrollProfile?> GetProfileByIdAsync(Guid id);
    Task<EmployeePayrollProfile?> GetProfileByEmployeeIdAsync(Guid employeeId);
    Task<EmployeePayrollProfile> CreateProfileAsync(EmployeePayrollProfile profile);
    Task<EmployeePayrollProfile> UpdateProfileAsync(EmployeePayrollProfile profile);
    Task<bool> DeleteProfileAsync(Guid id);
    Task<bool> ActivateProfileAsync(Guid id);
    Task<bool> DeactivateProfileAsync(Guid id);
    
    Task<List<PayHead>> GetPayHeadsAsync(bool activeOnly = true);
    Task<PayHead?> GetPayHeadByIdAsync(Guid id);
    Task<PayHead> CreatePayHeadAsync(PayHead payHead);
    Task<PayHead> UpdatePayHeadAsync(PayHead payHead);
    Task<bool> DeletePayHeadAsync(Guid id);
    
    Task<List<EmployeePayHead>> GetEmployeePayHeadsAsync(Guid employeePayrollProfileId);
    Task<EmployeePayHead?> GetEmployeePayHeadByIdAsync(Guid id);
    Task<EmployeePayHead> AssignPayHeadAsync(Guid employeePayrollProfileId, Guid payHeadId, decimal amount, decimal? percentage = null, DateTime? effectiveFrom = null, DateTime? effectiveTo = null);
    Task<EmployeePayHead> UpdateEmployeePayHeadAsync(EmployeePayHead employeePayHead);
    Task<bool> RemoveEmployeePayHeadAsync(Guid id);
    
    Task<List<PayrollCycle>> GetPayrollCyclesAsync(bool activeOnly = true);
    Task<PayrollCycle?> GetPayrollCycleByIdAsync(Guid id);
    Task<PayrollCycle> CreatePayrollCycleAsync(PayrollCycle cycle);
    Task<PayrollCycle> UpdatePayrollCycleAsync(PayrollCycle cycle);
    Task<bool> DeletePayrollCycleAsync(Guid id);
    
    Task<decimal> CalculateGrossSalaryAsync(Guid employeePayrollProfileId);
    Task<EmployeePayrollSummary> GetEmployeeSummaryAsync(Guid employeeId);
}

public class EmployeePayrollSummary
{
    public Guid EmployeeId { get; set; }
    public string EmployeeName { get; set; } = string.Empty;
    public string EmployeeCode { get; set; } = string.Empty;
    public Guid? PayrollProfileId { get; set; }
    public bool HasPayrollProfile { get; set; }
    public decimal BasicSalary { get; set; }
    public decimal HousingAllowance { get; set; }
    public decimal TransportAllowance { get; set; }
    public decimal OtherAllowances { get; set; }
    public decimal GrossSalary { get; set; }
    public string PaymentMode { get; set; } = "Bank";
    public bool IsWPSEligible { get; set; }
    public bool IsGOSIEligible { get; set; }
    public decimal AccruedGratuity { get; set; }
    public decimal OutstandingLoans { get; set; }
    public decimal LeaveBalance { get; set; }
    public int PendingDocuments { get; set; }
    public int IssuedAssets { get; set; }
}
