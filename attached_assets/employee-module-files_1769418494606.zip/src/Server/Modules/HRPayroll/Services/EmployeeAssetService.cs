using Microsoft.EntityFrameworkCore;
using Server.Data;
using Server.Modules.HRPayroll.Models;

namespace Server.Modules.HRPayroll.Services;

public class EmployeeAssetService : IEmployeeAssetService
{
    private readonly AppDbContext _context;
    private readonly ITenantProvider _tenantProvider;

    public EmployeeAssetService(AppDbContext context, ITenantProvider tenantProvider)
    {
        _context = context;
        _tenantProvider = tenantProvider;
    }

    public async Task<List<AssetCategory>> GetAssetCategoriesAsync(bool activeOnly = true)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<AssetCategory>();

        var query = _context.Set<AssetCategory>().Where(c => c.TenantId == tenantId.Value);
        if (activeOnly)
            query = query.Where(c => c.IsActive);

        return await query.OrderBy(c => c.Name).ToListAsync();
    }

    public async Task<AssetCategory?> GetAssetCategoryByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<AssetCategory>()
            .FirstOrDefaultAsync(c => c.Id == id && c.TenantId == tenantId.Value);
    }

    public async Task<AssetCategory> CreateAssetCategoryAsync(AssetCategory category)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        category.Id = Guid.NewGuid();
        category.TenantId = tenantId.Value;
        category.CreatedAt = DateTime.UtcNow;

        _context.Set<AssetCategory>().Add(category);
        await _context.SaveChangesAsync();

        return category;
    }

    public async Task<AssetCategory> UpdateAssetCategoryAsync(AssetCategory category)
    {
        category.UpdatedAt = DateTime.UtcNow;
        _context.Set<AssetCategory>().Update(category);
        await _context.SaveChangesAsync();
        return category;
    }

    public async Task<bool> DeleteAssetCategoryAsync(Guid id)
    {
        var category = await GetAssetCategoryByIdAsync(id);
        if (category == null)
            return false;

        category.IsActive = false;
        category.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<List<CompanyAsset>> GetCompanyAssetsAsync(Guid? categoryId = null, string? status = null)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<CompanyAsset>();

        var query = _context.Set<CompanyAsset>()
            .Where(a => a.TenantId == tenantId.Value && a.IsActive);

        if (categoryId.HasValue)
            query = query.Where(a => a.CategoryId == categoryId.Value);

        if (!string.IsNullOrEmpty(status) && Enum.TryParse<AssetStatus>(status, out var statusEnum))
            query = query.Where(a => a.Status == statusEnum);

        return await query
            .Include(a => a.Category)
            .OrderBy(a => a.AssetCode)
            .ToListAsync();
    }

    public async Task<List<CompanyAsset>> GetAvailableAssetsAsync()
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<CompanyAsset>();

        return await _context.Set<CompanyAsset>()
            .Where(a => a.TenantId == tenantId.Value && a.IsActive && a.Status == AssetStatus.Available)
            .Include(a => a.Category)
            .OrderBy(a => a.AssetCode)
            .ToListAsync();
    }

    public async Task<CompanyAsset?> GetCompanyAssetByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<CompanyAsset>()
            .Include(a => a.Category)
            .FirstOrDefaultAsync(a => a.Id == id && a.TenantId == tenantId.Value);
    }

    public async Task<CompanyAsset?> GetCompanyAssetByCodeAsync(string assetCode)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<CompanyAsset>()
            .Include(a => a.Category)
            .FirstOrDefaultAsync(a => a.AssetCode == assetCode && a.TenantId == tenantId.Value);
    }

    public async Task<CompanyAsset> CreateCompanyAssetAsync(CompanyAsset asset)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        asset.Id = Guid.NewGuid();
        asset.TenantId = tenantId.Value;
        if (string.IsNullOrEmpty(asset.AssetCode))
            asset.AssetCode = await GenerateAssetCodeAsync(asset.CategoryId);
        asset.Status = AssetStatus.Available;
        asset.CreatedAt = DateTime.UtcNow;

        _context.Set<CompanyAsset>().Add(asset);
        await _context.SaveChangesAsync();

        return asset;
    }

    public async Task<CompanyAsset> UpdateCompanyAssetAsync(CompanyAsset asset)
    {
        asset.UpdatedAt = DateTime.UtcNow;
        _context.Set<CompanyAsset>().Update(asset);
        await _context.SaveChangesAsync();
        return asset;
    }

    public async Task<bool> DeleteCompanyAssetAsync(Guid id)
    {
        var asset = await GetCompanyAssetByIdAsync(id);
        if (asset == null)
            return false;

        asset.IsActive = false;
        asset.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<string> GenerateAssetCodeAsync(Guid? categoryId = null)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        var prefix = "AST";
        if (categoryId.HasValue)
        {
            var category = await GetAssetCategoryByIdAsync(categoryId.Value);
            if (category != null && !string.IsNullOrEmpty(category.Code))
                prefix = category.Code;
        }

        var count = await _context.Set<CompanyAsset>()
            .CountAsync(a => a.TenantId == tenantId.Value);

        return $"{prefix}-{DateTime.UtcNow.Year}-{(count + 1):D5}";
    }

    public async Task<List<EmployeeAsset>> GetEmployeeAssetsAsync(Guid? employeeId = null, string? status = null)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<EmployeeAsset>();

        var query = _context.Set<EmployeeAsset>()
            .Where(a => a.TenantId == tenantId.Value);

        if (employeeId.HasValue)
            query = query.Where(a => a.EmployeeId == employeeId.Value);

        if (!string.IsNullOrEmpty(status) && Enum.TryParse<AssetAssignmentStatus>(status, out var statusEnum))
            query = query.Where(a => a.Status == statusEnum);

        return await query
            .Include(a => a.Asset)
            .ThenInclude(c => c!.Category)
            .OrderByDescending(a => a.IssuedDate)
            .ToListAsync();
    }

    public async Task<List<EmployeeAsset>> GetIssuedAssetsAsync()
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new List<EmployeeAsset>();

        return await _context.Set<EmployeeAsset>()
            .Where(a => a.TenantId == tenantId.Value && a.Status == AssetAssignmentStatus.Issued)
            .Include(a => a.Asset)
            .ThenInclude(c => c!.Category)
            .OrderByDescending(a => a.IssuedDate)
            .ToListAsync();
    }

    public async Task<List<EmployeeAsset>> GetOverdueAssetsAsync()
    {
        return await GetIssuedAssetsAsync();
    }

    public async Task<EmployeeAsset?> GetEmployeeAssetByIdAsync(Guid id)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return null;

        return await _context.Set<EmployeeAsset>()
            .Include(a => a.Asset)
            .ThenInclude(c => c!.Category)
            .FirstOrDefaultAsync(a => a.Id == id && a.TenantId == tenantId.Value);
    }

    public async Task<EmployeeAsset> IssueAssetToEmployeeAsync(Guid companyAssetId, Guid employeeId, Guid issuedByUserId, DateTime issuedDate, DateTime? expectedReturnDate = null, string? conditionOnIssue = null, string? notes = null)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            throw new InvalidOperationException("Tenant context is required");

        var companyAsset = await GetCompanyAssetByIdAsync(companyAssetId);
        if (companyAsset == null)
            throw new InvalidOperationException("Company asset not found");

        if (companyAsset.Status != AssetStatus.Available)
            throw new InvalidOperationException("Asset is not available for assignment");

        var condition = AssetCondition.Good;
        if (!string.IsNullOrEmpty(conditionOnIssue) && Enum.TryParse<AssetCondition>(conditionOnIssue, out var parsedCondition))
            condition = parsedCondition;

        var employeeAsset = new EmployeeAsset
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId.Value,
            EmployeeId = employeeId,
            AssetId = companyAssetId,
            IssuedDate = DateTime.SpecifyKind(issuedDate, DateTimeKind.Utc),
            IssuedByUserId = issuedByUserId,
            Status = AssetAssignmentStatus.Issued,
            ConditionAtIssue = condition,
            IssuedNotes = notes,
            CreatedAt = DateTime.UtcNow
        };

        companyAsset.Status = AssetStatus.Issued;
        companyAsset.UpdatedAt = DateTime.UtcNow;

        _context.Set<EmployeeAsset>().Add(employeeAsset);
        await _context.SaveChangesAsync();

        return employeeAsset;
    }

    public async Task<EmployeeAsset> ReturnAssetFromEmployeeAsync(Guid employeeAssetId, Guid returnedByUserId, DateTime returnDate, string? conditionOnReturn = null, string? notes = null)
    {
        var employeeAsset = await GetEmployeeAssetByIdAsync(employeeAssetId);
        if (employeeAsset == null)
            throw new InvalidOperationException("Employee asset not found");

        if (employeeAsset.Status != AssetAssignmentStatus.Issued)
            throw new InvalidOperationException("Asset is not currently issued");

        var condition = AssetCondition.Good;
        if (!string.IsNullOrEmpty(conditionOnReturn) && Enum.TryParse<AssetCondition>(conditionOnReturn, out var parsedCondition))
            condition = parsedCondition;

        employeeAsset.ReturnDate = DateTime.SpecifyKind(returnDate, DateTimeKind.Utc);
        employeeAsset.ReturnedToUserId = returnedByUserId;
        employeeAsset.ConditionAtReturn = condition;
        employeeAsset.Status = AssetAssignmentStatus.Returned;
        employeeAsset.ReturnNotes = notes ?? employeeAsset.ReturnNotes;
        employeeAsset.UpdatedAt = DateTime.UtcNow;

        if (employeeAsset.Asset != null)
        {
            employeeAsset.Asset.Status = AssetStatus.Available;
            employeeAsset.Asset.UpdatedAt = DateTime.UtcNow;
        }

        await _context.SaveChangesAsync();

        return employeeAsset;
    }

    public async Task<EmployeeAsset> UpdateEmployeeAssetAsync(EmployeeAsset employeeAsset)
    {
        employeeAsset.UpdatedAt = DateTime.UtcNow;
        _context.Set<EmployeeAsset>().Update(employeeAsset);
        await _context.SaveChangesAsync();
        return employeeAsset;
    }

    public async Task<bool> AcknowledgeAssetAsync(Guid employeeAssetId)
    {
        var employeeAsset = await GetEmployeeAssetByIdAsync(employeeAssetId);
        if (employeeAsset == null)
            return false;

        employeeAsset.IsAcknowledged = true;
        employeeAsset.AcknowledgedDate = DateTime.UtcNow;
        employeeAsset.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<bool> HasOutstandingAssetsAsync(Guid employeeId)
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return false;

        return await _context.Set<EmployeeAsset>()
            .AnyAsync(a => a.TenantId == tenantId.Value && a.EmployeeId == employeeId && a.Status == AssetAssignmentStatus.Issued);
    }

    public async Task<List<EmployeeAsset>> GetOutstandingAssetsForEmployeeAsync(Guid employeeId)
    {
        return await GetEmployeeAssetsAsync(employeeId: employeeId, status: "Issued");
    }

    public async Task<AssetStats> GetAssetStatsAsync()
    {
        var tenantId = _tenantProvider.CurrentTenantId;
        if (!tenantId.HasValue)
            return new AssetStats();

        var assets = await _context.Set<CompanyAsset>()
            .Where(a => a.TenantId == tenantId.Value && a.IsActive)
            .Include(a => a.Category)
            .ToListAsync();

        var stats = new AssetStats
        {
            TotalAssets = assets.Count,
            AvailableAssets = assets.Count(a => a.Status == AssetStatus.Available),
            IssuedAssets = assets.Count(a => a.Status == AssetStatus.Issued),
            UnderMaintenanceAssets = assets.Count(a => a.Status == AssetStatus.UnderMaintenance),
            RetiredAssets = assets.Count(a => a.Status == AssetStatus.Disposed),
            TotalAssetValue = assets.Sum(a => a.CurrentValue ?? 0),
            IssuedAssetValue = assets.Where(a => a.Status == AssetStatus.Issued).Sum(a => a.CurrentValue ?? 0),
            OverdueReturns = 0
        };

        stats.ByCategory = assets
            .GroupBy(a => new { a.CategoryId, CategoryName = a.Category?.Name ?? "Uncategorized" })
            .Select(g => new AssetStatsByCategory
            {
                CategoryId = g.Key.CategoryId,
                CategoryName = g.Key.CategoryName,
                Total = g.Count(),
                Available = g.Count(a => a.Status == AssetStatus.Available),
                Issued = g.Count(a => a.Status == AssetStatus.Issued),
                TotalValue = g.Sum(a => a.CurrentValue ?? 0)
            })
            .ToList();

        return stats;
    }
}
