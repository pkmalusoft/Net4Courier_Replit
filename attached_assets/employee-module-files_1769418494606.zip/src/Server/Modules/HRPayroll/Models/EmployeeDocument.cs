using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Server.Modules.HRPayroll.Models;

public enum DocumentStatus
{
    Valid,
    Expiring,
    Critical,
    Expired
}

public enum RenewalStatus
{
    NotRequired,
    Pending,
    InProgress,
    Completed
}

public class EmployeeDocument : BaseEntity
{
    [Required]
    public Guid EmployeeId { get; set; }

    [ForeignKey(nameof(EmployeeId))]
    public Employee? Employee { get; set; }

    [Required]
    public Guid DocumentTypeId { get; set; }

    [ForeignKey(nameof(DocumentTypeId))]
    public PayrollDocumentType? DocumentType { get; set; }

    [Required]
    [MaxLength(100)]
    public string DocumentNumber { get; set; } = string.Empty;

    public DateTime IssueDate { get; set; }

    public DateTime ExpiryDate { get; set; }

    [MaxLength(200)]
    public string? IssuingAuthority { get; set; }

    [MaxLength(100)]
    public string? IssuingCountry { get; set; }

    [MaxLength(500)]
    public string? AttachmentPath { get; set; }

    [MaxLength(100)]
    public string? AttachmentFileName { get; set; }

    public DocumentStatus Status { get; set; } = DocumentStatus.Valid;

    public RenewalStatus RenewalStatus { get; set; } = RenewalStatus.NotRequired;

    public int AlertDays { get; set; } = 30;

    public Guid? AssignedToUserId { get; set; }

    [MaxLength(200)]
    public string? AssignedToUserName { get; set; }

    public decimal? RenewalCost { get; set; }

    public bool IsVerified { get; set; } = false;

    public DateTime? VerifiedDate { get; set; }

    public Guid? VerifiedByUserId { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }

    public bool IsActive { get; set; } = true;
}
