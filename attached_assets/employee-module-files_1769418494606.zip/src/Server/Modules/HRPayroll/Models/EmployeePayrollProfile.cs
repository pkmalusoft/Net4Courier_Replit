using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Server.Modules.HRPayroll.Models;

public class EmployeePayrollProfile : BaseEntity
{
    [Required]
    public Guid EmployeeId { get; set; }

    [ForeignKey(nameof(EmployeeId))]
    public Employee? Employee { get; set; }

    [MaxLength(50)]
    public string? MOLId { get; set; }

    [MaxLength(50)]
    public string? IBAN { get; set; }

    [MaxLength(50)]
    public string? BankRoutingCode { get; set; }

    [MaxLength(100)]
    public string? BankSwiftCode { get; set; }

    [MaxLength(50)]
    public string? WPSEmployeeId { get; set; }

    [MaxLength(50)]
    public string? GOSINumber { get; set; }

    [MaxLength(50)]
    public string? GPSANumber { get; set; }

    [MaxLength(50)]
    public string? EmiratesId { get; set; }

    public DateTime? EmiratesIdExpiry { get; set; }

    [MaxLength(50)]
    public string? PassportNumber { get; set; }

    public DateTime? PassportExpiry { get; set; }

    [MaxLength(50)]
    public string? VisaNumber { get; set; }

    public DateTime? VisaExpiry { get; set; }

    [MaxLength(50)]
    public string? LaborCardNumber { get; set; }

    public DateTime? LaborCardExpiry { get; set; }

    public Guid? PayrollCycleId { get; set; }

    [ForeignKey(nameof(PayrollCycleId))]
    public PayrollCycle? PayrollCycle { get; set; }

    public decimal? FixedGrossSalary { get; set; }

    [MaxLength(3)]
    public string? SalaryCurrency { get; set; } = "AED";

    public bool IsWPSEnabled { get; set; } = true;

    public bool IsGOSIApplicable { get; set; } = false;

    public bool IsGPSAApplicable { get; set; } = false;

    public decimal? EmployerGOSIContribution { get; set; }

    public decimal? EmployeeGOSIContribution { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }
}
