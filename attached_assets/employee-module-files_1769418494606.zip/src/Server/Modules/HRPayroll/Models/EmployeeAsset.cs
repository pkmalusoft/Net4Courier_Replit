using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Server.Modules.HRPayroll.Models;

public enum AssetAssignmentStatus
{
    Issued,
    Returned,
    Lost,
    Damaged
}

public class EmployeeAsset : BaseEntity
{
    [Required]
    public Guid EmployeeId { get; set; }

    [ForeignKey(nameof(EmployeeId))]
    public Employee? Employee { get; set; }

    [Required]
    public Guid AssetId { get; set; }

    [ForeignKey(nameof(AssetId))]
    public CompanyAsset? Asset { get; set; }

    public DateTime IssuedDate { get; set; }

    public Guid IssuedByUserId { get; set; }

    [MaxLength(200)]
    public string? IssuedByUserName { get; set; }

    public AssetCondition ConditionAtIssue { get; set; } = AssetCondition.Good;

    public DateTime? ReturnDate { get; set; }

    public Guid? ReturnedToUserId { get; set; }

    [MaxLength(200)]
    public string? ReturnedToUserName { get; set; }

    public AssetCondition? ConditionAtReturn { get; set; }

    public AssetAssignmentStatus Status { get; set; } = AssetAssignmentStatus.Issued;

    [MaxLength(500)]
    public string? IssuedNotes { get; set; }

    [MaxLength(500)]
    public string? ReturnNotes { get; set; }

    [MaxLength(500)]
    public string? AcknowledgmentPath { get; set; }

    public bool IsAcknowledged { get; set; } = false;

    public DateTime? AcknowledgedDate { get; set; }
}
