using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Server.Modules.HRPayroll.Models;

public class EmployeePayHead : BaseEntity
{
    [Required]
    public Guid EmployeeId { get; set; }

    [ForeignKey(nameof(EmployeeId))]
    public Employee? Employee { get; set; }

    [Required]
    public Guid PayHeadId { get; set; }

    [ForeignKey(nameof(PayHeadId))]
    public PayHead? PayHead { get; set; }

    public decimal Amount { get; set; }

    public bool IsPercentage { get; set; } = false;

    public decimal? PercentageOf { get; set; }

    public Guid? PercentageOfPayHeadId { get; set; }

    [ForeignKey(nameof(PercentageOfPayHeadId))]
    public PayHead? PercentageOfPayHead { get; set; }

    public DateTime EffectiveFrom { get; set; }

    public DateTime? EffectiveTo { get; set; }

    public bool IsActive { get; set; } = true;

    [MaxLength(500)]
    public string? Notes { get; set; }
}
