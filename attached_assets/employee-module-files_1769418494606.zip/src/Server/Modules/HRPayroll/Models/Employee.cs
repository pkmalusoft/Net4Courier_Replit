using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Server.Modules.HRPayroll.Models;

public enum EmployeeStatus
{
    Active,
    OnLeave,
    Suspended,
    Resigned
}

public enum WorkMode
{
    Office,
    Remote,
    Hybrid
}

public class Employee : BaseEntity
{
    [Required]
    [MaxLength(50)]
    public string EmployeeCode { get; set; } = string.Empty;

    [Required]
    [MaxLength(200)]
    public string FirstName { get; set; } = string.Empty;

    [MaxLength(200)]
    public string? LastName { get; set; }

    [MaxLength(100)]
    public string Email { get; set; } = string.Empty;

    [MaxLength(20)]
    public string Phone { get; set; } = string.Empty;

    [MaxLength(500)]
    public string Address { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? Country { get; set; }

    [MaxLength(100)]
    public string? State { get; set; }

    [MaxLength(50)]
    public string? TaxIdNumber { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public DateTime JoiningDate { get; set; } = DateTime.UtcNow;

    [MaxLength(100)]
    public string? Designation { get; set; }

    [MaxLength(100)]
    public string? Department { get; set; }

    public EmployeeStatus Status { get; set; } = EmployeeStatus.Active;

    // Bank Details for Salary
    [MaxLength(50)]
    public string? BankAccountNumber { get; set; }

    [MaxLength(100)]
    public string? BankName { get; set; }

    [MaxLength(20)]
    public string? BankIFSC { get; set; }

    // Salary Information
    public decimal? BaseSalary { get; set; }

    public decimal? HRA { get; set; }

    public decimal? DA { get; set; }

    public int PaymentTermsDays { get; set; } = 30;

    // Soft Delete / Inactive
    public bool IsActive { get; set; } = true;

    // Deactivation / Void Metadata
    public DateTime? DeactivatedDate { get; set; }

    public Guid? DeactivatedByUserId { get; set; }

    [MaxLength(500)]
    public string? DeactivationReason { get; set; }

    // Mobile ESS - Work Location & Reporting
    public WorkMode WorkMode { get; set; } = WorkMode.Office;

    public Guid? DefaultWorkLocationId { get; set; }

    [ForeignKey(nameof(DefaultWorkLocationId))]
    public WorkLocation? DefaultWorkLocation { get; set; }

    public Guid? PrimarySupervisorId { get; set; }

    [ForeignKey(nameof(PrimarySupervisorId))]
    public Employee? PrimarySupervisor { get; set; }

    public int GeofenceToleranceMeters { get; set; } = 100;

    public bool AllowMobileAttendance { get; set; } = true;

    public bool RequireDeviceBinding { get; set; } = false;

    public ICollection<EmployeeDevice>? RegisteredDevices { get; set; }
}
