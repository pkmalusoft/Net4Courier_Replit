using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Server.Modules.HRPayroll.Models;

public enum DevicePlatform
{
    Android,
    iOS,
    Web,
    Windows,
    MacOS,
    Other
}

public enum DeviceStatus
{
    Active,
    Inactive,
    Blocked,
    PendingApproval
}

public class EmployeeDevice : BaseEntity
{
    [Required]
    public Guid EmployeeId { get; set; }

    [ForeignKey(nameof(EmployeeId))]
    public Employee? Employee { get; set; }

    [Required]
    [MaxLength(200)]
    public string DeviceId { get; set; } = string.Empty;

    [MaxLength(200)]
    public string? DeviceName { get; set; }

    [MaxLength(100)]
    public string? DeviceModel { get; set; }

    public DevicePlatform Platform { get; set; } = DevicePlatform.Web;

    [MaxLength(50)]
    public string? OSVersion { get; set; }

    [MaxLength(50)]
    public string? AppVersion { get; set; }

    public DeviceStatus Status { get; set; } = DeviceStatus.Active;

    public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;

    public DateTime? LastUsedAt { get; set; }

    [MaxLength(50)]
    public string? LastUsedIP { get; set; }

    public bool IsPrimary { get; set; } = false;

    public Guid? ApprovedByUserId { get; set; }

    public DateTime? ApprovedAt { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }
}
