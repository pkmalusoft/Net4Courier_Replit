using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Server.Modules.HRPayroll.Models;

public enum PayrollEmployeeStatus
{
    Pending,
    Calculated,
    OnHold,
    Excluded,
    Finalized,
    Paid
}

public class PayrollRunEmployee : BaseEntity
{
    [Required]
    public Guid PayrollRunId { get; set; }

    [ForeignKey(nameof(PayrollRunId))]
    public PayrollRun? PayrollRun { get; set; }

    [Required]
    public Guid EmployeeId { get; set; }

    [ForeignKey(nameof(EmployeeId))]
    public Employee? Employee { get; set; }

    public PayrollEmployeeStatus Status { get; set; } = PayrollEmployeeStatus.Pending;

    public int WorkingDays { get; set; } = 0;

    public int PresentDays { get; set; } = 0;

    public int AbsentDays { get; set; } = 0;

    public decimal LeaveDays { get; set; } = 0;

    public decimal UnpaidLeaveDays { get; set; } = 0;

    public decimal OvertimeHours { get; set; } = 0;

    public decimal GrossPay { get; set; } = 0;

    public decimal TotalEarnings { get; set; } = 0;

    public decimal TotalDeductions { get; set; } = 0;

    public decimal NetPay { get; set; } = 0;

    public decimal EmployerContributions { get; set; } = 0;

    public decimal LoanDeduction { get; set; } = 0;

    public decimal GOSIEmployeeShare { get; set; } = 0;

    public decimal GOSIEmployerShare { get; set; } = 0;

    public decimal LeaveSalaryAdvanceExclusion { get; set; } = 0;

    [MaxLength(500)]
    public string? HoldReason { get; set; }

    [MaxLength(500)]
    public string? ExclusionReason { get; set; }

    [MaxLength(500)]
    public string? Notes { get; set; }

    public ICollection<PayrollComponentLine>? ComponentLines { get; set; }
}
