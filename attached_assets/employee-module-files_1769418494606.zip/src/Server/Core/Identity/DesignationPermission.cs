using System.ComponentModel.DataAnnotations;

namespace Server.Core.Identity;

public class DesignationPermission : BaseEntity
{
    [Required]
    [MaxLength(100)]
    public string DesignationName { get; set; } = string.Empty;
    
    [Required]
    public Guid PermissionId { get; set; }
    
    public bool CanView { get; set; } = true;
    
    public bool CanCreate { get; set; } = false;
    
    public bool CanEdit { get; set; } = false;
    
    public bool CanDelete { get; set; } = false;
    
    public bool CanApprove { get; set; } = false;
    
    public bool CanVoid { get; set; } = false;
    
    public bool CanExport { get; set; } = false;
    
    public bool IsActive { get; set; } = true;
    
    public virtual Permission Permission { get; set; } = null!;
}
