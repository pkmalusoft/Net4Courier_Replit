using System.ComponentModel.DataAnnotations;

namespace Server.Core.Common;

public class Department : BaseEntity
{
    [Required]
    [MaxLength(50)]
    public string Code { get; set; } = string.Empty;

    [Required]
    [MaxLength(200)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }

    public Guid? BranchId { get; set; }

    public Guid? ParentDepartmentId { get; set; }

    public bool IsActive { get; set; } = true;

    public int SortOrder { get; set; } = 0;

    public DateTime? DeactivatedDate { get; set; }

    public Guid? DeactivatedByUserId { get; set; }

    [MaxLength(500)]
    public string? DeactivationReason { get; set; }

    public virtual Branch? Branch { get; set; }
    
    public virtual Department? ParentDepartment { get; set; }
    
    public virtual ICollection<Department> ChildDepartments { get; set; } = new List<Department>();
    
    public virtual ICollection<UserDepartmentAccess> UserDepartmentAccesses { get; set; } = new List<UserDepartmentAccess>();
}
