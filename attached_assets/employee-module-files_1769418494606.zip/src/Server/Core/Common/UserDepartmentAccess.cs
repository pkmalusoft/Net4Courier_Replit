using System.ComponentModel.DataAnnotations;

namespace Server.Core.Common;

public class UserDepartmentAccess : BaseEntity
{
    [Required]
    public Guid UserId { get; set; }

    [Required]
    public Guid DepartmentId { get; set; }

    public bool IsDefault { get; set; } = false;

    public bool CanView { get; set; } = true;

    public bool CanCreate { get; set; } = true;

    public bool CanEdit { get; set; } = true;

    public bool CanDelete { get; set; } = false;

    public bool CanApprove { get; set; } = false;

    public virtual Department Department { get; set; } = null!;
}
