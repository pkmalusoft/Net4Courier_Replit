namespace Truebooks.Platform.Contracts.Services;

public interface IEmployeeDocumentTypeService
{
    Task<List<EmployeeDocumentTypeDto>> GetAllAsync(Guid tenantId, bool activeOnly = true, CancellationToken cancellationToken = default);
    Task<EmployeeDocumentTypeDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<EmployeeDocumentTypeDto> CreateAsync(Guid tenantId, CreateEmployeeDocumentTypeRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateEmployeeDocumentTypeRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}

public record EmployeeDocumentTypeDto(
    Guid Id,
    string Code,
    string Name,
    string? Description,
    int DefaultAlertDays,
    int RenewalLeadTimeDays,
    bool IsRenewalRequired,
    bool IsMandatory,
    string? ResponsibleRole,
    int DisplayOrder,
    bool IsActive,
    bool IsSystemDefined
);

public record CreateEmployeeDocumentTypeRequest(
    string Code,
    string Name,
    string? Description,
    int DefaultAlertDays,
    int RenewalLeadTimeDays,
    bool IsRenewalRequired,
    bool IsMandatory,
    string? ResponsibleRole,
    int DisplayOrder
);

public record UpdateEmployeeDocumentTypeRequest(
    string Name,
    string? Description,
    int DefaultAlertDays,
    int RenewalLeadTimeDays,
    bool IsRenewalRequired,
    bool IsMandatory,
    string? ResponsibleRole,
    int DisplayOrder,
    bool IsActive
);
