namespace Truebooks.Platform.Contracts.Services;

public interface IEmployeeDocumentService
{
    Task<List<EmployeeDocumentDto>> GetAllAsync(Guid tenantId, Guid? employeeId = null, string? status = null, CancellationToken cancellationToken = default);
    Task<EmployeeDocumentDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task<EmployeeDocumentStatsDto> GetStatsAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<EmployeeDocumentDto> CreateAsync(Guid tenantId, CreateEmployeeDocumentRequest request, CancellationToken cancellationToken = default);
    Task UpdateAsync(Guid tenantId, Guid id, UpdateEmployeeDocumentRequest request, CancellationToken cancellationToken = default);
    Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
    Task VerifyAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default);
}

public record EmployeeDocumentDto(
    Guid Id,
    Guid EmployeeId,
    string EmployeeName,
    string EmployeeCode,
    Guid DocumentTypeId,
    string DocumentTypeName,
    string DocumentNumber,
    string? DocumentName,
    DateTime IssueDate,
    DateTime ExpiryDate,
    string? IssuePlace,
    string? IssuingAuthority,
    string Status,
    int DaysUntilExpiry,
    bool IsVerified,
    string? Notes
);

public record EmployeeDocumentStatsDto(
    int TotalDocuments,
    int ActiveDocuments,
    int ExpiringIn30Days,
    int ExpiringIn60Days,
    int ExpiringIn90Days,
    int AlreadyExpired
);

public record CreateEmployeeDocumentRequest(
    Guid EmployeeId,
    Guid DocumentTypeId,
    string DocumentNumber,
    string? DocumentName,
    DateTime IssueDate,
    DateTime ExpiryDate,
    string? IssuePlace,
    string? IssuingAuthority,
    int AlertDays,
    string? Notes
);

public record UpdateEmployeeDocumentRequest(
    Guid DocumentTypeId,
    string DocumentNumber,
    string? DocumentName,
    DateTime IssueDate,
    DateTime ExpiryDate,
    string? IssuePlace,
    string? IssuingAuthority,
    int AlertDays,
    string? Notes
);
