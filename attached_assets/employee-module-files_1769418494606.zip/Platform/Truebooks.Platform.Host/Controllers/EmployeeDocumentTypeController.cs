using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Truebooks.Platform.Core.Infrastructure;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Platform.Host.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class EmployeeDocumentTypeController : ControllerBase
{
    private readonly PlatformDbContext _context;
    private readonly ILogger<EmployeeDocumentTypeController> _logger;

    public EmployeeDocumentTypeController(PlatformDbContext context, ILogger<EmployeeDocumentTypeController> logger)
    {
        _context = context;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<EmployeeDocumentTypeDto>>> GetDocumentTypes([FromQuery] bool activeOnly = true)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var query = _context.EmployeeDocumentTypes.Where(dt => dt.TenantId == tenantId.Value);
        
        if (activeOnly)
        {
            query = query.Where(dt => dt.IsActive);
        }

        var documentTypes = await query
            .OrderBy(dt => dt.DisplayOrder)
            .ThenBy(dt => dt.Name)
            .Select(dt => new EmployeeDocumentTypeDto
            {
                Id = dt.Id,
                Code = dt.Code,
                Name = dt.Name,
                Description = dt.Description,
                DefaultAlertDays = dt.DefaultAlertDays,
                RenewalLeadTimeDays = dt.RenewalLeadTimeDays,
                IsRenewalRequired = dt.IsRenewalRequired,
                IsMandatory = dt.IsMandatory,
                ResponsibleRole = dt.ResponsibleRole,
                DisplayOrder = dt.DisplayOrder,
                IsActive = dt.IsActive,
                IsSystemDefined = dt.IsSystemDefined
            })
            .ToListAsync();

        return Ok(documentTypes);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<EmployeeDocumentTypeDto>> GetDocumentType(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var dt = await _context.EmployeeDocumentTypes.FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
        if (dt == null) return NotFound();

        return Ok(new EmployeeDocumentTypeDto
        {
            Id = dt.Id,
            Code = dt.Code,
            Name = dt.Name,
            Description = dt.Description,
            DefaultAlertDays = dt.DefaultAlertDays,
            RenewalLeadTimeDays = dt.RenewalLeadTimeDays,
            IsRenewalRequired = dt.IsRenewalRequired,
            IsMandatory = dt.IsMandatory,
            ResponsibleRole = dt.ResponsibleRole,
            DisplayOrder = dt.DisplayOrder,
            IsActive = dt.IsActive,
            IsSystemDefined = dt.IsSystemDefined
        });
    }

    [HttpPost]
    public async Task<ActionResult<EmployeeDocumentTypeDto>> CreateDocumentType([FromBody] EmployeeDocumentTypeCreateDto dto)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var exists = await _context.EmployeeDocumentTypes.AnyAsync(dt => dt.TenantId == tenantId.Value && dt.Code == dto.Code);
        if (exists) return BadRequest($"Document type with code '{dto.Code}' already exists");

        var documentType = new EmployeeDocumentType
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId.Value,
            Code = dto.Code,
            Name = dto.Name,
            Description = dto.Description,
            DefaultAlertDays = dto.DefaultAlertDays,
            RenewalLeadTimeDays = dto.RenewalLeadTimeDays,
            IsRenewalRequired = dto.IsRenewalRequired,
            IsMandatory = dto.IsMandatory,
            ResponsibleRole = dto.ResponsibleRole,
            DisplayOrder = dto.DisplayOrder,
            IsActive = true,
            IsSystemDefined = false,
            CreatedAt = DateTime.UtcNow
        };

        _context.EmployeeDocumentTypes.Add(documentType);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Created document type {Code} for tenant {TenantId}", dto.Code, tenantId);

        return CreatedAtAction(nameof(GetDocumentType), new { id = documentType.Id }, new EmployeeDocumentTypeDto
        {
            Id = documentType.Id,
            Code = documentType.Code,
            Name = documentType.Name,
            Description = documentType.Description,
            DefaultAlertDays = documentType.DefaultAlertDays,
            RenewalLeadTimeDays = documentType.RenewalLeadTimeDays,
            IsRenewalRequired = documentType.IsRenewalRequired,
            IsMandatory = documentType.IsMandatory,
            ResponsibleRole = documentType.ResponsibleRole,
            DisplayOrder = documentType.DisplayOrder,
            IsActive = documentType.IsActive,
            IsSystemDefined = documentType.IsSystemDefined
        });
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateDocumentType(Guid id, [FromBody] EmployeeDocumentTypeUpdateDto dto)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var documentType = await _context.EmployeeDocumentTypes.FirstOrDefaultAsync(dt => dt.Id == id && dt.TenantId == tenantId.Value);
        if (documentType == null) return NotFound();

        documentType.Name = dto.Name;
        documentType.Description = dto.Description;
        documentType.DefaultAlertDays = dto.DefaultAlertDays;
        documentType.RenewalLeadTimeDays = dto.RenewalLeadTimeDays;
        documentType.IsRenewalRequired = dto.IsRenewalRequired;
        documentType.IsMandatory = dto.IsMandatory;
        documentType.ResponsibleRole = dto.ResponsibleRole;
        documentType.DisplayOrder = dto.DisplayOrder;
        documentType.IsActive = dto.IsActive;
        documentType.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Updated document type {Id} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteDocumentType(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var documentType = await _context.EmployeeDocumentTypes.FirstOrDefaultAsync(dt => dt.Id == id && dt.TenantId == tenantId.Value);
        if (documentType == null) return NotFound();

        if (documentType.IsSystemDefined)
        {
            return BadRequest("Cannot delete system-defined document type");
        }

        var hasDocuments = await _context.EmployeeDocuments.AnyAsync(d => d.DocumentTypeId == id);
        if (hasDocuments)
        {
            documentType.IsActive = false;
            documentType.UpdatedAt = DateTime.UtcNow;
            _logger.LogInformation("Deactivated document type {Id} for tenant {TenantId} (has documents)", id, tenantId);
        }
        else
        {
            _context.EmployeeDocumentTypes.Remove(documentType);
            _logger.LogInformation("Deleted document type {Id} for tenant {TenantId}", id, tenantId);
        }

        await _context.SaveChangesAsync();
        return NoContent();
    }

    private Guid? GetTenantId()
    {
        var tenantIdHeader = Request.Headers["X-Tenant-Id"].FirstOrDefault();
        if (string.IsNullOrEmpty(tenantIdHeader)) return null;

        if (Guid.TryParse(tenantIdHeader, out var tenantId))
            return tenantId;

        var tenant = _context.Tenants.FirstOrDefault(t => t.Subdomain == tenantIdHeader);
        return tenant?.Id;
    }
}

public class EmployeeDocumentTypeDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public int DefaultAlertDays { get; set; } = 30;
    public int RenewalLeadTimeDays { get; set; } = 60;
    public bool IsRenewalRequired { get; set; } = true;
    public bool IsMandatory { get; set; } = false;
    public string? ResponsibleRole { get; set; }
    public int DisplayOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsSystemDefined { get; set; } = false;
}

public class EmployeeDocumentTypeCreateDto
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public int DefaultAlertDays { get; set; } = 30;
    public int RenewalLeadTimeDays { get; set; } = 60;
    public bool IsRenewalRequired { get; set; } = true;
    public bool IsMandatory { get; set; } = false;
    public string? ResponsibleRole { get; set; } = "PRO";
    public int DisplayOrder { get; set; } = 0;
}

public class EmployeeDocumentTypeUpdateDto
{
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public int DefaultAlertDays { get; set; } = 30;
    public int RenewalLeadTimeDays { get; set; } = 60;
    public bool IsRenewalRequired { get; set; } = true;
    public bool IsMandatory { get; set; } = false;
    public string? ResponsibleRole { get; set; }
    public int DisplayOrder { get; set; }
    public bool IsActive { get; set; } = true;
}
