using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Truebooks.Platform.Core.Infrastructure;
using LegacyDTOs = Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Platform.Host.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class DepartmentController : ControllerBase
{
    private readonly PlatformDbContext _context;
    private readonly ILogger<DepartmentController> _logger;

    public DepartmentController(PlatformDbContext context, ILogger<DepartmentController> logger)
    {
        _context = context;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<DepartmentDto>>> GetDepartments([FromQuery] bool includeInactive = false)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var query = _context.Departments.Where(d => d.TenantId == tenantId.Value);
        
        if (!includeInactive)
        {
            query = query.Where(d => d.IsActive);
        }

        var departments = await query.ToListAsync();
        var branches = await _context.Branches.Where(b => b.TenantId == tenantId.Value).ToListAsync();

        var result = departments
            .OrderBy(d => d.SortOrder)
            .ThenBy(d => d.Name)
            .Select(d => new DepartmentDto
            {
                Id = d.Id,
                Code = d.Code,
                Name = d.Name,
                Description = d.Description,
                BranchId = d.BranchId,
                BranchName = d.BranchId.HasValue ? branches.FirstOrDefault(b => b.Id == d.BranchId.Value)?.Name : null,
                ParentDepartmentId = d.ParentDepartmentId,
                ParentDepartmentName = d.ParentDepartmentId.HasValue ? departments.FirstOrDefault(p => p.Id == d.ParentDepartmentId.Value)?.Name : null,
                IsActive = d.IsActive,
                SortOrder = d.SortOrder,
                CreatedAt = d.CreatedAt,
                UpdatedAt = d.UpdatedAt
            })
            .ToList();

        return Ok(result);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<DepartmentDto>> GetDepartment(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var department = await _context.Departments
            .FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);

        if (department == null) return NotFound();

        var branch = department.BranchId.HasValue 
            ? await _context.Branches.FirstOrDefaultAsync(b => b.Id == department.BranchId.Value)
            : null;
        
        var parent = department.ParentDepartmentId.HasValue
            ? await _context.Departments.FirstOrDefaultAsync(d => d.Id == department.ParentDepartmentId.Value)
            : null;

        var dto = new DepartmentDto
        {
            Id = department.Id,
            Code = department.Code,
            Name = department.Name,
            Description = department.Description,
            BranchId = department.BranchId,
            BranchName = branch?.Name,
            ParentDepartmentId = department.ParentDepartmentId,
            ParentDepartmentName = parent?.Name,
            IsActive = department.IsActive,
            SortOrder = department.SortOrder,
            CreatedAt = department.CreatedAt,
            UpdatedAt = department.UpdatedAt
        };

        return Ok(dto);
    }

    [HttpPost]
    public async Task<ActionResult<DepartmentDto>> CreateDepartment([FromBody] DepartmentDto dto)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var exists = await _context.Departments.AnyAsync(d => d.TenantId == tenantId.Value && d.Code == dto.Code);
        if (exists) return BadRequest($"Department with code '{dto.Code}' already exists");

        var department = new LegacyDTOs.Department
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId.Value,
            Code = dto.Code,
            Name = dto.Name,
            Description = dto.Description,
            BranchId = dto.BranchId,
            ParentDepartmentId = dto.ParentDepartmentId,
            IsActive = true,
            SortOrder = dto.SortOrder,
            CreatedAt = DateTime.UtcNow
        };

        _context.Departments.Add(department);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Created department {DepartmentCode} for tenant {TenantId}", dto.Code, tenantId);

        dto.Id = department.Id;
        dto.CreatedAt = department.CreatedAt;
        return CreatedAtAction(nameof(GetDepartment), new { id = department.Id }, dto);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateDepartment(Guid id, [FromBody] DepartmentDto dto)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var department = await _context.Departments.FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
        if (department == null) return NotFound();

        department.Name = dto.Name;
        department.Description = dto.Description;
        department.BranchId = dto.BranchId;
        department.ParentDepartmentId = dto.ParentDepartmentId;
        department.SortOrder = dto.SortOrder;
        department.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Updated department {DepartmentId} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeactivateDepartment(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var department = await _context.Departments.FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
        if (department == null) return NotFound();

        var hasChildren = await _context.Departments.AnyAsync(d => d.ParentDepartmentId == id && d.IsActive);
        if (hasChildren)
        {
            return BadRequest("Cannot deactivate department with active child departments");
        }

        department.IsActive = false;
        department.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Deactivated department {DepartmentId} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    [HttpPost("{id}/activate")]
    public async Task<IActionResult> ActivateDepartment(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var department = await _context.Departments.FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
        if (department == null) return NotFound();

        department.IsActive = true;
        department.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Activated department {DepartmentId} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    private Guid? GetTenantId()
    {
        var tenantIdHeader = Request.Headers["X-Tenant-Id"].FirstOrDefault();
        if (string.IsNullOrEmpty(tenantIdHeader)) return null;

        if (Guid.TryParse(tenantIdHeader, out var tenantId))
            return tenantId;

        var tenant = _context.Tenants.FirstOrDefault(t => t.Subdomain == tenantIdHeader);
        return tenant?.Id;
    }
}

public class DepartmentDto
{
    public Guid Id { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public Guid? BranchId { get; set; }
    public string? BranchName { get; set; }
    public Guid? ParentDepartmentId { get; set; }
    public string? ParentDepartmentName { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}
