using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Truebooks.Platform.Core.Infrastructure;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Platform.Host.Controllers;

[Authorize]
[ApiController]
[Route("api/Employees")]
public class EmployeeController : ControllerBase
{
    private readonly PlatformDbContext _context;
    private readonly ILogger<EmployeeController> _logger;

    public EmployeeController(PlatformDbContext context, ILogger<EmployeeController> logger)
    {
        _context = context;
        _logger = logger;
    }

    private Guid? GetCurrentUserId()
    {
        var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value 
                          ?? User.FindFirst("sub")?.Value;
        return Guid.TryParse(userIdClaim, out var userId) ? userId : null;
    }

    [HttpGet("me")]
    public async Task<ActionResult<EmployeeDetailDto>> GetCurrentEmployee()
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var userId = GetCurrentUserId();
        if (userId == null) return Unauthorized("User not authenticated");

        var user = await _context.ApplicationUsers.FirstOrDefaultAsync(u => u.Id == userId.Value);
        if (user == null || !user.EmployeeId.HasValue)
            return NotFound("No employee record linked to current user");

        var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Id == user.EmployeeId.Value && e.TenantId == tenantId.Value);
        if (employee == null)
            return NotFound("Employee record not found");

        var department = employee.DepartmentId.HasValue
            ? await _context.Departments.FirstOrDefaultAsync(d => d.Id == employee.DepartmentId.Value)
            : null;

        return Ok(new EmployeeDetailDto
        {
            Id = employee.Id,
            EmployeeCode = employee.EmployeeCode,
            FirstName = employee.FirstName,
            LastName = employee.LastName,
            Email = employee.Email,
            Phone = employee.Phone,
            DateOfBirth = employee.DateOfBirth,
            Gender = employee.Gender,
            Nationality = employee.Nationality,
            DepartmentId = employee.DepartmentId,
            DepartmentName = department?.Name,
            Designation = employee.Designation,
            JoiningDate = employee.JoiningDate,
            TerminationDate = employee.TerminationDate,
            Address = employee.Address,
            City = employee.City,
            Country = employee.Country,
            Status = employee.Status.ToString(),
            IsActive = employee.IsActive,
            EmployeeType = (int)employee.EmployeeType,
            EmployeeTypeText = employee.EmployeeType.ToString(),
            PaymentType = (int)employee.PaymentType,
            PaymentTypeText = employee.PaymentType.ToString(),
            HourlyRate = employee.HourlyRate,
            MonthlySalary = employee.MonthlySalary,
            LumpsumAmount = employee.LumpsumAmount,
            CreatedAt = employee.CreatedAt,
            UpdatedAt = employee.UpdatedAt
        });
    }

    [HttpGet]
    public async Task<ActionResult<List<EmployeeListDto>>> GetEmployees([FromQuery] bool includeInactive = false)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var query = _context.Employees.Where(e => e.TenantId == tenantId.Value);
        
        if (!includeInactive)
        {
            query = query.Where(e => e.IsActive);
        }

        var departments = await _context.Departments.Where(d => d.TenantId == tenantId.Value).ToListAsync();
        var employees = await query.OrderBy(e => e.EmployeeCode).ToListAsync();

        var result = employees.Select(e => new EmployeeListDto
        {
            Id = e.Id,
            EmployeeCode = e.EmployeeCode,
            FirstName = e.FirstName,
            LastName = e.LastName,
            FullName = $"{e.FirstName} {e.LastName}".Trim(),
            Email = e.Email,
            Phone = e.Phone,
            DepartmentId = e.DepartmentId,
            DepartmentName = e.DepartmentId.HasValue ? departments.FirstOrDefault(d => d.Id == e.DepartmentId.Value)?.Name : null,
            Designation = e.Designation,
            JoiningDate = e.JoiningDate,
            Status = e.Status.ToString(),
            IsActive = e.IsActive
        }).ToList();

        return Ok(result);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<EmployeeDetailDto>> GetEmployee(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId.Value);
        if (employee == null) return NotFound();

        var department = employee.DepartmentId.HasValue
            ? await _context.Departments.FirstOrDefaultAsync(d => d.Id == employee.DepartmentId.Value)
            : null;

        var dto = new EmployeeDetailDto
        {
            Id = employee.Id,
            EmployeeCode = employee.EmployeeCode,
            FirstName = employee.FirstName,
            LastName = employee.LastName,
            Email = employee.Email,
            Phone = employee.Phone,
            DateOfBirth = employee.DateOfBirth,
            Gender = employee.Gender,
            Nationality = employee.Nationality,
            DepartmentId = employee.DepartmentId,
            DepartmentName = department?.Name,
            Designation = employee.Designation,
            JoiningDate = employee.JoiningDate,
            TerminationDate = employee.TerminationDate,
            Address = employee.Address,
            City = employee.City,
            Country = employee.Country,
            Status = employee.Status.ToString(),
            IsActive = employee.IsActive,
            EmployeeType = (int)employee.EmployeeType,
            EmployeeTypeText = employee.EmployeeType.ToString(),
            PaymentType = (int)employee.PaymentType,
            PaymentTypeText = employee.PaymentType.ToString(),
            HourlyRate = employee.HourlyRate,
            MonthlySalary = employee.MonthlySalary,
            LumpsumAmount = employee.LumpsumAmount,
            CreatedAt = employee.CreatedAt,
            UpdatedAt = employee.UpdatedAt
        };

        return Ok(dto);
    }

    [HttpPost]
    public async Task<ActionResult<EmployeeDetailDto>> CreateEmployee([FromBody] EmployeeCreateDto dto)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var exists = await _context.Employees.AnyAsync(e => e.TenantId == tenantId.Value && e.EmployeeCode == dto.EmployeeCode);
        if (exists) return BadRequest($"Employee with code '{dto.EmployeeCode}' already exists");

        var employee = new Employee
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId.Value,
            EmployeeCode = dto.EmployeeCode,
            FirstName = dto.FirstName,
            LastName = dto.LastName,
            Email = dto.Email,
            Phone = dto.Phone,
            DateOfBirth = dto.DateOfBirth,
            Gender = dto.Gender,
            Nationality = dto.Nationality,
            DepartmentId = dto.DepartmentId,
            Designation = dto.Designation,
            JoiningDate = dto.JoiningDate,
            Address = dto.Address,
            City = dto.City,
            Country = dto.Country,
            EmployeeType = (EmployeeType)dto.EmployeeType,
            PaymentType = (PaymentType)dto.PaymentType,
            HourlyRate = dto.HourlyRate,
            MonthlySalary = dto.MonthlySalary,
            LumpsumAmount = dto.LumpsumAmount,
            Status = EmployeeStatus.Active,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        _context.Employees.Add(employee);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Created employee {EmployeeCode} for tenant {TenantId}", dto.EmployeeCode, tenantId);

        return CreatedAtAction(nameof(GetEmployee), new { id = employee.Id }, new EmployeeDetailDto
        {
            Id = employee.Id,
            EmployeeCode = employee.EmployeeCode,
            FirstName = employee.FirstName,
            LastName = employee.LastName,
            Email = employee.Email,
            Phone = employee.Phone,
            DepartmentId = employee.DepartmentId,
            Designation = employee.Designation,
            JoiningDate = employee.JoiningDate,
            Status = employee.Status.ToString(),
            IsActive = employee.IsActive,
            EmployeeType = (int)employee.EmployeeType,
            EmployeeTypeText = employee.EmployeeType.ToString(),
            PaymentType = (int)employee.PaymentType,
            PaymentTypeText = employee.PaymentType.ToString(),
            HourlyRate = employee.HourlyRate,
            MonthlySalary = employee.MonthlySalary,
            LumpsumAmount = employee.LumpsumAmount,
            CreatedAt = employee.CreatedAt
        });
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateEmployee(Guid id, [FromBody] EmployeeUpdateDto dto)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId.Value);
        if (employee == null) return NotFound();

        employee.FirstName = dto.FirstName;
        employee.LastName = dto.LastName;
        employee.Email = dto.Email;
        employee.Phone = dto.Phone;
        employee.DateOfBirth = dto.DateOfBirth;
        employee.Gender = dto.Gender;
        employee.Nationality = dto.Nationality;
        employee.DepartmentId = dto.DepartmentId;
        employee.Designation = dto.Designation;
        employee.JoiningDate = dto.JoiningDate;
        employee.TerminationDate = dto.TerminationDate;
        employee.Address = dto.Address;
        employee.City = dto.City;
        employee.Country = dto.Country;
        employee.EmployeeType = (EmployeeType)dto.EmployeeType;
        employee.PaymentType = (PaymentType)dto.PaymentType;
        employee.HourlyRate = dto.HourlyRate;
        employee.MonthlySalary = dto.MonthlySalary;
        employee.LumpsumAmount = dto.LumpsumAmount;
        employee.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Updated employee {EmployeeId} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeactivateEmployee(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId.Value);
        if (employee == null) return NotFound();

        employee.IsActive = false;
        employee.Status = EmployeeStatus.Terminated;
        employee.TerminationDate = DateTime.UtcNow;
        employee.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Deactivated employee {EmployeeId} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    [HttpPost("{id}/activate")]
    public async Task<IActionResult> ActivateEmployee(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Id == id && e.TenantId == tenantId.Value);
        if (employee == null) return NotFound();

        employee.IsActive = true;
        employee.Status = EmployeeStatus.Active;
        employee.TerminationDate = null;
        employee.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Activated employee {EmployeeId} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    private Guid? GetTenantId()
    {
        var tenantIdHeader = Request.Headers["X-Tenant-Id"].FirstOrDefault();
        if (string.IsNullOrEmpty(tenantIdHeader)) return null;

        if (Guid.TryParse(tenantIdHeader, out var tenantId))
            return tenantId;

        var tenant = _context.Tenants.FirstOrDefault(t => t.Subdomain == tenantIdHeader);
        return tenant?.Id;
    }
}

public class EmployeeListDto
{
    public Guid Id { get; set; }
    public string EmployeeCode { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string FullName { get; set; } = "";
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public Guid? DepartmentId { get; set; }
    public string? DepartmentName { get; set; }
    public string? Designation { get; set; }
    public DateTime? JoiningDate { get; set; }
    public string Status { get; set; } = "Active";
    public bool IsActive { get; set; }
}

public class EmployeeDetailDto
{
    public Guid Id { get; set; }
    public string EmployeeCode { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? Gender { get; set; }
    public string? Nationality { get; set; }
    public Guid? DepartmentId { get; set; }
    public string? DepartmentName { get; set; }
    public string? Designation { get; set; }
    public DateTime? JoiningDate { get; set; }
    public DateTime? TerminationDate { get; set; }
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? Country { get; set; }
    public string Status { get; set; } = "Active";
    public bool IsActive { get; set; }
    public int EmployeeType { get; set; }
    public string? EmployeeTypeText { get; set; }
    public int PaymentType { get; set; }
    public string? PaymentTypeText { get; set; }
    public decimal? HourlyRate { get; set; }
    public decimal? MonthlySalary { get; set; }
    public decimal? LumpsumAmount { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class EmployeeCreateDto
{
    public string EmployeeCode { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? Gender { get; set; }
    public string? Nationality { get; set; }
    public Guid? DepartmentId { get; set; }
    public string? Designation { get; set; }
    public DateTime? JoiningDate { get; set; }
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? Country { get; set; }
    public int EmployeeType { get; set; }
    public int PaymentType { get; set; }
    public decimal? HourlyRate { get; set; }
    public decimal? MonthlySalary { get; set; }
    public decimal? LumpsumAmount { get; set; }
}

public class EmployeeUpdateDto
{
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? Gender { get; set; }
    public string? Nationality { get; set; }
    public Guid? DepartmentId { get; set; }
    public string? Designation { get; set; }
    public DateTime? JoiningDate { get; set; }
    public DateTime? TerminationDate { get; set; }
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? Country { get; set; }
    public int EmployeeType { get; set; }
    public int PaymentType { get; set; }
    public decimal? HourlyRate { get; set; }
    public decimal? MonthlySalary { get; set; }
    public decimal? LumpsumAmount { get; set; }
}
