using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Truebooks.Platform.Core.Infrastructure;
using Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Platform.Host.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class EmployeeDocumentController : ControllerBase
{
    private readonly PlatformDbContext _context;
    private readonly ILogger<EmployeeDocumentController> _logger;

    public EmployeeDocumentController(PlatformDbContext context, ILogger<EmployeeDocumentController> logger)
    {
        _context = context;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<EmployeeDocumentListDto>>> GetDocuments([FromQuery] Guid? employeeId = null, [FromQuery] string? status = null)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var query = _context.EmployeeDocuments.Where(d => d.TenantId == tenantId.Value && d.IsActive);
        
        if (employeeId.HasValue)
        {
            query = query.Where(d => d.EmployeeId == employeeId.Value);
        }

        var employees = await _context.Employees.Where(e => e.TenantId == tenantId.Value).ToListAsync();
        var documentTypes = await _context.EmployeeDocumentTypes.Where(dt => dt.TenantId == tenantId.Value).ToListAsync();
        var documents = await query.ToListAsync();

        var now = DateTime.UtcNow.Date;
        var result = documents.Select(d =>
        {
            var daysUntilExpiry = (d.ExpiryDate.Date - now).Days;
            var docStatus = daysUntilExpiry <= 0 ? "Expired" 
                : daysUntilExpiry <= 7 ? "Critical" 
                : daysUntilExpiry <= 30 ? "Expiring" 
                : "Valid";

            var employee = employees.FirstOrDefault(e => e.Id == d.EmployeeId);
            var docType = documentTypes.FirstOrDefault(dt => dt.Id == d.DocumentTypeId);

            return new EmployeeDocumentListDto
            {
                Id = d.Id,
                EmployeeId = d.EmployeeId,
                EmployeeName = employee != null ? $"{employee.FirstName} {employee.LastName}".Trim() : "Unknown",
                EmployeeCode = employee?.EmployeeCode ?? "",
                DocumentTypeId = d.DocumentTypeId,
                DocumentTypeName = docType?.Name ?? "Unknown",
                DocumentNumber = d.DocumentNumber,
                DocumentName = d.DocumentName,
                IssueDate = d.IssueDate,
                ExpiryDate = d.ExpiryDate,
                IssuePlace = d.IssuePlace,
                Status = docStatus,
                DaysUntilExpiry = daysUntilExpiry,
                IsVerified = d.IsVerified,
                Notes = d.Notes
            };
        })
        .OrderBy(d => d.ExpiryDate)
        .ToList();

        if (!string.IsNullOrEmpty(status))
        {
            result = result.Where(d => d.Status.Equals(status, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        return Ok(result);
    }

    [HttpGet("stats")]
    public async Task<ActionResult<EmployeeDocumentStatsDto>> GetStats()
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var documents = await _context.EmployeeDocuments
            .Where(d => d.TenantId == tenantId.Value && d.IsActive)
            .ToListAsync();

        var now = DateTime.UtcNow.Date;
        var stats = new EmployeeDocumentStatsDto
        {
            TotalDocuments = documents.Count,
            ActiveDocuments = documents.Count(d => (d.ExpiryDate.Date - now).Days > 30),
            ExpiringIn30Days = documents.Count(d => 
            {
                var days = (d.ExpiryDate.Date - now).Days;
                return days > 0 && days <= 30;
            }),
            ExpiringIn60Days = documents.Count(d =>
            {
                var days = (d.ExpiryDate.Date - now).Days;
                return days > 0 && days <= 60;
            }),
            ExpiringIn90Days = documents.Count(d =>
            {
                var days = (d.ExpiryDate.Date - now).Days;
                return days > 0 && days <= 90;
            }),
            AlreadyExpired = documents.Count(d => (d.ExpiryDate.Date - now).Days <= 0)
        };

        return Ok(stats);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<EmployeeDocumentDetailDto>> GetDocument(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var doc = await _context.EmployeeDocuments.FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
        if (doc == null) return NotFound();

        var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Id == doc.EmployeeId);
        var docType = await _context.EmployeeDocumentTypes.FirstOrDefaultAsync(dt => dt.Id == doc.DocumentTypeId);

        var now = DateTime.UtcNow.Date;
        var daysUntilExpiry = (doc.ExpiryDate.Date - now).Days;

        return Ok(new EmployeeDocumentDetailDto
        {
            Id = doc.Id,
            EmployeeId = doc.EmployeeId,
            EmployeeName = employee != null ? $"{employee.FirstName} {employee.LastName}".Trim() : "Unknown",
            EmployeeCode = employee?.EmployeeCode ?? "",
            DocumentTypeId = doc.DocumentTypeId,
            DocumentTypeName = docType?.Name ?? "Unknown",
            DocumentNumber = doc.DocumentNumber,
            DocumentName = doc.DocumentName,
            IssueDate = doc.IssueDate,
            ExpiryDate = doc.ExpiryDate,
            IssuePlace = doc.IssuePlace,
            IssuingAuthority = doc.IssuingAuthority,
            IssuingCountry = doc.IssuingCountry,
            AttachmentPath = doc.AttachmentPath,
            AttachmentFileName = doc.AttachmentFileName,
            AlertDays = doc.AlertDays,
            IsVerified = doc.IsVerified,
            VerifiedDate = doc.VerifiedDate,
            Notes = doc.Notes,
            DaysUntilExpiry = daysUntilExpiry,
            IsActive = doc.IsActive,
            CreatedAt = doc.CreatedAt,
            UpdatedAt = doc.UpdatedAt
        });
    }

    [HttpPost]
    public async Task<ActionResult<EmployeeDocumentDetailDto>> CreateDocument([FromBody] EmployeeDocumentCreateDto dto)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var employeeExists = await _context.Employees.AnyAsync(e => e.Id == dto.EmployeeId && e.TenantId == tenantId.Value);
        if (!employeeExists) return BadRequest("Employee not found");

        var docTypeExists = await _context.EmployeeDocumentTypes.AnyAsync(dt => dt.Id == dto.DocumentTypeId && dt.TenantId == tenantId.Value);
        if (!docTypeExists) return BadRequest("Document type not found");

        var document = new EmployeeDocument
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId.Value,
            EmployeeId = dto.EmployeeId,
            DocumentTypeId = dto.DocumentTypeId,
            DocumentNumber = dto.DocumentNumber,
            DocumentName = dto.DocumentName,
            IssueDate = dto.IssueDate,
            ExpiryDate = dto.ExpiryDate,
            IssuePlace = dto.IssuePlace,
            IssuingAuthority = dto.IssuingAuthority,
            IssuingCountry = dto.IssuingCountry,
            AlertDays = dto.AlertDays,
            Notes = dto.Notes,
            Status = DocumentStatus.Valid,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        _context.EmployeeDocuments.Add(document);
        await _context.SaveChangesAsync();

        _logger.LogInformation("Created document {DocumentNumber} for employee {EmployeeId} in tenant {TenantId}", 
            dto.DocumentNumber, dto.EmployeeId, tenantId);

        return CreatedAtAction(nameof(GetDocument), new { id = document.Id }, new EmployeeDocumentDetailDto
        {
            Id = document.Id,
            EmployeeId = document.EmployeeId,
            DocumentTypeId = document.DocumentTypeId,
            DocumentNumber = document.DocumentNumber,
            DocumentName = document.DocumentName,
            IssueDate = document.IssueDate,
            ExpiryDate = document.ExpiryDate,
            IssuePlace = document.IssuePlace,
            IsActive = document.IsActive,
            CreatedAt = document.CreatedAt
        });
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateDocument(Guid id, [FromBody] EmployeeDocumentUpdateDto dto)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var document = await _context.EmployeeDocuments.FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
        if (document == null) return NotFound();

        document.DocumentTypeId = dto.DocumentTypeId;
        document.DocumentNumber = dto.DocumentNumber;
        document.DocumentName = dto.DocumentName;
        document.IssueDate = dto.IssueDate;
        document.ExpiryDate = dto.ExpiryDate;
        document.IssuePlace = dto.IssuePlace;
        document.IssuingAuthority = dto.IssuingAuthority;
        document.IssuingCountry = dto.IssuingCountry;
        document.AlertDays = dto.AlertDays;
        document.Notes = dto.Notes;
        document.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Updated document {Id} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteDocument(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var document = await _context.EmployeeDocuments.FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
        if (document == null) return NotFound();

        document.IsActive = false;
        document.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Deactivated document {Id} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    [HttpPost("{id}/verify")]
    public async Task<IActionResult> VerifyDocument(Guid id)
    {
        var tenantId = GetTenantId();
        if (tenantId == null) return BadRequest("Tenant ID not provided");

        var document = await _context.EmployeeDocuments.FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId.Value);
        if (document == null) return NotFound();

        document.IsVerified = true;
        document.VerifiedDate = DateTime.UtcNow;
        document.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        _logger.LogInformation("Verified document {Id} for tenant {TenantId}", id, tenantId);

        return NoContent();
    }

    private Guid? GetTenantId()
    {
        var tenantIdHeader = Request.Headers["X-Tenant-Id"].FirstOrDefault();
        if (string.IsNullOrEmpty(tenantIdHeader)) return null;

        if (Guid.TryParse(tenantIdHeader, out var tenantId))
            return tenantId;

        var tenant = _context.Tenants.FirstOrDefault(t => t.Subdomain == tenantIdHeader);
        return tenant?.Id;
    }
}

public class EmployeeDocumentListDto
{
    public Guid Id { get; set; }
    public Guid EmployeeId { get; set; }
    public string EmployeeName { get; set; } = "";
    public string EmployeeCode { get; set; } = "";
    public Guid DocumentTypeId { get; set; }
    public string DocumentTypeName { get; set; } = "";
    public string DocumentNumber { get; set; } = "";
    public string? DocumentName { get; set; }
    public DateTime IssueDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public string? IssuePlace { get; set; }
    public string Status { get; set; } = "Valid";
    public int DaysUntilExpiry { get; set; }
    public bool IsVerified { get; set; }
    public string? Notes { get; set; }
}

public class EmployeeDocumentDetailDto
{
    public Guid Id { get; set; }
    public Guid EmployeeId { get; set; }
    public string EmployeeName { get; set; } = "";
    public string EmployeeCode { get; set; } = "";
    public Guid DocumentTypeId { get; set; }
    public string DocumentTypeName { get; set; } = "";
    public string DocumentNumber { get; set; } = "";
    public string? DocumentName { get; set; }
    public DateTime IssueDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public string? IssuePlace { get; set; }
    public string? IssuingAuthority { get; set; }
    public string? IssuingCountry { get; set; }
    public string? AttachmentPath { get; set; }
    public string? AttachmentFileName { get; set; }
    public int AlertDays { get; set; }
    public bool IsVerified { get; set; }
    public DateTime? VerifiedDate { get; set; }
    public string? Notes { get; set; }
    public int DaysUntilExpiry { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class EmployeeDocumentCreateDto
{
    public Guid EmployeeId { get; set; }
    public Guid DocumentTypeId { get; set; }
    public string DocumentNumber { get; set; } = "";
    public string? DocumentName { get; set; }
    public DateTime IssueDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public string? IssuePlace { get; set; }
    public string? IssuingAuthority { get; set; }
    public string? IssuingCountry { get; set; }
    public int AlertDays { get; set; } = 30;
    public string? Notes { get; set; }
}

public class EmployeeDocumentUpdateDto
{
    public Guid DocumentTypeId { get; set; }
    public string DocumentNumber { get; set; } = "";
    public string? DocumentName { get; set; }
    public DateTime IssueDate { get; set; }
    public DateTime ExpiryDate { get; set; }
    public string? IssuePlace { get; set; }
    public string? IssuingAuthority { get; set; }
    public string? IssuingCountry { get; set; }
    public int AlertDays { get; set; } = 30;
    public string? Notes { get; set; }
}

public class EmployeeDocumentStatsDto
{
    public int TotalDocuments { get; set; }
    public int ActiveDocuments { get; set; }
    public int ExpiringIn30Days { get; set; }
    public int ExpiringIn60Days { get; set; }
    public int ExpiringIn90Days { get; set; }
    public int AlreadyExpired { get; set; }
}
