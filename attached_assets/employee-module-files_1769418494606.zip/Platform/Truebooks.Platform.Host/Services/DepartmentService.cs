using Microsoft.EntityFrameworkCore;
using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Services;
using Truebooks.Platform.Core.Infrastructure;
using LegacyDTOs = Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Platform.Host.Services;

public class DepartmentService : IDepartmentService
{
    private readonly PlatformDbContext _context;

    public DepartmentService(PlatformDbContext context)
    {
        _context = context;
    }

    public async Task<List<DepartmentDto>> GetAllAsync(Guid tenantId, bool includeInactive = false, Guid? branchId = null)
    {
        if (tenantId == Guid.Empty)
            return new List<DepartmentDto>();

        var query = _context.Departments.Where(d => d.TenantId == tenantId);
        
        if (!includeInactive)
            query = query.Where(d => d.IsActive);
        
        if (branchId.HasValue)
            query = query.Where(d => d.BranchId == branchId.Value);

        var departments = await query
            .OrderBy(d => d.SortOrder)
            .ThenBy(d => d.Name)
            .ToListAsync();

        var branchIds = departments.Where(d => d.BranchId.HasValue).Select(d => d.BranchId!.Value).Distinct().ToList();
        var branches = await _context.Branches.Where(b => branchIds.Contains(b.Id)).ToDictionaryAsync(b => b.Id, b => b.Name);

        var deptDict = departments.ToDictionary(d => d.Id);

        return departments.Select(d => new DepartmentDto(
            d.Id,
            d.TenantId,
            d.CreatedAt,
            d.UpdatedAt,
            d.Code,
            d.Name,
            d.Description,
            d.BranchId,
            d.BranchId.HasValue && branches.ContainsKey(d.BranchId.Value) ? branches[d.BranchId.Value] : null,
            d.ParentDepartmentId,
            d.ParentDepartmentId.HasValue && deptDict.ContainsKey(d.ParentDepartmentId.Value) ? deptDict[d.ParentDepartmentId.Value].Name : null,
            d.IsActive,
            d.SortOrder,
            new List<DepartmentDto>()
        )).ToList();
    }

    public async Task<List<DepartmentDto>> GetActiveAsync(Guid tenantId, Guid? branchId = null)
    {
        return await GetAllAsync(tenantId, false, branchId);
    }

    public async Task<DepartmentDto?> GetByIdAsync(Guid tenantId, Guid id)
    {
        if (tenantId == Guid.Empty)
            return null;

        var dept = await _context.Departments
            .Where(d => d.TenantId == tenantId && d.Id == id)
            .FirstOrDefaultAsync();

        if (dept == null)
            return null;

        string? branchName = null;
        if (dept.BranchId.HasValue)
        {
            var branch = await _context.Branches.FirstOrDefaultAsync(b => b.Id == dept.BranchId.Value);
            branchName = branch?.Name;
        }

        string? parentName = null;
        if (dept.ParentDepartmentId.HasValue)
        {
            var parent = await _context.Departments.FirstOrDefaultAsync(d => d.Id == dept.ParentDepartmentId.Value);
            parentName = parent?.Name;
        }

        return new DepartmentDto(
            dept.Id,
            dept.TenantId,
            dept.CreatedAt,
            dept.UpdatedAt,
            dept.Code,
            dept.Name,
            dept.Description,
            dept.BranchId,
            branchName,
            dept.ParentDepartmentId,
            parentName,
            dept.IsActive,
            dept.SortOrder,
            new List<DepartmentDto>()
        );
    }

    public async Task<List<DepartmentDto>> GetHierarchyAsync(Guid tenantId, Guid? branchId = null)
    {
        var allDepts = await GetAllAsync(tenantId, false, branchId);
        
        var deptDict = allDepts.ToDictionary(d => d.Id);
        var rootDepts = allDepts.Where(d => !d.ParentDepartmentId.HasValue).ToList();

        List<DepartmentDto> BuildHierarchy(DepartmentDto parent)
        {
            var children = allDepts.Where(d => d.ParentDepartmentId == parent.Id).ToList();
            return children.Select(c => c with { ChildDepartments = BuildHierarchy(c) }).ToList();
        }

        return rootDepts.Select(r => r with { ChildDepartments = BuildHierarchy(r) }).ToList();
    }

    public async Task<List<DepartmentDto>> GetUserAccessibleDepartmentsAsync(Guid tenantId)
    {
        return await GetActiveAsync(tenantId);
    }

    public async Task<Guid> CreateAsync(Guid tenantId, CreateDepartmentRequest request)
    {
        if (tenantId == Guid.Empty)
            return Guid.Empty;

        var entity = new LegacyDTOs.Department
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId,
            Code = request.Code,
            Name = request.Name,
            Description = request.Description,
            BranchId = request.BranchId,
            ParentDepartmentId = request.ParentDepartmentId,
            IsActive = request.IsActive,
            SortOrder = request.SortOrder,
            CreatedAt = DateTime.UtcNow
        };

        _context.Departments.Add(entity);
        await _context.SaveChangesAsync();

        return entity.Id;
    }

    public async Task UpdateAsync(Guid tenantId, Guid id, UpdateDepartmentRequest request)
    {
        if (tenantId == Guid.Empty)
            return;

        var entity = await _context.Departments
            .FirstOrDefaultAsync(d => d.TenantId == tenantId && d.Id == id);

        if (entity == null)
            return;

        entity.Code = request.Code;
        entity.Name = request.Name;
        entity.Description = request.Description;
        entity.BranchId = request.BranchId;
        entity.ParentDepartmentId = request.ParentDepartmentId;
        entity.IsActive = request.IsActive;
        entity.SortOrder = request.SortOrder;
        entity.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(Guid tenantId, Guid id)
    {
        if (tenantId == Guid.Empty)
            return;

        var entity = await _context.Departments
            .FirstOrDefaultAsync(d => d.TenantId == tenantId && d.Id == id);

        if (entity == null)
            return;

        _context.Departments.Remove(entity);
        await _context.SaveChangesAsync();
    }
}
