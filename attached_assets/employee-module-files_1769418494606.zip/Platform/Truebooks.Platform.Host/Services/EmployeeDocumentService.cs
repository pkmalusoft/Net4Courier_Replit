using Microsoft.EntityFrameworkCore;
using Truebooks.Platform.Contracts.Services;
using Truebooks.Platform.Core.Infrastructure;
using LegacyDTOs = Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Platform.Host.Services;

public class EmployeeDocumentService : IEmployeeDocumentService
{
    private readonly PlatformDbContext _context;

    public EmployeeDocumentService(PlatformDbContext context)
    {
        _context = context;
    }

    public async Task<List<EmployeeDocumentDto>> GetAllAsync(Guid tenantId, Guid? employeeId = null, string? status = null, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var query = _context.EmployeeDocuments
            .Where(d => d.TenantId == tenantId && d.IsActive);

        if (employeeId.HasValue)
            query = query.Where(d => d.EmployeeId == employeeId.Value);

        var employees = await _context.Employees
            .Where(e => e.TenantId == tenantId)
            .AsNoTracking()
            .ToListAsync(cancellationToken);

        var documentTypes = await _context.EmployeeDocumentTypes
            .Where(dt => dt.TenantId == tenantId)
            .AsNoTracking()
            .ToListAsync(cancellationToken);

        var documents = await query.AsNoTracking().ToListAsync(cancellationToken);

        var now = DateTime.UtcNow.Date;
        var result = documents.Select(d =>
        {
            var daysUntilExpiry = (d.ExpiryDate.Date - now).Days;
            var docStatus = daysUntilExpiry <= 0 ? "Expired"
                : daysUntilExpiry <= 7 ? "Critical"
                : daysUntilExpiry <= 30 ? "Expiring"
                : "Valid";

            var employee = employees.FirstOrDefault(e => e.Id == d.EmployeeId);
            var docType = documentTypes.FirstOrDefault(dt => dt.Id == d.DocumentTypeId);

            return new EmployeeDocumentDto(
                d.Id,
                d.EmployeeId,
                employee != null ? $"{employee.FirstName} {employee.LastName}".Trim() : "Unknown",
                employee?.EmployeeCode ?? "",
                d.DocumentTypeId,
                docType?.Name ?? "Unknown",
                d.DocumentNumber,
                d.DocumentName,
                d.IssueDate,
                d.ExpiryDate,
                d.IssuePlace,
                d.IssuingAuthority,
                docStatus,
                daysUntilExpiry,
                d.IsVerified,
                d.Notes
            );
        })
        .OrderBy(d => d.ExpiryDate)
        .ToList();

        if (!string.IsNullOrEmpty(status))
            result = result.Where(d => d.Status.Equals(status, StringComparison.OrdinalIgnoreCase)).ToList();

        return result;
    }

    public async Task<EmployeeDocumentDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var d = await _context.EmployeeDocuments
            .AsNoTracking()
            .FirstOrDefaultAsync(doc => doc.Id == id && doc.TenantId == tenantId, cancellationToken);

        if (d == null) return null;

        var employee = await _context.Employees
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == d.EmployeeId, cancellationToken);
        var docType = await _context.EmployeeDocumentTypes
            .AsNoTracking()
            .FirstOrDefaultAsync(dt => dt.Id == d.DocumentTypeId, cancellationToken);

        var now = DateTime.UtcNow.Date;
        var daysUntilExpiry = (d.ExpiryDate.Date - now).Days;
        var status = daysUntilExpiry <= 0 ? "Expired"
            : daysUntilExpiry <= 7 ? "Critical"
            : daysUntilExpiry <= 30 ? "Expiring"
            : "Valid";

        return new EmployeeDocumentDto(
            d.Id,
            d.EmployeeId,
            employee != null ? $"{employee.FirstName} {employee.LastName}".Trim() : "Unknown",
            employee?.EmployeeCode ?? "",
            d.DocumentTypeId,
            docType?.Name ?? "Unknown",
            d.DocumentNumber,
            d.DocumentName,
            d.IssueDate,
            d.ExpiryDate,
            d.IssuePlace,
            d.IssuingAuthority,
            status,
            daysUntilExpiry,
            d.IsVerified,
            d.Notes
        );
    }

    public async Task<EmployeeDocumentStatsDto> GetStatsAsync(Guid tenantId, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var documents = await _context.EmployeeDocuments
            .Where(d => d.TenantId == tenantId && d.IsActive)
            .AsNoTracking()
            .ToListAsync(cancellationToken);

        var now = DateTime.UtcNow.Date;

        return new EmployeeDocumentStatsDto(
            TotalDocuments: documents.Count,
            ActiveDocuments: documents.Count(d => (d.ExpiryDate.Date - now).Days > 30),
            ExpiringIn30Days: documents.Count(d => { var days = (d.ExpiryDate.Date - now).Days; return days > 0 && days <= 30; }),
            ExpiringIn60Days: documents.Count(d => { var days = (d.ExpiryDate.Date - now).Days; return days > 0 && days <= 60; }),
            ExpiringIn90Days: documents.Count(d => { var days = (d.ExpiryDate.Date - now).Days; return days > 0 && days <= 90; }),
            AlreadyExpired: documents.Count(d => (d.ExpiryDate.Date - now).Days <= 0)
        );
    }

    public async Task<EmployeeDocumentDto> CreateAsync(Guid tenantId, CreateEmployeeDocumentRequest request, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var employeeExists = await _context.Employees.AnyAsync(e => e.Id == request.EmployeeId && e.TenantId == tenantId, cancellationToken);
        if (!employeeExists)
            throw new InvalidOperationException("Employee not found");

        var docTypeExists = await _context.EmployeeDocumentTypes.AnyAsync(dt => dt.Id == request.DocumentTypeId && dt.TenantId == tenantId, cancellationToken);
        if (!docTypeExists)
            throw new InvalidOperationException("Document type not found");

        var document = new LegacyDTOs.EmployeeDocument
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId,
            EmployeeId = request.EmployeeId,
            DocumentTypeId = request.DocumentTypeId,
            DocumentNumber = request.DocumentNumber,
            DocumentName = request.DocumentName,
            IssueDate = request.IssueDate,
            ExpiryDate = request.ExpiryDate,
            IssuePlace = request.IssuePlace,
            IssuingAuthority = request.IssuingAuthority,
            AlertDays = request.AlertDays,
            Notes = request.Notes,
            Status = LegacyDTOs.DocumentStatus.Valid,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        _context.EmployeeDocuments.Add(document);
        await _context.SaveChangesAsync(cancellationToken);

        var employee = await _context.Employees.FirstOrDefaultAsync(e => e.Id == request.EmployeeId, cancellationToken);
        var docType = await _context.EmployeeDocumentTypes.FirstOrDefaultAsync(dt => dt.Id == request.DocumentTypeId, cancellationToken);

        var now = DateTime.UtcNow.Date;
        var daysUntilExpiry = (document.ExpiryDate.Date - now).Days;

        return new EmployeeDocumentDto(
            document.Id,
            document.EmployeeId,
            employee != null ? $"{employee.FirstName} {employee.LastName}".Trim() : "Unknown",
            employee?.EmployeeCode ?? "",
            document.DocumentTypeId,
            docType?.Name ?? "Unknown",
            document.DocumentNumber,
            document.DocumentName,
            document.IssueDate,
            document.ExpiryDate,
            document.IssuePlace,
            document.IssuingAuthority,
            "Valid",
            daysUntilExpiry,
            document.IsVerified,
            document.Notes
        );
    }

    public async Task UpdateAsync(Guid tenantId, Guid id, UpdateEmployeeDocumentRequest request, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var document = await _context.EmployeeDocuments
            .FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId, cancellationToken)
            ?? throw new InvalidOperationException($"Document {id} not found");

        document.DocumentTypeId = request.DocumentTypeId;
        document.DocumentNumber = request.DocumentNumber;
        document.DocumentName = request.DocumentName;
        document.IssueDate = request.IssueDate;
        document.ExpiryDate = request.ExpiryDate;
        document.IssuePlace = request.IssuePlace;
        document.IssuingAuthority = request.IssuingAuthority;
        document.AlertDays = request.AlertDays;
        document.Notes = request.Notes;
        document.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var document = await _context.EmployeeDocuments
            .FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId, cancellationToken)
            ?? throw new InvalidOperationException($"Document {id} not found");

        document.IsActive = false;
        document.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task VerifyAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var document = await _context.EmployeeDocuments
            .FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId, cancellationToken)
            ?? throw new InvalidOperationException($"Document {id} not found");

        document.IsVerified = true;
        document.VerifiedDate = DateTime.UtcNow;
        document.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync(cancellationToken);
    }
}
