using Microsoft.EntityFrameworkCore;
using Truebooks.Platform.Contracts.DTOs;
using Truebooks.Platform.Contracts.Services;
using Truebooks.Platform.Core.Infrastructure;
using LegacyDTOs = Truebooks.Platform.Contracts.Legacy.DTOs;
using PlatformEnums = Truebooks.Platform.Contracts.Enums;

namespace Truebooks.Platform.Host.Services;

public class EmployeeService : IEmployeeService
{
    private readonly PlatformDbContext _context;

    public EmployeeService(PlatformDbContext context)
    {
        _context = context;
    }

    public async Task<EmployeeDto?> GetByIdAsync(Guid tenantId, Guid employeeId, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            return null;

        var entity = await _context.Employees
            .Include(e => e.Department)
            .FirstOrDefaultAsync(e => e.TenantId == tenantId && e.Id == employeeId, cancellationToken);

        return entity != null ? MapToDto(entity) : null;
    }

    public async Task<IEnumerable<EmployeeDto>> SearchAsync(Guid tenantId, string query, int maxResults = 50, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            return Enumerable.Empty<EmployeeDto>();

        var entities = await _context.Employees
            .Include(e => e.Department)
            .Where(e => e.TenantId == tenantId && e.IsActive &&
                       (e.FirstName.Contains(query) || 
                        e.LastName.Contains(query) ||
                        e.EmployeeCode.Contains(query) ||
                        (e.Email != null && e.Email.Contains(query))))
            .Take(maxResults)
            .ToListAsync(cancellationToken);

        return entities.Select(MapToDto);
    }

    public async Task<IEnumerable<EmployeeDto>> GetAllActiveAsync(Guid tenantId, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            return Enumerable.Empty<EmployeeDto>();

        var entities = await _context.Employees
            .Include(e => e.Department)
            .Where(e => e.TenantId == tenantId && e.IsActive)
            .OrderBy(e => e.FirstName)
            .ThenBy(e => e.LastName)
            .ToListAsync(cancellationToken);

        return entities.Select(MapToDto);
    }

    public async Task<IEnumerable<EmployeeDto>> GetAllAsync(Guid tenantId, bool? isActive = null, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            return Enumerable.Empty<EmployeeDto>();

        var query = _context.Employees
            .Include(e => e.Department)
            .Where(e => e.TenantId == tenantId);

        if (isActive.HasValue)
            query = query.Where(e => e.IsActive == isActive.Value);

        var entities = await query
            .OrderBy(e => e.FirstName)
            .ThenBy(e => e.LastName)
            .ToListAsync(cancellationToken);

        return entities.Select(MapToDto);
    }

    public async Task<EmployeeDto?> GetCurrentAsync(Guid tenantId, Guid userId, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            return null;

        var user = await _context.ApplicationUsers
            .FirstOrDefaultAsync(u => u.Id == userId, cancellationToken);
        
        if (user?.Email == null)
            return null;

        var entity = await _context.Employees
            .Include(e => e.Department)
            .FirstOrDefaultAsync(e => e.TenantId == tenantId && e.Email == user.Email, cancellationToken);

        return entity != null ? MapToDto(entity) : null;
    }

    public async Task<IEnumerable<EmployeeDropdownDto>> GetDropdownAsync(Guid tenantId, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            return Enumerable.Empty<EmployeeDropdownDto>();

        var entities = await _context.Employees
            .Include(e => e.Department)
            .Where(e => e.TenantId == tenantId && e.IsActive)
            .OrderBy(e => e.FirstName)
            .ThenBy(e => e.LastName)
            .Select(e => new EmployeeDropdownDto(
                e.Id,
                e.FullName,
                e.Email,
                e.Department != null ? e.Department.Name : null
            ))
            .ToListAsync(cancellationToken);

        return entities;
    }

    public async Task<EmployeeDto> CreateAsync(Guid tenantId, CreateEmployeeRequest request, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var existingCode = await _context.Employees
            .AnyAsync(e => e.TenantId == tenantId && e.EmployeeCode == request.EmployeeCode, cancellationToken);
        if (existingCode)
            throw new InvalidOperationException($"Employee code '{request.EmployeeCode}' already exists");

        var entity = new LegacyDTOs.Employee
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId,
            EmployeeCode = request.EmployeeCode,
            FirstName = request.FirstName,
            LastName = request.LastName ?? string.Empty,
            Email = request.Email,
            Phone = request.Phone,
            DepartmentId = request.DepartmentId,
            Designation = request.Designation,
            Address = request.Address,
            JoiningDate = request.JoiningDate,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        _context.Employees.Add(entity);
        await _context.SaveChangesAsync(cancellationToken);

        return MapToDto(entity);
    }

    public async Task UpdateAsync(Guid tenantId, Guid employeeId, UpdateEmployeeRequest request, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var entity = await _context.Employees
            .FirstOrDefaultAsync(e => e.TenantId == tenantId && e.Id == employeeId, cancellationToken)
            ?? throw new InvalidOperationException($"Employee {employeeId} not found");

        entity.FirstName = request.FirstName;
        entity.LastName = request.LastName ?? string.Empty;
        entity.Email = request.Email;
        entity.Phone = request.Phone;
        entity.DepartmentId = request.DepartmentId;
        entity.Designation = request.Designation;
        entity.Address = request.Address;
        entity.JoiningDate = request.JoiningDate;
        entity.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task DeactivateAsync(Guid tenantId, Guid employeeId, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var entity = await _context.Employees
            .FirstOrDefaultAsync(e => e.TenantId == tenantId && e.Id == employeeId, cancellationToken)
            ?? throw new InvalidOperationException($"Employee {employeeId} not found");

        entity.IsActive = false;
        entity.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task ActivateAsync(Guid tenantId, Guid employeeId, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var entity = await _context.Employees
            .FirstOrDefaultAsync(e => e.TenantId == tenantId && e.Id == employeeId, cancellationToken)
            ?? throw new InvalidOperationException($"Employee {employeeId} not found");

        entity.IsActive = true;
        entity.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);
    }

    private static EmployeeDto MapToDto(LegacyDTOs.Employee e) => new(
        e.Id,
        e.EmployeeCode,
        e.FirstName,
        e.LastName,
        e.FullName,
        e.Email,
        e.Phone,
        e.DepartmentId,
        e.Department?.Name,
        e.Designation,
        (PlatformEnums.EmployeeType)(int)e.EmployeeType,
        (PlatformEnums.PaymentType)(int)e.PaymentType,
        e.HourlyRate,
        e.MonthlySalary,
        e.IsActive,
        e.JoiningDate
    );
}
