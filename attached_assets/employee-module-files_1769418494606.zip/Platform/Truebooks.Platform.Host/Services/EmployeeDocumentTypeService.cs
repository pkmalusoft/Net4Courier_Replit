using Microsoft.EntityFrameworkCore;
using Truebooks.Platform.Contracts.Services;
using Truebooks.Platform.Core.Infrastructure;
using LegacyDTOs = Truebooks.Platform.Contracts.Legacy.DTOs;

namespace Truebooks.Platform.Host.Services;

public class EmployeeDocumentTypeService : IEmployeeDocumentTypeService
{
    private readonly PlatformDbContext _context;

    public EmployeeDocumentTypeService(PlatformDbContext context)
    {
        _context = context;
    }

    public async Task<List<EmployeeDocumentTypeDto>> GetAllAsync(Guid tenantId, bool activeOnly = true, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var query = _context.EmployeeDocumentTypes.Where(dt => dt.TenantId == tenantId);

        if (activeOnly)
            query = query.Where(dt => dt.IsActive);

        var types = await query
            .OrderBy(dt => dt.DisplayOrder)
            .ThenBy(dt => dt.Name)
            .AsNoTracking()
            .ToListAsync(cancellationToken);

        return types.Select(dt => new EmployeeDocumentTypeDto(
            dt.Id,
            dt.Code,
            dt.Name,
            dt.Description,
            dt.DefaultAlertDays,
            dt.RenewalLeadTimeDays,
            dt.IsRenewalRequired,
            dt.IsMandatory,
            dt.ResponsibleRole,
            dt.DisplayOrder,
            dt.IsActive,
            dt.IsSystemDefined
        )).ToList();
    }

    public async Task<EmployeeDocumentTypeDto?> GetByIdAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var dt = await _context.EmployeeDocumentTypes
            .AsNoTracking()
            .FirstOrDefaultAsync(d => d.Id == id && d.TenantId == tenantId, cancellationToken);

        if (dt == null) return null;

        return new EmployeeDocumentTypeDto(
            dt.Id,
            dt.Code,
            dt.Name,
            dt.Description,
            dt.DefaultAlertDays,
            dt.RenewalLeadTimeDays,
            dt.IsRenewalRequired,
            dt.IsMandatory,
            dt.ResponsibleRole,
            dt.DisplayOrder,
            dt.IsActive,
            dt.IsSystemDefined
        );
    }

    public async Task<EmployeeDocumentTypeDto> CreateAsync(Guid tenantId, CreateEmployeeDocumentTypeRequest request, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var exists = await _context.EmployeeDocumentTypes
            .AnyAsync(dt => dt.TenantId == tenantId && dt.Code == request.Code, cancellationToken);
        if (exists)
            throw new InvalidOperationException($"Document type with code '{request.Code}' already exists");

        var documentType = new LegacyDTOs.EmployeeDocumentType
        {
            Id = Guid.NewGuid(),
            TenantId = tenantId,
            Code = request.Code,
            Name = request.Name,
            Description = request.Description,
            DefaultAlertDays = request.DefaultAlertDays,
            RenewalLeadTimeDays = request.RenewalLeadTimeDays,
            IsRenewalRequired = request.IsRenewalRequired,
            IsMandatory = request.IsMandatory,
            ResponsibleRole = request.ResponsibleRole,
            DisplayOrder = request.DisplayOrder,
            IsActive = true,
            IsSystemDefined = false,
            CreatedAt = DateTime.UtcNow
        };

        _context.EmployeeDocumentTypes.Add(documentType);
        await _context.SaveChangesAsync(cancellationToken);

        return new EmployeeDocumentTypeDto(
            documentType.Id,
            documentType.Code,
            documentType.Name,
            documentType.Description,
            documentType.DefaultAlertDays,
            documentType.RenewalLeadTimeDays,
            documentType.IsRenewalRequired,
            documentType.IsMandatory,
            documentType.ResponsibleRole,
            documentType.DisplayOrder,
            documentType.IsActive,
            documentType.IsSystemDefined
        );
    }

    public async Task UpdateAsync(Guid tenantId, Guid id, UpdateEmployeeDocumentTypeRequest request, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var documentType = await _context.EmployeeDocumentTypes
            .FirstOrDefaultAsync(dt => dt.Id == id && dt.TenantId == tenantId, cancellationToken)
            ?? throw new InvalidOperationException($"Document type {id} not found");

        documentType.Name = request.Name;
        documentType.Description = request.Description;
        documentType.DefaultAlertDays = request.DefaultAlertDays;
        documentType.RenewalLeadTimeDays = request.RenewalLeadTimeDays;
        documentType.IsRenewalRequired = request.IsRenewalRequired;
        documentType.IsMandatory = request.IsMandatory;
        documentType.ResponsibleRole = request.ResponsibleRole;
        documentType.DisplayOrder = request.DisplayOrder;
        documentType.IsActive = request.IsActive;
        documentType.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteAsync(Guid tenantId, Guid id, CancellationToken cancellationToken = default)
    {
        if (tenantId == Guid.Empty)
            throw new ArgumentException("Invalid tenant ID", nameof(tenantId));

        var documentType = await _context.EmployeeDocumentTypes
            .FirstOrDefaultAsync(dt => dt.Id == id && dt.TenantId == tenantId, cancellationToken)
            ?? throw new InvalidOperationException($"Document type {id} not found");

        if (documentType.IsSystemDefined)
            throw new InvalidOperationException("Cannot delete system-defined document type");

        var hasDocuments = await _context.EmployeeDocuments.AnyAsync(d => d.DocumentTypeId == id, cancellationToken);
        if (hasDocuments)
        {
            documentType.IsActive = false;
            documentType.UpdatedAt = DateTime.UtcNow;
        }
        else
        {
            _context.EmployeeDocumentTypes.Remove(documentType);
        }

        await _context.SaveChangesAsync(cancellationToken);
    }
}
